import{readFileSync,writeFileSync}from'node:fs';import{createHash}from'node:crypto';
const{AgentSession}=await import('file:///C:/Users/adyba/pi-upstream-source-5ab7fe7-20261015/packages/coding-agent/src/core/agent-session.ts');
const p=AgentSession.prototype;
globalThis.customAPI={send:p.sendCustomMessage,append:p._appendCustomMessage,flush:p._flushPendingCustomMessages};
const input=readFileSync(process.argv[3]);
await import('data:text/javascript,'+encodeURIComponent(input.toString('utf8')));
const descriptors=['sendCustomMessage','_appendCustomMessage','_flushPendingCustomMessages'].map(name=>{const d=Object.getOwnPropertyDescriptor(p,name),f=d.value;return{name,length:f.length,enumerable:d.enumerable,configurable:d.configurable,writable:d.writable,ownPrototype:Object.hasOwn(f,'prototype'),async:Object.getPrototypeOf(f)===Object.getPrototypeOf(async()=>{})};});
writeFileSync(process.argv[2],JSON.stringify({sourceHead:'5ab7fe74c400097b386662205cd93900695b8a71',actualNode:{version:process.version,executable:process.execPath},inputSha256:createHash('sha256').update(input).digest('hex'),cases:customMessageRows.length,scope:'Actual ordinary custom message methods with caller-owned collaborators and genuine descriptor observations; full factory remains unqualified',descriptors,rows:customMessageRows},null,2));
