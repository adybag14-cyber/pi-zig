param([ValidateSet('compile','runtime')][string]$Phase,[string]$Attempt='first',[int]$Shard=0,[int]$Shards=8)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$true
$taskRoot='C:/Users/adyba/pi-zig-native-session-factory-composition-20261013'
$taskEvidence=$PSScriptRoot
$taskName="root-custom-message-5ab-gc-retry-$Phase-debug-$Attempt-shard$Shard-of$Shards-20261014"
$taskZig='C:/Users/adyba/pi-zig-toolchain-20261003/zig-x86_64-windows-0.16.0/zig.exe'
$taskToolManifest=Join-Path $taskEvidence 'durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
$taskOriginalManifest=Join-Path $taskEvidence 'source5ab-full-manifest-20261015.json'
$taskJobOwner=Join-Path $taskEvidence 'Invoke-OwnedEeSourceJob-20261012.ps1'
if(Test-Path -LiteralPath (Join-Path $taskEvidence "$taskName.json")){throw 'Refuse replay of an owned receipt'}
if($Shards -lt 1 -or $Shards -gt 4096 -or $Shard -lt 0 -or $Shard -ge $Shards){throw 'Invalid shard'}
function Source-Rows {
 @(git -C $taskRoot ls-files --cached --others --exclude-standard|Sort-Object -Unique|Where-Object{Test-Path -LiteralPath (Join-Path $taskRoot $_) -PathType Leaf}|ForEach-Object{[ordered]@{path=$_;sha256=(Get-FileHash -LiteralPath (Join-Path $taskRoot $_)).Hash}})
}
function Drift($rows,[string]$root='') {
 $changed=[Collections.Generic.List[string]]::new()
 foreach($row in $rows){
  $path=if([IO.Path]::IsPathRooted($row.path)){$row.path}else{Join-Path $root $row.path}
  if(!(Test-Path -LiteralPath $path -PathType Leaf)){$changed.Add($path);continue}
  $stream=[IO.File]::OpenRead($path)
  try{$sha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()}
  if($sha -cne $row.sha256){$changed.Add($path)}
 }
 @($changed)
}
$taskBefore=Source-Rows
$taskTools=@((Get-Content -LiteralPath $taskToolManifest -Raw|ConvertFrom-Json).inputs)
$taskOriginal=@(Get-Content -LiteralPath $taskOriginalManifest -Raw|ConvertFrom-Json)
if($taskTools.Count -ne 19546 -or $taskOriginal.Count -ne 1967){throw 'Full frozen inventory count changed'}
if(@(Drift $taskTools).Count -or @(Drift $taskOriginal).Count){throw 'Compiler or actual Original prehash changed'}
$taskToolNames=@(Get-ChildItem -LiteralPath (Split-Path -Parent $taskZig) -File -Recurse|ForEach-Object FullName|Sort-Object)
if(Compare-Object @($taskTools.path|Sort-Object) $taskToolNames){throw 'Compiler file inventory changed'}
if((Get-FileHash -LiteralPath $taskZig).Hash -cne '086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864'){throw 'Pinned Zig changed'}
$taskReferences=@((Get-Content -LiteralPath (Join-Path $taskEvidence 'durable-19cb534-reference-20261012-all-built-runtime.json') -Raw|ConvertFrom-Json)) + @((Get-Content -LiteralPath (Join-Path $taskEvidence 'root-current8a-npm-tools-before.json') -Raw|ConvertFrom-Json))
if($taskReferences.Count -ne 32838 -or @(Drift $taskReferences).Count){throw 'Full dependency/Node reference prehash changed'}
$taskControls=@(@($PSCommandPath,$taskToolManifest,$taskOriginalManifest,$taskJobOwner)|ForEach-Object{[ordered]@{path=$_;sha256=(Get-FileHash -LiteralPath $_).Hash}})
$taskReferences|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $taskEvidence "$taskName-references-before.json") -Encoding utf8NoBOM
$taskBefore|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $taskEvidence "$taskName-source-before.json") -Encoding utf8NoBOM
$taskControls|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $taskEvidence "$taskName-controls-before.json") -Encoding utf8NoBOM
if($Phase -eq 'runtime'){
 $taskCompileName='root-custom-message-5ab-gc-retry-compile-debug-first-shard0-of8-20261014'
 $taskCompile=Get-Content -LiteralPath (Join-Path $taskEvidence "$taskCompileName-posthash.json") -Raw|ConvertFrom-Json
 $taskCompileBefore=@(Get-Content -LiteralPath (Join-Path $taskEvidence "$taskCompileName-source-before.json") -Raw|ConvertFrom-Json)
 if($taskCompile.status -cne 'passed' -or $taskCompile.source_drift -or $taskCompile.compiler_drift -or $taskCompile.original_drift -or $taskCompile.control_drift -or $taskCompile.reference_drift){throw 'Exact compile prerequisite not passed'}
 if(Compare-Object @($taskCompileBefore|ForEach-Object{"$($_.path):$($_.sha256)"}) @($taskBefore|ForEach-Object{"$($_.path):$($_.sha256)"})){throw 'Candidate changed since compile'}
}
[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect()
$taskFree=[long](Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory*1024
$taskOther=@(Get-CimInstance Win32_Process -Filter "Name = 'zig.exe'"|Select-Object ProcessId,ParentProcessId,ExecutablePath,CommandLine,@{n='created_utc';e={([DateTimeOffset]$_.CreationDate).UtcDateTime.ToString('o')}})
$taskRoots=@($taskOther|Where-Object{$_.CommandLine -match '\sbuild\s'})
$taskAdmission=[ordered]@{free_bytes=$taskFree;required_bytes=16GB;max_reservations=4;other_native=$taskOther;source=$taskBefore.Count;compiler=$taskTools.Count;original=$taskOriginal.Count;jobs=1;runtime_seconds=120;host_await_ms=10000;normal_floor=$true;public_activation=$false;observed_utc=[DateTimeOffset]::UtcNow.ToString('o')}
$taskAdmission|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $taskEvidence "$taskName-admission.json") -Encoding utf8NoBOM
if($taskFree -lt 16GB -or $taskRoots.Count -ge 4){throw 'Fresh normal16GiB or max4 admission rejected; no native launch'}
$taskTarget=if($Phase -eq 'compile'){'build-native-sdk-custom-message'}else{'test-native-sdk-custom-message'}
$taskTimeout=if($Phase -eq 'compile'){1320}else{300}
& $taskJobOwner -Name $taskName -Executable $taskZig -WorkingDirectory $taskRoot -Arguments (@('build',$taskTarget)+$(if($Phase -eq 'compile'){@('build-native-sdk-registry-composition')}else{@()})+@('-Doptimize=Debug','-Duse-llvm=true','-j1','--test-timeout','120s','--summary','all')) -TimeoutSeconds $taskTimeout -EnvironmentOverrides @{PI_EXHAUSTIVE_ALLOCATION_SHARD="$Shard";PI_EXHAUSTIVE_ALLOCATION_SHARDS="$Shards"}
$taskAfter=Source-Rows
$taskSourceDrift=@(Compare-Object @($taskBefore|ForEach-Object{"$($_.path):$($_.sha256)"}) @($taskAfter|ForEach-Object{"$($_.path):$($_.sha256)"}))
$taskToolDrift=@(Drift $taskTools)
$taskOriginalDrift=@(Drift $taskOriginal)
$taskControlDrift=@(Drift $taskControls)
$taskReferenceDrift=@(Drift $taskReferences)
$taskToolNamesAfter=@(Get-ChildItem -LiteralPath (Split-Path -Parent $taskZig) -File -Recurse|ForEach-Object FullName|Sort-Object)
$taskToolInventoryDrift=@(Compare-Object $taskToolNames $taskToolNamesAfter)
$taskOwner=Get-Content -LiteralPath (Join-Path $taskEvidence "$taskName.json") -Raw|ConvertFrom-Json
$taskPost=[ordered]@{status=$taskOwner.status;exit_code=$taskOwner.exit_code;source=$taskBefore.Count;source_after=$taskAfter.Count;source_drift=$taskSourceDrift.Count;compiler=$taskTools.Count;compiler_drift=$taskToolDrift.Count;compiler_inventory_drift=$taskToolInventoryDrift.Count;original=$taskOriginal.Count;original_drift=$taskOriginalDrift.Count;control_drift=$taskControlDrift.Count;references=$taskReferences.Count;reference_drift=$taskReferenceDrift.Count;pid=$taskOwner.pid;phase=$Phase;shard=$Shard;shards=$Shards;public_activation=$false;completed_utc=[DateTimeOffset]::UtcNow.ToString('o')}
$taskPost|ConvertTo-Json -Depth 6|Tee-Object -FilePath (Join-Path $taskEvidence "$taskName-posthash.json")
if($taskSourceDrift.Count -or $taskToolDrift.Count -or $taskOriginalDrift.Count -or $taskControlDrift.Count -or $taskReferenceDrift.Count -or $taskToolInventoryDrift.Count){throw 'Native full freeze changed'}
if($taskOwner.status -cne 'passed'){throw "Native terminal $($taskOwner.status)"}
