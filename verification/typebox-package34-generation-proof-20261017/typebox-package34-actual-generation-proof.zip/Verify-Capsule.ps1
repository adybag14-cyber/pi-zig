param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop'
$base=[IO.Path]::GetFullPath($Root)
$m=Get-Content -LiteralPath (Join-Path $base 'capsule-manifest.json') -Raw|ConvertFrom-Json
$expected=@($m.members.member)+@('capsule-manifest.json')
$actual=@(Get-ChildItem -LiteralPath $base -File -Recurse|ForEach-Object{[IO.Path]::GetRelativePath($base,$_.FullName).Replace([char]92,[char]47)})
if(@(Compare-Object $expected $actual -CaseSensitive).Count){throw 'Member inventory differs'}
foreach($r in $m.members){if([IO.Path]::IsPathRooted($r.member)-or$r.member.Split('/')-contains'..'){throw 'Unsafe member'};$p=Join-Path $base $r.member;if((Get-Item -LiteralPath $p).Length-ne$r.bytes-or(Get-FileHash -LiteralPath $p).Hash-cne$r.sha256){throw ('Hash/size mismatch: '+$r.member)}}
$a=Get-Content -LiteralPath (Join-Path $base 'acceptance/independent-acceptance.json') -Raw|ConvertFrom-Json
$s=Get-Content -LiteralPath (Join-Path $base 'acceptance/independent-acceptance-controller-schema.json') -Raw|ConvertFrom-Json
$r=Get-Content -LiteralPath (Join-Path $base 'acceptance/registration-join.json') -Raw|ConvertFrom-Json
if($a.source_head-cne'fe18566011346d210267c2b49bc1eb0bcd5f7b4d'-or$a.selected_callbacks-ne34-or$a.original_metadata_drift-ne0-or@($a.checks|Where-Object passed -NE $true).Count){throw 'Acceptance scope/check failure'}
if((Get-FileHash -LiteralPath (Join-Path $base 'generated/native_typebox_operators_production.zig')).Hash-cne$a.generated_native_sha256-or(Get-FileHash -LiteralPath (Join-Path $base 'generated/lowering-map.json')).Hash-cne$a.map_sha256){throw 'Output/acceptance join differs'}
if($s.generated_map_sha256-cne$a.map_sha256-or$s.original_acceptance_sha256-cne(Get-FileHash -LiteralPath (Join-Path $base 'acceptance/independent-acceptance.json')).Hash-or$r.acceptance_sha256-cne$s.original_acceptance_sha256-or$r.native_sha256-cne$a.generated_native_sha256-or!$r.each_selected_registered-or$r.selected_distinct_callbacks-ne34){throw 'Schema/registration join differs'}
[ordered]@{status='verified_included_bytes_and_acceptance_joins';members=$m.members.Count;native_or_product_execution=$false}|ConvertTo-Json
