//! Owner-thread VM half of raw HTTP transport. Worker storage contains no JS.
//! This internal transport does not claim any provider's request/event codec.
const std = @import("std");
const em = @import("engine.zig");
const js = @import("native_js_values.zig");
const temp = @import("native_models_stream_scope.zig");
const Scope = temp.Scope;
const raw = @import("native_ai_http_worker.zig");
const c = em.c;
pub const maximum_requests = 16;
pub const Options = struct { raw_header_pairs: bool = false };
const Waiter = struct { resolve: c.JSValue, reject: c.JSValue };
const Job = struct {
    id: u64,
    worker: *raw.Worker,
    signal: c.JSValue,
    ready_resolve: c.JSValue,
    ready_reject: c.JSValue,
    ready_settled: bool = false,
    raw_header_pairs: bool = false,
    closed: bool = false,
    waiters: std.ArrayList(Waiter) = .empty,
    fn destroy(self: *Job, engine: *em.Engine) void {
        self.worker.destroy();
        for ([_]c.JSValue{ self.signal, self.ready_resolve, self.ready_reject }) |value| engine.freeValue(value);
        for (self.waiters.items) |waiter| {
            engine.freeValue(waiter.resolve);
            engine.freeValue(waiter.reject);
        }
        self.waiters.deinit(engine.gpa);
        engine.gpa.destroy(self);
    }
};
const State = struct { jobs: std.ArrayList(*Job) = .empty, next_id: u64 = 0, pumping: bool = false };
fn stateFor(engine: *em.Engine) !*State {
    if (engine.native_ai_http_state) |value| return @ptrCast(@alignCast(value));
    const state = try engine.gpa.create(State);
    state.* = .{};
    engine.native_ai_http_state = state;
    engine.native_ai_http_pump = pump;
    engine.native_ai_http_pending = pending;
    engine.native_ai_http_cleanup = deinit;
    return state;
}
pub fn pending(engine: *em.Engine) bool {
    const state: *State = @ptrCast(@alignCast(engine.native_ai_http_state orelse return false));
    return state.jobs.items.len != 0;
}
pub fn deinit(engine: *em.Engine) void {
    const state: *State = @ptrCast(@alignCast(engine.native_ai_http_state orelse return));
    engine.native_ai_http_state = null;
    engine.native_ai_http_pump = null;
    engine.native_ai_http_pending = null;
    engine.native_ai_http_cleanup = null;
    // Cancel every producer, including ones blocked on a full queue, before
    // joining any worker. VM roots and Io outlive every join.
    for (state.jobs.items) |job| job.worker.cancel();
    for (state.jobs.items) |job| job.destroy(engine);
    state.jobs.deinit(engine.gpa);
    engine.gpa.destroy(state);
}
fn find(engine: *em.Engine, id: u64) ?*Job {
    const state: *State = @ptrCast(@alignCast(engine.native_ai_http_state orelse return null));
    for (state.jobs.items) |job| if (job.id == id) return job;
    return null;
}
fn call(scope: *Scope, callee: c.JSValue, value: c.JSValue) !void {
    _ = try scope.call(callee, c.pi_js_undefined(), &.{value});
}
fn result(scope: *Scope, value: c.JSValue, done: bool) !c.JSValue {
    const object = try scope.object();
    try scope.put(object, "value", value);
    try scope.put(object, "done", c.pi_js_bool(scope.engine.context, @intFromBool(done)));
    return object;
}
fn resolved(engine: *em.Engine, value: c.JSValue) !c.JSValue {
    return engine.checked(c.JS_PiPromiseResolve(engine.context, value));
}
const Method = enum(c_int) { next, close, cancel, self };
fn callback(context: ?*c.JSContext, receiver: c.JSValue, _: c_int, _: [*c]c.JSValue, method: c_int, roots: [*c]c.JSValue) callconv(.c) c.JSValue {
    const engine = em.Engine.fromContext(context.?);
    engine.native_exception_diagnostics_suppressed += 1;
    defer engine.native_exception_diagnostics_suppressed -= 1;
    return operation(engine, receiver, @enumFromInt(method), roots[0]) catch |err| @import("native_sdk.zig").fail(engine, err);
}
fn function(scope: *Scope, id: c.JSValue, method: Method) !c.JSValue {
    var roots = [_]c.JSValue{id};
    return scope.own(try scope.engine.checked(c.JS_NewCFunctionData2(scope.engine.context, callback, switch (method) {
        .next => "next",
        .close => "return",
        .cancel => "cancel",
        .self => "asyncIterator",
    }, 0, @intFromEnum(method), roots.len, &roots)));
}
pub fn open(engine: *em.Engine, input: raw.Input, signal: c.JSValue) !c.JSValue {
    return openWithOptions(engine, input, signal, .{});
}
/// Optional raw header pairs are for genuine Response construction. Existing
/// provider ready/onResponse records retain their original property surface.
pub fn openWithOptions(engine: *em.Engine, input: raw.Input, signal: c.JSValue, options: Options) !c.JSValue {
    const io = engine.native_io orelse return error.NativeHttpIoRequired;
    const state = try stateFor(engine);
    if (state.jobs.items.len == maximum_requests) return error.NativeHttpRequestLimit;
    try state.jobs.ensureUnusedCapacity(engine.gpa, 1);
    var scope: Scope = .{ .engine = engine };
    defer scope.deinit();
    state.next_id +%= 1;
    if (state.next_id == 0) state.next_id = 1;
    const id = try scope.own(try engine.checked(c.JS_NewBigUint64(engine.context, state.next_id)));
    var caps: [2]c.JSValue = undefined;
    const ready = try scope.own(try engine.checked(c.JS_NewPromiseCapability(engine.context, &caps)));
    defer for (caps) |value| engine.freeValue(value);
    const output = try scope.object();
    const iterator = try scope.object();
    try scope.put(iterator, "next", try function(&scope, id, .next));
    try scope.put(iterator, "return", try function(&scope, id, .close));
    const symbol = try scope.own(try engine.checked(c.JS_GetAsyncIteratorSymbol(engine.context)));
    const atom = c.JS_ValueToAtom(engine.context, symbol);
    if (atom == c.JS_ATOM_NULL) return js.capture(engine);
    defer c.JS_FreeAtom(engine.context, atom);
    if (c.JS_DefinePropertyValue(engine.context, iterator, atom, c.JS_DupValue(engine.context, try function(&scope, id, .self)), c.JS_PROP_C_W_E) < 0) return js.capture(engine);
    try scope.put(output, "ready", ready);
    try scope.put(output, "events", iterator);
    try scope.put(output, "cancel", try function(&scope, id, .cancel));
    if (!temp.nullish(signal) and scope.truthy(try scope.get(signal, "aborted"))) {
        try call(&scope, caps[1], try failureValue(&scope, error.ProviderRequestAborted));
        return c.JS_DupValue(engine.context, output);
    }
    const job = try engine.gpa.create(Job);
    errdefer engine.gpa.destroy(job);
    // All fallible VM/owner allocations finish before the worker can notify.
    const worker = try raw.Worker.create(io, input, engine, em.Engine.notifyOwner);
    job.* = .{ .id = state.next_id, .worker = worker, .signal = c.JS_DupValue(engine.context, signal), .ready_resolve = c.JS_DupValue(engine.context, caps[0]), .ready_reject = c.JS_DupValue(engine.context, caps[1]), .raw_header_pairs = options.raw_header_pairs };
    state.jobs.appendAssumeCapacity(job);
    return c.JS_DupValue(engine.context, output);
}
fn operation(engine: *em.Engine, receiver: c.JSValue, method: Method, id_value: c.JSValue) !c.JSValue {
    if (method == .self) return c.JS_DupValue(engine.context, receiver);
    var id: u64 = 0;
    if (c.JS_ToBigUint64(engine.context, &id, id_value) < 0) return js.capture(engine);
    var scope: Scope = .{ .engine = engine };
    defer scope.deinit();
    const job = find(engine, id);
    if (method == .close or method == .cancel) {
        if (job) |value| {
            value.closed = true;
            value.worker.cancel();
        }
        return if (method == .close) resolved(engine, try result(&scope, c.pi_js_undefined(), true)) else c.pi_js_undefined();
    }
    if (job == null or job.?.closed) return resolved(engine, try result(&scope, c.pi_js_undefined(), true));
    var caps: [2]c.JSValue = undefined;
    const promise = try engine.checked(c.JS_NewPromiseCapability(engine.context, &caps));
    errdefer engine.freeValue(promise);
    var attached = false;
    errdefer if (!attached) for (caps) |value| engine.freeValue(value);
    try job.?.waiters.append(engine.gpa, .{ .resolve = caps[0], .reject = caps[1] });
    attached = true;
    return promise;
}
fn httpText(scope: *Scope, bytes: []const u8, latin1: bool) !c.JSValue {
    if (!latin1) return scope.text(bytes);
    const units = try scope.engine.gpa.alloc(u16, bytes.len);
    defer scope.engine.gpa.free(units);
    for (bytes, units) |byte, *unit| unit.* = byte;
    return scope.own(try scope.engine.checked(c.JS_NewStringUTF16(scope.engine.context, units.ptr, units.len)));
}
fn headValue(scope: *Scope, head: raw.Head, raw_header_pairs: bool) !c.JSValue {
    const value = try scope.object();
    const headers = try scope.object();
    try scope.put(value, "status", c.JS_NewInt32(scope.engine.context, head.status));
    // Actual Node24 Fetch39 decodes reason bytes as UTF8 (with replacement),
    // while Headers values below use isomorphic Latin1. They are distinct.
    try scope.put(value, "statusText", try scope.text(head.status_text));
    for (head.headers) |entry| {
        var row: Scope = .{ .engine = scope.engine };
        defer row.deinit();
        const name = try scope.engine.gpa.dupe(u8, entry.name);
        defer scope.engine.gpa.free(name);
        for (name) |*byte| byte.* = std.ascii.toLower(byte.*);
        const key = try row.text(name);
        const text = try httpText(&row, entry.value, raw_header_pairs);
        const atom = try js.atom(scope.engine, key);
        defer c.JS_FreeAtom(scope.engine.context, atom);
        var descriptor: c.JSPropertyDescriptor = undefined;
        const present = c.JS_GetOwnProperty(scope.engine.context, &descriptor, headers, atom);
        if (present < 0) return js.capture(scope.engine);
        defer if (present != 0) {
            scope.engine.freeValue(descriptor.value);
            scope.engine.freeValue(descriptor.getter);
            scope.engine.freeValue(descriptor.setter);
        };
        const existing = if (present != 0) descriptor.value else c.pi_js_undefined();
        const combined = if (c.JS_IsUndefined(existing)) text else try row.concat(try row.concat(existing, try row.text(", ")), text);
        if (c.JS_DefinePropertyValue(scope.engine.context, headers, atom, c.JS_DupValue(scope.engine.context, combined), c.JS_PROP_C_W_E) < 0) return js.capture(scope.engine);
    }
    try scope.put(value, "headers", headers);
    if (raw_header_pairs) {
        const pairs = try scope.array();
        for (head.headers, 0..) |entry, index| {
            var row: Scope = .{ .engine = scope.engine };
            defer row.deinit();
            const pair = try row.array();
            try row.index(pair, 0, try httpText(&row, entry.name, true));
            try row.index(pair, 1, try httpText(&row, entry.value, true));
            try scope.index(pairs, @intCast(index), pair);
        }
        try scope.put(value, "rawHeaders", pairs);
    }
    return value;
}
fn frameValue(scope: *Scope, event: raw.Event) !c.JSValue {
    const value = try scope.object();
    switch (event) {
        .frame => |frame| {
            try scope.put(value, "type", try scope.text("frame"));
            try scope.put(value, "event", if (frame.event) |name| try scope.text(name) else c.pi_js_null());
            try scope.put(value, "data", try scope.text(frame.data));
        },
        .error_body => |body| {
            try scope.put(value, "type", try scope.text("error_body"));
            try scope.put(value, "body", try scope.text(body));
        },
        .body => |body| {
            try scope.put(value, "type", try scope.text("body"));
            try scope.put(value, "body", try scope.text(body));
        },
        .bytes => |bytes| {
            try scope.put(value, "type", try scope.text("bytes"));
            const buffer = try scope.own(try scope.engine.checked(c.JS_NewArrayBufferCopy(scope.engine.context, bytes.ptr, bytes.len)));
            var args = [_]c.JSValue{buffer};
            const view = try scope.own(try scope.engine.checked(c.JS_NewTypedArray(scope.engine.context, args.len, &args, c.JS_TYPED_ARRAY_UINT8)));
            try scope.put(value, "data", view);
        },
        else => unreachable,
    }
    return value;
}
fn failureValue(scope: *Scope, failure: anyerror) !c.JSValue {
    // Provider-specific SDK error conversion belongs above this private raw
    // boundary. Guest replacements of Error must not strand an I/O waiter.
    const value = try scope.own(try scope.engine.checked(c.JS_NewObjectProto(scope.engine.context, c.pi_js_null())));
    try scope.put(value, "name", try scope.text("NativeHttpError"));
    try scope.put(value, "message", try scope.text(@errorName(failure)));
    try scope.put(value, "code", try scope.text(@errorName(failure)));
    return value;
}
fn modeledFailureValue(scope: *Scope, failure: @import("native_ai_http_failure.zig").Owned) !c.JSValue {
    // Use the VM intrinsic directly: replacing guest Error must not strand a
    // ready waiter or turn a typed worker failure into a constructor callback.
    const value = try scope.own(try scope.engine.checked(c.JS_NewError(scope.engine.context)));
    try scope.put(value, "name", try scope.text(failure.name));
    const message = try scope.text(failure.message);
    if (c.JS_DefinePropertyValueStr(scope.engine.context, value, "message", c.JS_DupValue(scope.engine.context, message), c.JS_PROP_WRITABLE | c.JS_PROP_CONFIGURABLE) < 0) return js.capture(scope.engine);
    if (failure.try_next_link) |next| try scope.put(value, "tryNextLink", c.pi_js_bool(scope.engine.context, @intFromBool(next)));
    return value;
}
pub fn pump(engine: *em.Engine) !bool {
    const state: *State = @ptrCast(@alignCast(engine.native_ai_http_state orelse return false));
    if (state.pumping) return false;
    state.pumping = true;
    defer state.pumping = false;
    var progressed = false;
    var index: usize = 0;
    while (index < state.jobs.items.len) {
        const job = state.jobs.items[index];
        var scope: Scope = .{ .engine = engine };
        defer scope.deinit();
        const signal_aborted = !temp.nullish(job.signal) and scope.truthy(try scope.get(job.signal, "aborted"));
        if (signal_aborted) job.worker.cancel();
        // Wire publications are I/O turns. Finish the current VM microtask
        // checkpoint before delivering another head, byte or EOF observation.
        // Abort and closed-owner retirement remain control work during jobs.
        if (!job.closed and !signal_aborted and c.JS_IsJobPending(engine.runtime)) {
            index += 1;
            continue;
        }
        while (job.worker.peek()) |kind| {
            if (!job.closed and !signal_aborted and c.JS_IsJobPending(engine.runtime)) break;
            if (kind != .head and job.waiters.items.len == 0 and !job.closed) break;
            const event = job.worker.pop() orelse break;
            defer event.deinit();
            progressed = true;
            if (job.closed) continue;
            if (kind == .head) {
                if (!job.ready_settled) {
                    const head = try headValue(&scope, event.head, job.raw_header_pairs);
                    try call(&scope, job.ready_resolve, head);
                    job.ready_settled = true;
                }
            } else {
                const waiter = job.waiters.orderedRemove(0);
                defer engine.freeValue(waiter.resolve);
                defer engine.freeValue(waiter.reject);
                const value = try frameValue(&scope, event);
                try call(&scope, waiter.resolve, try result(&scope, value, false));
            }
        }
        if (job.worker.finished.load(.acquire) and job.worker.peek() == null and
            (job.closed or signal_aborted or !c.JS_IsJobPending(engine.runtime)))
        {
            const failure: ?anyerror = if (signal_aborted) error.ProviderRequestAborted else job.worker.failure;
            const prepared_failure = if (failure) |err| err == error.NativeHttpPreparedFailure else false;
            const reason = if (prepared_failure and job.worker.modeled_failure != null) try modeledFailureValue(&scope, job.worker.modeled_failure.?) else if (failure) |err| try failureValue(&scope, err) else c.pi_js_undefined();
            if (!job.ready_settled) {
                try call(&scope, job.ready_reject, if (failure != null) reason else try failureValue(&scope, error.NativeHttpNoResponse));
                job.ready_settled = true;
            }
            while (job.waiters.items.len != 0) {
                const waiter = job.waiters.orderedRemove(0);
                defer engine.freeValue(waiter.resolve);
                defer engine.freeValue(waiter.reject);
                try call(&scope, if (failure != null and !job.closed) waiter.reject else waiter.resolve, if (failure != null and !job.closed) reason else try result(&scope, c.pi_js_undefined(), true));
            }
            _ = state.jobs.orderedRemove(index);
            job.destroy(engine);
            progressed = true;
        } else index += 1;
    }
    return progressed;
}

test "native AI HTTP ready bytes and EOF wait for complete Promise checkpoints" {
    const fixture = @import("../ai/http_fixture.zig");
    const server = try fixture.PlanServer.init(std.testing.allocator, std.testing.io, &.{.{ .path = "/checkpoint", .body = "wire" }});
    defer server.deinit();
    const url = try server.url(std.testing.allocator, "/checkpoint");
    defer std.testing.allocator.free(url);
    const engine = try em.Engine.init(std.testing.allocator, .{ .host_await_timeout_ms = 10000 });
    defer engine.deinit();
    engine.native_io = std.testing.io;
    const transport = try open(engine, .{ .url = url, .method = .GET, .payload = "", .headers = &.{}, .timeout_ms = 2000, .framing = .bytes }, c.pi_js_undefined());
    defer engine.freeValue(transport);
    const worker = (try stateFor(engine)).jobs.items[0].worker;
    const deadline = std.Io.Clock.awake.now(std.testing.io).toMilliseconds() + 2000;
    // Observe actual worker completion without publishing a VM response. The
    // ready head, bytes and terminal state are then genuinely available when
    // each Promise chain runs, independent of socket or machine timing.
    while (!worker.finished.load(.acquire)) {
        const epoch = engine.native_owner_signal.observe();
        if (worker.finished.load(.acquire)) break;
        const remaining = deadline - std.Io.Clock.awake.now(std.testing.io).toMilliseconds();
        if (remaining <= 0) return error.HttpCheckpointWorkerDidNotFinish;
        _ = try engine.native_owner_signal.waitAfter(std.testing.io, epoch, .{ .duration = .{ .raw = .fromMilliseconds(@intCast(remaining)), .clock = .awake } });
    }
    var scope: Scope = .{ .engine = engine };
    defer scope.deinit();
    const global = try scope.own(c.JS_GetGlobalObject(engine.context));
    try scope.put(global, "checkpointRequest", transport);
    const module = try engine.evalModule(
        \\const order=[];function chain(label){Promise.resolve().then(()=>order.push(label+'1')).then(()=>order.push(label+'2')).then(()=>order.push(label+'3'))}
        \\chain('head');await checkpointRequest.ready;order.push('ready');chain('byte');const bytes=await checkpointRequest.events.next();if(bytes.done||bytes.value.type!=='bytes')throw Error('missing wire bytes');order.push('bytes');chain('end');if(!(await checkpointRequest.events.next()).done)throw Error('missing EOF');order.push('eof');if(JSON.stringify(order)!==JSON.stringify(['head1','head2','head3','ready','byte1','byte2','byte3','bytes','end1','end2','end3','eof']))throw Error(JSON.stringify(order));export const done=true;
    , "native-http-promise-checkpoint.mjs");
    engine.freeValue(module);
    try server.finish();
}
test "native AI HTTP typed preparation failure skips HTTP and preserves abort precedence" {
    const Prepare = struct {
        fn call(a: std.mem.Allocator, _: @import("native_ai_http_prepare.zig").View, _: []const u8, _: @import("native_ai_http_prepare.zig").Budget) !@import("native_ai_http_prepare.zig").Prepared {
            const headers = try a.alloc(std.http.Header, 0);
            errdefer a.free(headers);
            return .{ .headers = headers, .failure = try @import("native_ai_http_failure.zig").Owned.init(a, "CredentialsProviderError", "fixture credentials failed", false) };
        }
    };
    const signal_api = @import("abort_signal.zig");
    for ([_]bool{ false, true }) |aborted| {
        const engine = try em.Engine.init(std.testing.allocator, .{ .host_await_timeout_ms = 10000 });
        defer engine.deinit();
        engine.native_io = std.testing.io;
        try signal_api.install(engine);
        const signal = try signal_api.create(engine);
        defer engine.freeValue(signal);
        const transport = try open(engine, .{ .url = "http://127.0.0.1:1/no-request-may-be-issued", .payload = "{}", .headers = &.{}, .timeout_ms = 2000, .prepare = Prepare.call }, signal);
        defer engine.freeValue(transport);
        const job = stateFor(engine) catch unreachable;
        const worker = job.jobs.items[0].worker;
        // A real worker terminal transition, without pumping owner promises,
        // makes abort-before-consumption deterministic rather than timed.
        const deadline = std.Io.Clock.awake.now(std.testing.io).toMilliseconds() + 2000;
        while (!worker.finished.load(.acquire)) {
            if (std.Io.Clock.awake.now(std.testing.io).toMilliseconds() >= deadline) return error.PreparedWorkerDidNotFinish;
            try std.testing.io.sleep(.fromMilliseconds(1), .awake);
        }
        if (aborted) try signal_api.abort(engine, signal, c.pi_js_undefined());
        var scope: Scope = .{ .engine = engine };
        defer scope.deinit();
        const global = try scope.own(c.JS_GetGlobalObject(engine.context));
        try scope.put(global, "preparedRequest", transport);
        const module = try engine.evalModule(if (aborted) "const error=await preparedRequest.ready.catch(error=>error);if(error.code!=='ProviderRequestAborted')throw Error('late abort lost to modeled failure');export const done=true;" else "const intrinsic=Error;globalThis.Error=function(){throw 'guest Error must not run'};const error=await preparedRequest.ready.catch(error=>error);globalThis.Error=intrinsic;if(!(error instanceof intrinsic)||error.name!=='CredentialsProviderError'||error.message!=='fixture credentials failed'||error.tryNextLink!==false)throw intrinsic('typed worker error changed');if(Object.getOwnPropertyDescriptor(error,'message').enumerable)throw intrinsic('message descriptor');export const done=true;", if (aborted) "prepared-abort.mjs" else "prepared-typed-error.mjs");
        engine.freeValue(module);
    }
}
