$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$true
$container='C:\Users\adyba\pi-zig'
$packet=Join-Path $container 'evidence/jiti-current-172-terminal-cache-reuse-prepared-20261017'
$run=Join-Path $packet 'root-current-172-package-retry-20261017-163830'
$candidate=Join-Path $container 'worktrees/jiti-current-172-lexical-fix'
$head='6f0214152c1813974af99c9f3d6f7658825ce400'
$checks=[Collections.Generic.List[object]]::new()
function ReadJson([string]$path){Get-Content -Raw -LiteralPath $path|ConvertFrom-Json -Depth 80 -DateKind String}
function Check([string]$name,[bool]$ok,$detail){if(!$ok){throw "Saved-proof audit failed: $name"};$checks.Add([ordered]@{name=$name;passed=$true;detail=$detail})}
function Pin([string]$path){[ordered]@{path=$path;bytes=(Get-Item -LiteralPath $path).Length;sha256=(Get-FileHash -LiteralPath $path).Hash}}
function Rows($items,[string]$key){@($items|ForEach-Object {([string]$_.$key).Replace('\','/')+' '+$_.sha256}|Sort-Object -CaseSensitive)}
$before=ReadJson "$run\before.json";$final=ReadJson "$run\final.json";$result=ReadJson "$run\result.json"
$compile=ReadJson "$run\compile.json";$outer=ReadJson "$run-outer.json";$outerAbsent=ReadJson "$run-outer-absence.json"
$absent=@(ReadJson "$run\owner-absence.json");$grant=ReadJson "$run\root-grant.json";$plan=ReadJson "$run\compile-plan.json"
Check 'exact successful saved result' ($result.status -ceq 'compile_only_passed' -and $result.source_head -ceq $head -and $result.postseal -and $result.artifacts_verified -and $result.native_roots_after -eq 0 -and $result.owner_absence_verified) '6f only; not newer Main'
foreach($field in 'runtime_executed','metadata_executed','node_executed','sentinel_executed'){Check $field ($result.$field -is [bool] -and !$result.$field) $false}
foreach($field in 'runtime_allowed','metadata_allowed','node_allowed','sentinel_allowed'){Check $field ($grant.$field -is [bool] -and !$grant.$field) $false}
Check 'saved authorized exact grant' ($grant.authorized -eq $true -and $grant.candidate_head -ceq $head -and $grant.driver_sha256 -ceq 'EF61538313B5E98F721972759DE3EA4A4838E4CA782DECD56002B218683A3487') (Pin "$run\root-grant.json")
Check 'grant issued bounded and compiler started within grant' (([DateTimeOffset]$grant.expires_utc-[DateTimeOffset]$grant.issued_utc).TotalSeconds -le 300 -and [DateTimeOffset]$compile.created_utc -ge [DateTimeOffset]$grant.issued_utc -and [DateTimeOffset]$compile.created_utc -le [DateTimeOffset]$grant.expires_utc) $null
Check 'terminal compiler' ($compile.pid -eq 29848 -and $compile.status -ceq 'passed' -and $compile.exit_code -eq 0 -and $compile.completed_utc -and $compile.timeout_seconds -eq 1320 -and $compile.working_directory -ceq $candidate) (Pin "$run\compile.json")
Check 'terminal outer' ($outer.pid -eq 29868 -and $outer.status -ceq 'passed' -and $outer.exit_code -eq 0 -and $outer.timeout_seconds -eq 1800 -and $outer.completed_utc) (Pin "$run-outer.json")
Check 'saved compiler exact absence' ($absent.Count -eq 1 -and $absent[0].pid -eq $compile.pid -and $absent[0].recorded_created_utc -ceq $compile.created_utc -and $absent[0].absent -and @($absent[0].current).Count -eq 0) $absent
Check 'saved outer exact absence' ($outerAbsent.pid -eq $outer.pid -and $outerAbsent.fresh_pid_present -eq 0 -and $outerAbsent.owner_sha256 -ceq (Get-FileHash -LiteralPath "$run-outer.json").Hash) $outerAbsent
Check 'warm cache exception is explicit' ($result.cache_mode -ceq 'terminal-owned-154003-unsealed-reuse' -and $result.unsealed_cache_exception -and !$result.fresh_reproducibility_claim -and $grant.reuse_unsealed_compile_caches -and $grant.unsealed_cache_exception -and !$grant.fresh_reproducibility_claim -and !$plan.cache_content_sealed -and $plan.output_prefix_fresh) 'No fresh-cache reproducibility claim'
$expectedArgs=@('build','build-current-main-jiti-sdk-agent-compile-only-artifact','-Doptimize=Debug','-Duse-llvm=true','-Ddiagnostic-tests=false','-j1','--prefix',"$run\out",'--cache-dir',$grant.cache_directory,'--global-cache-dir',$grant.global_cache_directory,'--summary','all')
Check 'only exact compile command' (($compile.arguments -join "`0") -ceq ($expectedArgs -join "`0") -and ($plan.arguments -join "`0") -ceq ($expectedArgs -join "`0")) $expectedArgs
Check 'source head clean and count' ((git -C $candidate rev-parse HEAD).Trim() -ceq $head -and @(git -C $candidate status --porcelain).Count -eq 0 -and @(git -C $candidate ls-files).Count -eq 11473) $head
foreach($g in 'source','compiler','controls'){
 $key=if($g -ceq 'controls'){'path'}else{'relative'};$left=Rows $before.$g $key;$right=Rows $final.$g $key
 Check "$g before/final full inventory" ($left.Count -eq $right.Count -and @(Compare-Object $left $right -CaseSensitive).Count -eq 0 -and @($left|Select-Object -Unique).Count -eq $left.Count) @{count=$left.Count;drift=0}
 $drift=[Collections.Generic.List[string]]::new()
 foreach($row in $final.$g){if((Get-FileHash -LiteralPath $row.path).Hash -cne $row.sha256){$drift.Add($row.path)}}
 Check "$g full readback" ($drift.Count -eq 0) @{count=@($final.$g).Count;drift=$drift.Count}
}
Check 'exact seal counts' (@($before.source).Count -eq 11473 -and @($before.compiler).Count -eq 19546 -and @($before.controls).Count -eq 28) @{source=11473;compiler=19546;controls=28}
$authorityPath=Join-Path $container 'evidence/durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
Check 'original compiler authority pin' ((Get-FileHash -LiteralPath $authorityPath).Hash -ceq 'DEE259F171F720AB2C08E8DD473975E22C876417CD62E4F016C71A7C662794EB') (Pin $authorityPath)
$authority=ReadJson $authorityPath
$oldRows=@($authority.inputs|ForEach-Object {$_.path.Substring($authority.root.Length+1).Replace('\','/')+' '+$_.sha256}|Sort-Object -CaseSensitive)
Check 'all19546 match original compiler' (@($oldRows).Count -eq 19546 -and @(Compare-Object $oldRows (Rows $before.compiler 'relative') -CaseSensitive).Count -eq 0) @{count=19546;drift=0}
Check 'saved nine explicit absences plus current readback' (@($before.expected_absences).Count -eq 9 -and ($before.expected_absences -join "`0") -ceq ($final.expected_absences -join "`0") -and @($final.expected_absences|Where-Object {Test-Path -LiteralPath (Join-Path $candidate $_)}).Count -eq 0) $final.expected_absences
foreach($phase in 'initial-admission','compile-admission'){$a=ReadJson "$run\$phase.json";Check $phase ($a.free_kib -ge 16777216 -and $a.native_roots -eq 0 -and @($a.native_candidates).Count -eq 0 -and $a.census_count -gt 0) $a}
$census=ReadJson "$run\process-census-final.json"
Check 'saved full final census/native zero' (@($census.rows).Count -eq 591 -and @($census.candidates).Count -eq 0 -and @($census.rows|Where-Object ProcessId -EQ $compile.pid).Count -eq 0) @{rows=591;candidates=0;compiler_pid_absent=$true;original=Pin "$run\process-census-final.json"}
$stderr=[IO.File]::ReadAllText("$run\compile.stderr.log")
Check 'raw actual158 build success' ($stderr.StartsWith('Build Summary: 158/158 steps succeeded') -and $stderr.Contains('compile test pi-current-jiti-sdk-agent-compile-only Debug native success 45s') -and !$stderr.Contains('compilation errors')) (Pin "$run\compile.stderr.log")
Check 'compiler stdout empty' ((Get-Item -LiteralPath "$run\compile.stdout.bin").Length -eq 0) $null
$artBefore=ReadJson "$run\artifacts-before.json";$artFinal=ReadJson "$run\artifacts-final.json"
$roles=@('bin/pi-current-jiti-sdk-agent-compile-only.exe','bin/pi-current-jiti-sdk-agent-compile-only.pdb')
Check 'exact two sealed artifact roles' (@($artBefore.rows).Count -eq 2 -and @($artFinal.rows).Count -eq 2 -and ($artFinal.rows.relative -join "`0") -ceq ($roles -join "`0") -and @(Compare-Object (Rows $artBefore.rows 'relative') (Rows $artFinal.rows 'relative') -CaseSensitive).Count -eq 0 -and @($artFinal.path_drift).Count -eq 0 -and @($artFinal.hash_drift).Count -eq 0) $artFinal.rows
foreach($row in $artFinal.rows){Check "artifact readback $($row.relative)" ((Get-FileHash -LiteralPath $row.path).Hash -ceq $row.sha256) (Pin $row.path)}
# Read PE exports directly as inert bytes. No query, image loading or execution.
$b=[IO.File]::ReadAllBytes($artFinal.rows[0].path)
function U16([int]$o){[BitConverter]::ToUInt16($b,$o)}
function U32([int]$o){[BitConverter]::ToUInt32($b,$o)}
$pe=U32 60;$optional=$pe+24;$sections=U16 ($pe+6);$sectionStart=$optional+(U16 ($pe+20))
function Offset([uint32]$rva){for($i=0;$i -lt $sections;$i++){$s=$sectionStart+40*$i;$va=U32 ($s+12);$size=[Math]::Max((U32 ($s+8)),(U32 ($s+16)));if($rva -ge $va -and $rva -lt $va+$size){return [int]((U32 ($s+20))+$rva-$va)}};throw 'PE RVA not mapped'}
function CString([int]$o){$end=$o;while($end -lt $b.Length -and $b[$end] -ne 0){$end++};[Text.Encoding]::ASCII.GetString($b,$o,$end-$o)}
Check 'PE64 artifact signature' ((U16 0) -eq 0x5a4d -and (U32 $pe) -eq 0x4550 -and (U16 $optional) -eq 0x20b) 'Inert byte read only'
$exportRva=U32 ($optional+112);$exports=[Collections.Generic.List[string]]::new()
if($exportRva){$directory=Offset $exportRva;$nameCount=U32 ($directory+24);$names=Offset (U32 ($directory+32));for($i=0;$i -lt $nameCount;$i++){$exports.Add((CString (Offset (U32 ($names+4*$i)))))}}
$source=[IO.File]::ReadAllText((Join-Path $candidate 'src/native_jiti_current_compile_only_root.zig'))
$expected=[Collections.Generic.List[string]]::new();$groupCount=0
foreach($m in [regex]::Matches($source,'(?s)retain\(@import\("[^"]+"\)(?:\.\w+)?,\s*"(?<prefix>[^"]+)",\s*\.\{(?<names>.*?)\}\);')){$groupCount++;foreach($n in [regex]::Matches($m.Groups['names'].Value,'"([^"]+)"')){$expected.Add('current_main_compile_only_'+$m.Groups['prefix'].Value+'_'+$n.Groups[1].Value)}}
foreach($m in [regex]::Matches($source,'\.name = "(current_main_compile_only_[^"]+)"')){if(!$m.Groups[1].Value.Contains('" ++')){$expected.Add($m.Groups[1].Value)}}
# Zig @export symbols are COFF/PDB public functions here, not PE dllexports.
# Validate actual CodeView S_PUB32 records and executable section addresses.
$pdb=[IO.File]::ReadAllBytes($artFinal.rows[1].path)
$symbols=[regex]::Matches([Text.Encoding]::Latin1.GetString($pdb),'current_main_compile_only_[A-Za-z0-9_]+')
$symbolRows=[Collections.Generic.List[object]]::new()
foreach($symbol in $symbols){
 $o=$symbol.Index;$type=[BitConverter]::ToUInt16($pdb,$o-12);$length=[BitConverter]::ToUInt16($pdb,$o-14);$flags=[BitConverter]::ToUInt32($pdb,$o-10);$offset=[BitConverter]::ToUInt32($pdb,$o-6);$segment=[BitConverter]::ToUInt16($pdb,$o-2)
 if($type -ne 0x110e -or ($flags-band 2) -eq 0 -or $length -lt 13+$symbol.Length -or $pdb[$o+$symbol.Length] -ne 0 -or $segment -lt 1 -or $segment -gt $sections){throw 'Invalid actual CodeView public function record'}
 $section=$sectionStart+40*($segment-1);$characteristics=U32 ($section+36);$virtualSize=U32 ($section+8)
 if(($characteristics-band 0x20000000) -eq 0 -or $offset -ge $virtualSize){throw 'Anchor symbol does not address an executable PE section'}
 $symbolRows.Add([ordered]@{name=$symbol.Value;record_type='S_PUB32';function_flag=$true;segment=$segment;section_offset=$offset;rva=(U32 ($section+12))+$offset})
}
$actual=@($symbolRows.name|Sort-Object -CaseSensitive)
Check '172 actual PDB public function anchors' ($groupCount -eq 58 -and $expected.Count -eq 172 -and $actual.Count -eq 172 -and @(Compare-Object @($expected|Sort-Object -CaseSensitive) $actual -CaseSensitive).Count -eq 0) @{groups=58;expected=172;actual_public_function_records=172;missing=0;extra=0;PE_dllexport_anchor_count=@($exports|Where-Object {$_ -clike 'current_main_compile_only_*'}).Count}
# Match linked EXE RSDS GUID+age to actual PDB info stream1 (MSF7).
$debug=Offset (U32 ($optional+112+6*8));$debugSize=U32 ($optional+116+6*8);$rsds=$null
for($i=0;$i -lt $debugSize/28;$i++){if((U32 ($debug+28*$i+12)) -eq 2){$raw=U32 ($debug+28*$i+24);if([Text.Encoding]::ASCII.GetString($b,$raw,4) -ceq 'RSDS'){$rsds=[ordered]@{guid=[Convert]::ToHexString($b[($raw+4)..($raw+19)]);age=U32 ($raw+20)}}}}
if(!$rsds){throw 'Missing EXE RSDS identity'}
$blockSize=[BitConverter]::ToUInt32($pdb,32);$directorySize=[BitConverter]::ToUInt32($pdb,44);$blockMap=[BitConverter]::ToUInt32($pdb,52);$directory=[byte[]]::new($directorySize)
for($i=0;$i -lt [Math]::Ceiling($directorySize/$blockSize);$i++){$block=[BitConverter]::ToUInt32($pdb,$blockMap*$blockSize+4*$i);[Array]::Copy($pdb,$block*$blockSize,$directory,$i*$blockSize,[Math]::Min($blockSize,$directorySize-$i*$blockSize))}
$streamCount=[BitConverter]::ToUInt32($directory,0);$cursor=4+4*$streamCount;$info=$null
for($streamIndex=0;$streamIndex -lt 2;$streamIndex++){$size=[BitConverter]::ToUInt32($directory,4+4*$streamIndex);$blocks=if($size -eq [uint32]::MaxValue){0}else{[int][Math]::Ceiling($size/$blockSize)};if($streamIndex -eq 1){$info=[byte[]]::new($size);for($i=0;$i -lt $blocks;$i++){$block=[BitConverter]::ToUInt32($directory,$cursor+4*$i);[Array]::Copy($pdb,$block*$blockSize,$info,$i*$blockSize,[Math]::Min($blockSize,$size-$i*$blockSize))}};$cursor+=4*$blocks}
$pdbIdentity=[ordered]@{guid=[Convert]::ToHexString($info[12..27]);age=[BitConverter]::ToUInt32($info,8)}
Check 'EXE/PDB linked GUID and age' ($rsds.guid -ceq $pdbIdentity.guid -and $rsds.age -eq $pdbIdentity.age) @{EXE_RSDS=$rsds;PDB_info=$pdbIdentity}
$symbolRows|ConvertTo-Json -Depth 10|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'actual-anchor-symbols.json') -Encoding utf8NoBOM
$pins=@(Get-ChildItem -LiteralPath $run -File|ForEach-Object {Pin $_.FullName})+@(Pin "$run-outer.json";Pin "$run-outer-absence.json";Pin "$run-outer.stdout.bin";Pin "$run-outer.stderr.log")
$receipt=[ordered]@{status='independent_saved_raw_audit_passed';candidate_head=$head;scope='Actual172 compile/link only at6f; not newer Main/default/runtime';checks=$checks;actual_anchor_symbols=Pin (Join-Path $PSScriptRoot 'actual-anchor-symbols.json');artifact_roles=$artFinal.rows;cache_exception='Exact154003 terminal-owned unsealed mutable caches';fresh_cache_reproducibility_claim=$false;runtime_or_metadata_or_query_or_Node_or_sentinel_executed_by_auditor=$false;new_process_CIM_or_admission_probes=$false;Main_written=$false;full_private_census_retained_local=$true;original_file_pins=$pins;auditor_script=Pin $PSCommandPath;completed_utc=[DateTimeOffset]::UtcNow.ToString('o')}
$receipt|ConvertTo-Json -Depth 40|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'raw-audit.json') -Encoding utf8NoBOM
[pscustomobject]@{status=$receipt.status;checks=$checks.Count;head=$head;source=11473;compiler=19546;controls=28;actual_anchor_exports=$actual.Count;receipt_sha256=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'raw-audit.json')).Hash}|ConvertTo-Json
