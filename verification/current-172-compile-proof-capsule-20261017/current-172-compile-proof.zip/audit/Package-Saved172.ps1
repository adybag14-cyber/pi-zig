$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$true
$container='C:\Users\adyba\pi-zig'
$worktree=Join-Path $container 'worktrees/jiti-resolver-dependencies'
$output=Join-Path $worktree 'verification/current-172-compile-proof-capsule-20261017'
$stage=Join-Path $PSScriptRoot 'public-staging'
New-Item -ItemType Directory -Path $output -ErrorAction Stop|Out-Null
New-Item -ItemType Directory -Path $stage -ErrorAction Stop|Out-Null
$entries=[Collections.Generic.List[object]]::new()
$privacy=[Collections.Generic.List[object]]::new()
$negative=[Collections.Generic.List[object]]::new()
function J([string]$p){Get-Content -Raw -LiteralPath $p|ConvertFrom-Json -Depth 80 -DateKind String}
function Pin([string]$p){[ordered]@{path=$p;bytes=(Get-Item -LiteralPath $p).Length;sha256=(Get-FileHash -LiteralPath $p).Hash}}
function Add([string]$source,[string]$name){if($name -match '(^|/)(cache|global-cache|out)(/|$)' -or $name -match '\.(exe|pdb|obj|lib|dll)$'){throw 'Disallowed binary/cache payload'};if($entries.name -ccontains $name){throw 'Duplicate public member'};$entries.Add([ordered]@{name=$name;source=$source;bytes=(Get-Item -LiteralPath $source).Length;sha256=(Get-FileHash -LiteralPath $source).Hash;kind='byte_exact_original'})}
function SaveDerived($value,[string]$name){$path=Join-Path $stage $name;New-Item -ItemType Directory -Path (Split-Path $path) -Force|Out-Null;$value|ConvertTo-Json -Depth 40|Set-Content -LiteralPath $path -Encoding utf8NoBOM;Add $path $name;$entries[$entries.Count-1].kind='derived_explicitly_labeled'}
function UtcMicros($value){$t=[DateTimeOffset]::Parse([string]$value,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind).UtcTicks; $t-($t%10)}
function ProjectCensus([string]$path,$compiler,$outer,[string]$name){
 $doc=J $path;$all=@($doc.rows);if(!$all.Count){throw 'Empty saved census'}
 $selected=[Collections.Generic.Dictionary[int,object]]::new();$rejected=[Collections.Generic.List[object]]::new()
 foreach($owner in @($compiler,$outer)){
  foreach($row in @($all|Where-Object ProcessId -EQ $owner.pid)){
   $match=($row.ExecutablePath -and [StringComparer]::OrdinalIgnoreCase.Equals([string]$row.ExecutablePath,[string]$owner.executable) -and (UtcMicros $row.CreationDate) -eq (UtcMicros $owner.created_utc))
   if(!$match){$rejected.Add([ordered]@{pid=$row.ProcessId;reason='Recorded owner PID reused or incomplete; original full row stays private'});continue}
   $selected[[int]$row.ProcessId]=$row
  }
 }
 do{$changed=$false;foreach($row in $all){$pidKey=[int]$row.ProcessId;$parentKey=[int]$row.ParentProcessId;if(!$selected.ContainsKey($pidKey) -and $selected.ContainsKey($parentKey) -and $row.CreationDate -and $selected[$parentKey].CreationDate -and (UtcMicros $row.CreationDate) -ge (UtcMicros $selected[$parentKey].CreationDate)){$selected[$pidKey]=$row;$changed=$true}}}while($changed)
 foreach($candidate in @($doc.candidates)){
  $candidateId=if($null-ne$candidate.pid){[int]$candidate.pid}else{[int]$candidate.ProcessId}
  foreach($row in @($all|Where-Object ProcessId -EQ $candidateId)){$selected[[int]$row.ProcessId]=$row}
 }
 $projection=@($selected.Values|Sort-Object ProcessId|ForEach-Object {[ordered]@{pid=$_.ProcessId;parent_pid=$_.ParentProcessId;name=$_.Name;executable=$_.ExecutablePath;created_utc=$_.CreationDate;command_line=$_.CommandLine}})
 $record=[ordered]@{kind='DERIVED_PROJECT_ONLY_PROCESS_PROJECTION_NOT_FULL_CENSUS';source=Pin $path;original_rows=$all.Count;selected_rows=$projection.Count;withheld_unrelated_rows=$all.Count-$projection.Count;filter='Exact compiler/outer PID+executable+UTC birth truncated to CIM microseconds; transitive children born at/after parent; saved native candidate IDs. Only relevant identity columns retained.';rows=$projection;saved_native_candidates=@($doc.candidates);rejected_identity_hints=@($rejected);private_original_retained_local_unchanged=$true;privacy='Full unrelated workstation command lines are intentionally excluded. Public projection does not reproduce the private full census.'}
 SaveDerived $record $name;$privacy.Add([ordered]@{member=$name;original=$record.source;original_rows=$record.original_rows;selected_rows=$record.selected_rows;withheld_rows=$record.withheld_unrelated_rows})
}
$runs=@(
 @{packet='jiti-current-172-compile-only-prepared-20261017';id='root-current-172-compile-20261017-152608';expected='failed';errors=8},
 @{packet='jiti-current-172-lexical-retry-prepared-20261017';id='root-current-172-lexical-retry-20261017-154003';expected='failed';errors=1},
 @{packet='jiti-current-172-terminal-cache-reuse-prepared-20261017';id='root-current-172-cache-retry-20261017-162129';expected='failed';errors=9},
 @{packet='jiti-current-172-terminal-cache-reuse-prepared-20261017';id='root-current-172-types-retry-20261017-163533';expected='failed';errors=3},
 @{packet='jiti-current-172-terminal-cache-reuse-prepared-20261017';id='root-current-172-package-retry-20261017-163830';expected='compile_only_passed';errors=0}
)
foreach($spec in $runs){
 $packet=Join-Path $container ('evidence/'+$spec.packet);$run=Join-Path $packet $spec.id;$result=J "$run\result.json";$compile=J "$run\compile.json";$outer=J "$run-outer.json";$before=J "$run\before.json";$final=J "$run\final.json";$absent=@(J "$run\owner-absence.json");$outerAbsent=J "$run-outer-absence.json"
 if($result.status -cne $spec.expected -or !$result.postseal -or $result.native_roots_after -ne 0 -or !$result.owner_absence_verified -or $compile.exit_code -ne $(if($spec.errors){1}else{0}) -or $outer.exit_code -ne $compile.exit_code -or !$absent[0].absent -or $absent[0].pid -ne $compile.pid -or $outerAbsent.fresh_pid_present -ne 0 -or $outerAbsent.pid -ne $outer.pid -or $outerAbsent.owner_sha256 -cne (Get-FileHash -LiteralPath "$run-outer.json").Hash){throw 'Historical terminal/absence proof mismatch'}
 foreach($g in 'source','compiler','controls'){$key=if($g -ceq 'controls'){'path'}else{'relative'};$l=@($before.$g|ForEach-Object {$_.$key+' '+$_.sha256}|Sort-Object -CaseSensitive);$r=@($final.$g|ForEach-Object {$_.$key+' '+$_.sha256}|Sort-Object -CaseSensitive);if(@(Compare-Object $l $r -CaseSensitive).Count){throw 'Historical full seal drift'}}
 $log=[IO.File]::ReadAllText("$run\compile.stderr.log");if($spec.errors -and !$log.Contains("error: $($spec.errors) compilation errors")){throw 'Historical error count mismatch'}
 $negative.Add([ordered]@{run_id=$spec.id;source_head=$result.source_head;status=$result.status;actual_compilation_errors=$spec.errors;compiler_pid=$compile.pid;outer_pid=$outer.pid;exit_code=$compile.exit_code;full_postseal=$true;native_zero=$true;saved_owned_absences=$true;source_count=@($before.source).Count;compiler_count=@($before.compiler).Count;control_count=@($before.controls).Count})
 foreach($file in Get-ChildItem -LiteralPath $run -File){if($file.Name -ceq 'process-census-final.json'){continue};Add $file.FullName ('runs/'+$spec.id+'/'+$file.Name)}
 foreach($suffix in '-outer.json','-outer-absence.json','-outer.stdout.bin','-outer.stderr.log','-grant.json'){$file="$run$suffix";if(Test-Path -LiteralPath $file){Add $file ('runs/'+$spec.id+'/'+$spec.id+$suffix)}}
 ProjectCensus "$run\process-census-final.json" $compile $outer ('privacy/'+$spec.id+'-project-processes.json')
 foreach($file in Get-ChildItem -LiteralPath $packet -File){if($file.Name -like 'root-current-*'){continue};$member='controls/'+$spec.packet+'/'+$file.Name;if($entries.name -cnotcontains $member){Add $file.FullName $member}}
}
# Shared terminal packet control files are admitted once by their exact member path.
foreach($file in 'Audit-Saved172.ps1','raw-audit.json','actual-anchor-symbols.json'){Add (Join-Path $PSScriptRoot $file) ('audit/'+$file)}
Add $PSCommandPath 'audit/Package-Saved172.ps1'
$candidate=Join-Path $container 'worktrees/jiti-current-172-lexical-fix'
foreach($file in 'src/native_jiti_current_compile_only_root.zig','build.zig','tools/ci/native_qualification_ci.ps1'){Add (Join-Path $candidate $file) ('source/'+$file+'.txt')}
Add (Join-Path $container 'evidence/durable-latest89-full-inspect-53ae-tool-prehash-20261011.json') 'authority/compiler19546-original.json'
foreach($commit in 'b34833e8ec18c8721ac44d1aee3684f6ac3ffb43','a7c7ef6b84e99cc018e75b2725c1b1375c41e56a','5d3626fa3fd8ea74070c4ce7cabc7b6feec122be','c2af41ef8c0d5edfd20e8e653f459b68abc7a136','6f0214152c1813974af99c9f3d6f7658825ce400'){
 $path=Join-Path $stage ($commit+'.patch.txt');git -C $candidate show --format=fuller --no-ext-diff --no-renames $commit|Set-Content -LiteralPath $path -Encoding utf8NoBOM;Add $path ('fixes/'+$commit+'.patch.txt')
}
SaveDerived ([ordered]@{scope='6f actual compile/link172 only';runs=$negative;privacy=$privacy;no_full_private_census_payload=$true;no_binary_PDB_or_cache_payload=$true;no_currentMain_or_default_or_runtime_claim=$true}) 'capsule-scope-and-derivation.json'
$manifest=[ordered]@{status='prepared_for_Root_intake_not_published';candidate_head='6f0214152c1813974af99c9f3d6f7658825ce400';scope='172 actual PDB public function anchors compile/link only;158/158 build steps; warmed unsealed154003 cache';runtime_metadata_query_Node_sentinel_execution=$false;newer_Main_qualification=$false;fresh_cache_reproducibility_claim=$false;privacy=$privacy;member_count=$entries.Count;members=@($entries|Sort-Object name|ForEach-Object {[ordered]@{name=$_.name;bytes=$_.bytes;sha256=$_.sha256;kind=$_.kind}})}
$manifest|ConvertTo-Json -Depth 30|Set-Content -LiteralPath (Join-Path $output 'capsule-manifest.json') -Encoding utf8NoBOM
function WriteZip([string]$path){$stream=[IO.File]::Open($path,[IO.FileMode]::CreateNew);try{$zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true);try{foreach($row in @($entries|Sort-Object name)){$entry=$zip.CreateEntry($row.name,[IO.Compression.CompressionLevel]::Optimal);$entry.LastWriteTime=[DateTimeOffset]::new(2000,1,1,0,0,0,[TimeSpan]::Zero);$entry.ExternalAttributes=0;$input=[IO.File]::OpenRead($row.source);try{$dest=$entry.Open();try{$input.CopyTo($dest)}finally{$dest.Dispose()}}finally{$input.Dispose()}}}finally{$zip.Dispose()}}finally{$stream.Dispose()}}
$zipPath=Join-Path $output 'current-172-compile-proof.zip';$second=Join-Path $PSScriptRoot 'deterministic-second.zip';WriteZip $zipPath;WriteZip $second
if((Get-FileHash -LiteralPath $zipPath).Hash -cne (Get-FileHash -LiteralPath $second).Hash){throw 'Deterministic ZIP differs'}
$readback=[Collections.Generic.List[object]]::new();$archive=[IO.Compression.ZipFile]::OpenRead($zipPath)
try{if($archive.Entries.Count -ne $entries.Count){throw 'ZIP count differs'};foreach($entry in $archive.Entries){$expected=@($entries|Where-Object name -CEQ $entry.FullName);if($expected.Count -ne 1){throw 'ZIP path mismatch'};$input=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($input))}finally{$input.Dispose()};if($entry.Length -ne $expected[0].bytes -or $hash -cne $expected[0].sha256){throw 'ZIP decompressed member drift'};$readback.Add([ordered]@{name=$entry.FullName;bytes=$entry.Length;sha256=$hash})}}finally{$archive.Dispose()}
foreach($row in $entries){if((Get-FileHash -LiteralPath $row.source).Hash -cne $row.sha256){throw 'Original drift after ZIP'}}
foreach($record in $privacy){if((Get-FileHash -LiteralPath $record.original.path).Hash -cne $record.original.sha256 -or (Get-Item -LiteralPath $record.original.path).Length -ne $record.original.bytes){throw 'Private original census changed'}}
[ordered]@{status='two_deterministic_stream_archives_and_all_decompressed_members_verified';archive=Pin $zipPath;second_archive=Pin $second;member_count=$readback.Count;members=$readback;all_original_payload_readbacks_zero_drift=$true;all_private_census_originals_unchanged=$true;no_binary_PDB_cache_payload=$true;no_jobs_or_Main_writes=$true}|ConvertTo-Json -Depth 30|Set-Content -LiteralPath (Join-Path $output 'archive-verification.json') -Encoding utf8NoBOM
@'
Actual native172 compile/link proof for candidate6f0214152c1813974af99c9f3d6f7658825ce400 only

The Root-owned build completed158/158 steps, and inert PDB CodeView public-function record inspection and executable-section address checks independently confirmed all172 actual typed body anchors; the EXE/PDB GUID and age agree. Compiler and outer exited0 with saved exact-owner absence; full11473 source/19546 compiler/28 control before-final seals and artifact roles were independently audited. The artifact/sentinel was never run; no query, metadata, Node, SDK runtime/default, or newer Main qualification is claimed.

This used the explicitly authorized terminal-owned154003 mutable UNSEALED cache/global-cache pair. It is not a fresh-cache reproducibility result. EXE/PDB bytes and caches are excluded; their exact saved identities remain in raw receipts. Original negatives8→1→9→3, complete raw seals/owners/grants/logs and compact candidate fix diffs are retained.

Privacy: full original workstation process censuses remain LOCAL unchanged. Public JSON projections are explicitly DERIVED: exact compiler/outer PID+executable+UTC microsecond birth, descendants born after their selected parent, and saved native candidates, with only relevant identity columns. Each derivation gives original SHA256/length/row counts/filter and withheld counts. Public projections do not reproduce private full censuses. Actual source/compiler/control seals and logs remain byte-exact; no claim that a filtered public census alone proves full workstation absence is made.

The external capsule-manifest lists every ZIP member with SHA256/length; archive-verification records two deterministic streaming ZIPs and every decompressed member. Preparation for Root intake only; not published by this lane. No Main/product changes.
'@|Set-Content -LiteralPath (Join-Path $output 'README.md') -Encoding utf8NoBOM
[ordered]@{output=$output;archive=Pin $zipPath;manifest=Pin (Join-Path $output 'capsule-manifest.json');verification=Pin (Join-Path $output 'archive-verification.json');member_count=$entries.Count;privacy=$privacy}|ConvertTo-Json -Depth 20|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'capsule-readiness.json') -Encoding utf8NoBOM
Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'capsule-readiness.json')
