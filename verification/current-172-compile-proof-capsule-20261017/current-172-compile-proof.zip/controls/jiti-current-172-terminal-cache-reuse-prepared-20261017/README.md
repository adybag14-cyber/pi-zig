# Prospective terminal-owned154003 cache exception

SOURCE ONLY. The false template grants no launch. Root must review this exact
driver and issue one fresh exact terminal-cache-reuse grant after its live lane
finishes. Candidate remains the same physical worktree
worktrees/jiti-current-172-lexical-fix, now clean at
5d3626fa3fd8ea74070c4ce7cabc7b6feec122be with11472 tracked files. Only Root's
95704c4 whitespace correction was cherry-picked from the original a7 head.

## Immutable predecessor and explicit cache exception

Original a7c7ef6b84e99cc018e75b2725c1b1375c41e56a and154003 evidence are unchanged.
The previous compiler27688 and outer53836 both have terminal failed/exit1
receipts and recorded absence. Its result has postseal=true, native0 and owned
absence=true. Full before/final source11472, compiler19546 and controls18 rows
match. These saved facts were checked BEFORE advancing the worktree. The
terminal-source-verification.json binding pins all nine original proof files,
including result, compiler, both absences, outer, full before/final, diagnostic
and original compile plan. No fresh CIM/probe or job was run in preparation.

The ONLY allowed mutable cache pair is:

C:\Users\adyba\pi-zig\evidence\jiti-current-172-lexical-retry-prepared-20261017\root-current-172-lexical-retry-20261017-154003\cache

C:\Users\adyba\pi-zig\evidence\jiti-current-172-lexical-retry-prepared-20261017\root-current-172-lexical-retry-20261017-154003\global-cache

cache_mode must be exactly terminal-owned-154003-unsealed-reuse, with explicit
reuse_unsealed_compile_caches=true, unsealed_cache_exception=true and
fresh_reproducibility_claim=false. The grant must name those exact two paths
and the predecessor result/compiler/outer SHA-256. Every other cache mode/path
is rejected. No old out/EXE/PDB is reused. Each new RunId requires a fresh out.

Caches are explicitly UNSEALED state. C/C++ inputs, toolchain, flags and physical
source path remain compatible with this one whitespace correction, but the
compiler remains responsible for validating its cache. Cache contents/counts
may change and are not accepted evidence. Even an accepted compile here is NOT
a fresh-cache reproducibility result. No prior negative is converted into a pass.

The driver rechecks pinned terminal evidence and its saved owner/absence facts,
original working directory and originally recorded cache pair. It enforces exact
allowlist/containment and checks every cache ancestor and nested entry for reparse
points, with no deletion, move, ACL change or broader directory permission. Each
authorized native admission also rejects either original PID if live or reused;
such a case requires independent Root reconciliation, never an unowned stop.

## Unchanged gate and custody

CI607, outer53E5, classifier3413 and compiler authorityDEE19546 stay byte-exact.
Literal current172 compile-only target, Debug LLVM,-j1, compile1320/pipe10,
Root-owned external1800, initial grant max300s, fresh16GiB/native0 admission54s
with successful nonempty bounded3s CIM remain. Runtime, metadata query, Node and
sentinel must be explicitly false. The installed sentinel MUST NEVER RUN.

Before/final seals cover all11472 source files,19546 actual compiler files against
original authority, all controls/grants and original terminal proof references.
Fresh named EXE/PDB roles are inventoried before/final. Independent final attempts
retain full seals, negative artifacts, census and exact compiler-owner absence.
Root must separately retain/verify outer runner and descendants after terminal
return. Canonical owner behavior is unchanged; no new supervisor or kill authority
is added. Synchronous OS hashing/enumeration/CIM may stall; no new hard-wall promise
is invented. All existing negatives and raw before/final files remain immutable.

Target172 peer review is historical source-body retention evidence. This driver's
new cache policy requires its own independent Body source review. Template
authorized=false remains until Root issues a separate grant. No compiler, Node,
native artifact, query, AST/parser/formatter/generator job or Main edit occurred
while preparing it. Full compiler/cache execution and all runtime/default graph,
GPA/GC, application and release claims remain unqualified.
