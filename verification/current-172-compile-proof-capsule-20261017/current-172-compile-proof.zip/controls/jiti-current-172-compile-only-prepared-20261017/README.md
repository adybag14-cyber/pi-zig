# Prospective immutable C3/172 compile-link-only driver

SOURCE ONLY. This packet and its false grant template authorize no execution.
Root must review the final driver/control hashes and issue a fresh exact grant.
Candidate:worktrees/jiti-current-compile-only at
8f69a877a59aeeb0d5b4afff460ced8b82a73b37, clean11462 tracked paths. Its actual
compile-only target has independent Body source review4F290B61...1768B57. The
172 count describes planned typed actual-body anchors, not observed binary
symbols, test metadata or execution results. No product/candidate file is edited.

This is a minimal derivative of closed retry4 driver1CC8A417...DFD4371. The old
packet, all prior negatives and the old C2/83 evidence remain unchanged; none
qualifies this new C3/172 attempt. retry4.prepared-manifest.json is copied
byte-exact as historical provenance. derivation.json records the exact changes.

The only candidate process invocation is pinned Zig0.16 with the literal target
build-current-main-jiti-sdk-agent-compile-only-artifact, Debug LLVM,
diagnostic-tests=false and-j1. Each fresh RunId owns a new out, cache and
global-cache. Every historical cache reuse mode/path is rejected. Caches are
disposable UNSEALED compiler state, not accepted product evidence. No old EXE/PDB
or prefix is reused. Exactly two nonempty fresh installed roles are required:
bin/pi-current-jiti-sdk-agent-compile-only.exe and the matching.pdb. They are
inventoried before/final and NEVER launched. There is no metadata query, runtime,
Node, reference capture, generator or sentinel invocation. All four execution
permissions are explicitly false in the template and required false by the driver.

Canonical inner CI607, classifier3413 and outer53E5 are unchanged bytes. Compiler
timeout1320s, its existing pipe settlement10s, external Root-owned outer1800s.
The exact grant has at most300s initial validity. Two fresh16GiB/zero-native
admission checks use successful nonempty CIM census and the same reviewed pure
classifier; each admission wait is bounded54s and each CIM request specifies3s.
No admission/census, process, compiler, query or artifact was run during preparation.

Before/final seals cover all11462 tracked source paths and exact clean head;
all19546 compiler files compared to immutable original authorityDEE259F1...794EB;
the driver, canonical owner, classifier, outer, compiler authority, packet,
target/driver peer receipts, actual Root grant, container metadata/relocations,
Git and pwsh binaries. C3 C/headers and exact build/anchor pins are checked in
each seal. Nine uncaptured expected JSON paths remain explicitly absent. The
driver independently attempts final seals, fresh/negative artifact inventory,
complete process census and original compiler PID absence even after failure.
Missing receipts, any live/reused original PID, seal drift or residual native
candidate remains negative. Old compiler authority paths are normalized for
comparison only; the immutable historical authority is never rewritten.

Root's future external invocation uses the byte-identical outer-owned-process
helper to own one dedicated pwsh-NoProfile-NonInteractive-File driver, with an
exact grant path/RunId and1800s timeout. Root retains that outer receipt/raws and
must independently establish runner/descendant absence after terminal return.
This packet does not invoke that helper. It adds no process supervisor, kill
authority, permission exception, global hook or environment reset. Existing
canonical owner cleanup/custody remains unchanged. Synchronous OS hashing/CIM
can stall; this preparation does not invent an additional hard-wall guarantee.

Acceptance can mean only a genuine compiler terminal0, the exact EXE/PDB roles,
zero full pre/post drift and verified owner/census absence under the Root-owned
outer. A still-running build, process disappearance or failed postseal is not a
pass. Even an accepted compile/link result does not qualify any runtime test,
Source parity, actual public/default graph or whole application/release behavior.
The failing CURRENT_MAIN_COMPILE_LINK_ONLY_SENTINEL_NEVER_EXECUTE must NEVER RUN.

All files are prospective. Driver review and Root grant remain separate from
source preparation. No Zig/Node/native/AST/parser/formatter/generator job, no
current Main edit and no runtime qualification occurs here.
