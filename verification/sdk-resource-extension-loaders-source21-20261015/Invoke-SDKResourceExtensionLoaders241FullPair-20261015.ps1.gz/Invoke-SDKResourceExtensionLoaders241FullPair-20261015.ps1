param([Parameter(Mandatory)][string]$SlotGrant,[string]$Attempt='slot5-first')
$ErrorActionPreference='Stop'
$taskPrivate='C:/Users/adyba/pi-zig-sdk-resource-extensions-20261015'
$taskEvidence='C:/Users/adyba/pi-zig-update-evidence-20261003'
$taskGit='C:/Program Files/Git/cmd/git.exe'
$taskHead='24178131955e3e1d61e1e443438568a7d360ff45'
$taskOwner=Join-Path $taskPrivate 'tools/oracles/Invoke-SDKResourceExtensionLoaders5abSource.ps1'
$taskName="sdk-resource-extension-loaders-5ab-source-$Attempt-20261015"
$taskReceipt=Join-Path $taskEvidence "$taskName-full-pair.json"
if(Test-Path -LiteralPath $taskReceipt){throw 'A unique full-pair attempt is required'}
if((& $taskGit -C $taskPrivate rev-parse HEAD).Trim() -cne $taskHead){throw 'Sealed candidate head changed'}
if(@(& $taskGit -C $taskPrivate status --porcelain=v1).Count){throw 'Sealed candidate is dirty'}
$taskPaths=@(& $taskGit -C $taskPrivate ls-files | ForEach-Object{Join-Path $taskPrivate $_})
$taskCandidate=@($taskPaths|ForEach-Object{@{path=$_;sha256=(Get-FileHash -LiteralPath $_).Hash}})
$taskManifest=Join-Path $taskEvidence "$taskName-candidate-before.json"
$taskCandidate|ConvertTo-Json -Depth 4|Set-Content -LiteralPath $taskManifest -Encoding utf8NoBOM
$taskControlPaths=@($PSCommandPath,$taskManifest,$taskGit,$taskOwner)
$taskControls=@($taskControlPaths|ForEach-Object{@{path=$_;sha256=(Get-FileHash -LiteralPath $_).Hash}})
$taskControls|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $taskEvidence "$taskName-outer-controls-before.json") -Encoding utf8NoBOM
$taskStart=[DateTimeOffset]::UtcNow.ToString('o')
$taskFailure=$null
try{& $taskOwner -SlotGrant $SlotGrant -Attempt $Attempt;if($LASTEXITCODE -ne 0){throw "Strict Source owner exit $LASTEXITCODE"}}catch{$taskFailure=$_.Exception.Message}
$taskCandidateDrift=@($taskCandidate|Where-Object{!(Test-Path -LiteralPath $_.path -PathType Leaf) -or (Get-FileHash -LiteralPath $_.path).Hash -cne $_.sha256}|ForEach-Object path)
$taskControlsDrift=@($taskControls|Where-Object{!(Test-Path -LiteralPath $_.path -PathType Leaf) -or (Get-FileHash -LiteralPath $_.path).Hash -cne $_.sha256}|ForEach-Object path)
$taskAfterPaths=@(& $taskGit -C $taskPrivate ls-files|ForEach-Object{Join-Path $taskPrivate $_})
$taskInventoryDrift=@(Compare-Object $taskPaths $taskAfterPaths)
$taskHeadAfter=(& $taskGit -C $taskPrivate rev-parse HEAD).Trim()
$taskDirty=@(& $taskGit -C $taskPrivate status --porcelain=v1)
$taskStatus=if($taskFailure -or $taskCandidateDrift.Count -or $taskControlsDrift.Count -or $taskInventoryDrift.Count -or $taskHeadAfter -cne $taskHead -or $taskDirty.Count){'failed'}else{'passed'}
@{status=$taskStatus;tested_candidate_head=$taskHead;candidate_files=$taskCandidate.Count;candidate_manifest_sha256=(Get-FileHash -LiteralPath $taskManifest).Hash;candidate_drift=$taskCandidateDrift;candidate_inventory_drift=$taskInventoryDrift;outer_controls=$taskControls;outer_control_drift=$taskControlsDrift;head_after=$taskHeadAfter;dirty_after=$taskDirty;owner_failure=$taskFailure;root_slot_grant=$SlotGrant;started_utc=$taskStart;completed_utc=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $taskReceipt -Encoding utf8NoBOM
if($taskStatus -cne 'passed'){throw "Source full-pair failure: $taskFailure"}
Write-Output ('SOURCE_EXTENSION_LOADER_FULL_PAIR_PASS='+$taskCandidate.Count)
