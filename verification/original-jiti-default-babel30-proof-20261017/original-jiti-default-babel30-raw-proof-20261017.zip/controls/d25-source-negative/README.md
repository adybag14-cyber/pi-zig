# Prospective original jiti2.7 default Babel collector

PREPARED SOURCE ONLY. The grant is false. No Node, compiler, AST/parser, native,
generator or capture has run; no collected baseline, expected, observed or result
artifact exists. This packet requires independent source review and a separate
Root serial/resource/ownership grant before execution.

The subject is the exact unchanged source-caller.mjs A3C1C5FC...A4B178 and its
original inputs.json 4BD4707F...50B8FE at clean9f4fc947 (all10965 tracked files).
It calls the actual official dist/babel.cjs and lib/jiti.cjs, with default Babel
and no custom opts.transform, observing12 admitted programs and18 frontier
programs in original order. It captures actual raw generated code/errors, public
evalModule completion and Function.prototype.toString text. The nine corrective
target and seven corrective read inputs are explicitly excluded. Candidate Zig
code, default selection and native control specifications are never executed.

Run-OriginalBabel30.ps1 is an unexecuted source adaptation of the closed C8
controller, not a replacement owner. It retains byte-original CI607 owner
607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285 and
historical96BE unchanged as a control. Root must use a dedicated PowerShell
-File runner. Before child launch the runner clears process-local Node/debug/
coverage/config keys, BABEL_ENV/NODE_ENV, owned dummy keys and inherited JITI_*
keys; their values are never logged. The shared parent shell is not modified.

The builtin-only bootstrap reads the exact uppercase32-byte nonce plus newline
from stdin and checks Node24.14.0 before importing the original caller. CI607
writes that65-byte token only after obtaining its retained native handle and
fresh live PID/executable/UTC/full-command identity. Bootstrap sets the public
owned nonce environment key and exact original caller argv contract; it records
Node version/execPath/argv/execArgv with sourceImported:false before import.
No compiler implementation, monkeypatched SDK, identity transform or package
manager is run. Only the pinned self-contained jiti package, Node builtins and
owned input fixtures are intended executable reference dependencies.

Node.exe must be SHA63C259C81E5D472B5F11C8D506070130CB04A1ECF84B80377A34ED6EC9048088.
The original complete Node1774 and1838 inventories are checked at before,
before-node, after-node and final. All four seals also cover the complete clean
tracked source/fresh tree, full16-file official jiti package inventory and all
controls/Root grant. The complete source must equal its actual fresh tree; the
original package must have no additions/omissions or byte drift. The borrowed
package control inventory is read-only; deleted runtime restoration is not
claimed and no recovered runtime/dependency tree is used.

Admission retains fresh16GiB free RAM, native-zero and bounded54-second RAM
readmission/history from closed C8. The budget records reserve2GiB, V8 heap256MiB,
Node deadline60s and pipe settlement10s. It does not claim an OS-enforced2GiB
process working-set limit. Root must separately supply the exclusive serial
lease and durable outer owner. Unknown native/process metadata blocks admission;
there are no process-name kills or unrelated service/WSL operations.

Terminal validation checks zero exit, empty stderr, real Node identity/version,
all30 input IDs/profiles, raw observation schema and strings for observed code
and function text. It never invents or normalizes returned/thrown/code values.
Raw stdout/stderr remain retained on every negative. Copying stdout unchanged to
original-output.json requires successful final source/package/Node/control
seals and independent owner/descendant/global-native absence. Output is capped
at8MiB for acceptance after capture, matching CI607's existing raw pipe owner;
this is not a new streaming memory cap. No expected golden is created.

Root must author a fresh issued/unexpired release using status
root_reviewed_jiti_default_babel_original30_release, exact reviewed control hashes,
a fresh unique contained non-reparse proof root and a new public stdin nonce.
The false grant template cannot launch work. This packet has not been syntax
parsed or executed and does not establish Node/default-backend/native parity.
Any controller-review correction must be resealed before a possible grant.
