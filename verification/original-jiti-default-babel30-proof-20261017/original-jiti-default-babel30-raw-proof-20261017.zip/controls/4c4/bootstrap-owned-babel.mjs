// PREPARED ONLY: builtin-only CI607 owned-start fence. No candidate import.
import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
if(process.argv.length!==7||!/^[A-F0-9]{64}$/.test(process.argv[2]))throw Error('Exact original Babel bootstrap arguments required');
const nonce=process.argv[2];
if(readFileSync(0,'utf8')!==nonce+'\n')throw Error('Owned original Babel stdin fence mismatch');
if(process.version!=='v24.14.0')throw Error('Pinned original Node24.14.0 required');
const [caller,backend,publicJiti,fixtures]=process.argv.slice(3);
writeFileSync(join(fixtures,'node-start.json'),JSON.stringify({version:process.version,execPath:process.execPath,argv:process.argv,execArgv:process.execArgv,sourceImported:false})+'\n');
process.env.PI_JITI_DEFAULT_CAPTURE_OWNED=nonce;
process.argv=[process.execPath,caller,backend,publicJiti,fixtures,nonce];
await import(pathToFileURL(caller).href);
