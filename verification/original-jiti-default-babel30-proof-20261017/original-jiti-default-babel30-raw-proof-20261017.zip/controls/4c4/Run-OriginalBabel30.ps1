param([Parameter(Mandatory)][string]$RootGrant)
$ErrorActionPreference='Stop'
$taskContainer=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$taskResolver=Join-Path $taskContainer 'main/tools/workspace/Resolve-PiZigWorkspace.ps1'
$taskWorkspace=& $taskResolver -StartPath $PSScriptRoot
function Contained([string]$Path,[string]$Under){
 if(!$Path){throw 'Explicit contained path required'};$resolved=[IO.Path]::GetFullPath($Path)
 if(!$resolved.StartsWith([IO.Path]::GetFullPath($Under)+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Path escapes its explicit root'}
 $ancestor=[IO.DirectoryInfo]::new($resolved);while($ancestor){if($ancestor.Exists-and($ancestor.Attributes-band[IO.FileAttributes]::ReparsePoint)){throw 'Reparse ancestor rejected'};if($ancestor.FullName-eq$taskContainer){break};$ancestor=$ancestor.Parent}
 if((Test-Path -LiteralPath $resolved)-and((Get-Item -LiteralPath $resolved -Force).Attributes-band[IO.FileAttributes]::ReparsePoint)){throw 'Reparse leaf rejected'};return $resolved
}
$RootGrant=Contained $RootGrant $taskWorkspace.evidence
$taskGrant=Get-Content -LiteralPath $RootGrant -Raw|ConvertFrom-Json
$taskRoot=Contained ([string]$taskGrant.candidate_root) $taskWorkspace.worktrees
$taskProof=Contained ([string]$taskGrant.receipt_directory) $taskWorkspace.evidence
$taskHead='9f4fc947e93eb9230eecd3f79838e69db3308976';$taskSourceCount=10965
if($taskGrant.authorized-isnot[bool]-or!$taskGrant.authorized-or$taskGrant.status-cne'root_reviewed_jiti_default_babel_original30_release'-or
 $taskGrant.candidate_head-cne$taskHead-or$taskRoot-cne(Join-Path $taskWorkspace.worktrees 'jiti-default-transform')-or
 !$taskGrant.grant_id-or$taskGrant.runtime_restoration_claim-isnot[bool]-or$taskGrant.runtime_restoration_claim-or
 $taskGrant.candidate_implementation_executed-isnot[bool]-or$taskGrant.candidate_implementation_executed){throw 'Exact authorized Root original default Babel30 release required'}
if([string]$taskGrant.stdin_nonce-cnotmatch'^[A-F0-9]{64}$'){throw 'Exact 32-byte public owned-start nonce required'}
if(Test-Path -LiteralPath $taskProof){throw 'Fresh unique proof directory required'}
function CheckRelease {
 $now=[DateTimeOffset]::UtcNow
 if(!$taskGrant.issued_utc-or!$taskGrant.expires_utc-or([DateTimeOffset]$taskGrant.issued_utc)-gt$now-or([DateTimeOffset]$taskGrant.expires_utc)-le$now){throw 'Current issued/unexpired Root release required'}
}
CheckRelease
# These changes apply only to an explicitly dedicated -File runner, never a
# caller's shared PowerShell session or ProcessStartInfo.Environment dictionary.
$taskRunnerArguments=@([Environment]::GetCommandLineArgs());$taskFileIndex=-1
for($i=0;$i-lt$taskRunnerArguments.Count;$i++){if($taskRunnerArguments[$i]-ieq'-File'){$taskFileIndex=$i;break}}
if($taskFileIndex-lt0-or$taskFileIndex+1-ge$taskRunnerArguments.Count-or
 !([StringComparer]::OrdinalIgnoreCase.Equals([IO.Path]::GetFullPath($taskRunnerArguments[$taskFileIndex+1]),$PSCommandPath))){throw 'Dedicated PowerShell -File runner required; refuse shared-session environment changes'}
$taskResetKeys=@('NODE_OPTIONS','NODE_PATH','NODE_COMPILE_CACHE','NODE_DEBUG','NODE_DEBUG_NATIVE','NODE_V8_COVERAGE','NODE_REDIRECT_WARNINGS','NODE_EXTRA_CA_CERTS','NODE_ICU_DATA','OPENSSL_CONF','SSL_CERT_FILE','SSL_CERT_DIR','BABEL_ENV','NODE_ENV','PI_JITI_DEFAULT_CAPTURE_OWNED','PI_JITI_DEFAULT_OWNED_VALUE')
$taskResetKeys+=@([Environment]::GetEnvironmentVariables([EnvironmentVariableTarget]::Process).Keys|Where-Object{[string]$_-like'JITI_*'-or[string]$_-like'BABEL_*'});foreach($key in $taskResetKeys){[Environment]::SetEnvironmentVariable($key,[System.Management.Automation.Language.NullString]::Value,[EnvironmentVariableTarget]::Process)}
if(@($taskResetKeys|Where-Object{$null-ne[Environment]::GetEnvironmentVariable($_,[EnvironmentVariableTarget]::Process)}).Count){throw 'Dedicated child environment reset failed'}
$taskOwner=Join-Path $taskWorkspace.main 'tools/ci/native_qualification_ci.ps1'
$taskHistoricalOwner=Join-Path $taskWorkspace.evidence 'owners/run-owned-source-node.ps1'
$taskNodeRoot='C:\Program Files\nodejs';$taskNode=Join-Path $taskNodeRoot 'node.exe'
$taskOriginal1774=Join-Path $taskWorkspace.evidence 'source4954-node-tools-before-20261015.json'
$taskOriginal1838=Join-Path $taskWorkspace.evidence 'typebox-heap-scope-args-static-second49d-20261016-frozen.json'
$taskLayout=Join-Path $taskContainer '.pi-zig-workspace.json'
$taskBootstrap=Join-Path $PSScriptRoot 'bootstrap-owned-babel.mjs'
$taskCaller=Join-Path $taskRoot 'verification/jiti-default-transform-sourceonly-20261017/source-caller.mjs'
$taskInputs=Join-Path $taskRoot 'verification/jiti-default-transform-sourceonly-20261017/inputs.json'
$taskPackage=Contained (Join-Path $taskWorkspace.worktrees 'extension-import/verification/node-module-constructor-sourceonly-20261016/authority/jiti-package') $taskWorkspace.worktrees
$taskPackageInventory=Join-Path $PSScriptRoot 'jiti-package-inventory.json'
$taskBackend=Join-Path $taskPackage 'dist/babel.cjs';$taskPublicJiti=Join-Path $taskPackage 'lib/jiti.cjs'
$taskFixtures=Contained (Join-Path $taskProof 'fixtures') $taskProof
$taskAuthority=@(
 @{path=$PSCommandPath;sha256=$taskGrant.driver_sha256},@{path=$taskResolver;sha256=$taskGrant.workspace_resolver_sha256},
 @{path=$taskLayout;sha256=$taskGrant.workspace_layout_sha256},@{path=$taskWorkspace.path_relocations;sha256=$taskGrant.path_relocations_sha256},
 @{path=$taskOwner;sha256='607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285'},
 @{path=$taskHistoricalOwner;sha256='96BEA0CF8E17535C322EE4F36C0115387386F16988BC2B98465BD070A504F5E5'},
 @{path=$taskNode;sha256='63C259C81E5D472B5F11C8D506070130CB04A1ECF84B80377A34ED6EC9048088'},
 @{path=$taskOriginal1774;sha256='F834312AAC6AC8D79EF4B49CCB806096D80E92FCA403CC650A05E901D4C280DD'},
 @{path=$taskOriginal1838;sha256='35F1F2B0F12BF79C06B47AE2BA8C485EF10A7714BE3F129772E3BA1BBB97B927'},
 @{path=$taskBootstrap;sha256='613A022847B2D7A6AFD521DE40D4DB1545CD835867E4258BA607FFCB84AB384C'},
 @{path=$taskCaller;sha256='A3C1C5FC70E78A32C4362841F81732077CF82128982697A96BCAD820ADA4B178'},
 @{path=$taskInputs;sha256='4BD4707F127820EE482F7E9A808BCE5AAAA05E0DA3C5261CC44BF4A99E50B8FE'},
 @{path=$taskPackageInventory;sha256='B503B49C6B83F7BABE31B9201EC90390052CA384420D4FAC729593A24771E259'},
 @{path=(Join-Path $taskRoot 'verification/jiti-default-transform-sourceonly-20261017/prepared.json');sha256='5139CD5DC4FD3CDBFAD39173ED58B9C2FAB5C7DDCF9FAA933AB5E144E5E550BB'},
 @{path=(Join-Path $taskRoot 'verification/jiti-default-transform-targets-sourceonly-20261017/prepared.json');sha256='136AE83439B1469D22B3E0F1179349720CF05D5E187E9F93D02D310AC0446C3C'}
)
foreach($row in $taskAuthority){if(!$row.sha256-or(Get-FileHash -LiteralPath $row.path -Algorithm SHA256).Hash-cne$row.sha256){throw "Reviewed original Babel authority differs: $($row.path)"}}
. $taskOwner
$taskRows1774=@(Get-Content -LiteralPath $taskOriginal1774 -Raw|ConvertFrom-Json)
$taskRows1838=@((Get-Content -LiteralPath $taskOriginal1838 -Raw|ConvertFrom-Json).node_complete)
if($taskRows1774.Count-ne1774-or$taskRows1838.Count-ne1838){throw 'Original complete Node1774/1838 authorities required'}
function NodeKeys($Rows){@(foreach($row in $Rows){$path=[IO.Path]::GetFullPath([string]$row.path);if(!$path.StartsWith($taskNodeRoot+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Node authority escapes explicitly unmoved installation'};[IO.Path]::GetRelativePath($taskNodeRoot,$path).Replace('\','/')+' '+$row.sha256})}
$taskExpected1774=NodeKeys $taskRows1774;$taskExpected1838=NodeKeys $taskRows1838
$taskPackageRows=@((Get-Content -LiteralPath $taskPackageInventory -Raw|ConvertFrom-Json).rows)
if($taskPackageRows.Count-ne16){throw 'Complete original16 jiti package controls required'}
$taskExpectedPackage=@($taskPackageRows|ForEach-Object{$_.relative+' '+$_.sha256})
$taskControlPaths=@($RootGrant)+@($taskAuthority|ForEach-Object path)
[void](New-Item -ItemType Directory -Path $taskProof)
[void](New-Item -ItemType Directory -Path $taskFixtures)
function Save($Value,[string]$Name){
 $target=Contained (Join-Path $taskProof $Name) $taskProof
 $temp=$target+'.writing';if(Test-Path -LiteralPath $temp){throw 'Unexpected proof temporary file exists'}
 [IO.File]::WriteAllText($temp,(ConvertTo-Json -InputObject $Value -Depth 16)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
 [IO.File]::Move($temp,$target,$true)
}
$taskAdmissions=[Collections.Generic.List[object]]::new()
function Processes {$rows=@(Get-CimInstance Win32_Process -OperationTimeoutSec 5 -ErrorAction Stop);if(!$rows.Count){throw 'Process census unavailable'};return $rows}
function Native($Rows){@(foreach($row in $Rows){
 if(!$row.Name-and!$row.ExecutablePath-and!$row.CommandLine){throw "Unidentified process metadata blocks census: $($row.ProcessId)"}
 $known=$row.Name-in@('zig','zig.exe','build','build.exe','test','test.exe')
 $pathHint=$row.ExecutablePath-and([IO.Path]::GetFileName($row.ExecutablePath)-in@('zig','zig.exe','build','build.exe','test','test.exe')-or
  $row.ExecutablePath-match'[\\/](?:\.zig-cache|zig-out)[\\/]'-or$row.ExecutablePath.StartsWith($taskProof+'\',[StringComparison]::OrdinalIgnoreCase))
 $missingPathHint=!$row.ExecutablePath-and$row.CommandLine-and($row.CommandLine-match'[\\/](?:\.zig-cache|zig-out)[\\/]'-or
  $row.CommandLine.IndexOf($taskProof+'\',[StringComparison]::OrdinalIgnoreCase)-ge0)
 if($known-or$pathHint-or$missingPathHint){$row}
})}
function Admission([string]$Phase){
 $watch=[Diagnostics.Stopwatch]::StartNew();$probes=[Collections.Generic.List[object]]::new()
 try{do{
  CheckRelease;$os=Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 5 -ErrorAction Stop;if($null-eq$os.FreePhysicalMemory){throw 'Memory census unavailable'}
  $roots=@(Native (Processes));$probe=[ordered]@{phase=$Phase;free_kib=[uint64]$os.FreePhysicalMemory;minimum_kib=16777216;native=@($roots|Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,CreationDate);elapsed_seconds=$watch.Elapsed.TotalSeconds;utc=[DateTimeOffset]::UtcNow.ToString('o')}
  $probes.Add($probe);$taskAdmissions.Add($probe);if($roots.Count){throw 'Other/unknown native roots prevent serial capture admission'}
  if($watch.Elapsed.TotalSeconds-ge54){throw '54-second admission expired before acceptance'}
  if($os.FreePhysicalMemory-ge16777216){Save @{status='admitted';phase=$Phase;probes=$probes.ToArray();accepted_elapsed_seconds=$watch.Elapsed.TotalSeconds} "$Phase-admission.json";return}
  $remaining=54000-$watch.ElapsedMilliseconds;if($remaining-le0){throw 'Admission expired'};Start-Sleep -Milliseconds ([int][Math]::Min(1000,$remaining))
 }while($true)}catch{Save @{status='denied';phase=$Phase;error=[string]$_;probes=$probes.ToArray()} "$Phase-admission.json";throw}
}
function Seal([string]$Name){
 $seal=[ordered]@{head=$null;clean=$false;source=@();tree=@();node1838=@();node1774=@();jiti_package=@();controls=@();errors=@()}
 try{$seal.head=([string](git --no-optional-locks -C $taskRoot rev-parse HEAD)).Trim();if($LASTEXITCODE-ne0){throw 'Head unavailable'};$seal.clean=@(git --no-optional-locks -C $taskRoot status --porcelain).Count-eq0;if($LASTEXITCODE-ne0){throw 'Clean state unavailable'}}catch{$seal.errors+=,[string]$_}
 foreach($group in @('source','tree','node1838','node1774','jiti_package','controls')){try{switch($group){
  source{$paths=@(git --no-optional-locks -C $taskRoot ls-files);if($LASTEXITCODE-ne0){throw 'Tracked inventory unavailable'};$seal.source=@(Get-CiRows $taskRoot $paths)}
  tree{$seal.tree=@((Get-CiInventory $taskRoot tree @('.git','.zig-cache','zig-out')).rows)}
  node1838{$seal.node1838=@((Get-CiInventory $taskNodeRoot).rows|ForEach-Object{$_.relative+' '+$_.sha256})}
  node1774{$npm=Get-CiInventory (Join-Path $taskNodeRoot 'node_modules/npm');$seal.node1774=@('node.exe '+(Get-FileHash -LiteralPath $taskNode -Algorithm SHA256).Hash)+@($npm.rows|ForEach-Object{'node_modules/npm/'+$_.relative+' '+$_.sha256})}
  jiti_package{$seal.jiti_package=@((Get-CiInventory $taskPackage).rows|ForEach-Object{$_.relative+' '+$_.sha256})}
  controls{$seal.controls=@(foreach($path in $taskControlPaths){[ordered]@{path=$path;sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}})}
 }}catch{$seal.errors+=,[ordered]@{group=$group;error=[string]$_}}}
 Save $seal "$Name.json";return $seal
}
function Keys($Rows){@($Rows|ForEach-Object{$_.relative+' '+$_.sha256})}
function AssertSeal($Actual,$Expected){
 if($Actual.errors.Count-or!$Actual.clean-or$Actual.head-cne$taskHead-or$Actual.source.Count-ne$taskSourceCount){throw 'Full exact clean candidate/control seal failed'}
 if(@(Compare-Object @(Keys $Actual.source) @(Keys $Actual.tree) -CaseSensitive).Count){throw 'Fresh source tree differs from complete tracked source inventory'}
 if($Actual.node1838.Count-ne1838-or$Actual.node1774.Count-ne1774-or@(Compare-Object $Actual.node1838 $taskExpected1838 -CaseSensitive).Count-or@(Compare-Object $Actual.node1774 $taskExpected1774 -CaseSensitive).Count){throw 'Original complete Node1838/1774 path/hash differs'}
 if($Actual.jiti_package.Count-ne16-or@(Compare-Object $Actual.jiti_package $taskExpectedPackage -CaseSensitive).Count){throw 'Complete original jiti package path/hash differs'}
 if($null-ne$Expected){foreach($group in @('source','tree')){if(@(Compare-Object @(Keys $Actual[$group]) @(Keys $Expected[$group]) -CaseSensitive).Count){throw "$group path/hash drift"}};if(@(Compare-Object @($Actual.controls|ForEach-Object{$_.path+' '+$_.sha256}) @($Expected.controls|ForEach-Object{$_.path+' '+$_.sha256}) -CaseSensitive).Count){throw 'Control hash drift'}}
}
function Evidence {
 $record=[ordered]@{owner=$null;owner_pid_present=$null;observed_descendants_by_parent_pid=@();raw=@();absence_error=$null}
 $path=Join-Path $taskProof 'node.json'
 if(Test-Path -LiteralPath $path){try{
  $record.owner=Get-Content -LiteralPath $path -Raw|ConvertFrom-Json;$rows=@(Processes);$record.owner_pid_present=@($rows|Where-Object ProcessId -EQ $record.owner.pid).Count
  $parents=@([int]$record.owner.pid);do{$children=@($rows|Where-Object{$_.ParentProcessId-in$parents-and$_.ProcessId-notin$parents});if(!$children.Count){break};$record.observed_descendants_by_parent_pid+=@($children|Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,CreationDate);$parents+=@($children.ProcessId)}while($true)
 }catch{$record.absence_error=[string]$_}}
 foreach($suffix in @('stdout.bin','stderr.log')){$raw=Join-Path $taskProof "node.$suffix";if(Test-Path -LiteralPath $raw){$record.raw+=,[ordered]@{path=$raw;bytes=(Get-Item -LiteralPath $raw).Length;sha256=(Get-FileHash -LiteralPath $raw -Algorithm SHA256).Hash}}};return $record
}
# Only original12+18 inputs: correction9+7 inputs/native candidate are not run.
$taskInputData=Get-Content -LiteralPath $taskInputs -Raw|ConvertFrom-Json
$taskExpectedIds=@($taskInputData.supported_execution_inputs.id)+@($taskInputData.declared_native_frontier_inputs.id)
if(@($taskInputData.supported_execution_inputs).Count-ne12-or@($taskInputData.declared_native_frontier_inputs).Count-ne18){throw 'Exact original12+18 input enumeration required'}
$taskArguments=@('--max-old-space-size=256',$taskBootstrap,[string]$taskGrant.stdin_nonce,$taskCaller,$taskBackend,$taskPublicJiti,$taskFixtures)
Save @{scope='Original unchanged public jiti and default Babel12+18 only; no custom transform/candidate execution';executable=$taskNode;arguments=$taskArguments;expected_input_ids=$taskExpectedIds;expected_results_created=$false;timeout_seconds=60;pipe_settle_seconds=10;heap_mib=256;reserve_mib=2048;historical_source_owner_control_only=$taskHistoricalOwner;actual_launcher=$taskOwner;fixture_root=$taskFixtures;dedicated_runner_environment_reset_keys=$taskResetKeys;inherited_environment_values_logged=$false} 'plan.json'
$result=[ordered]@{status='running';scope='Original jiti2.7 default Babel12+18 capture only';candidate_head=$taskHead;node_owner=$null;input_rows=$taskExpectedIds.Count;observed_rows=0;postseal=$false;absence=$null;fixtures=@();original_output=$null;errors=@();expected_created=$false;candidate_implementation_executed=$false;native_qualified=$false;runtime_restoration_claim=$false;full_babel_parity_claim=$false}
$before=$null;$parsed=$null;$originalReady=$false
try{
 CheckRelease;$before=Seal 'before';AssertSeal $before $null
 CheckRelease;AssertSeal (Seal 'before-node') $before
 Admission 'node'
 $result.node_owner=Invoke-CiOwnedProcess $taskNode $taskArguments $taskFixtures (Join-Path $taskProof 'node') 60 ([Text.Encoding]::UTF8.GetBytes(([string]$taskGrant.stdin_nonce)+"`n"))
 $owner=$result.node_owner
 if($owner.status-cne'passed'-or$owner.exit_code-ne0-or$owner.timeout_seconds-ne60-or$owner.executable_sha256-cne'63C259C81E5D472B5F11C8D506070130CB04A1ECF84B80377A34ED6EC9048088'-or!$owner.live_identity){throw 'Actual terminal-zero live-bound Node60 owner required'}
 if((Get-Item -LiteralPath (Join-Path $taskProof 'node.stderr.log')).Length-ne0){throw 'Original default Babel stderr must be empty; preserve any negative'}
 $bytes=[IO.File]::ReadAllBytes((Join-Path $taskProof 'node.stdout.bin'));if(!$bytes.Length-or$bytes.Length-gt8MB){throw 'Original default Babel output size invalid'}
 $parsed=[Text.Encoding]::UTF8.GetString($bytes)|ConvertFrom-Json
 $start=Get-Content -LiteralPath (Join-Path $taskFixtures 'node-start.json') -Raw|ConvertFrom-Json
 if($start.version-cne'v24.14.0'-or!([StringComparer]::OrdinalIgnoreCase.Equals([string]$start.execPath,$taskNode))-or$start.sourceImported-isnot[bool]-or$start.sourceImported){throw 'Actual original Node authority/version/start phase differs'}
 if($parsed.authority-cne'official-jiti2.7-default-babel-no-custom-transform'-or@($parsed.rows).Count-ne30){throw 'Every original default Babel row required'}
 for($i=0;$i-lt30;$i++){
  $row=$parsed.rows[$i];$profile=if($i-lt12){'consumed-profile'}else{'native-frontier'}
  if($row.id-cne$taskExpectedIds[$i]-or$row.profile-cne$profile-or(!$row.result-and!$row.thrown)){throw 'Original ordered input/raw observation schema differs'}
  if($row.result-and$row.result.code-isnot[string]){throw 'Actual raw generated code string required'}
  if($row.execution-and$row.execution.defaultType-ceq'function'-and$row.execution.functionSource-isnot[string]){throw 'Actual raw Function.prototype.toString observation required'}
 }
 $result.observed_rows=@($parsed.rows).Count;$originalReady=$true
 AssertSeal (Seal 'after-node') $before
 $result.status='terminal_zero_pending_final_seal'
}catch{$result.status='failed';$result.errors+=,[string]$_}finally{
 try{AssertSeal (Seal 'final') $before;$result.postseal=$true}catch{$result.status='failed_postseal';$result.errors+=,[string]$_}
 try{
  $evidence=Evidence;$roots=@(Native (Processes));$result.absence=[ordered]@{node=$evidence;global_native=@($roots|Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,CreationDate)}
  Save $result.absence 'absence.json'
  if($roots.Count-or!$evidence.owner-or$evidence.absence_error-or$evidence.owner_pid_present-or$evidence.observed_descendants_by_parent_pid.Count){throw 'Independent owner/descendant/global native absence not established'}
 }catch{$result.status='failed_absence';$result.errors+=,[string]$_}
 try{$result.fixtures=@((Get-CiInventory $taskFixtures).rows);Save $result.fixtures 'fixture-inventory.json'}catch{$result.status='failed_fixture_inventory';$result.errors+=,[string]$_}
 if(!$result.errors.Count-and$result.postseal-and$originalReady){try{
  # Only now retain an admitted parsed-output artifact; preserve raw bytes/order.
  $captured=Join-Path $taskProof 'original-output.json';[IO.File]::Copy((Join-Path $taskProof 'node.stdout.bin'),$captured,$false)
  $result.original_output=[ordered]@{path=$captured;bytes=(Get-Item -LiteralPath $captured).Length;sha256=(Get-FileHash -LiteralPath $captured -Algorithm SHA256).Hash}
  $result.status='passed_original_capture'
 }catch{$result.status='failed_output_copy';$result.errors+=,[string]$_}}
 $result.admission_probes=$taskAdmissions.ToArray();$result.completed_utc=[DateTimeOffset]::UtcNow.ToString('o');Save $result 'result.json'
}
$result|ConvertTo-Json -Depth 16
if($result.status-cne'passed_original_capture'){throw 'Original default Babel capture terminal negative; preserve all raw/owners/seals/absence'}
