#!/usr/bin/env node
export default function extension(){return 42}