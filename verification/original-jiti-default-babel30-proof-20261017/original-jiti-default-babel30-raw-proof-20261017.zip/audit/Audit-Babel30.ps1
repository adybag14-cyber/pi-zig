$ErrorActionPreference='Stop'
$container='C:\Users\adyba\pi-zig'
$run=Join-Path $container 'evidence/root-original-babel30-20261017-145214'
$control=Join-Path $container 'evidence/root-jiti-default-babel-env-source-prepared-20261017'
$candidate=Join-Path $container 'worktrees/jiti-default-transform'
function ReadJson([string]$Path){Get-Content -LiteralPath $Path -Raw|ConvertFrom-Json}
function Require([bool]$Value,[string]$Message){if(!$Value){throw $Message}}
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash}
function Keys($Rows,[string]$Field='relative'){@($Rows|ForEach-Object{$_.$Field+' '+$_.sha256})}
function CompareRows($Left,$Right,[string]$Name){Require (@(Compare-Object @($Left) @($Right) -CaseSensitive).Count-eq0) "$Name differs"}
$before=ReadJson (Join-Path $run 'before.json');$result=ReadJson (Join-Path $run 'result.json');$owner=ReadJson (Join-Path $run 'node.json');$plan=ReadJson (Join-Path $run 'plan.json')
$grant=ReadJson (Join-Path $control 'root-original-babel30-20261017-145214-grant.json')
$outerPath=Join-Path $control 'root-original-babel30-20261017-145214-outer.json';$outer=ReadJson $outerPath
$outerAbsent=ReadJson (Join-Path $control 'root-original-babel30-20261017-145214-outer-absence.json')
$absence=ReadJson (Join-Path $run 'absence.json');$raw=ReadJson (Join-Path $run 'original-output.json')
$phases=@(foreach($phase in @('before','before-node','after-node','final')){
 $seal=ReadJson (Join-Path $run "$phase.json")
 Require ($seal.head-ceq'9f4fc947e93eb9230eecd3f79838e69db3308976'-and$seal.clean-and!$seal.errors.Count-and$seal.source.Count-eq10965-and$seal.tree.Count-eq10965-and$seal.node1774.Count-eq1774-and$seal.node1838.Count-eq1838-and$seal.jiti_package.Count-eq16-and$seal.controls.Count-eq16) "$phase full seal/count differs"
 CompareRows (Keys $seal.source) (Keys $seal.tree) "$phase complete source/tree"
 CompareRows (Keys $seal.source) (Keys $before.source) "$phase source"
 foreach($name in @('node1774','node1838','jiti_package')){CompareRows $seal.$name $before.$name "$phase $name"}
 CompareRows (Keys $seal.controls 'path') (Keys $before.controls 'path') "$phase controls"
 [ordered]@{phase=$phase;source=10965;tree=10965;node1774=1774;node1838=1838;package=16;controls=16;drift=0;sha256=Hash (Join-Path $run "$phase.json")}
})
$nodeRoot='C:\Program Files\nodejs'
function NodeKeys($Rows){@($Rows|ForEach-Object{[IO.Path]::GetRelativePath($nodeRoot,$_.path).Replace('\','/')+' '+$_.sha256})}
$authority1774=@(ReadJson (Join-Path $container 'evidence/source4954-node-tools-before-20261015.json'))
$authority1838=@((ReadJson (Join-Path $container 'evidence/typebox-heap-scope-args-static-second49d-20261016-frozen.json')).node_complete)
CompareRows $before.node1774 (NodeKeys $authority1774) 'Original complete1774'
CompareRows $before.node1838 (NodeKeys $authority1838) 'Original complete1838'
$package=ReadJson (Join-Path $control 'jiti-package-inventory.json')
CompareRows $before.jiti_package (Keys $package.rows) 'Official complete package16'
foreach($row in $before.controls){Require ((Hash $row.path)-ceq$row.sha256) "Current control differs: $($row.path)"}
foreach($row in $before.source){Require ((Hash (Join-Path $candidate $row.relative))-ceq$row.sha256) "Current source differs: $($row.relative)"}
foreach($row in $package.rows){Require ((Hash (Join-Path $package.root $row.relative))-ceq$row.sha256) "Current package differs: $($row.relative)"}
foreach($key in $before.node1838){$split=$key.LastIndexOf(' ');Require ((Hash (Join-Path $nodeRoot $key.Substring(0,$split)))-ceq$key.Substring($split+1)) 'Current complete Node1838 differs'}
Require (([string](git --no-optional-locks -C $candidate rev-parse HEAD)).Trim()-ceq$before.head-and@(git --no-optional-locks -C $candidate status --porcelain).Count-eq0) 'Current exact candidate/clean differs'
Require ($result.status-ceq'passed_original_capture'-and!$result.errors.Count-and$result.postseal-and!$result.expected_created-and!$result.candidate_implementation_executed-and!$result.native_qualified-and!$result.runtime_restoration_claim-and!$result.full_babel_parity_claim) 'Original-only terminal result differs'
Require ($owner.pid-eq43192-and$owner.status-ceq'passed'-and$owner.exit_code-eq0-and$owner.timeout_seconds-eq60-and$owner.executable_sha256-ceq'63C259C81E5D472B5F11C8D506070130CB04A1ECF84B80377A34ED6EC9048088') 'Actual Node owner differs'
Require ($owner.live_identity.pid-eq$owner.pid-and([DateTimeOffset]$owner.created_utc)-eq([DateTimeOffset]$owner.live_identity.created_utc)-and$owner.live_identity.executable-ceq$owner.executable-and$owner.live_identity.command_line-ceq('"'+$owner.executable+'" '+($owner.arguments-join' '))) 'Node live command/birth differs'
Require (($owner.arguments-join"`0")-ceq($plan.arguments-join"`0")-and$owner.arguments.Count-eq7-and$owner.arguments[0]-ceq'--max-old-space-size=256'-and$owner.arguments[2]-ceq$grant.stdin_nonce-and$owner.arguments[3]-ceq(Join-Path $candidate 'verification/jiti-default-transform-sourceonly-20261017/source-caller.mjs')-and$owner.arguments[4]-ceq(Join-Path $package.root 'dist/babel.cjs')-and$owner.arguments[5]-ceq(Join-Path $package.root 'lib/jiti.cjs')) 'Exact official backend/caller/fence arguments differ'
Require ($grant.authorized-and$grant.status-ceq'root_reviewed_jiti_default_babel_original30_release'-and$grant.driver_sha256-ceq'4C4F299DEC04B41820264F6151D3809B5C4F32F0515C5B72491B870E8AB9474C'-and([DateTimeOffset]$owner.created_utc)-ge([DateTimeOffset]$grant.issued_utc)-and([DateTimeOffset]$owner.created_utc)-lt([DateTimeOffset]$grant.expires_utc)) 'Actual authorized grant differs'
Require ($outer.pid-eq48756-and$outer.status-ceq'passed'-and$outer.exit_code-eq0-and$outer.timeout_seconds-eq600-and$outer.live_identity.pid-eq$outer.pid-and([DateTimeOffset]$outer.created_utc)-eq([DateTimeOffset]$outer.live_identity.created_utc)-and$outer.live_identity.command_line-ceq('"'+$outer.executable+'" '+($outer.arguments-join' '))) 'Outer terminal/live identity differs'
Require ($outerAbsent.pid-eq$outer.pid-and$outerAbsent.fresh_pid_present-eq0-and$outerAbsent.owner_sha256-ceq(Hash $outerPath)-and([DateTimeOffset]$outerAbsent.checked_utc)-ge([DateTimeOffset]$outer.completed_utc)) 'Recorded outer fresh absence differs'
Require ((Hash (Join-Path $container 'evidence/root-crypto58-native-outer-prepared-20261017/outer-owned-process.ps1'))-ceq'53E522C8397B5F7EE9AF721D8160B227E97FADA4E1DA36A938656E2403D56B6B'-and(Hash $outer.executable)-ceq$outer.executable_sha256) 'Actual outer source/image pin differs'
Require (!$absence.node.owner_pid_present-and!$absence.node.observed_descendants_by_parent_pid.Count-and!$absence.node.absence_error-and!$absence.global_native.Count) 'Recorded Node/descendant/native absence differs'
Require ((Get-Item (Join-Path $run 'node.stderr.log')).Length-eq0-and(Get-Item (Join-Path $control 'root-original-babel30-20261017-145214-outer.stderr.log')).Length-eq0-and(Hash (Join-Path $run 'result.json'))-ceq(Hash (Join-Path $control 'root-original-babel30-20261017-145214-outer.stdout.bin'))) 'Outer/raw stderr differs'
$rawHash=Hash (Join-Path $run 'original-output.json')
Require ($rawHash-ceq'96DA1A507001E61D539E067E99203B4F35BF982BEF64D8A3A7E152B350DC5C37'-and$rawHash-ceq(Hash (Join-Path $run 'node.stdout.bin'))-and(Get-Item (Join-Path $run 'node.stdout.bin')).Length-eq33061) 'Unchanged raw original bytes differ'
$start=ReadJson (Join-Path $run 'fixtures/node-start.json')
Require ($start.version-ceq'v24.14.0'-and$start.execPath-ceq$owner.executable-and$start.sourceImported-is[bool]-and!$start.sourceImported-and($start.execArgv-join'|')-ceq'--max-old-space-size=256'-and($start.argv[1..6]-join"`0")-ceq($owner.arguments[1..6]-join"`0")) 'Actual fenced start phase differs'
$inputs=ReadJson (Join-Path $candidate 'verification/jiti-default-transform-sourceonly-20261017/inputs.json')
$ids=@($inputs.supported_execution_inputs.id)+@($inputs.declared_native_frontier_inputs.id)
Require ($raw.authority-ceq'official-jiti2.7-default-babel-no-custom-transform'-and$raw.rows.Count-eq30-and$ids.Count-eq30) 'Original30 identity/count differs'
for($i=0;$i-lt30;$i++){
 $row=$raw.rows[$i];Require ($row.id-ceq$ids[$i]-and$row.profile-ceq$(if($i-lt12){'consumed-profile'}else{'native-frontier'})-and$row.result.code-is[string]) "Original row$i schema/order differs"
 if($i-lt12){Require (!$row.result.error-and!$row.thrown-and$row.execution.defaultType-ceq'function'-and$row.execution.functionSource-is[string]-and$row.execution.functionSource.Length-gt0) "Original consumed evaluation$i missing"}else{Require (!$row.execution) "Frontier$i unexpectedly executed"}
}
$fixtures=@(ReadJson (Join-Path $run 'fixture-inventory.json'));Require ($fixtures.Count-eq33) 'Complete owned fixture33 differs'
foreach($row in $fixtures){Require ((Hash $row.path)-ceq$row.sha256) "Owned fixture differs: $($row.relative)"}
$admission=ReadJson (Join-Path $run 'node-admission.json');$probe=@($admission.probes)[-1]
Require ($admission.status-ceq'admitted'-and$probe.free_kib-ge16777216-and!$probe.native.Count-and$admission.accepted_elapsed_seconds-lt54-and([DateTimeOffset]$probe.utc)-lt([DateTimeOffset]$owner.created_utc)) 'Recorded fresh admission differs'
$oldPrepared=ReadJson (Join-Path $control 'prepared.json')
foreach($property in $oldPrepared.PSObject.Properties){if($property.Value-is[array]){foreach($row in $property.Value){if($row.path-and$row.sha256){Require ((Hash $row.path)-ceq$row.sha256) "Prepared/old negative pin differs: $($row.path)"}}}}
$diagnosticRows=@($raw.rows|Where-Object{$_.result.error}|ForEach-Object id)
$audit=[ordered]@{status='accepted_original_default_Babel30_authority';source_head_for_seals_only=$before.head;raw_bytes=33061;raw_sha256=$rawHash;ordered_rows=30;actual_consumed_function_evaluations=12;frontier_compiler_observations=18;frontier_Babel_diagnostic_ids=$diagnosticRows;frontier_diagnostics_are_not_successful_transformations=$true;full_seals=$phases;current_source_Node_package_controls_fixtures_drift=0;actual_owned_fixture_files=33;node_pid=$owner.pid;node_elapsed_seconds=(([DateTimeOffset]$owner.completed_utc)-([DateTimeOffset]$owner.created_utc)).TotalSeconds;outer_pid=$outer.pid;outer_elapsed_seconds=(([DateTimeOffset]$outer.completed_utc)-([DateTimeOffset]$outer.created_utc)).TotalSeconds;recorded_owned_absence=$true;auditor_fresh_process_census=$false;admitted_free_kib=$probe.free_kib;original_observations_preserved=@{live_named_import=@($raw.rows|Where-Object id -CEQ 'live-named-import')[0].execution.value;meta_resolve_builtin=@($raw.rows|Where-Object id -CEQ 'meta-resolve-real-builtin')[0].execution.value;strict_top_level_this=@($raw.rows|Where-Object id -CEQ 'strict-top-level-this')[0].execution.value};preserved_raw_quirk='result.node_owner is empty-object-plus-receipt array; node.json authoritative';native_candidate_executed=$false;expected_generated=$false;native_runtime_API_default_fullBabel_restoration_qualified=$false;reviewer_Node_native_compiler_AST_parser_generator_jobs=$false;reviewer_Main_product_edits=$false}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'raw-audit.json'),($audit|ConvertTo-Json -Depth 10)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
[ordered]@{status=$audit.status;rows=30;actual_function_evaluations=12;frontier_observations=18;diagnostic_rows=$diagnosticRows;receipt_sha256=Hash (Join-Path $PSScriptRoot 'raw-audit.json')}|ConvertTo-Json
