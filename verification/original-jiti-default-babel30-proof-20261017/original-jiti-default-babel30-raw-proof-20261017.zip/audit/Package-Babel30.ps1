$ErrorActionPreference='Stop'
$container='C:\Users\adyba\pi-zig'
$intake=Join-Path $container 'worktrees/original-babel30-public-intake-20261017'
$destination=Join-Path $intake 'verification/original-jiti-default-babel30-proof-20261017'
$run=Join-Path $container 'evidence/root-original-babel30-20261017-145214'
$control=Join-Path $container 'evidence/root-jiti-default-babel-env-source-prepared-20261017'
$oldControl=Join-Path $container 'evidence/root-jiti-default-babel-source-prepared-20261017'
$source=Join-Path $container 'worktrees/jiti-default-transform'
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash}
function Json([string]$Path){Get-Content -LiteralPath $Path -Raw|ConvertFrom-Json}
function WriteJson([string]$Path,$Value){[IO.File]::WriteAllText($Path,($Value|ConvertTo-Json -Depth 15)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))}
if((Hash (Join-Path $PSScriptRoot 'raw-audit.json'))-cne'D7F1AE1AF872564F9AC1BAE0452BE4B4DE3B2B75176BE70D3A6B78200A6421F5'){throw 'Accepted audit changed'}
if((Hash (Join-Path $run 'original-output.json'))-cne'96DA1A507001E61D539E067E99203B4F35BF982BEF64D8A3A7E152B350DC5C37'){throw 'Original raw output changed'}
if((git -C $intake rev-parse HEAD)-ne'65dc640634d6bb1ae3ed4fba8a6b17eb50ab83b7'){throw 'Wrong intake base'}
[void][IO.Directory]::CreateDirectory($destination)
$mapping=[Collections.Generic.Dictionary[string,object]]::new([StringComparer]::Ordinal)
function Add([string]$Path,[string]$Public,[string]$Expected=''){
 if($Public.Contains('..')-or$Public.StartsWith('/')-or$Public-match'\.(exe|pdb|dll|lib|obj|o|a)$'-or$Public-match'(^|/)(node_modules|cache|global-cache|\.zig-cache|zig-out|out)/'){throw "Excluded/unsafe path $Public"}
 $item=Get-Item -LiteralPath $Path
 if($item.PSIsContainer-or($item.Attributes-band[IO.FileAttributes]::ReparsePoint)){throw "Non-regular input $Path"}
 $sha=Hash $Path;if($Expected-and$sha-cne$Expected){throw "Pinned input changed $Path"}
 $mapping.Add($Public,[ordered]@{path=$Public;source_path=$item.FullName;bytes=$item.Length;sha256=$sha})
}
# Every run record and all 33 owned fixtures, retaining raw streams and full seals.
foreach($file in Get-ChildItem -LiteralPath $run -File -Recurse){Add $file.FullName ('capture/'+[IO.Path]::GetRelativePath($run,$file.FullName).Replace('\','/'))}
# Current 4C4 driver, issued grant, outer receipts/streams and six unchanged D25 negatives.
foreach($file in Get-ChildItem -LiteralPath $control -File){Add $file.FullName ('controls/4c4/'+$file.Name)}
foreach($file in Get-ChildItem -LiteralPath $oldControl -File){Add $file.FullName ('controls/d25-source-negative/'+$file.Name)}
foreach($file in @('Audit-Babel30.ps1','raw-audit.json','Package-Babel30.ps1')){Add (Join-Path $PSScriptRoot $file) ('audit/'+$file)}
Add (Join-Path $container 'evidence/jiti-default-babel-independent-controller-review-4c4f-20261017.json') 'audit/controller-source-review-4c4f.json' '89AD15FCD45C2384C69606022F25E7FDF7F79D338662F1D38FD57D9916E82E57'
$prepared=Json (Join-Path $control 'prepared.json')
foreach($row in $prepared.source_controls){Add $row.path ('source-controls/'+[IO.Path]::GetRelativePath($source,$row.path).Replace('\','/')) $row.sha256}
foreach($row in $prepared.canonical_control_authorities){Add $row.path ('authority/'+[IO.Path]::GetFileName($row.path)) $row.sha256}
Add (Join-Path $container 'evidence/root-crypto58-native-outer-prepared-20261017/outer-owned-process.ps1') 'authority/outer-owned-process.ps1' '53E522C8397B5F7EE9AF721D8160B227E97FADA4E1DA36A938656E2403D56B6B'
$before=Json (Join-Path $run 'before.json')
foreach($row in $before.controls){
 if($row.path.EndsWith('\node.exe',[StringComparison]::OrdinalIgnoreCase)){continue}
 if($row.path.EndsWith('\Resolve-PiZigWorkspace.ps1',[StringComparison]::OrdinalIgnoreCase)-or$row.path.EndsWith('\.pi-zig-workspace.json',[StringComparison]::OrdinalIgnoreCase)-or$row.path.EndsWith('\path-relocations.json',[StringComparison]::OrdinalIgnoreCase)){
  Add $row.path ('authority/'+[IO.Path]::GetFileName($row.path)) $row.sha256
 }
}
$package=Json (Join-Path $control 'jiti-package-inventory.json')
foreach($row in $package.rows){Add (Join-Path $package.root $row.relative) ('official-jiti-package/'+$row.relative) $row.sha256}
$names=[string[]]@($mapping.Keys);[Array]::Sort($names,[StringComparer]::Ordinal)
WriteJson (Join-Path $PSScriptRoot 'public-files.json') ([ordered]@{files=@($names|ForEach-Object{$mapping[$_]});count=$names.Count})
function WriteZip([string]$Path){
 $stream=[IO.File]::Open($Path,[IO.FileMode]::Create,[IO.FileAccess]::Write,[IO.FileShare]::None)
 $zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$false,[Text.UTF8Encoding]::new($false))
 try{foreach($name in $names){$entry=$zip.CreateEntry($name,[IO.Compression.CompressionLevel]::Optimal);$entry.LastWriteTime=[DateTimeOffset]::new(1980,1,1,0,0,0,[TimeSpan]::Zero);$entry.ExternalAttributes=0;$output=$entry.Open();$input=[IO.File]::OpenRead($mapping[$name].source_path);try{$input.CopyTo($output)}finally{$input.Dispose();$output.Dispose()}}}finally{$zip.Dispose();$stream.Dispose()}
}
function VerifyZip([string]$Path){
 $stream=[IO.File]::OpenRead($Path);$zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Read,$false,[Text.UTF8Encoding]::new($false))
 try{if($zip.Entries.Count-ne$names.Count){throw 'ZIP count mismatch'};for($index=0;$index-lt$names.Count;$index++){$entry=$zip.Entries[$index];$row=$mapping[$names[$index]];if($entry.FullName-cne$row.path-or$entry.Length-ne$row.bytes-or$entry.LastWriteTime.DateTime-ne[DateTime]::new(1980,1,1,0,0,0)){throw 'ZIP name/length/time mismatch'};$data=$entry.Open();try{$sha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($data))}finally{$data.Dispose()};if($sha-cne$row.sha256){throw "ZIP hash mismatch $($row.path)"}}}finally{$zip.Dispose();$stream.Dispose()}
 return Hash $Path
}
$zipName='original-jiti-default-babel30-raw-proof-20261017.zip'
$zipPath=Join-Path $destination $zipName;WriteZip $zipPath;$first=VerifyZip $zipPath
$repeat=Join-Path $PSScriptRoot 'babel30-determinism-repeat-local.zip';WriteZip $repeat;$second=VerifyZip $repeat
if($first-cne$second){throw 'Repeat ZIP differs'}
$rawCopy=Join-Path $destination 'original-output.json';[IO.File]::Copy((Join-Path $run 'original-output.json'),$rawCopy,$true)
if((Hash $rawCopy)-cne'96DA1A507001E61D539E067E99203B4F35BF982BEF64D8A3A7E152B350DC5C37'){throw 'Published original copy differs'}
$uncompressedBytes=[long]0;foreach($row in $mapping.Values){$uncompressedBytes+=[long]$row.bytes}
$manifest=[ordered]@{status='audited_original_default_Babel30_raw_authority_no_native_expected';intake_base='65dc640634d6bb1ae3ed4fba8a6b17eb50ab83b7';sealed_source_head='9f4fc947e93eb9230eecd3f79838e69db3308976';actual_run='root-original-babel30-20261017-145214';original_output=[ordered]@{path='original-output.json';bytes=33061;sha256=Hash $rawCopy;expected_fixture=$false};archive=[ordered]@{path=$zipName;bytes=(Get-Item -LiteralPath $zipPath).Length;sha256=$first;entries=$names.Count;uncompressed_bytes=$uncompressedBytes};raw_audit_sha256=Hash (Join-Path $PSScriptRoot 'raw-audit.json');files=@($names|ForEach-Object{$row=$mapping[$_];[ordered]@{path=$row.path;bytes=$row.bytes;sha256=$row.sha256}});scope=[ordered]@{ordered_rows=30;actual_function_evaluations=12;frontier_compiler_observations=18;frontier_diagnostic_ids=@('jsx','malformed-source-diagnostic');full_seal_phases=4;source_files_each=10965;node_authority_counts=@(1774,1838);official_package_files=16;control_files_each=16;owned_fixture_files=33;driver_sha256='4C4F299DEC04B41820264F6151D3809B5C4F32F0515C5B72491B870E8AB9474C';node_pid=43192;outer_pid=48756;both_exit_zero=$true;recorded_absence=$true;auditor_fresh_census=$false};preserved_negative='Original D25 prospective source packet, unexecuted: missed ambient BABEL_* environment reset; exact old bytes retained. 4C4 only broadens child-only reset predicate to JITI_* or BABEL_*.';preserved_raw_quirk='result.node_owner is array containing empty object and receipt; node.json scalar authoritative';excluded=@('Node/pwsh executable payloads and whole Node installation','Whole sealed source payload beyond exact original caller/input/provenance; full source/tree inventories included','Cache/PDB/object/library/native executable payloads');native_candidate_executed=$false;expected_created=$false;full_Babel_native_runtime_API_default_Main_or_restoration_qualified=$false}
WriteJson (Join-Path $destination 'public-manifest.json') $manifest
WriteJson (Join-Path $destination 'package-verification.json') ([ordered]@{status='two_identical_ZIPs_all_entries_rehashed';entries_each=$names.Count;archive_sha256=$first;repeat_archive_sha256=$second;entry_hash_mismatches=0;entry_order='Ordinal ascending';entry_timestamp='1980-01-01T00:00:00';entry_external_attributes=0;compression='DotNet Optimal Deflate';determinism_scope='Two writes using same payload and .NET implementation';separate_original_output_matches_capture=$true;packaging_script_sha256=Hash $PSCommandPath;Node_compiler_AST_parser_native_generator_jobs=$false;Main_edited=$false;pushed=$false})
WriteJson (Join-Path $PSScriptRoot 'local-only-ledger.json') ([ordered]@{excluded_images=@([ordered]@{path='C:\Program Files\nodejs\node.exe';sha256='63C259C81E5D472B5F11C8D506070130CB04A1ECF84B80377A34ED6EC9048088'},[ordered]@{path='C:\Program Files\PowerShell\7\pwsh.exe';sha256='BFB46AF89433268872DDB43D1CA7A3F433452EE91ED356A9786940F90118E285'});repeat_zip=$repeat;repeat_zip_sha256=$second;not_deleted=$true})
[ordered]@{entries=$names.Count;zip_bytes=$manifest.archive.bytes;zip_sha256=$first;original_sha256=Hash $rawCopy;manifest_sha256=Hash (Join-Path $destination 'public-manifest.json');verification_sha256=Hash (Join-Path $destination 'package-verification.json')}|ConvertTo-Json
