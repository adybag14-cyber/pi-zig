import{readFileSync,writeFileSync}from'node:fs';import{createHash}from'node:crypto';
const{AgentSession}=await import('file:///C:/Users/adyba/pi-upstream-source-b06c1f2-20261014/packages/coding-agent/src/core/agent-session.ts');
globalThis.thresholdB06={exceeds:AgentSession.prototype._exceedsCompactionThreshold,before:AgentSession.prototype._compactBeforeNextAssistantResponse};
const input=readFileSync(new URL('./sdk-compaction-threshold-b06-caller-20261014.mjs',import.meta.url));
await import('data:text/javascript,'+encodeURIComponent(input.toString('utf8')));
writeFileSync(process.argv[2],JSON.stringify({sourceHead:'b06c1f2cf1dea6af8748ddeee18c23587d2cb7c6',actualNode:{version:process.version,executable:process.execPath},inputSha256:createHash('sha256').update(input).digest('hex'),cases:thresholdB06Rows.length,scope:'Actual ordinary threshold method and live method override dispatch, genuine imported token estimates; no full session factory qualification',rows:thresholdB06Rows},null,2));
