// A reporter for actual node:test events in direct-file mode. No run(), child
// process, assertion replacement, expected-name fixture or third-party import.
export default async function* report(source) {
  let count = 0;
  yield 'TAP version 13\n';
  for await (const event of source) {
    if (event.type === 'test:pass' || event.type === 'test:fail') {
      const item = event.data;
      if (item.nesting !== 0 || typeof item.name !== 'string' || /[\r\n]/.test(item.name)) {
        throw Error('Unsupported nested or malformed tooling test event');
      }
      const passed = event.type === 'test:pass' && !item.skip && !item.todo;
      yield `${passed ? 'ok' : 'not ok'} ${++count} - ${item.name}\n`;
    } else if (['test:stdout', 'test:stderr', 'test:coverage'].includes(event.type)) {
      throw Error(`Unexpected tooling output event: ${event.type}`);
    }
  }
  yield `1..${count}\n`;
}
