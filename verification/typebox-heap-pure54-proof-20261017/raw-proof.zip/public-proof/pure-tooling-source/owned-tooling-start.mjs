// Preload only: the retained CI607 owner writes this after live identity checks.
import {readFileSync} from 'node:fs';
if (readFileSync(0, 'utf8') !== 'TYPEBOX_HEAP_TOOLING_OWNED_START\n') {
  throw Error('Exact owned tooling start token required');
}
