# Actual TypeBox pure tooling54 — raw proof, privacy filtered

Accepted local run: root-typebox-heap-pure54-v3-20261017-164011 at exact source f5dba5c680813cf0ecb829185b593fa873b74b5e. All 54 original named assertions passed, in three separately owned direct Node invocations:27+18+9. Raw TAP files and empty stderr files are byte-for-byte copies. Owned Node PIDs26420/55944/23356 and outer61144 exited0, with original retained/live identities, deadlines, exact stdin start barriers and independently checked absence receipts.

The independent audit freshly rehashed10643 source files,1838 Node files and15 controls; exact physical source/Node inventories and all8 full before/between/after seal snapshots matched. Original1774 authority remains separate and its paths/hashes are a verified subset of the full1838 authority. Complete relative inventories are included once rather than duplicating eight identical large seals; each original raw seal SHA remains in the audit.

This proves pure static-authoring tooling assertions only. No Zig compilation, product/native test, Source generator, hosted job or runtime restoration occurred in this gate. The reviewer launched no candidate jobs. No product/native/default qualification or recovery authority is implied. Current Root serial jobs are separate; this bundle's global-native-zero/absence observations refer to the accepted run, not the present host.

Only the local container prefix is replaced with {CONTAINER} in filtered JSON/log derivatives. Original receipt SHA256 and lengths identify the retained local originals; filtered derivative hashes are listed separately. No environment values, unrelated process census, credentials, executables, PDBs, cache or recovered-runtime bytes are included. Owned process identities and timestamps are retained for review.

The prior V2 Windows ESM URL negative is preserved as a separate filtered derivative. Its actual Node failure is ERR_UNSUPPORTED_ESM_URL_SCHEME for protocol c:. Its overall failed_absence also includes consequential missing unlaunched phase evidence. V3 uses explicit file URLs for ESM preload/reporter and retains absolute positional test paths. This does not rewrite or convert the V2 negative to a pass.

Prepared for review only. No upload, publication or remote job was launched.