$ErrorActionPreference='Stop'
$container='C:\Users\adyba\pi-zig'
function J($path){Get-Content -Raw -LiteralPath $path|ConvertFrom-Json}
function Get-AuditHash($path){(Get-FileHash -LiteralPath $path).Hash}
function A($condition,$message){if(!$condition){throw $message}}
function Rows($items){@($items|ForEach-Object{$_.relative+' '+$_.sha256})}
function ParseProtocol($path,[bool]$metadata){
 $b=[IO.File]::ReadAllBytes($path);$o=0;$version=$null;$names=@();$starts=0;$results=@()
 while($o -lt $b.Length){
  A ($b.Length-$o -ge 8) 'Truncated header';$tag=[BitConverter]::ToUInt32($b,$o);$n=[BitConverter]::ToUInt32($b,$o+4);$o+=8
  A ($n -le $b.Length-$o -and $n -le 1MB) 'Bad body length'
  if($tag -eq 0){A ($null -eq $version -and $starts -eq 0 -and $names.Count -eq 0) 'Bad version order';$version=[Text.Encoding]::UTF8.GetString($b,$o,$n)}
  elseif($metadata -and $tag -eq 3){
   A ($version -ceq '0.16.0' -and $names.Count -eq 0 -and $n -ge 8) 'Bad metadata order'
   $strings=[BitConverter]::ToUInt32($b,$o);$count=[BitConverter]::ToUInt32($b,$o+4);A ($count -eq 4 -and $n -eq 8+8*$count+$strings) 'Bad metadata count'
   $start=$o+8+8*$count
   for($i=0;$i -lt $count;$i++){$at=[BitConverter]::ToUInt32($b,$o+8+4*$i);A ($at -lt $strings -and [BitConverter]::ToUInt32($b,$o+8+4*$count+4*$i) -eq 0) 'Bad name/panic';$end=$at;while($end -lt $strings -and $b[$start+$end] -ne 0){$end++};A ($end -lt $strings) 'Unterminated name';$names+=[Text.Encoding]::UTF8.GetString($b,$start+$at,$end-$at)}
  }elseif(!$metadata -and $tag -eq 5){A ($version -ceq '0.16.0' -and $n -eq 0 -and $starts -eq $results.Count -and $starts -lt 4) 'Bad start';$starts++}
  elseif(!$metadata -and $tag -eq 4){A ($n -eq 12 -and $starts -eq $results.Count+1) 'Bad result';$index=[BitConverter]::ToUInt32($b,$o);$flags=[BitConverter]::ToUInt64($b,$o+4);A ($index -eq $results.Count) 'Result index';$results+=,[ordered]@{index=$index;flags=$flags}}
  else{throw "Unexpected tag $tag"}
  $o+=$n
 }
 A ($version -ceq '0.16.0') 'Wrong version'
 if($metadata){A ($names.Count -eq 4) 'Incomplete metadata'}else{A ($starts -eq 4 -and $results.Count -eq 4) 'Incomplete execution'}
 return [ordered]@{bytes=$b.Length;version=$version;names=$names;starts=$starts;results=$results}
}
$compilerPath=Join-Path $container 'evidence\durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
A ((Get-AuditHash $compilerPath) -ceq 'DEE259F171F720AB2C08E8DD473975E22C876417CD62E4F016C71A7C662794EB') 'Compiler authority'
$compiler=J $compilerPath;$expectedCompiler=@($compiler.inputs|ForEach-Object{$_.path.Substring($compiler.root.Length+1).Replace('\','/')+' '+$_.sha256})
$names=@('native_typebox_compile_production_test.test.actual TypeBox Compile Validator matches complete genuine Source80','native_typebox_compile_production_test.test.actual provider schemas Partial and Memory match genuine Source52 on shared compiler graph','native_typebox_compile_production_test.test.actual TypeBox generic operators match complete genuine Source396 on shared compiler graph','extensions.native_durable_storage.test_0')
$runReports=@()
foreach($runName in @('root-typebox-component-first38a8-20261016','root-typebox-component-second1f9-20261017')){
 $run=Join-Path $container "evidence\$runName";$before=J "$run\before.json";$result=J "$run\result.json";$first=$runName.Contains('first38')
 $head=if($first){'38a8e606c159a8e918142b4e1b5210c4af707ac8'}else{'1f9eee9e5e5672167f70b032beaa167a5a99556a'}
 A ($before.candidate_head -ceq $head -and $result.candidate_head -ceq $head -and $result.status -ceq 'failed' -and $result.postseal -eq $true) 'Wrong failed scope'
 A ($before.source.Count -eq 10631 -and $before.tree.Count -eq 10631 -and $before.vendor.Count -eq 1336 -and $before.compiler.Count -eq 19546 -and $before.controls.Count -eq 9) 'Incomplete inventory'
 A (@(Compare-Object (Rows $before.compiler) $expectedCompiler -CaseSensitive).Count -eq 0) 'Compiler authority drift'
 $checks=@(foreach($phase in @('compile-before','compile-after','metadata-before','metadata-after','runtime-before','runtime-after','final')){
  $seal=J "$run\$phase.json";A ($seal.candidate_head -ceq $head -and $seal.clean -eq $true -and $seal.errors.Count -eq 0) 'Source identity/errors'
  foreach($group in @('source','tree','vendor','compiler','controls')){A (@($seal.$group.relative|Sort-Object -Unique).Count -eq $seal.$group.Count) 'Duplicate inventory path';$drift=@(Compare-Object (Rows $before.$group) (Rows $seal.$group) -CaseSensitive).Count;A ($drift -eq 0) "$runName $phase $group drift"}
  [ordered]@{phase=$phase;all_five_groups_drift=0}
 })
 foreach($row in $before.controls){A ((Get-AuditHash $row.path) -ceq $row.sha256) 'Control changed since execution'}
 $metadata=ParseProtocol "$run\metadata.stdout.bin" $true;A (($metadata.names -join "`n") -ceq ($names -join "`n")) 'Wrong metadata names'
 $runtime=ParseProtocol "$run\runtime.stdout.bin" $false;$flags=if($first){@(1,0,1,0)}else{@(0,0,1,0)}
 A (($runtime.results.flags -join ',') -ceq ($flags -join ',')) 'Wrong actual flags'
 A ((Get-Item -LiteralPath "$run\metadata.stderr.log").Length -eq 0) 'Metadata stderr'
 $exeHash=if($first){'E6B13E703F04B6176CE3F34FB6890A71ADD65A44F0B4462A29C217828BF7661D'}else{'E2E091FCADDBC9192143E634F235483CC957DC727073D2E046E0D9729B450927'}
 $installed="$run\installed\bin\test.exe";$artifact=J "$run\compile-after-artifacts.json"
 foreach($row in $artifact.installed){A ((Get-AuditHash $row.path) -ceq $row.sha256 -and (Get-Item -LiteralPath $row.path).Length -eq $row.bytes) 'Installed artifact changed'}
 A ((Get-AuditHash $installed) -ceq $exeHash) 'Wrong exe'
 $pe=[IO.File]::ReadAllBytes($installed);$peOffset=[BitConverter]::ToInt32($pe,0x3c);A ([BitConverter]::ToUInt32($pe,$peOffset) -eq 0x4550 -and [BitConverter]::ToUInt16($pe,$peOffset+24) -eq 0x20b) 'Wrong PE'
 A ([BitConverter]::ToUInt64($pe,$peOffset+24+72) -eq 16777216) 'Wrong PE stack reserve'
 foreach($phase in @('metadata-before','metadata-after','runtime-before','runtime-after','final')){
  $current=J "$run\$phase-artifacts.json";A ($current.errors.Count -eq 0 -and $current.installed.Count -eq 2) 'Artifact observation'
  A (@(Compare-Object @($artifact.installed|ForEach-Object{$_.path+' '+$_.sha256}) @($current.installed|ForEach-Object{$_.path+' '+$_.sha256}) -CaseSensitive).Count -eq 0) 'Installed phase drift'
  $match=@($current.cached_executables|Where-Object sha256 -CEQ $exeHash);$original=@($artifact.cached_executables|Where-Object sha256 -CEQ $exeHash);A ($match.Count -eq 1 -and $original.Count -eq 1 -and $match[0].path -ceq $original[0].path) 'Matching cached exe drift'
 }
 $ownerReports=@(foreach($phase in @('compile','metadata','runtime')){
  $owner=J "$run\$phase.json";$deadline=@{compile=1320;metadata=30;runtime=120}[$phase]
  A ($owner.status -ceq 'passed' -and $owner.exit_code -eq 0 -and $owner.timeout_seconds -eq $deadline -and $owner.retained_handle -gt 0) 'Owner terminal/deadline'
  A ($owner.live_identity.pid -eq $owner.pid -and $owner.live_identity.executable -ceq $owner.executable -and $owner.live_identity.created_utc -ceq $owner.created_utc -and $owner.live_identity.command_line_method -ceq 'Win32_Process.CommandLine') 'Owner identity'
  $expectedHash=if($phase -eq 'compile'){'086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864'}else{$exeHash};A ($owner.executable_sha256 -ceq $expectedHash) 'Owner executable hash'
  $elapsed=([DateTimeOffset]$owner.completed_utc-[DateTimeOffset]$owner.created_utc).TotalSeconds;A ($elapsed -ge 0 -and $elapsed -le $deadline) 'Owner time bounds'
  A (@(Get-CimInstance Win32_Process -Filter "ProcessId = $($owner.pid)").Count -eq 0) 'Original PID present/reused'
  $absence=J "$run\$phase-absence.json";A ($absence.global_native.Count -eq 0 -and $absence.evidence.current_owner_pid_present -eq 0 -and $absence.evidence.current_owned_descendants.Count -eq 0 -and !$absence.evidence.absence_error) 'Saved absence'
  $admit=J "$run\$phase-admission.json";A ($admit.status -ceq 'admitted' -and $admit.probe.free_kib -ge 16777216 -and $admit.probe.native_roots -eq 0) 'Fresh admission'
  [ordered]@{phase=$phase;pid=$owner.pid;created_utc=$owner.created_utc;elapsed_seconds=$elapsed;exit_code=0;currently_absent=$true;live_command_line=$owner.live_identity.command_line}
 })
 A ($result.absence.native_roots.Count -eq 0) 'Final native census'
 $stderr=[IO.File]::ReadAllText("$run\runtime.stderr.log")
 if(!$first){A ($stderr.Contains('TYPEBOX_COMPILE_SOURCE_PARITY cases=80') -and $stderr.Contains('TYPEBOX_PROVIDER_SCHEMA_SOURCE_PARITY cases=52') -and !$stderr.Contains('TYPEBOX_OPERATOR_SOURCE_PARITY cases=396')) 'Scoped completion markers'}
 $mismatches=@(foreach($line in ($stderr -split '\r?\n')){if($line -match '^Actual TypeBox Source(\d+) replay: Error: (\{.+\})$'){[ordered]@{source_count=[int]$Matches[1];detail=($Matches[2]|ConvertFrom-Json)}}})
 if(!$first){A ($mismatches.Count -eq 1 -and $mismatches[0].source_count -eq 396 -and $mismatches[0].detail.index -eq 391) 'Remaining mismatch scope';$m=$mismatches[0].detail;A ($m.expected.metrics.assign -eq 129 -and $m.expected.metrics.create -eq 792 -and $m.actual.metrics.assign -eq 28 -and $m.actual.metrics.create -eq 186) 'Mismatch counters';A (($m.expected.value[1]|ConvertTo-Json -Depth 10 -Compress) -ceq ($m.actual.value[1]|ConvertTo-Json -Depth 10 -Compress)) 'Recovered literal differs'}
 $engine=@($before.source|Where-Object relative -CEQ 'src/extensions/engine.zig')[0]
 $enginePath=Join-Path $container 'worktrees\root-typebox-qualification\src\extensions\engine.zig';A ((Get-AuditHash $enginePath) -ceq $engine.sha256) 'Engine pin changed';A ([IO.File]::ReadAllText($enginePath) -match 'stack_limit:\s*usize\s*=\s*1024\s*\*\s*1024') 'Guard default'
 $runReports+=,[ordered]@{run=$run;head=$head;overall='failed';metadata=$metadata;raw_runtime=$runtime;seals=$checks;source_count=10631;tree_count=10631;vendor_count=1336;compiler_count=19546;control_count=9;compiler_original_drift=0;artifacts=$artifact.installed;PE_reserved_stack_bytes=16777216;Engine_default_guard_bytes=1048576;dynamic_frames_measured=$false;owners=$ownerReports;postseal=$true;historical_native_roots=0;mismatches=$mismatches}
}
$receipt=[ordered]@{status='both_negatives_confirmed_with_scoped_second_run_passes';audited_utc=[DateTimeOffset]::UtcNow.ToString('o');runs=$runReports;second_run_passes=@('complete Source80','complete Source52','storage test_0');second_run_negative='Source396 index391 generic-default-instantiation-limit-recovery: actual RangeError/Maximum call stack size exceeded vs expected Error/Type instantiation is excessively deep and possibly infinite; actual28/186 vs expected129/792; recovered literal matches';cache_policy='Only original two unsealed compiler caches reused; old installed executable/PDB unchanged; unique matching current cache executable bound per run; unrelated cache entries not immutable authority';limits=@('No full TypeBox/whole application/runtime restoration acceptance','No dynamic frame or GPA qualification; old E6/PDB measurement separate','Full saved seals and current control/artifact/Engine pins checked; no fresh full compiler rehash','Original bytes preserved; no jobs or main edits')}
ConvertTo-Json -InputObject $receipt -Depth 30|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'audit.json') -Encoding utf8NoBOM
[pscustomobject]@{status=$receipt.status;sha256=Get-AuditHash (Join-Path $PSScriptRoot 'audit.json')}|ConvertTo-Json
