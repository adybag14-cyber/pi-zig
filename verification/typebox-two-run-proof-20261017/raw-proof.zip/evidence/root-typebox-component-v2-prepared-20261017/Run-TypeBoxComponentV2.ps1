param([Parameter(Mandatory)][string]$RootGrant)
$ErrorActionPreference='Stop'
$taskContainer=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$taskResolver=Join-Path $taskContainer 'main/tools/workspace/Resolve-PiZigWorkspace.ps1'
$taskWorkspace=& $taskResolver -StartPath $PSScriptRoot
function Contained([string]$Path,[string]$Under){
 if(!$Path){throw 'Explicit contained path required'}
 $resolved=[IO.Path]::GetFullPath($Path)
 if(!$resolved.StartsWith([IO.Path]::GetFullPath($Under)+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Path escapes declared contained root'}
 $ancestor=[IO.DirectoryInfo]::new($resolved)
 while($ancestor){if($ancestor.Exists-and($ancestor.Attributes-band[IO.FileAttributes]::ReparsePoint)){throw 'Reparse ancestor rejected'};if($ancestor.FullName-eq$taskContainer){break};$ancestor=$ancestor.Parent}
 if((Test-Path -LiteralPath $resolved)-and((Get-Item -LiteralPath $resolved -Force).Attributes-band[IO.FileAttributes]::ReparsePoint)){throw 'Reparse leaf rejected'}
 return $resolved
}
$RootGrant=Contained $RootGrant $taskWorkspace.evidence
$taskGrant=Get-Content -LiteralPath $RootGrant -Raw|ConvertFrom-Json
$taskRoot=Contained ([string]$taskGrant.candidate_root) $taskWorkspace.worktrees
$taskProof=Contained ([string]$taskGrant.receipt_directory) $taskWorkspace.evidence
$taskHead='1f9eee9e5e5672167f70b032beaa167a5a99556a'
if($taskGrant.status-cne'root_reviewed_typebox_component_native_release'-or$taskGrant.candidate_head-cne$taskHead-or$taskRoot-cne(Join-Path $taskWorkspace.worktrees 'root-typebox-qualification')-or!$taskGrant.grant_id-or$taskGrant.runtime_restoration_claim-ne$false-or$taskGrant.runtime_outer_actual_seconds-ne120-or$taskGrant.runtime_outer_plan_maximum_seconds-ne300){throw 'Exact Root1f9eee9e component release and explicit actual120/maximum300 scope required'}
if(Test-Path -LiteralPath $taskProof){throw 'Fresh unique receipt/output directory required; preserve every prior negative'}
$taskCompiler=[IO.Path]::GetDirectoryName($taskWorkspace.zig)
$taskZig=$taskWorkspace.zig
$taskCi=Join-Path $taskRoot 'tools/ci/native_qualification_ci.ps1'
$taskProtocol=Join-Path $taskRoot 'tools/ci/Invoke-NativeTestProtocol.ps1'
$taskLayout=Join-Path $taskContainer '.pi-zig-workspace.json'
$taskCompilerManifest=Join-Path $taskWorkspace.evidence 'durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
$taskAcceptance=Join-Path $taskWorkspace.evidence 'typebox-package-authoring-independent-acceptance-20261016.json'
foreach($seal in @(
 @{path=$PSCommandPath;hash=$taskGrant.driver_sha256},@{path=$taskResolver;hash=$taskGrant.workspace_resolver_sha256},@{path=$taskLayout;hash=$taskGrant.workspace_layout_sha256},@{path=$taskWorkspace.path_relocations;hash=$taskGrant.path_relocations_sha256},
 @{path=$taskCi;hash='607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285'},@{path=$taskProtocol;hash='39F273D35A5B28E9D60FBE93355828314458A67FB472D60E0A8A6D4DD1FB704D'},
 @{path=$taskZig;hash='086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864'},@{path=$taskCompilerManifest;hash='DEE259F171F720AB2C08E8DD473975E22C876417CD62E4F016C71A7C662794EB'},
 @{path=$taskAcceptance;hash='466EE4FBE21B155C16B24FFD4C804549A6CB0FADD435CFD6F33820ECC54F5EFB'}
)){if(!$seal.hash-or(Get-FileHash -LiteralPath $seal.path -Algorithm SHA256).Hash-cne$seal.hash){throw "Exact reviewed control/tool authority differs: $($seal.path)"}}
. $taskCi
. $taskProtocol
$taskPrefix=Join-Path $taskProof 'installed'
$taskCache=Contained (Join-Path $taskWorkspace.evidence 'root-typebox-component-first38a8-20261016/cache') $taskWorkspace.evidence
$taskGlobalCache=Contained (Join-Path $taskWorkspace.evidence 'root-typebox-component-first38a8-20261016/global-cache') $taskWorkspace.evidence
# Reused caches are unsealed build outputs, never source/tool authority.
if($taskGrant.reuse_unsealed_original_compile_caches-ne$true-or$taskGrant.cache_directory-cne$taskCache-or$taskGrant.global_cache_directory-cne$taskGlobalCache){throw 'Explicit Root permission for exact original unsealed caches required'}
$taskBinary=Join-Path $taskPrefix 'bin/test.exe'
$taskPdb=Join-Path $taskPrefix 'bin/test.pdb'
$taskExpectedNames=@(
 'native_typebox_compile_production_test.test.actual TypeBox Compile Validator matches complete genuine Source80',
 'native_typebox_compile_production_test.test.actual provider schemas Partial and Memory match genuine Source52 on shared compiler graph',
 'native_typebox_compile_production_test.test.actual TypeBox generic operators match complete genuine Source396 on shared compiler graph',
 'extensions.native_durable_storage.test_0'
)
$taskFixed=@(
 @{path='src/extensions/native_typebox_compile_ir.zig';sha256='BBBC4E2CD596F3BCC17DC5F1449EBF24118D54F8E295F31A594F704918B5D655'},
 @{path='vendor/quickjs/quickjs.c';sha256='2FA2E26E35B7D5C45D1FFD3F6F10EE3A5DE9A984738486128399A20BD8E4D88D'},
 @{path='vendor/quickjs/quickjs.h';sha256='341CF06F8041B8311D49767026C85C7B859BCFEE3088380F3FFE6D77527052AB'},
 @{path='src/extensions/native_typebox_operators_production.zig';sha256='BF583CCD1D6A92A4FED0D7D4ED17422FDFBE0E7B261444A65D3C287FBB3F3FB1'},
 @{path='src/extensions/fixtures/typebox-compile-production.input.mjs';sha256='B7DC5B8F18B42E70410438DE323B408D4BB268CF45E19BE923952D9097BE60AB'},
 @{path='src/extensions/fixtures/typebox-compile-production.json';sha256='54303EE9477C4632F408963887DD58E5103775D1C8B75B37DF8F27A020984DE2'},
 @{path='src/extensions/fixtures/ai-model-schemas-partial-4954.input.mjs';sha256='EB4619FFE139943A7227B61D4A793A2B0D24C22F7C1037784AF066E17C7C9B34'},
 @{path='src/extensions/fixtures/ai-model-schemas-partial-4954.json';sha256='A29A7FF43504C73BA436AA697D284C86F08E67F7965BA99603E100ED5F77D742'},
 @{path='src/extensions/fixtures/typebox-operators-production.input.txt';sha256='37CEEAC103C70BF1C587F03CAA11C5EE4EC0A6AE414222D8653116E94DB5C9AA'},
 @{path='src/extensions/fixtures/typebox-operators-production.expected.json';sha256='888586A031E42C1C33A4A119F7196F5EE3E60A6466B1D9712BD28E28186E728C'}
)
$taskControlPaths=@($PSCommandPath,$RootGrant,$taskResolver,$taskLayout,$taskWorkspace.path_relocations,$taskCompilerManifest,$taskAcceptance,$taskCi,$taskProtocol)
$taskOriginalCompiler=Get-Content -LiteralPath $taskCompilerManifest -Raw|ConvertFrom-Json
$taskMap=Get-Content -LiteralPath $taskWorkspace.path_relocations -Raw|ConvertFrom-Json
$taskMappedCompiler=$null
foreach($mapping in @($taskMap.mappings|Sort-Object {$_.old.Length} -Descending)){
 $old=[IO.Path]::GetFullPath([string]$mapping.old);$historical=[IO.Path]::GetFullPath([string]$taskOriginalCompiler.root)
 if($historical-eq$old-or$historical.StartsWith($old+'\',[StringComparison]::OrdinalIgnoreCase)){$taskMappedCompiler=[IO.Path]::GetFullPath([string]$mapping.new+$historical.Substring($old.Length));break}
}
if($taskMap.schema-ne1-or$taskMappedCompiler-cne$taskCompiler-or@($taskOriginalCompiler.inputs).Count-ne19546){throw 'Explicit historical compiler relocation/count differs'}
$taskExpectedCompiler=@(foreach($row in $taskOriginalCompiler.inputs){$relative=[IO.Path]::GetRelativePath([string]$taskOriginalCompiler.root,[string]$row.path).Replace('\','/');if([IO.Path]::IsPathRooted($relative)-or$relative-eq'..'-or$relative.StartsWith('../')){throw 'Historical compiler row escapes its root'};[ordered]@{relative=$relative;sha256=[string]$row.sha256}})
[void](New-Item -ItemType Directory -Path $taskProof)
function Save-Json($Value,[string]$Name,[int]$Depth=10){$Value|ConvertTo-Json -Depth $Depth|Set-Content -LiteralPath (Join-Path $taskProof $Name) -Encoding utf8NoBOM}
$taskAdmissions=[Collections.Generic.List[object]]::new()
function Get-TaskProcesses {
 $rows=@(Get-CimInstance Win32_Process -OperationTimeoutSec 5 -ErrorAction Stop)
 if(!$rows.Count){throw 'Complete process census unavailable'}
 return $rows
}
function Select-TaskNative($Rows){
 @($Rows|Where-Object{$_.Name-in@('zig','zig.exe','build','build.exe','test','test.exe')-or($_.ExecutablePath-and([IO.Path]::GetFileName($_.ExecutablePath)-in@('zig','zig.exe','build','build.exe','test','test.exe')-or$_.ExecutablePath-match'[\\/](?:\.zig-cache|zig-out)[\\/]'-or$_.ExecutablePath.StartsWith($taskProof+'\',[StringComparison]::OrdinalIgnoreCase)))})
}
function Assert-TaskAdmission([string]$Phase){
 $watch=[Diagnostics.Stopwatch]::StartNew();$probes=[Collections.Generic.List[object]]::new()
 try{do{
  $os=Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 5 -ErrorAction Stop
  if($null-eq$os.FreePhysicalMemory){throw 'Memory census unavailable'}
  $roots=@(Select-TaskNative (Get-TaskProcesses))
  $probe=[ordered]@{phase=$Phase;free_kib=[uint64]$os.FreePhysicalMemory;minimum_kib=16777216;native_roots=$roots.Count;native=@($roots|Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,CreationDate);elapsed_seconds=$watch.Elapsed.TotalSeconds;utc=[DateTimeOffset]::UtcNow.ToString('o')}
  $probes.Add($probe);$taskAdmissions.Add($probe)
  if($roots.Count){throw 'Other/unknown native roots prevent serial admission'}
  if($watch.Elapsed.TotalSeconds-ge54){throw 'Fresh admission54-second deadline expired before acceptance'}
  if($os.FreePhysicalMemory-ge16777216){Save-Json ([ordered]@{status='admitted';phase=$Phase;probe=$probe;accepted_elapsed_seconds=$watch.Elapsed.TotalSeconds;probes=$probes.ToArray()}) "$Phase-admission.json";return}
  $remaining=54000-$watch.ElapsedMilliseconds
  if($remaining-le0){throw 'Fresh admission deadline expired'}
  Start-Sleep -Milliseconds ([int][Math]::Min(1000,$remaining))
 }while($true)}catch{Save-Json ([ordered]@{status='denied';phase=$Phase;error=[string]$_;elapsed_seconds=$watch.Elapsed.TotalSeconds;probes=$probes.ToArray()}) "$Phase-admission.json";throw}
}
function Get-TaskSeal([string]$Name){
 $seal=[ordered]@{candidate_head=$null;clean=$false;source=@();tree=@();vendor=@();compiler=@();controls=@();errors=@()}
 try{$seal.candidate_head=([string](git --no-optional-locks -C $taskRoot rev-parse HEAD)).Trim();if($LASTEXITCODE-ne0){throw 'git head unavailable'};$seal.clean=@(git --no-optional-locks -C $taskRoot status --porcelain).Count-eq0;if($LASTEXITCODE-ne0){throw 'git clean state unavailable'}}catch{$seal.errors+=,[ordered]@{group='identity';error=[string]$_}}
 foreach($group in @('source','tree','vendor','compiler','controls')){try{
  switch($group){
   source{$paths=@(git --no-optional-locks -C $taskRoot ls-files);if($LASTEXITCODE-ne0){throw 'Tracked inventory unavailable'};$seal.source=@(Get-CiRows $taskRoot $paths)}
   tree{$seal.tree=@((Get-CiInventory $taskRoot tree @('.git','.zig-cache','zig-out')).rows)}
   vendor{$seal.vendor=@((Get-CiInventory (Join-Path $taskRoot 'vendor')).rows)}
   compiler{$seal.compiler=@((Get-CiInventory $taskCompiler).rows)}
   controls{$seal.controls=@(foreach($path in $taskControlPaths){[ordered]@{relative=[IO.Path]::GetFullPath($path);path=[IO.Path]::GetFullPath($path);sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}})}
  }
 }catch{$seal.errors+=,[ordered]@{group=$group;error=[string]$_}}}
 Save-Json $seal "$Name.json" 8
 return $seal
}
function Assert-Rows($Actual,$Expected,[string]$Group){
 $left=@($Actual|ForEach-Object{$_.relative+' '+$_.sha256});$right=@($Expected|ForEach-Object{$_.relative+' '+$_.sha256})
 if(@(Compare-Object $left $right -CaseSensitive).Count){throw "$Group inventory/hash drift"}
}
function Assert-TaskSeal($Actual,$Expected){
 if($Actual.errors.Count-or!$Actual.clean-or$Actual.candidate_head-cne$taskHead){throw 'Complete clean exact-head source seal failed'}
 if($Actual.compiler.Count-ne19546){throw 'Complete compiler19546 required'}
 Assert-Rows $Actual.compiler $taskExpectedCompiler 'original compiler19546'
 foreach($fixed in $taskFixed){$found=@($Actual.source|Where-Object relative -CEQ $fixed.path);if($found.Count-ne1-or$found[0].sha256-cne$fixed.sha256){throw "Fixed C/H/module/fixture identity differs: $($fixed.path)"}}
 if($null-ne$Expected){foreach($group in @('source','tree','vendor','compiler','controls')){Assert-Rows $Actual[$group] $Expected[$group] $group}}
}
function Get-TaskArtifacts([string]$Name){
 $artifact=[ordered]@{installed=@();cached_executables=@();pe=$null;errors=@()}
 foreach($path in @($taskBinary,$taskPdb)){try{if(Test-Path -LiteralPath $path -PathType Leaf){$artifact.installed+=,[ordered]@{path=$path;bytes=(Get-Item -LiteralPath $path).Length;sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}}}catch{$artifact.errors+=,[string]$_}}
 try{if(Test-Path -LiteralPath $taskCache){$artifact.cached_executables=@(Get-ChildItem -LiteralPath $taskCache -File -Filter test.exe -Recurse|ForEach-Object{[ordered]@{path=$_.FullName;sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}})}}catch{$artifact.errors+=,[string]$_}
 if(Test-Path -LiteralPath $taskBinary -PathType Leaf){try{
  $bytes=[IO.File]::ReadAllBytes($taskBinary);if($bytes.Length-lt64){throw 'Truncated PE image'};$offset=[BitConverter]::ToInt32($bytes,0x3c)
  if($offset-lt0-or$offset+112-gt$bytes.Length-or[BitConverter]::ToUInt32($bytes,$offset)-ne0x4550-or[BitConverter]::ToUInt16($bytes,$offset+24)-ne0x20b){throw 'Expected PE32+ executable'}
  $artifact.pe=[ordered]@{reserved_stack_bytes=[BitConverter]::ToUInt64($bytes,$offset+24+72);committed_stack_bytes=[BitConverter]::ToUInt64($bytes,$offset+24+80);Engine_guard_bytes=1048576;guard_authority='Frozen Engine default1MiB; three test engines override only host await10000ms';dynamic_stack_measured=$false}
 }catch{$artifact.errors+=,[string]$_}}
 Save-Json $artifact "$Name-artifacts.json"
 return $artifact
}
function Assert-TaskArtifacts($Actual,$Expected){
 if($Actual.errors.Count-or$Actual.installed.Count-ne2-or$null-eq$Actual.pe-or$Actual.pe.reserved_stack_bytes-ne16777216){throw 'Exact executable/PDB and previous16MiB PE reserve required'}
 $exe=@($Actual.installed|Where-Object path -CEQ $taskBinary)
 if($exe.Count-ne1-or@($Actual.cached_executables|Where-Object sha256 -CEQ $exe[0].sha256).Count-ne1){throw 'Exactly one matching cached/installed executable required'}
 if($null-ne$Expected){foreach($group in @('installed')){if(@(Compare-Object @($Actual[$group]|ForEach-Object{$_.path+' '+$_.sha256}) @($Expected[$group]|ForEach-Object{$_.path+' '+$_.sha256}) -CaseSensitive).Count){throw 'Compiled artifact changed between phases'}}}
 if($null-ne$Expected){
  $originalExe=@($Expected.installed|Where-Object path -CEQ $taskBinary)[0]
  $beforeMatch=@($Expected.cached_executables|Where-Object sha256 -CEQ $originalExe.sha256)
  $afterMatch=@($Actual.cached_executables|Where-Object sha256 -CEQ $exe[0].sha256)
  if($beforeMatch.Count-ne1-or$afterMatch.Count-ne1-or$beforeMatch[0].path-cne$afterMatch[0].path){throw 'Exact current matching cached executable identity drift'}
 }
}
function Get-PhaseEvidence([string]$Phase){
 $record=[ordered]@{owner=$null;canonical_results=$null;raw_outputs=@();current_owner_pid_present=$null;current_owned_descendants=@();absence_error=$null}
 $ownerPath=Join-Path $taskProof "$Phase.json"
 if(Test-Path -LiteralPath $ownerPath){$record.owner=Get-Content -LiteralPath $ownerPath -Raw|ConvertFrom-Json;try{$rows=@(Get-TaskProcesses);$record.current_owner_pid_present=@($rows|Where-Object ProcessId -EQ $record.owner.pid).Count;$parents=@([int]$record.owner.pid);do{$children=@($rows|Where-Object{$_.ParentProcessId-in$parents-and$_.ProcessId-notin$parents});if(!$children.Count){break};$record.current_owned_descendants+=@($children|Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,CreationDate);$parents+=@($children.ProcessId)}while($true)}catch{$record.absence_error=[string]$_}}
 foreach($path in @((Join-Path $taskProof "$Phase.stdout.bin"),(Join-Path $taskProof "$Phase.stderr.log"))){if(Test-Path -LiteralPath $path){$record.raw_outputs+=,[ordered]@{path=$path;bytes=(Get-Item -LiteralPath $path).Length;sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}}}
 if(Test-Path -LiteralPath (Join-Path $taskProof "$Phase.results.json")){$record.canonical_results=Get-Content -LiteralPath (Join-Path $taskProof "$Phase.results.json") -Raw|ConvertFrom-Json}
 return $record
}
function Observe-RuntimeFrames {
 $path=Join-Path $taskProof 'runtime.stdout.bin';$observation=[ordered]@{scope='Raw complete protocol frames including partial failure evidence; never acceptance authority';frames=@();parse_error=$null;trailing_bytes=0}
 if(Test-Path -LiteralPath $path){try{$bytes=[IO.File]::ReadAllBytes($path);$offset=0;while($offset-lt$bytes.Length){if($bytes.Length-$offset-lt8){$observation.trailing_bytes=$bytes.Length-$offset;break};$tag=[BitConverter]::ToUInt32($bytes,$offset);$length=[BitConverter]::ToUInt32($bytes,$offset+4);$offset+=8;if($length-gt1MB-or$length-gt$bytes.Length-$offset){$observation.trailing_bytes=$bytes.Length-$offset;throw 'Incomplete/invalid raw frame body'};$frame=[ordered]@{tag=$tag;length=$length};if($tag-eq0){$frame.version=[Text.Encoding]::UTF8.GetString($bytes,$offset,$length)};if($tag-eq4-and$length-eq12){$frame.index=[BitConverter]::ToUInt32($bytes,$offset);$frame.flags=[BitConverter]::ToUInt64($bytes,$offset+4)};$observation.frames+=,$frame;$offset+=$length}}catch{$observation.parse_error=[string]$_}}
 Save-Json $observation 'runtime-raw-frame-observation.json'
}
$taskResult=[ordered]@{status='running';scope='Exact Root1f9eee9e TypeBox80/52/396 component only';candidate_head=$taskHead;runtime_restoration_claim=$false;full_pi_qualified=$false;frame_measurement=$false;GPA_executed=$false;runtime_outer_actual_seconds=120;runtime_outer_plan_maximum_seconds=300;per_test_upper_bound_seconds=120;per_test_bound_method='Whole canonical protocol batch120 implies each test<=120; no independent direct-protocol per-test timer claimed';guest_await_milliseconds=10000;phases=[ordered]@{};postseal=$false;errors=@();absence=$null}
$taskBefore=$null;$taskArtifact=$null
try{
 $engine=Get-Content -LiteralPath (Join-Path $taskRoot 'src/extensions/engine.zig') -Raw
 $test=Get-Content -LiteralPath (Join-Path $taskRoot 'src/native_typebox_compile_production_test.zig') -Raw
 if($engine-notmatch'stack_limit:\s*usize\s*=\s*1024\s*\*\s*1024'-or[regex]::Matches($test,'\.host_await_timeout_ms\s*=\s*10000').Count-ne3-or$test-match'\.stack_limit\s*='){throw 'Unchanged1MiB/default engines and three10s awaits required'}
 $taskBefore=Get-TaskSeal 'before';Assert-TaskSeal $taskBefore $null
 $compileArgs=@('build','build-native-typebox-production-source','-Doptimize=Debug','-Duse-llvm=true','-Ddiagnostic-tests=false','-j1','--test-timeout','120s','--prefix',$taskPrefix,'--cache-dir',$taskCache,'--global-cache-dir',$taskGlobalCache,'--summary','all')
 Save-Json ([ordered]@{compile=$compileArgs;metadata=@('--listen=-');runtime=@('--listen=-');expected_tests=$taskExpectedNames;compile_outer_seconds=1320;metadata_outer_seconds=30;runtime_outer_actual_seconds=120;runtime_outer_plan_maximum_seconds=300;settle_seconds=10}) 'commands.json'
 foreach($phase in @('compile','metadata','runtime')){
  Assert-TaskSeal (Get-TaskSeal "$phase-before") $taskBefore
  if($phase-ne'compile'){Assert-TaskArtifacts (Get-TaskArtifacts "$phase-before") $taskArtifact}
  Assert-TaskAdmission $phase
  $phaseFailure=$null
  try{
   switch($phase){
    compile{[void](Invoke-CiOwnedProcess $taskZig $compileArgs $taskRoot (Join-Path $taskProof 'compile') 1320)}
    metadata{$metadata=Read-CiTestMetadata $taskBinary $taskRoot (Join-Path $taskProof 'metadata') 4;Save-Json $metadata 'selected-tests.json';if([string]::Join("`n",@($metadata.tests))-cne[string]::Join("`n",$taskExpectedNames)){throw 'Exact four metadata names/order required'}}
    runtime{[void](Invoke-NativeTestProtocol -Binary $taskBinary -Root $taskRoot -Receipt (Join-Path $taskProof 'runtime') -ExpectedCount 4)}
   }
  }catch{$phaseFailure=[string]$_}finally{
   $evidence=Get-PhaseEvidence $phase;$taskResult.phases[$phase]=[ordered]@{failure=$phaseFailure;evidence=$evidence}
   $after=Get-TaskSeal "$phase-after";try{Assert-TaskSeal $after $taskBefore}catch{$taskResult.errors+=,[string]$_;if(!$phaseFailure){$phaseFailure=[string]$_}}
   $artifacts=Get-TaskArtifacts "$phase-after"
   if($phase-eq'compile'-and!$phaseFailure){$taskArtifact=$artifacts;try{Assert-TaskArtifacts $taskArtifact $null}catch{$taskResult.errors+=,[string]$_;$phaseFailure=[string]$_}}
   if($phase-ne'compile'){try{Assert-TaskArtifacts $artifacts $taskArtifact}catch{$taskResult.errors+=,[string]$_;if(!$phaseFailure){$phaseFailure=[string]$_}}}
   $roots=@(Select-TaskNative (Get-TaskProcesses));if($roots.Count-or$evidence.absence_error-or($evidence.owner-and($evidence.current_owner_pid_present-or$evidence.current_owned_descendants.Count))){if(!$phaseFailure){$phaseFailure='Phase-owned/global native absence failed'}}
   Save-Json ([ordered]@{phase=$phase;evidence=$evidence;global_native=@($roots|Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,CreationDate)}) "$phase-absence.json"
   if($phase-eq'runtime'){Observe-RuntimeFrames}
   $taskResult.phases[$phase].failure=$phaseFailure
  }
  if($phaseFailure){throw $phaseFailure}
  if(!$evidence.owner-or$evidence.owner.status-cne'passed'-or$evidence.owner.exit_code-ne0){throw 'Matching actual terminal0 owner receipt required'}
  $expectedDeadline=@{compile=1320;metadata=30;runtime=120}[$phase]
  if($evidence.owner.timeout_seconds-ne$expectedDeadline){throw 'Actual owner deadline differs from declared phase budget'}
  if($phase-ne'compile'-and$evidence.owner.executable_sha256-cne@($taskArtifact.installed|Where-Object path -CEQ $taskBinary)[0].sha256){throw 'Metadata/runtime used a different installed executable'}
 }
 $runtimeResults=$taskResult.phases.runtime.evidence.canonical_results
 if(!$runtimeResults-or$runtimeResults.status-cne'passed'-or$runtimeResults.started-ne4-or$runtimeResults.completed-ne4-or$runtimeResults.failed_or_skipped_or_logged_or_leaked-ne0){throw 'All four selected protocol tests must complete/pass without skips/logs/leaks'}
 $stderr=[IO.File]::ReadAllText((Join-Path $taskProof 'runtime.stderr.log'))
 foreach($marker in @('TYPEBOX_COMPILE_SOURCE_PARITY cases=80','TYPEBOX_PROVIDER_SCHEMA_SOURCE_PARITY cases=52','TYPEBOX_OPERATOR_SOURCE_PARITY cases=396')){if(!$stderr.Contains($marker)){throw "Missing original complete parity marker: $marker"}}
 $taskResult.status='passed'
}catch{$taskResult.status='failed';$taskResult.errors+=,[string]$_}finally{
 try{$final=Get-TaskSeal 'final';Assert-TaskSeal $final $taskBefore;$taskResult.postseal=$true}catch{$taskResult.status='failed_postseal';$taskResult.errors+=,[string]$_}
 try{$rows=@(Get-TaskProcesses);$roots=@(Select-TaskNative $rows);$owners=@(foreach($phase in @('compile','metadata','runtime')){$evidence=Get-PhaseEvidence $phase;if($evidence.owner){[ordered]@{phase=$phase;evidence=$evidence}}});$taskResult.absence=[ordered]@{native_roots=@($roots|Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,CreationDate);owners=$owners;utc=[DateTimeOffset]::UtcNow.ToString('o')};if($roots.Count-or@($owners|Where-Object{$_.evidence.absence_error-or$_.evidence.current_owner_pid_present-or$_.evidence.current_owned_descendants.Count}).Count){$taskResult.status='failed_absence'}}catch{$taskResult.status='failed_absence';$taskResult.errors+=,[string]$_}
 try{[void](Get-TaskArtifacts 'final')}catch{$taskResult.errors+=,[string]$_;$taskResult.status='failed_artifact_observation'}
 try{Observe-RuntimeFrames}catch{$taskResult.errors+=,[string]$_;$taskResult.status='failed_raw_observation'}
 $taskResult.admission_probes=$taskAdmissions.ToArray();$taskResult.completed_utc=[DateTimeOffset]::UtcNow.ToString('o');Save-Json $taskResult 'result.json' 16
}
$taskResult|ConvertTo-Json -Depth 16
if($taskResult.status-cne'passed'){throw 'TypeBox component gate terminal negative; preserve result/raw receipts and reconcile absence before another lease'}
