# Independently accepted PURE27 raw proof

This packet preserves the actual original Node direct-file18+9 tooling run at
3c0603d2d32122db2811774eae4fbbc04d843100, all six full source/tree/Node/control
seals, actual TAP and empty stderr, live owner and independent absence receipts,
outer parent terminal/absence evidence, exact original Node inventory authorities
and immutable control sources. The manifest maps every preserved byte to its
original contained path and SHA256. No Node executable, npm payload, compiler,
compiled artifact or cache is included.

The independent acceptance is limited to pure tooling assertions. It proves no
TypeBox source evaluation, native execution, runtime restoration, stack reduction,
GPA, product intake or hosted validation. The separately included package V2
wrapper is source-reviewed only: its exact helper-AST models demonstrate the
old SameFields parameter shadowing and the corrected later-field comparisons.
Its grant skeleton remains unauthorized; package authoring needs Root's separate
grant and actual output/seal/absence audit.
