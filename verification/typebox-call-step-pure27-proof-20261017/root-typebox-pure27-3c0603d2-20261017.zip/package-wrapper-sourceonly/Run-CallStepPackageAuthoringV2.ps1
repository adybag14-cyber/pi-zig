param([Parameter(Mandatory)][string]$RootGrant)
$ErrorActionPreference='Stop'
$taskContainer=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$taskResolver=Join-Path $taskContainer 'main/tools/workspace/Resolve-PiZigWorkspace.ps1'
$taskWorkspace=& $taskResolver -StartPath $PSScriptRoot
function Contained([string]$Path,[string]$Under){
 if(!$Path){throw 'Explicit contained path required'};$resolved=[IO.Path]::GetFullPath($Path);if(!$resolved.StartsWith([IO.Path]::GetFullPath($Under)+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Path escapes contained root'}
 $ancestor=[IO.DirectoryInfo]::new($resolved);while($ancestor){if($ancestor.Exists-and($ancestor.Attributes-band[IO.FileAttributes]::ReparsePoint)){throw 'Reparse ancestor rejected'};if($ancestor.FullName-eq$taskContainer){break};$ancestor=$ancestor.Parent};if((Test-Path -LiteralPath $resolved)-and((Get-Item -LiteralPath $resolved -Force).Attributes-band[IO.FileAttributes]::ReparsePoint)){throw 'Reparse leaf rejected'};return $resolved
}
$RootGrant=Contained $RootGrant $taskWorkspace.evidence
$taskGrant=Get-Content -LiteralPath $RootGrant -Raw|ConvertFrom-Json
$taskRoot=Join-Path $taskWorkspace.worktrees 'typebox'
$taskHead='3c0603d2d32122db2811774eae4fbbc04d843100'
$taskProof=Contained ([string]$taskGrant.receipt_directory) $taskWorkspace.evidence
if($taskGrant.status-cne'root_reviewed_typebox_static_package_authoring_release'-or$taskGrant.candidate_head-cne$taskHead-or$taskGrant.input_authority-cne'source_package_only'-or$taskGrant.runtime_restoration_claim-ne$false-or!$taskGrant.grant_id){throw 'Exact3c source-only package generation Root grant required'}
if(Test-Path -LiteralPath $taskProof){throw 'Fresh unique package proof directory required'}
$taskCaller=Join-Path $taskRoot 'verification/typebox-production-native-qualification-20261016/Run-OwnedStaticPackageAuthoring.ps1'
$taskGenerator=Join-Path $taskRoot 'verification/typebox-operators-production-20261016/lower-authority.mjs'
$taskOwner=Join-Path $taskWorkspace.main 'tools/ci/native_qualification_ci.ps1'
$taskToolingResult=Contained ([string]$taskGrant.tooling_result_path) $taskWorkspace.evidence
$taskBaseline=Join-Path $taskWorkspace.evidence 'root-typebox-package-authoring-20261016/staged/lowering-map.json'
$taskNodeManifest=Join-Path $taskWorkspace.evidence 'source4954-node-tools-before-20261015.json'
$taskPrefix=Join-Path $taskProof 'run';$taskOutput=Join-Path $taskProof 'staged'
if($taskGrant.receipt_base-cne$taskPrefix-or$taskGrant.output_directory-cne$taskOutput){throw 'Exact fresh run-prefix and staged output paths required'}
foreach($seal in @(
 @{path=$PSCommandPath;hash=$taskGrant.outer_driver_sha256},@{path=$taskCaller;hash='7049991E10FD9338CB9A2E4EBDF865CFD610A7F3C8D22F611FE8827F983C60A5'},
 @{path=$taskGenerator;hash='88E68EF4313978B41786A2D12A37B2B8380DCB020501248A2DF20959423193AD'},@{path=$taskOwner;hash='607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285'},
 @{path=$taskBaseline;hash='F1D8A2DD5B19745DACD6F092A0F06C19373CED6DAAE65493BFA93828AA225A2B'},@{path=$taskNodeManifest;hash='F834312AAC6AC8D79EF4B49CCB806096D80E92FCA403CC650A05E901D4C280DD'},
 @{path=$taskToolingResult;hash=$taskGrant.tooling_result_sha256}
)){if(!$seal.hash-or(Get-FileHash -LiteralPath $seal.path -Algorithm SHA256).Hash-cne$seal.hash){throw "Exact reviewed wrapper/prerequisite authority differs: $($seal.path)"}}
$taskPrerequisite=Get-Content -LiteralPath $taskToolingResult -Raw|ConvertFrom-Json
if($taskPrerequisite.status-cne'passed'-or$taskPrerequisite.candidate_head-cne$taskHead-or$taskPrerequisite.completed_cases-ne27-or$taskPrerequisite.postseal-ne$true-or@($taskPrerequisite.absence.native).Count-or@($taskPrerequisite.absence.owners).Count-ne2){throw 'Successful exact3c pure18+retained9 fullpost/absence receipt required'}
foreach($name in @('pure18','retained9')){$suite=$taskPrerequisite.suites.$name;if(!$suite-or$suite.failure-or$suite.evidence.owner.status-cne'passed'-or$suite.evidence.owner.exit_code-ne0-or$suite.evidence.owner_pid_present-or$suite.evidence.owned_descendants.Count-or$suite.evidence.absence_error){throw 'Both actual tooling suite owners must be terminal/absent'}}
if((git --no-optional-locks -C $taskRoot rev-parse HEAD).Trim()-cne$taskHead-or@(git --no-optional-locks -C $taskRoot status --porcelain).Count){throw 'Exact clean3c candidate required'}
. $taskOwner
[void](New-Item -ItemType Directory -Path $taskProof)
function Save($Value,[string]$Name){$Value|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $taskProof $Name) -Encoding utf8NoBOM}
$taskExternalPaths=@($PSCommandPath,$RootGrant,$taskCaller,$taskGenerator,$taskToolingResult,$taskBaseline,$taskNodeManifest,$taskOwner)
$taskControls=@(foreach($path in $taskExternalPaths){[ordered]@{path=$path;sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}})
Save $taskControls 'wrapper-frozen-controls.json'
function VerifyExternal([string]$Name){
 $errors=@(foreach($row in $taskControls){try{if((Get-FileHash -LiteralPath $row.path -Algorithm SHA256).Hash-cne$row.sha256){throw 'Control hash changed'}}catch{[ordered]@{path=$row.path;error=[string]$_}}})
 try{$expected=@(Get-Content -LiteralPath $taskNodeManifest -Raw|ConvertFrom-Json);$actual=@('node.exe '+(Get-FileHash -LiteralPath 'C:\Program Files\nodejs\node.exe' -Algorithm SHA256).Hash)+@((Get-CiInventory 'C:\Program Files\nodejs\node_modules\npm').rows|ForEach-Object{'node_modules/npm/'+$_.relative+' '+$_.sha256});$keys=@($expected|ForEach-Object{[IO.Path]::GetRelativePath('C:\Program Files\nodejs',[string]$_.path).Replace('\','/')+' '+$_.sha256});if($expected.Count-ne1774-or$actual.Count-ne1774-or@(Compare-Object $keys $actual -CaseSensitive).Count){throw 'Complete original Node1774 subset drift'};Save @{scope='Original full1774 subset; complete1838 also checked by reviewed caller';rows=$actual} "$Name-node1774.json"}catch{$errors+=,[ordered]@{path='Node1774';error=[string]$_}}
 Save @{phase=$Name;errors=$errors;runtime_restoration_claim=$false} "$Name-wrapper-seal.json";if($errors.Count){throw 'Complete wrapper/node1774 seal failed'}
}
function SameFields($Left,$Right,[string[]]$Fields){foreach($field in $Fields){$taskLeftJson=ConvertTo-Json -InputObject $Left.$field -Depth 12 -Compress;$taskRightJson=ConvertTo-Json -InputObject $Right.$field -Depth 12 -Compress;if($taskLeftJson-cne$taskRightJson){throw "Original metadata differs: $field"}}}
$result=[ordered]@{status='running';candidate_head=$taskHead;scope='Owned Acorn-only generation from pinned TypeBox1385/Acorn10 and Node1838/1774; no Source evaluation';runtime_restoration_claim=$false;postseal=$false;errors=@();caller_owner=$null;outputs=@();structural_checks=$null;native_compiled=$false;native_executed=$false;frame_reduction_claim=$false;product_intaken=$false;goldens_generated=$false}
try{
 VerifyExternal 'before'
 # The unchanged704 caller owns the only Node launch, with original token/60s/256MiB/10s.
 & $taskCaller -ReceiptBase $taskPrefix -OutputDirectory $taskOutput -RootGrant $RootGrant
 $validation=Get-Content -LiteralPath "$taskPrefix-validation.json" -Raw|ConvertFrom-Json
 if($validation.status-cne'static_package_authoring_terminal0_fullpost0'-or$validation.candidate_head-cne$taskHead-or$validation.runtime_restoration_claim-ne$false){throw 'Actual reviewed caller terminal0/fullpost0 required'}
 $result.caller_owner=Get-Content -LiteralPath "$taskPrefix-owner.json" -Raw|ConvertFrom-Json
 $map=Get-Content -LiteralPath (Join-Path $taskOutput 'lowering-map.json') -Raw|ConvertFrom-Json
 $old=Get-Content -LiteralPath $taskBaseline -Raw|ConvertFrom-Json
 if(@($map.functions).Count-ne1669-or@($map.branches).Count-ne585-or$map.tryHelpers-ne1-or$map.callSetup.selectedCallbacks-ne24-or@($map.callSetup.helpers).Count-ne165){throw 'Original1669/585/1/24/165 scope differs'}
 $functionFields=@('nativeCallback','source','start','end','sourceDeclarationSha256','name','length','arrow','originalUsesReceiver','originalUsesArgs','originalUsesEnv','heapOperandSlots','originalOperandSlots','appendedArgumentSlots','callArgumentSlices','setupDescriptorSlots','setupDescriptors')
 for($i=0;$i-lt1669;$i++){SameFields $map.functions[$i] $old.functions[$i] $functionFields}
 for($i=0;$i-lt585;$i++){SameFields $map.branches[$i] $old.branches[$i] @('nativeHelper','source','start','end','iterativeJumpChained')}
 $helperFields=@('nativeHelper','owner','bodyKind','bodyId','source','start','end','sourceExpressionSha256','originalLines','descriptorOffset','noinline','declaredLocals','abiNeeds','nestedHelpers')
 for($i=0;$i-lt165;$i++){SameFields $map.callSetup.helpers[$i] $old.callSetup.helpers[$i] $helperFields}
 if($map.callSetup.originalFreshSerial-ne$old.callSetup.originalFreshSerial-or$map.callSetup.identityFrozen-ne$true-or@($map.callSetup.selectedModules).Count-ne2-or(($map.functions|Measure-Object setupDescriptorSlots -Sum).Sum)-ne330){throw 'Original serial/flags/330 descriptor scope differs'}
 SameFields $map.callSetup $old.callSetup @('selectedModules','selectedCallbacks','originalFreshSerial','identityFrozen')
 $steps=@($map.callSetup.actualCallSteps.steps);$shared=@($map.callSetup.actualCallSteps.sharedHelpers)
 if($steps.Count-ne165-or$map.callSetup.actualCallSteps.count-ne165-or@($steps|Where-Object construct -EQ $true).Count-or@($steps|Where-Object emptyArguments -EQ $true).Count-ne4-or$shared.Count-ne2-or$shared[0].nativeHelper-cne'invokePrepared'-or$shared[0].recordedUses-ne165-or$shared[0].noinline-ne$true-or$shared[1].nativeHelper-cne'constructPrepared'-or$shared[1].recordedUses-ne0-or$shared[1].noinline-ne$true-or$shared[1].constructorPathExercised-ne$false){throw 'Actual165invoke/0construct/4empty/two noinline step scope differs'}
 for($i=0;$i-lt165;$i++){
  $step=$steps[$i];$helper=$map.callSetup.helpers[$i];$owner=@($map.functions|Where-Object nativeCallback -CEQ ('f_'+$step.owner.Substring(1)))
  if($owner.Count-ne1-or$step.id-ne$i-or$step.nativeHelper-cne'invokePrepared'-or$step.preparationHelper-cne$helper.nativeHelper-or$step.owner-cne$helper.owner-or$step.noinline-ne$true-or$step.resultIndex-lt0-or$step.resultIndex-ge$owner[0].originalOperandSlots-or$step.argumentOwner-cne$step.owner-or$step.originalCallLine-ne$helper.originalLines.call-or$step.descriptorOffset-ne$helper.descriptorOffset){throw 'Actual step owner/result/call/descriptor metadata differs'}
  SameFields $step $helper @('bodyKind','bodyId','source','start','end','sourceExpressionSha256')
  $descriptor=$owner[0].originalOperandSlots+$owner[0].appendedArgumentSlots+$step.descriptorOffset
  if($step.absoluteDescriptorStart-ne$descriptor-or$descriptor+1-ge$owner[0].heapOperandSlots){throw 'Actual descriptor pair escapes existing owner'}
  if($step.emptyArguments){if($step.argumentOffset-ne0-or$step.argumentCount-ne0-or$step.absoluteArgumentStart-ne0-or$step.absoluteArgumentEnd-ne0){throw 'Actual empty arguments must be zero-zero without slots'}}else{if($step.argumentCount-le0-or$step.absoluteArgumentStart-ne($owner[0].originalOperandSlots+$step.argumentOffset)-or$step.absoluteArgumentEnd-ne($step.absoluteArgumentStart+$step.argumentCount)-or@($owner[0].callArgumentSlices|Where-Object{$_.start-eq$step.absoluteArgumentStart-and$_.count-eq$step.argumentCount}).Count-ne1){throw 'Actual argument slice differs from one exact original range'}}
 }
 $native=[IO.File]::ReadAllText((Join-Path $taskOutput 'native_typebox_operators_production.zig'))
 if([regex]::Matches($native,'(?m)^noinline fn invokePrepared\(').Count-ne1-or[regex]::Matches($native,'(?m)^noinline fn constructPrepared\(').Count-ne1-or[regex]::Matches($native,'(?m)^try invokePrepared\(s, native_values,').Count-ne165-or[regex]::Matches($native,'(?m)^try constructPrepared\(').Count-ne0-or[regex]::Matches($native,'(?m)^noinline fn call_setup_\d+\(').Count-ne165-or[regex]::Matches($native,'gpa\.create\(rt\.Scope\)').Count-ne1670){throw 'Actual native source helper/call/scope counts differ'}
 foreach($pair in @(@{name='reachable-closure.json';hash='4E718CCE679A362BCC74A02F6FA717A61240619FA6D1B83BB394706476DC4F93'},@{name='initialization-order.json';hash='C4BB3782E6353A073B34842E8D64BCE12E0C318476D69E4F6106DC8BEF9667ED'})){if((Get-FileHash -LiteralPath (Join-Path $taskOutput $pair.name) -Algorithm SHA256).Hash-cne$pair.hash){throw 'Original reachable/init authority differs'}}
 $result.outputs=@($validation.outputs);$result.structural_checks=@{callbacks=1669;branches=585;tries=1;selected_callbacks=24;preparation_helpers=165;descriptor_slots=330;actual_call_steps=165;invokes=165;constructs=0;empty_arguments=4;shared_helpers=2;callback_scope_allocations=1670;original_metadata_drift=0};$result.status='passed'
}catch{$result.status='failed';$result.errors+=,[string]$_}finally{
 try{VerifyExternal 'after';$result.postseal=$true}catch{$result.status='failed_postseal';$result.errors+=,[string]$_}
 if(Test-Path -LiteralPath "$taskPrefix-owner.json"){$result.caller_owner=Get-Content -LiteralPath "$taskPrefix-owner.json" -Raw|ConvertFrom-Json}
 if(Test-Path -LiteralPath "$taskPrefix-absence.json"){$result.absence=Get-Content -LiteralPath "$taskPrefix-absence.json" -Raw|ConvertFrom-Json}else{$result.absence=$null}
 if($result.caller_owner-and(!$result.absence-or$result.absence.owner_pid_present-or@($result.absence.global_native).Count)){$result.status='failed_absence'}
 if(Test-Path -LiteralPath "$taskPrefix-output-after.json"){$result.actual_output_observation=Get-Content -LiteralPath "$taskPrefix-output-after.json" -Raw|ConvertFrom-Json}
 $result.completed_utc=[DateTimeOffset]::UtcNow.ToString('o');Save $result 'wrapper-result.json'
}
$result|ConvertTo-Json -Depth 12
if($result.status-cne'passed'){throw 'Call-step source authoring terminal negative; preserve actual four/partial outputs and receipts'}
