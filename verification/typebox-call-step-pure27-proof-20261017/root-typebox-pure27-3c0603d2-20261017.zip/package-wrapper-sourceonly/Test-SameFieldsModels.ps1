# Pure PowerShell model checks only. Extract one helper; never invoke either driver.
$ErrorActionPreference='Stop'
$old=Join-Path $PSScriptRoot 'Run-CallStepPackageAuthoring.ps1'
$successor=Join-Path $PSScriptRoot 'Run-CallStepPackageAuthoringV2.ps1'
if((Get-FileHash -LiteralPath $old -Algorithm SHA256).Hash-cne'84AAD84613EC1C47F34E705B4EB1195B2FAFC2F231C8F66FD7CFB4613123D479'){throw 'Original84AAD authority differs'}
if(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'same-fields-model-results.json')){throw 'Preserve previous model result'}
function ExtractHelper([string]$Path){$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($Path,[ref]$tokens,[ref]$errors);if($errors.Count){throw 'Driver source parse failed'};$functions=@($ast.FindAll({param($node)$node-is[Management.Automation.Language.FunctionDefinitionAst]-and$node.Name-ceq'SameFields'},$true));if($functions.Count-ne1){throw 'Exactly one actual helper required'};return $functions[0].Extent.Text}
$legacy=ExtractHelper $old;$fixed=ExtractHelper $successor
. ([scriptblock]::Create($legacy.Replace('function SameFields(','function LegacySameFields(')))
. ([scriptblock]::Create($fixed))
function Clone($Value){ConvertFrom-Json -InputObject (ConvertTo-Json -InputObject $Value -Depth 12 -Compress)}
$function=[pscustomobject][ordered]@{nativeCallback='f_628';source='type/engine/call/instantiate.mjs';start=3039;length=4;heapOperandSlots=94;callArgumentSlices=@([pscustomobject]@{start=55;count=3})}
$branch=[pscustomobject][ordered]@{nativeHelper='branch_445';source='type/engine/call/instantiate.mjs';start=3353;end=3550;iterativeJumpChained=$true}
$helper=[pscustomobject][ordered]@{nativeHelper='call_setup_154';owner='f628';bodyId=445;originalLines=[pscustomobject]@{start=1;calleeEnd=2;end=4;call=4};abiNeeds=[pscustomobject]@{s=$true;receiver=$false};nestedHelpers=@('call_setup_155')}
$models=@(
 @{name='function';value=$function;fields=@('nativeCallback','source','start','length','heapOperandSlots','callArgumentSlices')},
 @{name='branch';value=$branch;fields=@('nativeHelper','source','start','end','iterativeJumpChained')},
 @{name='helper';value=$helper;fields=@('nativeHelper','owner','bodyId','originalLines','abiNeeds','nestedHelpers')}
)
$results=[Collections.Generic.List[object]]::new()
foreach($model in $models){SameFields (Clone $model.value) (Clone $model.value) $model.fields;$results.Add([ordered]@{case=$model.name+' identical metadata';fixed_accepts=$true;expected='accept'})}
$mutations=@(
 @{name='function nonfirst source';model=0;field='source';change={param($value)$value.source='wrong/module.mjs'}},
 @{name='function later scalar length';model=0;field='length';change={param($value)$value.length=99}},
 @{name='function later nested argument count';model=0;field='callArgumentSlices';change={param($value)$value.callArgumentSlices[0].count=2}},
 @{name='branch nonfirst source';model=1;field='source';change={param($value)$value.source='wrong/module.mjs'}},
 @{name='branch later end';model=1;field='end';change={param($value)$value.end=3551}},
 @{name='helper nonfirst owner';model=2;field='owner';change={param($value)$value.owner='f9'}},
 @{name='helper later nested call boundary';model=2;field='originalLines';change={param($value)$value.originalLines.call=5}},
 @{name='helper later ABI flag';model=2;field='abiNeeds';change={param($value)$value.abiNeeds.receiver=$true}},
 @{name='helper later nested edge';model=2;field='nestedHelpers';change={param($value)$value.nestedHelpers[0]='call_setup_156'}}
)
foreach($mutation in $mutations){
 $model=$models[$mutation.model];$modelLeft=Clone $model.value;$modelRight=Clone $model.value;& $mutation.change $modelRight
 $legacyRejected=$false;try{LegacySameFields $modelLeft $modelRight $model.fields}catch{$legacyRejected=$true}
 $fixedRejected=$false;$failure=$null;try{SameFields $modelLeft $modelRight $model.fields}catch{$fixedRejected=$true;$failure=[string]$_}
 if($legacyRejected-or!$fixedRejected-or$failure-notlike('*Original metadata differs: '+$mutation.field+'*')){throw ('Actual helper mutation check failed: '+$mutation.name)}
 $results.Add([ordered]@{case=$mutation.name;changed_field=$mutation.field;legacy84AAD_incorrectly_accepts=$true;fixed_rejects=$fixedRejected;actual_error=$failure;expected='reject'})
}
$receipt=[ordered]@{status='passed';scope='Pure PowerShell models of exact extracted SameFields helpers; no complete driver, Node, generator or native execution';original_path=$old;original_sha256=(Get-FileHash -LiteralPath $old -Algorithm SHA256).Hash;successor_path=$successor;successor_sha256=(Get-FileHash -LiteralPath $successor -Algorithm SHA256).Hash;test_sha256=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash;identical_accepts=3;later_field_mutations_rejected=9;cases=$results.ToArray();Node_generator_compiler_native_jobs=0;completed_utc=[DateTimeOffset]::UtcNow.ToString('o')}
$receipt|ConvertTo-Json -Depth 10|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'same-fields-model-results.json') -Encoding utf8NoBOM
$receipt|ConvertTo-Json -Depth 6
