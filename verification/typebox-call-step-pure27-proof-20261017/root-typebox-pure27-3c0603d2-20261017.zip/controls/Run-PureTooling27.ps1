param([Parameter(Mandatory)][string]$RootGrant)
$ErrorActionPreference='Stop'
$taskContainer=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$taskResolver=Join-Path $taskContainer 'main/tools/workspace/Resolve-PiZigWorkspace.ps1'
$taskWorkspace=& $taskResolver -StartPath $PSScriptRoot
function Contained([string]$Path,[string]$Under){
 if(!$Path){throw 'Explicit contained path required'};$resolved=[IO.Path]::GetFullPath($Path)
 if(!$resolved.StartsWith([IO.Path]::GetFullPath($Under)+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Path escapes contained root'}
 $ancestor=[IO.DirectoryInfo]::new($resolved);while($ancestor){if($ancestor.Exists-and($ancestor.Attributes-band[IO.FileAttributes]::ReparsePoint)){throw 'Reparse ancestor rejected'};if($ancestor.FullName-eq$taskContainer){break};$ancestor=$ancestor.Parent}
 if((Test-Path -LiteralPath $resolved)-and((Get-Item -LiteralPath $resolved -Force).Attributes-band[IO.FileAttributes]::ReparsePoint)){throw 'Reparse leaf rejected'};return $resolved
}
$RootGrant=Contained $RootGrant $taskWorkspace.evidence
$taskGrant=Get-Content -LiteralPath $RootGrant -Raw|ConvertFrom-Json
$taskRoot=Contained ([string]$taskGrant.candidate_root) $taskWorkspace.worktrees
$taskProof=Contained ([string]$taskGrant.receipt_directory) $taskWorkspace.evidence
$taskHead='3c0603d2d32122db2811774eae4fbbc04d843100'
if($taskGrant.status-cne'root_reviewed_typebox_pure_tooling27_release'-or$taskGrant.candidate_head-cne$taskHead-or$taskRoot-cne(Join-Path $taskWorkspace.worktrees 'typebox')-or!$taskGrant.grant_id-or$taskGrant.runtime_restoration_claim-ne$false){throw 'Exact clean3c pure18+retained9 Root release required'}
if(Test-Path -LiteralPath $taskProof){throw 'Fresh unique proof directory required'}
$taskOwner=Join-Path $taskWorkspace.main 'tools/ci/native_qualification_ci.ps1'
$taskNodeRoot='C:\Program Files\nodejs';$taskNode=Join-Path $taskNodeRoot 'node.exe'
$taskOriginal1774=Join-Path $taskWorkspace.evidence 'source4954-node-tools-before-20261015.json'
$taskOriginal1838=Join-Path $taskWorkspace.evidence 'typebox-heap-scope-args-static-second49d-20261016-frozen.json'
$taskLayout=Join-Path $taskContainer '.pi-zig-workspace.json'
$taskFiles=@(
 @{relative='verification/typebox-operators-production-20261016/lower-authority.mjs';sha256='88E68EF4313978B41786A2D12A37B2B8380DCB020501248A2DF20959423193AD'},
 @{relative='verification/typebox-operators-production-20261016/outline-call-setup.mjs';sha256='685DFEF18D5145985767E73BBD0F7ECEE69755FA8B0C6DBFC049D8DC551D8C00'},
 @{relative='verification/typebox-operators-production-20261016/outline-call-steps.test.mjs';sha256='7A6E8957199DEE1097A0EC4862809978DD8677546F8AFB9862ABFF6756EF1658'},
 @{relative='verification/typebox-operators-production-20261016/outline-call-setup.test.mjs';sha256='9B7B80E4DACF47D9505D688D1EE5DB09BD93E3C611427128E4EFF1932676CE2C'}
)
foreach($seal in @(
 @{path=$PSCommandPath;hash=$taskGrant.driver_sha256},@{path=$taskResolver;hash=$taskGrant.workspace_resolver_sha256},@{path=$taskLayout;hash=$taskGrant.workspace_layout_sha256},@{path=$taskWorkspace.path_relocations;hash=$taskGrant.path_relocations_sha256},
 @{path=$taskOwner;hash='607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285'},@{path=$taskNode;hash='63C259C81E5D472B5F11C8D506070130CB04A1ECF84B80377A34ED6EC9048088'},
 @{path=$taskOriginal1774;hash='F834312AAC6AC8D79EF4B49CCB806096D80E92FCA403CC650A05E901D4C280DD'},@{path=$taskOriginal1838;hash='35F1F2B0F12BF79C06B47AE2BA8C485EF10A7714BE3F129772E3BA1BBB97B927'}
)){if(!$seal.hash-or(Get-FileHash -LiteralPath $seal.path -Algorithm SHA256).Hash-cne$seal.hash){throw "Reviewed tooling authority differs: $($seal.path)"}}
foreach($file in $taskFiles){if((Get-FileHash -LiteralPath (Join-Path $taskRoot $file.relative) -Algorithm SHA256).Hash-cne$file.sha256){throw 'Exact reviewed3c source differs'}}
. $taskOwner
$taskRows1774=@(Get-Content -LiteralPath $taskOriginal1774 -Raw|ConvertFrom-Json)
$taskRows1838=@((Get-Content -LiteralPath $taskOriginal1838 -Raw|ConvertFrom-Json).node_complete)
if($taskRows1774.Count-ne1774-or$taskRows1838.Count-ne1838){throw 'Complete original1774/1838 Node authority required'}
function NodeKeys($Rows){@(foreach($row in $Rows){$path=[IO.Path]::GetFullPath([string]$row.path);if(!$path.StartsWith($taskNodeRoot+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Historical Node row escapes explicitly unmoved installation'};[IO.Path]::GetRelativePath($taskNodeRoot,$path).Replace('\','/')+' '+$row.sha256})}
$taskNodeExpected1774=NodeKeys $taskRows1774;$taskNodeExpected1838=NodeKeys $taskRows1838
$taskControls=@($PSCommandPath,$RootGrant,$taskOwner,$taskResolver,$taskLayout,$taskWorkspace.path_relocations,$taskOriginal1774,$taskOriginal1838)
$taskSuites=@(
 @{name='pure18';file=(Join-Path $taskRoot 'verification/typebox-operators-production-20261016/outline-call-steps.test.mjs');mode='--call-step-controls';token="TYPEBOX_CALL_STEP_CONTROLS_OWNED_START`n";names=@(
 'invoke step retains original owner slot slice boundary and metadata','two noinline steps only call and store existing Scope-owned success','empty original arguments become zero-zero slice without slots','dormant constructor route is distinct synthetic authoring only','nested actual call stays after own preparation inside original outer preparation',
 'out-of-bounds result rejects','negative result rejects','result spelling mismatch rejects','foreign frame owner rejects','foreign argument owner rejects','foreign emitted slice endpoint rejects','argument range beyond original area rejects','fusion of adjacent original slices rejects','unsupported raw argument expression rejects','false empty argument metadata rejects','descriptor pair beyond existing area rejects','descriptor allocation mismatch rejects','original call line mismatch rejects')},
 @{name='retained9';file=(Join-Path $taskRoot 'verification/typebox-operators-production-20261016/outline-call-setup.test.mjs');mode='--tooling-controls';token="TYPEBOX_TOOLING_CONTROLS_OWNED_START`n";names=@(
 'nested callee descriptors preserve original call boundaries and flags','free enclosing optional local rejects','numeric-start slice free endpoint rejects','marker-start slice foreign owner endpoint rejects','allocator free ownership rejects','JS_FreeValueRT ownership rejects','defer ownership rejects','errdefer ownership rejects','region-owned local and quoted cleanup text remain admissible')}
)
[void](New-Item -ItemType Directory -Path $taskProof)
function Save($Value,[string]$Name){$Value|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $taskProof $Name) -Encoding utf8NoBOM}
Save @{scope='Prepared direct-file invocation/expected TAP, not execution evidence';Node=$taskNode;suites=$taskSuites;heap_mib=256;owner_timeout_seconds=60;owner_pipe_settle_seconds=10;expected_cases=27;compiler_needed=$false;third_party_runtime_needed=$false} 'planned-suites.json'
$taskAdmissions=[Collections.Generic.List[object]]::new()
function Processes {$rows=@(Get-CimInstance Win32_Process -OperationTimeoutSec 5 -ErrorAction Stop);if(!$rows.Count){throw 'Process census unavailable'};return $rows}
function Native($Rows){@($Rows|Where-Object{$_.Name-in@('zig','zig.exe','build','build.exe','test','test.exe')-or($_.ExecutablePath-and([IO.Path]::GetFileName($_.ExecutablePath)-in@('zig','zig.exe','build','build.exe','test','test.exe')-or$_.ExecutablePath-match'[\\/](?:\.zig-cache|zig-out)[\\/]'-or$_.ExecutablePath.StartsWith($taskProof+'\',[StringComparison]::OrdinalIgnoreCase)))})}
function Admission([string]$Phase){
 $watch=[Diagnostics.Stopwatch]::StartNew();$probes=[Collections.Generic.List[object]]::new()
 try{do{$os=Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 5 -ErrorAction Stop;if($null-eq$os.FreePhysicalMemory){throw 'Memory census unavailable'};$roots=@(Native (Processes));$probe=[ordered]@{phase=$Phase;free_kib=[uint64]$os.FreePhysicalMemory;minimum_kib=16777216;native=@($roots|Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,CreationDate);elapsed_seconds=$watch.Elapsed.TotalSeconds;utc=[DateTimeOffset]::UtcNow.ToString('o')};$probes.Add($probe);$taskAdmissions.Add($probe);if($roots.Count){throw 'Other/unknown native roots prevent serial tooling admission'};if($watch.Elapsed.TotalSeconds-ge54){throw '54-second admission deadline expired before acceptance'};if($os.FreePhysicalMemory-ge16777216){Save @{status='admitted';phase=$Phase;probes=$probes.ToArray();accepted_elapsed_seconds=$watch.Elapsed.TotalSeconds} "$Phase-admission.json";return};$remaining=54000-$watch.ElapsedMilliseconds;if($remaining-le0){throw 'Admission deadline expired'};Start-Sleep -Milliseconds ([int][Math]::Min(1000,$remaining))}while($true)}catch{Save @{status='denied';phase=$Phase;error=[string]$_;probes=$probes.ToArray()} "$Phase-admission.json";throw}
}
function Seal([string]$Name){
 $seal=[ordered]@{head=$null;clean=$false;source=@();tree=@();node1838=@();node1774=@();controls=@();errors=@()}
 try{$seal.head=([string](git --no-optional-locks -C $taskRoot rev-parse HEAD)).Trim();if($LASTEXITCODE-ne0){throw 'Head unavailable'};$seal.clean=@(git --no-optional-locks -C $taskRoot status --porcelain).Count-eq0;if($LASTEXITCODE-ne0){throw 'Clean state unavailable'}}catch{$seal.errors+=,[string]$_}
 foreach($group in @('source','tree','node1838','node1774','controls')){try{switch($group){
  source{$paths=@(git --no-optional-locks -C $taskRoot ls-files);if($LASTEXITCODE-ne0){throw 'Tracked inventory unavailable'};$seal.source=@(Get-CiRows $taskRoot $paths)}
  tree{$seal.tree=@((Get-CiInventory $taskRoot tree @('.git','.zig-cache','zig-out')).rows)}
  node1838{$seal.node1838=@((Get-CiInventory $taskNodeRoot).rows|ForEach-Object{$_.relative+' '+$_.sha256})}
  node1774{$npm=Get-CiInventory (Join-Path $taskNodeRoot 'node_modules/npm');$seal.node1774=@('node.exe '+(Get-FileHash -LiteralPath $taskNode -Algorithm SHA256).Hash)+@($npm.rows|ForEach-Object{'node_modules/npm/'+$_.relative+' '+$_.sha256})}
  controls{$seal.controls=@(foreach($path in $taskControls){[ordered]@{path=$path;sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}})}
 }}catch{$seal.errors+=,[ordered]@{group=$group;error=[string]$_}}}
 Save $seal "$Name.json";return $seal
}
function AssertSeal($Actual,$Expected){
 if($Actual.errors.Count-or!$Actual.clean-or$Actual.head-cne$taskHead){throw 'Full clean exact3c source seal failed'}
 if($Actual.node1838.Count-ne1838-or$Actual.node1774.Count-ne1774-or@(Compare-Object $Actual.node1838 $taskNodeExpected1838 -CaseSensitive).Count-or@(Compare-Object $Actual.node1774 $taskNodeExpected1774 -CaseSensitive).Count){throw 'Original full Node1838/1774 inventory/hash differs'}
 if($null-ne$Expected){foreach($group in @('source','tree')){if(@(Compare-Object @($Actual[$group]|ForEach-Object{$_.relative+' '+$_.sha256}) @($Expected[$group]|ForEach-Object{$_.relative+' '+$_.sha256}) -CaseSensitive).Count){throw "$group source inventory/hash drift"}};if(@(Compare-Object @($Actual.controls|ForEach-Object{$_.path+' '+$_.sha256}) @($Expected.controls|ForEach-Object{$_.path+' '+$_.sha256}) -CaseSensitive).Count){throw 'Control hash drift'}}
}
function Evidence([string]$Name){
 $record=[ordered]@{owner=$null;owner_pid_present=$null;owned_descendants=@();raw=@();absence_error=$null};$path=Join-Path $taskProof "$Name.json"
 if(Test-Path -LiteralPath $path){$record.owner=Get-Content -LiteralPath $path -Raw|ConvertFrom-Json;try{$rows=@(Processes);$record.owner_pid_present=@($rows|Where-Object ProcessId -EQ $record.owner.pid).Count;$parents=@([int]$record.owner.pid);do{$children=@($rows|Where-Object{$_.ParentProcessId-in$parents-and$_.ProcessId-notin$parents});if(!$children.Count){break};$record.owned_descendants+=@($children|Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,CreationDate);$parents+=@($children.ProcessId)}while($true)}catch{$record.absence_error=[string]$_}}
 foreach($suffix in @('stdout.bin','stderr.log')){$raw=Join-Path $taskProof "$Name.$suffix";if(Test-Path -LiteralPath $raw){$record.raw+=,[ordered]@{path=$raw;bytes=(Get-Item -LiteralPath $raw).Length;sha256=(Get-FileHash -LiteralPath $raw -Algorithm SHA256).Hash}}};return $record
}
$result=[ordered]@{status='running';scope='Pure18 plus retained9 authored tooling controls only';candidate_head=$taskHead;expected_cases=27;completed_cases=0;suites=[ordered]@{};postseal=$false;absence=$null;errors=@();compiler_needed=$false;third_party_runtime_needed=$false;generator_executed=$false;runtime_restoration_claim=$false;native_qualified=$false}
$before=$null
try{
 $before=Seal 'before';AssertSeal $before $null
 foreach($suite in $taskSuites){
  AssertSeal (Seal ($suite.name+'-before')) $before;Admission $suite.name;$failure=$null
  try{
   [void](Invoke-CiOwnedProcess $taskNode @('--max-old-space-size=256',$suite.file,$suite.mode,'--owned-start') $taskRoot (Join-Path $taskProof $suite.name) 60 ([Text.Encoding]::UTF8.GetBytes($suite.token)))
   $lines=@('TAP version 13');for($i=0;$i-lt$suite.names.Count;$i++){$lines+='ok '+($i+1)+' - '+$suite.names[$i]};$lines+='1..'+$suite.names.Count
   $text=[Text.Encoding]::UTF8.GetString([IO.File]::ReadAllBytes((Join-Path $taskProof ($suite.name+'.stdout.bin')))).Replace("`r`n","`n");if($text.EndsWith("`n",[StringComparison]::Ordinal)){$text=$text.Substring(0,$text.Length-1)}
   if($text-cne($lines-join"`n")-or(Get-Item -LiteralPath (Join-Path $taskProof ($suite.name+'.stderr.log'))).Length){throw 'Exact named TAP/plan and empty stderr required'}
   $result.completed_cases+=$suite.names.Count
  }catch{$failure=[string]$_}finally{
   $evidence=Evidence $suite.name;$result.suites[$suite.name]=[ordered]@{failure=$failure;expected=$suite.names.Count;evidence=$evidence}
   try{AssertSeal (Seal ($suite.name+'-after')) $before}catch{$result.errors+=,[string]$_;if(!$failure){$failure=[string]$_}}
   $roots=@(Native (Processes));Save @{suite=$suite.name;owner=$evidence;global_native=@($roots|Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,CreationDate)} ($suite.name+'-absence.json')
   if($roots.Count-or$evidence.absence_error-or$evidence.owner_pid_present-or$evidence.owned_descendants.Count){if(!$failure){$failure='Suite-owned/global native absence failed'}}
   $result.suites[$suite.name].failure=$failure
  }
  if($failure){throw $failure};if(!$evidence.owner-or$evidence.owner.status-cne'passed'-or$evidence.owner.exit_code-ne0-or$evidence.owner.timeout_seconds-ne60-or$evidence.owner.executable_sha256-cne'63C259C81E5D472B5F11C8D506070130CB04A1ECF84B80377A34ED6EC9048088'){throw 'Actual matching terminal0 Node60 owner required'}
 }
 if($result.completed_cases-ne27){throw 'All18 plus retained9 tooling assertions required'};$result.status='passed'
}catch{$result.status='failed';$result.errors+=,[string]$_}finally{
 try{AssertSeal (Seal 'final') $before;$result.postseal=$true}catch{$result.status='failed_postseal';$result.errors+=,[string]$_}
 try{$roots=@(Native (Processes));$owners=@(foreach($suite in $taskSuites){$evidence=Evidence $suite.name;if($evidence.owner){[ordered]@{suite=$suite.name;evidence=$evidence}}});$result.absence=[ordered]@{native=@($roots|Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,CreationDate);owners=$owners};if($roots.Count-or@($owners|Where-Object{$_.evidence.absence_error-or$_.evidence.owner_pid_present-or$_.evidence.owned_descendants.Count}).Count){$result.status='failed_absence'}}catch{$result.status='failed_absence';$result.errors+=,[string]$_}
 $result.admission_probes=$taskAdmissions.ToArray();$result.completed_utc=[DateTimeOffset]::UtcNow.ToString('o');Save $result 'result.json'
}
$result|ConvertTo-Json -Depth 12
if($result.status-cne'passed'){throw 'Pure tooling gate terminal negative; preserve raw/result/seals/absence'}
