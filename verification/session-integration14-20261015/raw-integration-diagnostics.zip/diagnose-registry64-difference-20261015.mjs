import {readFileSync,writeFileSync} from 'node:fs';
const log=readFileSync(process.argv[2],'utf8');
const parse=label=>JSON.parse(log.match(new RegExp(label+':\\r?\\n\\s*(\\{[^\\r\\n]+\\})'))?.[1]??'null');
const actual=parse('Actual full private registry64'),expected=parse('Expected genuine b45');
if(!actual||!expected)throw Error('Full original observations absent');
const differences=[];
const short=value=>typeof value==='string'?value.slice(0,160):value;
function compare(a,b,path){
 if(differences.length>=16||Object.is(a,b))return;
 if(a&&b&&typeof a==='object'&&typeof b==='object'){
  const ak=Object.keys(a),bk=Object.keys(b);
  if(JSON.stringify(ak)!==JSON.stringify(bk))differences.push({path,kind:'keys/order',actual:ak.slice(0,22),expected:bk.slice(0,22)});
  for(const key of new Set([...ak,...bk])){
   if(!Object.hasOwn(a,key)||!Object.hasOwn(b,key))differences.push({path:path+'.'+key,actualPresent:Object.hasOwn(a,key),expectedPresent:Object.hasOwn(b,key)});
   else compare(a[key],b[key],path+'.'+key);
   if(differences.length>=16)break;
  }
 }else differences.push({path,actual:short(a),expected:short(b)});
}
compare(actual,expected,'$');
const result={scope:'Diagnostic comparison of immutable failed native Source64 observations; no expected fixture change',differences};
if(process.argv[3])writeFileSync(process.argv[3],JSON.stringify(result,null,2));
process.stdout.write(JSON.stringify(result,null,2)+'\n');
