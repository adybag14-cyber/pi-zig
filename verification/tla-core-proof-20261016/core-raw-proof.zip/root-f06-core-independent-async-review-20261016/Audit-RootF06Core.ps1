$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$true
$reviewRoot='C:/Users/adyba/pi-zig/worktrees/root-tla-qualification'
$reviewEvidence='C:/Users/adyba/pi-zig/evidence'
$reviewCompiler='C:/Users/adyba/pi-zig/toolchain/zig-x86_64-windows-0.16.0'
$reviewHead='4e94611b6f1379df92a4eb35c14cb91bc5c4531e'
function Read-ReviewJson([string]$Path){Get-Content -LiteralPath $Path -Raw|ConvertFrom-Json}
function Require([bool]$Condition,[string]$Message){if(!$Condition){throw $Message}}
function Sha([string]$Path){(Get-FileHash -LiteralPath $Path).Hash}
function Row-Signatures($Rows){@($Rows|ForEach-Object {$_.relative+':'+$_.sha256}|Sort-Object -CaseSensitive)}
function Equal-Strings($Left,$Right){(@($Left).Count -eq @($Right).Count) -and ((@($Left) -join [char]0) -ceq (@($Right) -join [char]0))}
function Parse-Metadata([string]$Path){
 $bytes=[IO.File]::ReadAllBytes($Path);$at=0;$version=$null;$names=$null
 while($at -lt $bytes.Length){
  Require ($at+8 -le $bytes.Length) 'Metadata truncated header'
  $tag=[BitConverter]::ToUInt32($bytes,$at);$length=[BitConverter]::ToUInt32($bytes,$at+4);$at+=8
  Require ($length -le 1MB -and $at+$length -le $bytes.Length) 'Metadata body bounds'
  if($tag -eq 0){Require ($null -eq $version -and $null -eq $names) 'Duplicate/late version';$version=[Text.Encoding]::UTF8.GetString($bytes,$at,$length)}
  elseif($tag -eq 3){
   Require ($null -eq $names -and $version -ceq '0.16.0' -and $length -ge 8) 'Metadata tag order'
   $strings=[BitConverter]::ToUInt32($bytes,$at);$count=[BitConverter]::ToUInt32($bytes,$at+4)
   Require ($count -gt 0 -and $length -eq 8+8*$count+$strings) 'Metadata exact array length'
   $start=$at+8+8*$count;$names=@()
   for($i=0;$i -lt $count;$i++){
    $offset=[BitConverter]::ToUInt32($bytes,$at+8+4*$i);$panic=[BitConverter]::ToUInt32($bytes,$at+8+4*$count+4*$i)
    Require ($panic -eq 0 -and $offset -lt $strings) 'Unexpected panic/name offset'
    $end=$offset;while($end -lt $strings -and $bytes[$start+$end] -ne 0){$end++}
    Require ($end -lt $strings) 'Unterminated name'
    $names+=[Text.Encoding]::UTF8.GetString($bytes,$start+$offset,$end-$offset)
   }
  }else{throw "Unexpected metadata tag $tag"}
  $at+=$length
 }
 Require ($version -ceq '0.16.0' -and @($names).Count -gt 0) 'Missing metadata/version'
 @{version=$version;names=$names;count=$names.Count;raw_sha256=Sha $Path}
}
function Parse-Runtime([string]$Path,[int]$Count){
 $bytes=[IO.File]::ReadAllBytes($Path);$at=0;$version=$null;$started=0;$finished=0;$flags=@()
 while($at -lt $bytes.Length){
  Require ($at+8 -le $bytes.Length) 'Runtime truncated header'
  $tag=[BitConverter]::ToUInt32($bytes,$at);$length=[BitConverter]::ToUInt32($bytes,$at+4);$at+=8
  Require ($length -le 1MB -and $at+$length -le $bytes.Length) 'Runtime body bounds'
  switch($tag){
   0 {Require ($null -eq $version -and $started -eq 0 -and $finished -eq 0) 'Runtime version order';$version=[Text.Encoding]::UTF8.GetString($bytes,$at,$length)}
   5 {Require ($version -ceq '0.16.0' -and $length -eq 0 -and $started -eq $finished -and $started -lt $Count) 'Runtime start order';$started++}
   4 {Require ($length -eq 12 -and $started -eq $finished+1) 'Runtime result size/order';$index=[BitConverter]::ToUInt32($bytes,$at);$flag=[BitConverter]::ToUInt64($bytes,$at+4);Require ($index -eq $finished -and $flag -eq 0) 'Runtime missing/out-of-order/failing/logging/leaking/skipping result';$flags+=$flag;$finished++}
   default {throw "Unexpected runtime tag $tag"}
  }
  $at+=$length
 }
 Require ($version -ceq '0.16.0' -and $started -eq $Count -and $finished -eq $Count) 'Runtime incomplete selection'
 @{version=$version;started=$started;completed=$finished;all_u64_flags_zero=$true;raw_sha256=Sha $Path}
}
$sets=@(
 @{folder='root-tla-core-regression-v2-20261016';driver='Run-CoreRegression.ps1';groups=@(@{name='foundation';count=6},@{name='async26';count=26},@{name='generator';count=19},@{name='generator-gpa';count=2},@{name='json';count=11},@{name='source51';count=2},@{name='operators';count=2});terminal='failed'},
 @{folder='root-tla-core-continuation-20261016';driver='Run-CoreContinuation.ps1';groups=@(@{name='engine';count=20},@{name='recovery';count=23},@{name='sdk-boundary';count=5});terminal='passed'}
)
$baseline=$null;$sourceSignatures=$null;$compilerSignatures=$null;$checkedSeals=@();$owners=@();$groupResults=@();$grants=@();$allFiles=@()
foreach($set in $sets){
 $dir=Join-Path $reviewEvidence $set.folder;$grant=Read-ReviewJson (Join-Path $dir 'grant.json');$terminal=Read-ReviewJson (Join-Path $dir 'result.json');$before=Read-ReviewJson (Join-Path $dir 'before.json')
 Require ($grant.status -ceq 'admitted' -and $grant.source_head -ceq $reviewHead -and $grant.source_files -eq 10495 -and $grant.compiler_files -eq 19546 -and $grant.admission.free_kib -ge 16777216 -and $grant.admission.native_roots -eq 0) 'Grant/candidate/admission negative'
 Require ($terminal.status -ceq $set.terminal -and $terminal.postseal -eq $true -and $terminal.native_roots_after -eq 0 -and (Equal-Strings $terminal.groups.name $set.groups.name)) 'Terminal scope/fullpost/absence negative'
 if($set.terminal -ceq 'failed'){Require ($terminal.error -ceq 'Exact selected native test count required') 'Unexpected predecessor failure'}
 Require ($before.candidate_head -ceq $reviewHead -and $before.source.Count -eq 10495 -and $before.compiler.Count -eq 19546 -and $before.driver_sha256 -ceq (Sha (Join-Path $dir $set.driver))) 'Before source/compiler/driver mismatch'
 $source=Row-Signatures $before.source;$compiler=Row-Signatures $before.compiler
 if(!$baseline){$baseline=$before;$sourceSignatures=$source;$compilerSignatures=$compiler}else{Require ((Equal-Strings $sourceSignatures $source) -and (Equal-Strings $compilerSignatures $compiler)) 'Continuation source/compiler identity differs'}
 foreach($sealName in @('final')+@($set.groups|ForEach-Object {$_.name+'-after'})){
  $path=Join-Path $dir ($sealName+'.json');Require ((Sha $path) -ceq (Sha (Join-Path $dir 'before.json'))) 'Recorded full seal differs within same driver';$checkedSeals+=@{path=$path;sha256=Sha $path;source_files=10495;compiler_files=19546;drift=0}
 }
 Require ($grant.ci_owner_sha256 -ceq (Sha (Join-Path $reviewRoot 'tools/ci/native_qualification_ci.ps1')) -and $grant.protocol_sha256 -ceq (Sha (Join-Path $reviewRoot 'tools/ci/Invoke-NativeTestProtocol.ps1'))) 'Owner/protocol source changed'
 $grants+=@{path=(Join-Path $dir 'grant.json');sha256=Sha (Join-Path $dir 'grant.json');head=$grant.source_head;admission=$grant.admission}
 foreach($group in $set.groups){
  $prefix=Join-Path $dir $group.name;$copy=Read-ReviewJson ($prefix+'-artifact-copy.json');$metadata=Parse-Metadata ($prefix+'-metadata.stdout.bin');$selected=Read-ReviewJson ($prefix+'-selected-tests.json');$runtime=Parse-Runtime ($prefix+'-runtime.stdout.bin') $group.count;$savedRuntime=Read-ReviewJson ($prefix+'-runtime.results.json')
  Require ($metadata.count -eq $group.count -and (Equal-Strings $metadata.names $selected.tests)) 'Actual metadata differs from selected list/count'
  Require ((Sha $copy.compiled) -ceq $copy.sha256 -and (Sha $copy.owned) -ceq $copy.sha256 -and $selected.binary_sha256 -ceq $copy.sha256 -and $savedRuntime.binary_sha256 -ceq $copy.sha256) 'Compiled/canonical/metadata/runtime artifact identity drift'
  Require ($savedRuntime.status -ceq 'passed' -and $savedRuntime.expected -eq $group.count -and $savedRuntime.started -eq $group.count -and $savedRuntime.completed -eq $group.count -and $savedRuntime.failed_or_skipped_or_logged_or_leaked -eq 0 -and @($savedRuntime.results|Where-Object {$_.flags -ne 0 -or $_.passed -ne $true}).Count -eq 0) 'Saved runtime result disagrees with raw protocol'
  foreach($phase in @('compile','metadata','runtime')){
   $path=$prefix+'-'+$phase+'.json';$owner=Read-ReviewJson $path;$expectedTimeout=if($phase -ceq 'compile'){1320}elseif($phase -ceq 'metadata'){30}else{120}
   Require ($owner.status -ceq 'passed' -and $null -ne $owner.exit_code -and $owner.exit_code -eq 0 -and $owner.timeout_seconds -eq $expectedTimeout -and $owner.retained_handle -gt 0 -and $owner.live_identity.pid -eq $owner.pid -and $owner.live_identity.created_utc -ceq $owner.created_utc -and $owner.live_identity.executable -ceq $owner.executable -and $owner.live_identity.command_line_method -ceq 'Win32_Process.CommandLine' -and !!$owner.live_identity.command_line -and $owner.working_directory -ieq ([IO.Path]::GetFullPath($reviewRoot))) 'Owner terminal/handle/live identity negative'
   # These frozen paths/arguments contain no whitespace except the executable.
   # Compare the actual saved CIM text with the intended PSI argument list.
   Require (@($owner.arguments|Where-Object {$_ -match '[\s"]'}).Count -eq 0 -and $owner.live_identity.command_line -ceq ('"'+$owner.executable+'" '+($owner.arguments -join ' '))) 'Actual owner CIM argv differs from intended arguments'
   if($phase -ceq 'compile'){
    $granted=@($grant.groups|Where-Object name -ceq $group.name)
    Require ($granted.Count -eq 1 -and $owner.arguments[1] -ceq $granted[0].step) 'Compile target differs from granted group'
    Require ($owner.executable_sha256 -ceq '086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864' -and $owner.arguments[0] -ceq 'build' -and $owner.arguments -ccontains '-Doptimize=Debug' -and $owner.arguments -ccontains '-Duse-llvm=true' -and $owner.arguments -ccontains '-j1') 'Compiler/flags differ'
   }else{Require ($owner.executable -ceq $copy.owned -and $owner.executable_sha256 -ceq $copy.sha256 -and (Equal-Strings $owner.arguments @('--listen=-'))) 'Metadata/runtime executable or argv differs'}
   $owners+=@{receipt=$path;pid=$owner.pid;created_utc=$owner.created_utc;executable=$owner.executable;argv=$owner.arguments;actual_cim_argv=$owner.live_identity.command_line;intended_argv_verified=$true;exit_code=0;timeout_seconds=$owner.timeout_seconds}
  }
  if($group.name -ceq 'async26'){Require (Equal-Strings @($metadata.names|Sort-Object -CaseSensitive) @((Read-ReviewJson (Join-Path $reviewRoot 'verification/native-async-function-20261016/expected-tests26.json'))|Sort-Object -CaseSensitive)) 'AF26 qualified names differ'}
  if($group.name -cin @('engine','recovery')){$required=@(Select-String -LiteralPath (Join-Path $reviewRoot 'src/extensions/engine.zig') -Pattern '^test "([^"]+)"'|ForEach-Object {'extensions.engine.test.'+$_.Matches[0].Groups[1].Value});Require (@($required|Where-Object {$_ -cnotin $metadata.names}).Count -eq 0 -and $metadata.names -ccontains 'extensions.native_durable_storage.test_0') 'Engine/recovery misses actual named tests or storage test0'}
  $groupResults+=@{name=$group.name;proof=$set.folder;count=$group.count;metadata=$metadata;runtime=$runtime;binary=$copy.owned;binary_sha256=$copy.sha256;tests=$metadata.names}
 }
 $allFiles+=@(Get-ChildItem -LiteralPath $dir -File|ForEach-Object {@{path=$_.FullName;bytes=$_.Length;sha256=Sha $_.FullName}})
}
# Independently parse the refused old engine count. It is preserved as a
# control negative, and contributes no runtime results to the accepted ten.
$refused=Parse-Metadata (Join-Path $reviewEvidence 'root-tla-core-regression-v2-20261016/engine-metadata.stdout.bin')
Require ($refused.count -eq 20) 'Refused engine actual metadata is not20'
foreach($phase in @('compile','metadata')){$path=Join-Path $reviewEvidence ('root-tla-core-regression-v2-20261016/engine-'+$phase+'.json');$owner=Read-ReviewJson $path;Require ($owner.status -ceq 'passed' -and $owner.exit_code -eq 0) 'Predecessor engine owner failed unexpectedly';$owners+=@{receipt=$path;pid=$owner.pid;created_utc=$owner.created_utc;executable=$owner.executable;exit_code=0}}
Require (([string](& git -C $reviewRoot rev-parse HEAD)).Trim() -ceq $reviewHead -and !@(& git -C $reviewRoot status --porcelain).Count) 'Current frozen candidate changed'
Require (Equal-Strings @((& git -C $reviewRoot ls-files)|Sort-Object -CaseSensitive) @($baseline.source.relative|Sort-Object -CaseSensitive)) 'Current tracked path inventory differs'
$currentDrift=@(foreach($row in @($baseline.source)+@($baseline.compiler)){if((Sha $row.path) -cne $row.sha256){$row.path}})
Require ($currentDrift.Count -eq 0) 'Current complete source/compiler hash drift'
$compilerFiles=@(Get-ChildItem -LiteralPath $reviewCompiler -Recurse -File -Force|ForEach-Object {[IO.Path]::GetRelativePath($reviewCompiler,$_.FullName).Replace('\','/')}|Sort-Object -CaseSensitive)
Require ($compilerFiles.Count -eq 19546 -and (Equal-Strings $compilerFiles @($baseline.compiler.relative|Sort-Object -CaseSensitive))) 'Current compiler exact path inventory differs'
Require ((Sha (Join-Path $reviewRoot 'vendor/quickjs/quickjs.c')) -ceq 'F06F1F2A23CB024FF381DB02CF43D1C249DE5848689D005918F7D1FB80BE9B5E' -and (Sha (Join-Path $reviewRoot 'vendor/quickjs/quickjs.h')) -ceq '341CF06F8041B8311D49767026C85C7B859BCFEE3088380F3FFE6D77527052AB') 'F06 C/H identity differs'
$snapshot=@(Get-CimInstance Win32_Process)
$absence=@(foreach($owner in $owners){$live=$snapshot|Where-Object ProcessId -eq $owner.pid|Select-Object -First 1;$reused=$live -and $live.CreationDate -and ([DateTimeOffset]$live.CreationDate).UtcDateTime -ne ([DateTimeOffset]$owner.created_utc).UtcDateTime;@{pid=$owner.pid;created_utc=$owner.created_utc;original_absent=(!$live -or $reused);pid_reused=[bool]$reused}})
Require (@($absence|Where-Object {!$_.original_absent}).Count -eq 0) 'Owned original process present or unknown'
$native=@($snapshot|Where-Object {$_.Name -in @('zig.exe','build.exe','test.exe') -or ($_.ExecutablePath -and $_.ExecutablePath -match '\\(?:\.zig-cache|zig-out)\\')}|Select-Object ProcessId,ExecutablePath,CreationDate)
$originalNegative=Read-ReviewJson (Join-Path $reviewEvidence 'root-tla-core-regression-20261016/result.json')
$record=[ordered]@{status='passed';kind='independent_exact_F06_core_receipt_raw_protocol_artifact_seal_audit';candidate_head=$reviewHead;C='F06F1F2A23CB024FF381DB02CF43D1C249DE5848689D005918F7D1FB80BE9B5E';H='341CF06F8041B8311D49767026C85C7B859BCFEE3088380F3FFE6D77527052AB';groups=$groupResults;total_groups=$groupResults.Count;total_entries=($groupResults|Measure-Object count -Sum).Sum;predecessor_entries=68;continuation_entries=48;refused_predecessor_engine_actual_metadata=20;refused_predecessor_expected=19;predecessor_control_negative_preserved=$true;original_v1_negative=@{status=$originalNegative.status;error=$originalNegative.error;result_sha256=Sha (Join-Path $reviewEvidence 'root-tla-core-regression-20261016/result.json')};source_files=10495;compiler_files=19546;current_source_compiler_drift=0;checked_recorded_full_seals=$checkedSeals;grants=$grants;owners=$owners;independent_owner_absence=$absence;global_native_snapshot=$native;proof_files=$allFiles;runtime_recovery_claimed=$false;C409_E334_or_shared_thenable_qualified=$false;new_jobs_launched=$false;observed_utc=[DateTimeOffset]::UtcNow.ToString('o')}
$record|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'audit.json') -Encoding utf8NoBOM
[pscustomobject]$record|Select-Object status,candidate_head,total_groups,total_entries,source_files,compiler_files,current_source_compiler_drift,@{Name='owned_receipts';Expression={$_.owners.Count}},@{Name='owned_present';Expression={@($_.independent_owner_absence|Where-Object {!$_.original_absent}).Count}},@{Name='global_native';Expression={$_.global_native_snapshot.Count}},observed_utc|ConvertTo-Json
