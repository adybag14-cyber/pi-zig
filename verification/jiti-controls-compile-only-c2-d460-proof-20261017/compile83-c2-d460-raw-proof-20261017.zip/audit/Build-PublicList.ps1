$ErrorActionPreference='Stop'
$container='C:\Users\adyba\pi-zig';$candidate=Join-Path $container 'worktrees/jiti-compile-only'
$rows=[Collections.Generic.List[object]]::new()
function AddFile([string]$Source,[string]$Destination){
 $file=Get-Item -LiteralPath $Source
 if($file.PSIsContainer-or$file.Extension-in@('.exe','.pdb','.dll','.lib','.a','.obj','.o')-or$Source.StartsWith('C:\Program Files\',[StringComparison]::OrdinalIgnoreCase)-or$Source-match'[\\/](cache|global-cache|\.zig-cache|zig-out|out)[\\/]'){throw "Excluded payload: $Source"}
 $rows.Add([pscustomobject][ordered]@{public_path=$Destination;source_path=$file.FullName;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash})
}
$packets=@('jiti-controls-compile-only-native-prepared-20261017','jiti-controls-compile-only-retry-prepared-20261017','jiti-controls-compile-only-retry3-prepared-20261017','jiti-controls-compile-only-retry4-prepared-20261017')
foreach($name in $packets){
 $folder=Join-Path $container ('evidence/'+$name)
 foreach($file in Get-ChildItem -LiteralPath $folder -File -Force){AddFile $file.FullName ('evidence/'+$name+'/'+$file.Name)}
 foreach($attempt in Get-ChildItem -LiteralPath $folder -Directory|Where-Object Name -Like 'root-jiti*'){
  foreach($file in Get-ChildItem -LiteralPath $attempt.FullName -File -Force){AddFile $file.FullName ('evidence/'+$name+'/'+$attempt.Name+'/'+$file.Name)}
 }
}
$coverage=Get-Content (Join-Path $candidate 'verification/jiti-controls-compile-only-20261017/coverage.json') -Raw|ConvertFrom-Json
$selected=@('build.zig','src/native_jiti_compile_only_root.zig')+@($coverage.anchors.module|ForEach-Object{'src/'+$_})+@(
 'src/extensions/native_jiti_cjs_eval.zig','src/extensions/native_file_stat.zig','src/extensions/typescript.zig','src/extensions/native_ai_provider_values.zig','src/extensions/native_models_stream_scope.zig','src/extensions/native_node_module_callable.zig','src/extensions/engine.zig','src/extensions/engine_abi.c','src/extensions/engine_abi.h','vendor/quickjs/quickjs.c','vendor/quickjs/quickjs.h','vendor/tree-sitter/lib/include/tree_sitter/api.h','vendor/typescript-parser/typescript/src/parser.c','vendor/typescript-parser/typescript/src/scanner.c')
foreach($path in @($selected|Sort-Object -Unique -CaseSensitive)){AddFile (Join-Path $candidate $path) ('source-d460/'+$path)}
foreach($file in Get-ChildItem -LiteralPath (Join-Path $candidate 'verification/jiti-controls-compile-only-20261017') -File){AddFile $file.FullName ('source-d460/verification/jiti-controls-compile-only-20261017/'+$file.Name)}
foreach($path in @('tools/ci/native_qualification_ci.ps1','tools/workspace/Resolve-PiZigWorkspace.ps1')){AddFile (Join-Path $candidate $path) ('source-d460/'+$path)}
foreach($path in @('.pi-zig-workspace.json','path-relocations.json','evidence/durable-latest89-full-inspect-53ae-tool-prehash-20261011.json')){AddFile (Join-Path $container $path) ('authority/'+$path)}
foreach($name in @('README.md','Audit-Compile83.ps1','raw-audit.json','Build-PublicList.ps1')){AddFile (Join-Path $PSScriptRoot $name) ('audit/'+$name)}
$unique=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($row in $rows){if(!$unique.Add($row.public_path)){throw "Duplicate destination: $($row.public_path)"}}
$artifactRoot=Join-Path $container 'evidence/jiti-controls-compile-only-retry4-prepared-20261017/root-jiti-83-compile-retry4-20261017-143404/out'
$localArtifacts=@(foreach($file in Get-ChildItem -LiteralPath $artifactRoot -Recurse -File){[ordered]@{path=$file.FullName;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash;public_payload=$false}})
$oldRoot=Join-Path $container 'evidence/jiti-controls-compile-only-native-prepared-20261017/root-jiti-83-compile-only-20261017-134316'
$cacheRows=@(foreach($name in @('cache','global-cache')){$path=Join-Path $oldRoot $name;$files=@(Get-ChildItem -LiteralPath $path -Recurse -File -Force);[ordered]@{path=$path;observed_files=$files.Count;observed_bytes=($files|Measure-Object Length -Sum).Sum;content_sealed=$false;hash_integrity_claim=$false;public_payload=$false}})
$ledger=[ordered]@{scope='LOCAL ONLY excluded output and mutable cache metadata';artifacts=$localArtifacts;caches=$cacheRows;observed_utc=[DateTimeOffset]::UtcNow.ToString('o');cache_reproducibility_claim=$false}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'local-only-ledger.json'),($ledger|ConvertTo-Json -Depth 7)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
$manifest=[ordered]@{scope='Finite C2 compile/link only, no metadata/runtime/Node execution';source_head='d460a3258903fb4b4e724c4ddc7b266e394315fe';file_count=$rows.Count;bytes=($rows|Measure-Object bytes -Sum).Sum;files=$rows.ToArray();whole_source_compiler_payload_included=$false;complete_source_compiler_inventory_included=$true;all_three_negative_raw_packets_preserved=$true;binary_PDB_cache_payloads_excluded=$true;mutable_cache_exception='Exact original134316 two caches explicitly granted; unsealed';runtime_API_default_release_qualified=$false;remote_published_by_reviewer=$false}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'public-files.json'),($manifest|ConvertTo-Json -Depth 8)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllLines((Join-Path $PSScriptRoot 'public-paths.txt'),[string[]]@($rows|ForEach-Object public_path),[Text.UTF8Encoding]::new($false))
[ordered]@{file_count=$rows.Count;bytes=$manifest.bytes;manifest_sha256=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'public-files.json') -Algorithm SHA256).Hash;local_ledger_sha256=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'local-only-ledger.json') -Algorithm SHA256).Hash}|ConvertTo-Json
