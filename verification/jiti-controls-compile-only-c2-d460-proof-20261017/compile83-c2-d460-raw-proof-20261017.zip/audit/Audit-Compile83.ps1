$ErrorActionPreference='Stop'
$container='C:\Users\adyba\pi-zig'
$candidate=Join-Path $container 'worktrees/jiti-compile-only'
$packet=Join-Path $container 'evidence/jiti-controls-compile-only-retry4-prepared-20261017'
$run=Join-Path $packet 'root-jiti-83-compile-retry4-20261017-143404'
function ReadJson([string]$Path){Get-Content -LiteralPath $Path -Raw|ConvertFrom-Json}
function Require([bool]$Condition,[string]$Message){if(!$Condition){throw $Message}}
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash}
function Keys($Rows,[string]$Field='relative'){@($Rows|ForEach-Object{$_.$Field+' '+$_.sha256})}
function EqualRows($A,$B,[string]$Label){Require (@(Compare-Object @($A) @($B) -CaseSensitive).Count-eq0) "$Label differs"}
$before=ReadJson (Join-Path $run 'before.json');$final=ReadJson (Join-Path $run 'final.json')
$result=ReadJson (Join-Path $run 'result.json');$owner=ReadJson (Join-Path $run 'compile.json');$plan=ReadJson (Join-Path $run 'compile-plan.json')
$grant=ReadJson (Join-Path $run 'root-grant.json');$outer=ReadJson (Join-Path $packet 'root-jiti-83-compile-retry4-20261017-143404-outer.json')
$outerAbsent=ReadJson (Join-Path $packet 'root-jiti-83-compile-retry4-20261017-143404-outer-absence.json')
Require ($before.candidate_head-ceq'd460a3258903fb4b4e724c4ddc7b266e394315fe'-and$final.candidate_head-ceq$before.candidate_head) 'Exact candidate head differs'
Require ($before.source.Count-eq11101-and$final.source.Count-eq11101-and$before.compiler.Count-eq19546-and$final.compiler.Count-eq19546-and$before.controls.Count-eq14-and$final.controls.Count-eq14) 'Complete inventory counts differ'
foreach($name in @('source','compiler','controls')){EqualRows (Keys $before.$name $(if($name-eq'controls'){'path'}else{'relative'})) (Keys $final.$name $(if($name-eq'controls'){'path'}else{'relative'})) "$name pre/final"}
$authorityPath=Join-Path $container 'evidence/durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
Require ((Hash $authorityPath)-ceq'DEE259F171F720AB2C08E8DD473975E22C876417CD62E4F016C71A7C662794EB') 'Compiler original authority differs'
$authority=ReadJson $authorityPath
$authorityKeys=@($authority.inputs|ForEach-Object{$_.path.Substring($authority.root.Length+1).Replace('\','/')+' '+$_.sha256})
EqualRows (Keys $before.compiler) $authorityKeys 'Original complete compiler19546'
foreach($row in @($final.source)+@($final.compiler)+@($final.controls)){Require ((Hash $row.path)-ceq$row.sha256) "Current sealed input differs: $($row.path)"}
Require (([string](git --no-optional-locks -C $candidate rev-parse HEAD)).Trim()-ceq$before.candidate_head-and@(git --no-optional-locks -C $candidate status --porcelain).Count-eq0) 'Current candidate head/clean differs'
Require (@(git --no-optional-locks -C $candidate ls-files).Count-eq11101) 'Current source count differs'
Require ($result.status-ceq'compile_only_passed'-and$result.postseal-and$result.artifacts_verified-and$result.owner_absence_verified-and$result.native_roots_after-eq0-and!$result.runtime_executed-and!$result.metadata_executed-and!$result.node_executed) 'Finite compile-only result differs'
Require ($owner.status-ceq'passed'-and$owner.exit_code-eq0-and$owner.pid-eq53212-and$owner.timeout_seconds-eq1320-and$owner.executable_sha256-ceq'086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864') 'Actual compile owner differs'
Require ($owner.live_identity.pid-eq$owner.pid-and([DateTimeOffset]$owner.created_utc)-eq([DateTimeOffset]$owner.live_identity.created_utc)-and$owner.executable-ceq$owner.live_identity.executable-and$owner.live_identity.command_line-ceq('"'+$owner.executable+'" '+($owner.arguments-join' '))) 'Actual compile live identity/arguments differ'
EqualRows $owner.arguments $plan.arguments 'Actual owner/plan arguments'
Require (($owner.arguments-join"`0")-ceq($plan.arguments-join"`0")) 'Ordered actual owner/plan arguments differ'
Require (($owner.arguments[0..5]-join'|')-ceq'build|build-jiti-controls-compile-only-artifact|-Doptimize=Debug|-Duse-llvm=true|-Ddiagnostic-tests=false|-j1'-and$owner.arguments.Count-eq14) 'Only exact one compile target allowed'
Require ($grant.authorized-and$grant.candidate_head-ceq$before.candidate_head-and$grant.driver_sha256-ceq'1CC8A417DF223E27A1728AB4E4B82391A16A94960302D8A7A2802960BDFD4371'-and([DateTimeOffset]$owner.created_utc)-ge([DateTimeOffset]$grant.issued_utc)-and([DateTimeOffset]$owner.created_utc)-lt([DateTimeOffset]$grant.expires_utc)-and!$grant.runtime_allowed-and!$grant.metadata_allowed-and!$grant.node_allowed) 'Actual issued compile-only grant differs'
Require ($grant.cache_mode-ceq'reuse_exact_unsealed'-and$grant.reuse_unsealed_compile_caches-and!$plan.cache_content_sealed-and$plan.output_prefix_fresh) 'Explicit cache exception differs'
$oldRoot=Join-Path $container 'evidence/jiti-controls-compile-only-native-prepared-20261017/root-jiti-83-compile-only-20261017-134316'
Require ($owner.arguments[9]-ceq(Join-Path $oldRoot 'cache')-and$owner.arguments[11]-ceq(Join-Path $oldRoot 'global-cache')-and$grant.cache_directory-ceq$owner.arguments[9]-and$grant.global_cache_directory-ceq$owner.arguments[11]-and$owner.arguments[7]-ceq(Join-Path $run 'out')) 'Exact old two caches/fresh output differ'
Require (($owner.arguments[6],$owner.arguments[8],$owner.arguments[10],$owner.arguments[12],$owner.arguments[13]-join'|')-ceq'--prefix|--cache-dir|--global-cache-dir|--summary|all') 'Ordered output/cache/summary flags differ'
Require ((Hash (Join-Path $run 'root-grant.json'))-ceq(Hash (Join-Path $packet 'root-jiti-83-compile-retry4-20261017-143404-grant.json'))) 'Copied grant differs'
$oldDriver=[IO.File]::ReadAllText((Join-Path $container 'evidence/jiti-controls-compile-only-retry3-prepared-20261017/Run-JitiCompileOnly.ps1'))
$newDriver=[IO.File]::ReadAllText((Join-Path $packet 'Run-JitiCompileOnly.ps1'))
Require ($oldDriver.Replace('20e8a95fcaf3f16daa18b71476189a019e4fa8e9','d460a3258903fb4b4e724c4ddc7b266e394315fe')-ceq$newDriver) 'Retry4 driver differs beyond exact head from retry3'
Require ($outer.status-ceq'passed'-and$outer.exit_code-eq0-and$outer.pid-eq15540-and$outer.timeout_seconds-eq1800-and$outer.live_identity.pid-eq$outer.pid-and([DateTimeOffset]$outer.created_utc)-eq([DateTimeOffset]$outer.live_identity.created_utc)-and$outer.live_identity.command_line-ceq('"'+$outer.executable+'" '+($outer.arguments-join' '))) 'Actual outer identity/terminal differs'
Require ($outerAbsent.pid-eq$outer.pid-and$outerAbsent.absent-and([DateTimeOffset]$outerAbsent.utc)-ge([DateTimeOffset]$outer.completed_utc)) 'Recorded outer absence differs'
Require ((Get-Item (Join-Path $packet 'root-jiti-83-compile-retry4-20261017-143404-outer.stderr.log')).Length-eq0-and(Hash (Join-Path $packet 'root-jiti-83-compile-retry4-20261017-143404-outer.stdout.bin'))-ceq(Hash (Join-Path $run 'result.json'))) 'Outer raw output differs'
$absent=@(ReadJson (Join-Path $run 'owner-absence.json'))
Require ($absent.Count-eq1-and$absent[0].pid-eq$owner.pid-and$absent[0].absent-and!$absent[0].current.Count) 'Recorded inner absence differs'
$censusPath=Join-Path $run 'process-census-final.json';$censusBytes=[IO.File]::ReadAllBytes($censusPath);$census=[Text.Json.JsonDocument]::Parse([ReadOnlyMemory[byte]]::new($censusBytes))
try{Require ($census.RootElement.GetProperty('candidates').GetArrayLength()-eq0-and$census.RootElement.GetProperty('rows').GetArrayLength()-gt0) 'Recorded final native census differs';$censusRows=$census.RootElement.GetProperty('rows').GetArrayLength()}finally{$census.Dispose();$censusBytes=$null}
foreach($name in @('initial-admission.json','compile-admission.json')){$probe=ReadJson (Join-Path $run $name);Require ($probe.free_kib-ge16777216-and$probe.native_roots-eq0-and!$probe.native_candidates.Count-and$probe.census_count-gt0-and([DateTimeOffset]$probe.utc)-lt([DateTimeOffset]$owner.created_utc)) "$name admission differs"}
$artifacts=ReadJson (Join-Path $run 'artifacts-before.json');$artifactsFinal=ReadJson (Join-Path $run 'artifacts-final.json')
Require ($artifacts.rows.Count-eq2-and$artifactsFinal.before_count-eq2-and$artifactsFinal.after_count-eq2-and!$artifactsFinal.path_drift.Count-and!$artifactsFinal.hash_drift.Count) 'Two-role artifact settlement differs'
EqualRows (Keys $artifacts.rows) (Keys $artifactsFinal.rows) 'Artifact pre/final'
Require (($artifacts.rows.relative-join'|')-ceq'bin/test.exe|bin/test.pdb') 'Actual artifact roles differ'
foreach($row in $artifacts.rows){Require ((Hash $row.path)-ceq$row.sha256-and(Get-Item $row.path).Length-gt0) "Artifact current hash differs: $($row.relative)"}
$coverage=ReadJson (Join-Path $candidate 'verification/jiti-controls-compile-only-20261017/coverage.json')
Require ($coverage.anchors.Count-eq83-and@($coverage.anchors.export|Sort-Object -Unique -CaseSensitive).Count-eq83) 'Typed source anchor list differs'
Require ((Hash (Join-Path $candidate 'src/native_jiti_compile_only_root.zig'))-ceq'36FE25C2E8500450ECC19A7F05AF8A8E7DA3D55DC9DE9A5612F656E3FD9E82A5') 'Reviewed real anchor root changed'
foreach($row in $coverage.anchors){Require ([IO.File]::ReadAllText((Join-Path $candidate ('src/'+$row.module))).Contains($row.signature)) "Actual typed signature differs: $($row.export)"}
$pdbText=[Text.Encoding]::Latin1.GetString([IO.File]::ReadAllBytes((Join-Path $run 'out/bin/test.pdb')))
Require (@($coverage.anchors|Where-Object{$pdbText.IndexOf($_.export,[StringComparison]::Ordinal)-lt0}).Count-eq0) 'Expected anchor name missing in static PDB bytes'
$pdbText=$null
$log=Get-Content (Join-Path $run 'compile.stderr.log')
Require ($log[0]-ceq'Build Summary: 158/158 steps succeeded'-and@($log|Where-Object{$_-match'compile test Debug native success'}).Count-eq1-and@($log|Where-Object{$_-match'compile lib pi-typescript-parser Debug native success'}).Count-eq1) 'Raw successful compile/link summary differs'
Require ((Get-Item (Join-Path $run 'compile.stdout.bin')).Length-eq0) 'Unexpected compile stdout'
$negatives=@(foreach($entry in @(@('jiti-controls-compile-only-native-prepared-20261017','2C8BCA9B60B20CEFFDDA353FA80A7DC4FD64921EA63DC79298CE5A9FBAFC6BB9'),@('jiti-controls-compile-only-retry-prepared-20261017','6057C0F37B02C0925FEAD95B22E70EAA3BFCB467432945BAB00E898F84F39BFA'),@('jiti-controls-compile-only-retry3-prepared-20261017','0DB0A453B862FA928A195FA294FB6EA3E1E1AB2DD13B507ABDEE97A39BABCE3D'))){
 $folder=Join-Path $container ('evidence/'+$entry[0]);Require ((Hash (Join-Path $folder 'Run-JitiCompileOnly.ps1'))-ceq$entry[1]) 'Historical driver differs'
 $attempt=Get-ChildItem -LiteralPath $folder -Directory|Where-Object Name -Like 'root-jiti*'|Select-Object -First 1
 $negative=ReadJson (Join-Path $attempt.FullName 'result.json');$negativeOwner=ReadJson (Join-Path $attempt.FullName 'compile.json');$nb=ReadJson (Join-Path $attempt.FullName 'before.json');$nf=ReadJson (Join-Path $attempt.FullName 'final.json')
 Require ($negative.status-ceq'failed'-and$negative.postseal-and$negative.owner_absence_verified-and$negative.native_roots_after-eq0-and!$negative.runtime_executed-and!$negative.metadata_executed-and!$negative.node_executed-and$negativeOwner.exit_code-eq1) 'Historical negative terminal differs'
 foreach($name in @('source','compiler','controls')){EqualRows (Keys $nb.$name $(if($name-eq'controls'){'path'}else{'relative'})) (Keys $nf.$name $(if($name-eq'controls'){'path'}else{'relative'})) "Historical $($entry[0]) $name"}
 [ordered]@{packet=$entry[0];run=$attempt.Name;source=$negative.source_head;driver_sha256=$entry[1];exit_code=1;postseal_drift=0;owner_absent=$true;native_roots_after=0;result_sha256=Hash (Join-Path $attempt.FullName 'result.json');stderr_sha256=Hash (Join-Path $attempt.FullName 'compile.stderr.log')}
})
$immutableNegative=ReadJson (Join-Path $packet 'negative-original.json')
foreach($row in $immutableNegative.files){Require ((Hash $row.path)-ceq$row.sha256) "Original negative immutable pin differs: $($row.path)"}
$audit=[ordered]@{status='accepted_finite_compile_and_link_only';head=$before.candidate_head;source_count=11101;compiler_count=19546;control_count=14;pre_final_current_drift=0;compiler_original_DEE_drift=0;typed_anchor_signatures=83;static_anchor_names_found_in_PDB=83;PDB_name_presence_is_not_runtime_or_DLL_export_proof=$true;test_metadata_queried=$false;test_bodies_executed=$false;sentinel_executed=$false;node_executed=$false;compile_owner_pid=$owner.pid;compile_elapsed_seconds=(([DateTimeOffset]$owner.completed_utc)-([DateTimeOffset]$owner.created_utc)).TotalSeconds;outer_owner_pid=$outer.pid;outer_elapsed_seconds=(([DateTimeOffset]$outer.completed_utc)-([DateTimeOffset]$outer.created_utc)).TotalSeconds;recorded_native_candidates=0;recorded_census_rows=$censusRows;fresh_auditor_census_performed=$false;artifacts=$artifacts.rows;cache_mode='explicit_exact134316_unsealed_reuse';cache_integrity_or_fresh_build_claim=$false;raw_build_steps=158;cached_labelled_lines=@($log|Where-Object{$_-match' cached(?: |$)'}).Count;success_labelled_lines=@($log|Where-Object{$_-match' success(?: |$)'}).Count;reused_labelled_lines=@($log|Where-Object{$_-match'reused'}).Count;historical_negatives=$negatives;immutable_original_negative_pins=$immutableNegative.files.Count;preserved_quirk='result.compile contains empty object plus receipt; compile.json authoritative';runtime_API_default_release_qualified=$false;reviewer_native_node_compiler_AST_jobs=$false;reviewer_Main_product_edits=$false}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'raw-audit.json'),($audit|ConvertTo-Json -Depth 10)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
[ordered]@{status=$audit.status;source=11101;compiler=19546;controls=14;anchors=83;negatives=$negatives.Count;raw_cached_lines=$audit.cached_labelled_lines;receipt_sha256=Hash (Join-Path $PSScriptRoot 'raw-audit.json')}|ConvertTo-Json
