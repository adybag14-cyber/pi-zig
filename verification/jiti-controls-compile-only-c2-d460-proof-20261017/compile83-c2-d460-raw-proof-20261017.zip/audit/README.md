This audit accepts compilation and linkage only for exact
d460a3258903fb4b4e724c4ddc7b266e394315fe, the C2 component worktree. It does
not qualify current Main, runtime behavior, API semantics, default assembly or
a release. No test artifact, metadata protocol, sentinel or Node was launched.

The actual single invocation was pinned Zig0.16 build of
build-jiti-controls-compile-only-artifact, Debug/LLVM, diagnostic-tests=false,
-j1, with fresh output and explicitly Root-authorized reuse of only the two
original134316 disposable UNSEALED caches. Neither cache integrity, a fresh
dependency build nor reproducibility is established. The raw build log reports
158/158 success, with153 cached-labelled lines and5 success-labelled lines
(target/install/test compile/TypeScript parser/options);80 lines mention reuse.
Those are raw line counts rather than an invented new dependency DAG metric.

Actual Zig owner PID53212 exited0 in20.612 seconds; outer PowerShell PID15540
exited0 in46.675 seconds. Their exact live command, retained handle, birth,
executable hash, grant and recorded independent absence evidence were checked.
The final recorded native-candidate set is empty. This audit did not perform a
fresh CIM census or start another native/process-qualification job.

All11101 source files,19546 compiler files and14 controls match both complete
before/final inventories and current read-only hashes. Compiler rows match the
immutable original DEE authority. The source remains clean at the exact head.
The83 genuine typed-call anchors and all actual signatures were checked; their
83 names also occur in static PDB bytes. This is not83 DLL exports, runtime
execution or symbol-level behavior proof. Planned eight test bodies remain
unqueried and unrun, including the deliberate failing sentinel.

Fresh output has exactly two nonempty roles. test.exe is49801728 bytes,
SHA256 E2FFEE13E02E11F3CED94DC4641F7B057A684FE2512FD8335FC23385DA5DC416;
test.pdb is16031744 bytes,
SHA256 AC21E44CE157B8C12F36A7FE8572F518F109B2D4167B65BA2506DAC5C940872F.
Both match before/final/current hashes. Their payloads remain local and are
excluded from the public file list. Mutable cache metadata is a local-only
observation, not a sealed accepted input.

The original7746/2C8 attempt,51e2/6057 attempt and20e8/0DB attempt all remain
terminal compile negatives with zero postseal drift and recorded absence/native
zero. Original18 immutable negative pins still match. Their raw outputs and
full seals are preserved in the public list. The final driver1CC8 differs from
0DB only by the exact candidate head, retaining the explicit cache exception.
The source fixes include C-value shims/typed capture handling, CJS argument
storage and actual TypeScript parser linkage; they are compile fixes, not
runtime qualification. result.compile's original [empty object,receipt] shape
is retained; compile.json is the authoritative scalar receipt.

public-files.json is a compact exact source/evidence path mapping, not a claim
that it has been published. It includes full pre/post inventories and raw owner,
grant, admission, absence, process-census, compile and negative records; selected
actual source/controls/C-H and source deltas. Whole source/compiler payloads,
executables, PDBs, libraries and all caches are excluded. No old proof or Main
file was edited. This directory's scripts perform source/hash/JSON reads only.
