//! Compile/link-only composition. No Subject, fixture or namespace is created.
//! Exported typed calls force dormant actual bodies to be analyzed/emitted.
//! This artifact has no approved runtime use; its sentinel fails if executed.
const std = @import("std");

fn Anchor(comptime function: anytype) type {
    const info = @typeInfo(@TypeOf(function)).@"fn";
    const Args = std.meta.ArgsTuple(@TypeOf(function));
    const Return = info.return_type orelse @compileError("Explicit control return type required");
    if (@typeInfo(Return) != .error_union) @compileError("This compile anchor requires an actual fallible control/body");
    const Payload = @typeInfo(Return).error_union.payload;
    return struct {
        fn entry(raw_args: *const anyopaque, raw_result: ?*anyopaque) callconv(.c) c_int {
            // Opaque pointers avoid inventing runtime inputs or a replacement
            // ABI for private Subject types. An approved real caller would own
            // this exact ArgsTuple and any returned payload; none runs here.
            const args: *const Args = @ptrCast(@alignCast(raw_args));
            if (Payload == void) {
                @call(.never_inline, function, args.*) catch return 1;
            } else {
                const result: *Payload = @ptrCast(@alignCast(raw_result orelse return 2));
                result.* = @call(.never_inline, function, args.*) catch return 1;
            }
            return 0;
        }
    };
}
fn retain(comptime module: type, comptime prefix: []const u8, comptime names: anytype) void {
    inline for (names) |name| {
        @export(&Anchor(@field(module, name)).entry, .{ .name = "jiti_compile_only_" ++ prefix ++ "_" ++ name });
    }
}
comptime {
    retain(@import("native_jiti_core_factory_controls.zig"), "core_control", .{
        "verifyUnlinkedNotExposed", "verifyForeignEngineRejected", "verifyCanonicalCycleAndOnce", "verifyWrapFailureAfterPublication", "verifyCompileFailureReturnsThroughRealTail", "verifyAcceptedTrace",
    });
    retain(@import("native_jiti_eval_module_controls.zig"), "eval_control", .{
        "verifyRealModuleAndCaches", "verifyAsyncPublicationAndFinish", "verifyAcceptedReturningOnError", "verifyMissingBindingBeforePublication", "verifyUnsupportedBeforePublication",
    });
    retain(@import("native_jiti_import_rejected_data_controls.zig"), "import_control", .{
        "verifyOldFlaggedData", "verifySameObjectOrdinaryRethrow", "installFreshFaultProbe", "verifyFreshResumedOOM", "verifyPendingHookFatalWins", "verifyDeferredBudgetInterrupt",
    });
    retain(@import("native_jiti_options_controls.zig"), "options_control", .{
        "verifyDirectHostCatchBeforeDiagnostics", "verifyDefaultsOverridesAndCallable", "verifyInheritedSettersAndSymbols", "verifyAcceptedGetterAndCatchTrace",
    });
    retain(@import("native_jiti_utils_controls.zig"), "utils_control", .{
        "verifyPhysicalDirectoryAndHashes", "verifyHashTemporaryRetirement", "verifyAcceptedCaller",
    });
    retain(@import("native_node_module_constructor_controls.zig"), "module_control", .{
        "verifyConstructorAndPrivateParents", "verifyEffectsAndPrimordials", "verifyActualPathReference", "verifyActualCachePublication", "verifyExactThrownReasons", "verifyPendingDeprecation",
    });
    retain(@import("native_get_tsconfig_test.zig"), "tsconfig_control", .{ "compareOriginal", "retainedMatcher" });
    retain(@import("native_mlly_syntax_controls.zig"), "syntax_control", .{ "observeActualExport", "observeAfterGc", "verifyAcceptedOriginalObservation" });

    // Cache/transform have actual production leaves but no dedicated control
    // module in this Root base. Retain their real exports, never fake subjects.
    retain(@import("extensions/native_jiti_fs_cache.zig"), "fs_cache", .{ "create", "getCache", "prepareCacheDir", "getCacheDir" });
    retain(@import("extensions/native_jiti_transform.zig"), "transform", .{ "create", "transform" });
    retain(@import("extensions/native_jiti_module_cache.zig"), "module_cache", .{ "forRequire", "lookup", "publishBeforeEval", "afterEvalFailure", "afterNativeSuccess", "loadedExports" });
    retain(@import("extensions/native_jiti_interop.zig"), "interop", .{ "jitiInteropDefault", "interopDefault", "jsonSelfDefault", "importDefault" });
    retain(@import("extensions/native_jiti_import.zig"), "import", .{"create"});
    retain(@import("extensions/native_jiti_require.zig"), "require", .{ "create", "require", "nativeImportOrRequire" });
    retain(@import("extensions/native_jiti_resolve.zig"), "resolve", .{ "createConstants", "create", "resolve" });
    retain(@import("extensions/native_jiti_core_factory.zig"), "core", .{ "validate", "instantiate" });
    retain(@import("extensions/native_jiti_core_graph.zig"), "graph", .{ "declare", "create" });
    retain(@import("extensions/native_jiti_module_cells.zig"), "cells", .{ "declare", "link", "initialize", "exports", "coreImports", "frontendImports", "isWindows" });
    retain(@import("extensions/native_jiti_eval_frontend.zig"), "frontend", .{ "validate", "evaluate" });
    retain(@import("extensions/native_jiti_eval_module.zig"), "evaluation", .{ "evaluateTransformed", "evaluateLowered" });
    retain(@import("extensions/native_jiti_options.zig"), "options", .{ "create", "resolve" });
    retain(@import("extensions/native_get_tsconfig.zig"), "tsconfig", .{"create"});
    retain(@import("extensions/native_mlly_syntax.zig"), "syntax", .{ "create", "hasESMSyntax" });
    retain(@import("extensions/native_jiti_colors.zig"), "colors", .{"create"});
    retain(@import("extensions/native_jiti_crypto.zig"), "crypto", .{"create"});
    retain(@import("extensions/native_jiti_utils.zig"), "utils", .{"create"});
    retain(@import("extensions/native_jiti_budget.zig"), "budget", .{ "check", "next" });
}

test "JITI_COMPILE_ONLY_SENTINEL_NEVER_RUNTIME_ACCEPTANCE" {
    return error.CompileOnlyArtifactMustNotRun;
}
