# Dormant jiti controls — compile/link only, not executed

This isolated target starts at Root263c8a92888f32097bd5b5a4ce0498aef1770eff,
after the exact reviewed utilities intake. It retains that C2 component base:
C 2FA2E26E35B7D5C45D1FFD3F6F10EE3A5DE9A984738486128399A20BD8E4D88D,
H 341CF06F8041B8311D49767026C85C7B859BCFEE3088380F3FFE6D77527052AB.
Root subsequently qualified C3 at21fb5be5;
any later Root rebase/grant must explicitly bind its actual C/H and exact source.
This packet does not silently claim the later C3 source or whole application.

build-jiti-controls-compile-only-artifact builds and installs one test artifact
with the existing real QuickJS/ICU/YAML/SQLite/photon/native-VM-identity/catalog
link configuration. There is NO addRunArtifact edge for this target. The source
test root exports small typed call anchors for the actual existing controls and
production bodies. Each anchor accepts opaque pointers to the genuine callee's
std.meta.ArgsTuple and output type and contains a real never-inline call. Those
arguments are never constructed or passed during compilation. The exports force
body analysis/code emission instead of merely inspecting signatures/refAllDecls.
They are internal compiler-retention devices, not a selected or stable runtime
ABI, and have no approved execution route in this gate.

The root retains controls for core/cells/frontend, transformed evaluation,
ordinary import rejection/fatal ownership, options, utilities, Module constructor,
get-tsconfig and MLLY syntax. Actual production exports additionally retain cache,
transform, interop/module cache, require/resolve, core/graph/cells/frontend,
evaluation, options, get-tsconfig, syntax, colors/crypto/utilities and budget bodies.
No fake Subject, empty namespace, dummy dependency or replacement fixture is
introduced. Existing control assertions, accepted inputs and expected-absence
state remain unchanged. Cache/transform have no dedicated native control leaf in
this base; their real production exports are explicitly retained instead.

The finite test filters compile the existing three get-tsconfig JSONC tests and
four utility primitive/budget tests, plus one deliberate compile-only sentinel.
NONE run. The sentinel returns CompileOnlyArtifactMustNotRun if someone executes
the artifact, preventing an all-tests-pass runtime receipt from this composition.
No expected runtime count/metadata is presented as observed; the planned count
is8, while the typed-export inventory is independently listed in coverage.json.
Exported calls preserve original function bodies and assertions; they do not
stand in for physical fixtures, actual dependency assembly or accepted observations.

The first static preparation established no missing relative module file, but
actual retry3 exposed the missing tree-sitter include/link binding reached by
native_jiti_cjs_lower. The target now calls existing linkTypeScriptParser with
the real typescript_parser library, exactly as existing native TypeScript tests.
That library builds actual tree-sitter lib.c, TypeScript parser.c and scanner.c;
the shared helper supplies tree_sitter/api.h, static linkage and libc. No header,
grammar, production body or anchor is replaced. This dependency fix itself has
not been compiled; prior actual compile negatives remain retained in evidence.
Public entrypoint signatures remain subject to the real compiler's typecheck/link.
Actual runtime prerequisites still missing/incomplete include the genuine linked
require/eval bootstrap, source expected observations and physical subjects, full
Node.Module/CommonJS/Babel/queued-import composition and native TTY/FIPS/default
graph gates. Their absence does not justify constructing empty positive subjects.

Future compile command, only with Root's separately issued exact-head grant:

    <pinned Zig0.16> build build-jiti-controls-compile-only-artifact -Doptimize=Debug -Duse-llvm=true -Ddiagnostic-tests=false -j1 --prefix <fresh-proof>/out --cache-dir <fresh-proof>/cache --global-cache-dir <fresh-proof>/global-cache --summary all

Root must retain canonical CI607 ownership, fresh16GiB/serial-native admission,
bounded compile lifetime, complete source/compiler/control before/final seals,
fresh EXE/PDB output inventory and independent owned-process/descendant absence.
No metadata/test/runtime process is required or authorized by this compile-only
target. Compile success, if later obtained, establishes body analysis/linkage only;
it cannot qualify jiti behavior, physical dependencies, Source parity or a release.

Only build.zig, this new root and source-only packet files change. Main, C/H,
Engine, production/control body assertions, inputs and goldens are untouched.
No Node, Zig, AST, formatter, generator, compiler or native job ran in preparation.
