param([Parameter(Mandatory)][string]$RootGrantPath,[Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9][A-Za-z0-9._-]{0,100}$')][string]$RunId)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$true
$taskContainer='C:\Users\adyba\pi-zig'
$taskRoot=Join-Path $taskContainer 'worktrees/jiti-compile-only'
$taskExpectedHead='20e8a95fcaf3f16daa18b71476189a019e4fa8e9'
$taskProof=Join-Path $PSScriptRoot $RunId
$taskCompiler=Join-Path $taskContainer 'toolchain/zig-x86_64-windows-0.16.0'
$taskZig=Join-Path $taskCompiler 'zig.exe'
$taskGit='C:\Program Files\Git\cmd\git.exe'
$taskCi=Join-Path $taskRoot 'tools/ci/native_qualification_ci.ps1'
$taskClassifier=Join-Path $PSScriptRoot 'Get-ModelsNativeCandidates.ps1'
$taskOuter=Join-Path $PSScriptRoot 'outer-owned-process.ps1'
$taskCompilerAuthority=Join-Path $taskContainer 'evidence/durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
$taskDriverHash=(Get-FileHash -LiteralPath $PSCommandPath).Hash
$taskGrant=Get-Content -Raw -LiteralPath $RootGrantPath|ConvertFrom-Json
$taskNow=[DateTimeOffset]::UtcNow
if($taskGrant.authorized -isnot [bool] -or !$taskGrant.authorized -or $taskGrant.scope -cne 'ROOT-JITI-C2-COMPILE-ONLY-RETRY-SERIAL' -or $taskGrant.run_id -cne $RunId -or $taskGrant.candidate_head -cne $taskExpectedHead -or $taskGrant.driver_sha256 -cne $taskDriverHash -or $taskGrant.runtime_allowed -isnot [bool] -or $taskGrant.runtime_allowed){throw 'Exact compile-only retry Root grant required'}
$taskIssued=[DateTimeOffset]$taskGrant.issued_utc;$taskExpires=[DateTimeOffset]$taskGrant.expires_utc
if($taskIssued -gt $taskNow -or $taskExpires -lt $taskNow -or $taskExpires -le $taskIssued -or ($taskExpires-$taskIssued).TotalSeconds -gt 300){throw 'Fresh initial Root grant bounded to300s required'}
$taskReusableBase=Join-Path $taskContainer 'evidence/jiti-controls-compile-only-native-prepared-20261017/root-jiti-83-compile-only-20261017-134316'
$taskReusableCache=Join-Path $taskReusableBase 'cache';$taskReusableGlobalCache=Join-Path $taskReusableBase 'global-cache'
if($taskGrant.cache_mode -cnotin @('fresh','reuse_exact_unsealed')){throw 'Explicit fresh or exact-unsealed cache mode required'}
if($taskGrant.reuse_unsealed_compile_caches -isnot [bool]){throw 'Explicit boolean cache reuse permission required'}
if($taskGrant.cache_mode -ceq 'reuse_exact_unsealed'){
 if(!$taskGrant.reuse_unsealed_compile_caches -or $taskGrant.cache_directory -cne $taskReusableCache -or $taskGrant.global_cache_directory -cne $taskReusableGlobalCache){throw 'Root must approve exact original two unsealed cache paths'}
 foreach($taskReusable in @($taskReusableCache,$taskReusableGlobalCache)){if(!(Test-Path -LiteralPath $taskReusable -PathType Container) -or ((Get-Item -LiteralPath $taskReusable).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Exact existing non-reparse disposable cache directories required'}}
}elseif($taskGrant.reuse_unsealed_compile_caches -or $null -ne $taskGrant.cache_directory -or $null -ne $taskGrant.global_cache_directory){throw 'Fresh cache mode must not authorize historical paths'}
if((Get-FileHash -LiteralPath $taskCi).Hash -cne '607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285' -or (Get-FileHash -LiteralPath $taskClassifier).Hash -cne '3413A2A50B4D4C3BFF8709E4EE08C76BE449AAB1EDCB1E0C5C167DC7A804E301' -or (Get-FileHash -LiteralPath $taskOuter).Hash -cne '53E522C8397B5F7EE9AF721D8160B227E97FADA4E1DA36A938656E2403D56B6B'){throw 'Canonical owner/census/outer identity differs'}
. $taskCi
. $taskClassifier
New-Item -ItemType Directory -Path $taskProof -ErrorAction Stop|Out-Null
Copy-Item -LiteralPath $RootGrantPath -Destination (Join-Path $taskProof 'root-grant.json') -ErrorAction Stop
$taskAdmissionHistory=[Collections.Generic.List[object]]::new()
function Write-TaskJson {param($Value,[string]$Name) ConvertTo-Json -InputObject $Value -Depth 16|Set-Content -LiteralPath (Join-Path $taskProof $Name) -Encoding utf8NoBOM}
function Get-TaskCensus {
 $taskRows=@(Get-CimInstance Win32_Process -OperationTimeoutSec 3 -ErrorAction Stop)
 if(!$taskRows.Count){throw 'Successful nonempty process census required'}
 return @{rows=$taskRows;candidates=@(Get-ModelsNativeCandidates -Rows $taskRows -Container $taskContainer)}
}
function Assert-TaskAdmission {
 $taskWait=[Diagnostics.Stopwatch]::StartNew()
 do {
  $taskOs=@(Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 3 -ErrorAction Stop)
  if($taskOs.Count -ne 1 -or $null -eq $taskOs[0].FreePhysicalMemory){throw 'One OS row with available RAM required'}
  $taskCensus=Get-TaskCensus
  $taskProbe=[ordered]@{free_kib=[long]$taskOs[0].FreePhysicalMemory;minimum_kib=16777216;native_roots=$taskCensus.candidates.Count;native_candidates=$taskCensus.candidates;census_count=$taskCensus.rows.Count;utc=[DateTimeOffset]::UtcNow.ToString('o')}
  $taskAdmissionHistory.Add($taskProbe)
  if($taskCensus.candidates.Count){throw 'Another native candidate prevents serial admission'}
  if($taskWait.Elapsed.TotalSeconds -ge 54){throw 'Fresh16GiB admission expired after bounded54s'}
  if($taskProbe.free_kib -ge 16777216){return $taskProbe}
  $taskRemainingMs=54000-$taskWait.ElapsedMilliseconds
  if($taskRemainingMs -gt 0){Start-Sleep -Milliseconds ([int][Math]::Min(1000,$taskRemainingMs))}
 }while($true)
}
function Get-TaskSeal {
 param([string]$Name)
 $taskPaths=@(& $taskGit -c core.fsmonitor=false -c core.hooksPath=NUL -C $taskRoot ls-files)
 if($LASTEXITCODE -ne 0 -or $taskPaths.Count -ne 11101 -or @($taskPaths|Sort-Object -Unique -CaseSensitive).Count -ne 11101){throw 'Exact full11101 tracked candidate paths required'}
 $taskHead=([string](& $taskGit -c core.fsmonitor=false -c core.hooksPath=NUL -C $taskRoot rev-parse HEAD)).Trim()
 if($LASTEXITCODE -ne 0 -or $taskHead -cne $taskExpectedHead){throw 'Exact C2 compile-only head differs'}
 $taskStatus=@(& $taskGit -c core.fsmonitor=false -c core.hooksPath=NUL -C $taskRoot status --porcelain)
 if($LASTEXITCODE -ne 0 -or $taskStatus.Count){throw 'Clean exact candidate required'}
 $taskCompilerInventory=Get-CiInventory $taskCompiler
 if($taskCompilerInventory.rows.Count -ne 19546){throw 'Complete compiler19546 required'}
 if((Get-FileHash -LiteralPath $taskCompilerAuthority).Hash -cne 'DEE259F171F720AB2C08E8DD473975E22C876417CD62E4F016C71A7C662794EB'){throw 'Immutable compiler authority differs'}
 $taskOriginal=Get-Content -Raw -LiteralPath $taskCompilerAuthority|ConvertFrom-Json
 $taskAuthorityRows=@($taskOriginal.inputs|ForEach-Object {if(!$_.path.StartsWith($taskOriginal.root+'\',[StringComparison]::Ordinal)){throw 'Compiler authority path escapes original root'};$_.path.Substring($taskOriginal.root.Length+1).Replace([char]92,[char]47)+' '+$_.sha256})
 $taskCompilerRows=@($taskCompilerInventory.rows|ForEach-Object {$_.relative.Replace([char]92,[char]47)+' '+$_.sha256})
 if($taskAuthorityRows.Count -ne 19546 -or @($taskAuthorityRows|Sort-Object -Unique -CaseSensitive).Count -ne 19546 -or @($taskCompilerRows|Sort-Object -Unique -CaseSensitive).Count -ne 19546 -or @(Compare-Object $taskAuthorityRows $taskCompilerRows -CaseSensitive).Count){throw 'Full compiler differs from original19546 authority'}
 $taskCPins=@{'vendor/quickjs/quickjs.c'='2FA2E26E35B7D5C45D1FFD3F6F10EE3A5DE9A984738486128399A20BD8E4D88D';'vendor/quickjs/quickjs.h'='341CF06F8041B8311D49767026C85C7B859BCFEE3088380F3FFE6D77527052AB';'tools/ci/native_qualification_ci.ps1'='607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285'}
 foreach($taskPin in $taskCPins.GetEnumerator()){if((Get-FileHash -LiteralPath (Join-Path $taskRoot $taskPin.Key)).Hash -cne $taskPin.Value){throw "Exact C2/owner pin differs: $($taskPin.Key)"}}
 $taskExpectedAbsent=@('src/extensions/fixtures/jiti-utils-2_7.expected.json','src/extensions/fixtures/jiti-options-2_7.expected.json')
 foreach($taskPath in $taskExpectedAbsent){if(Test-Path -LiteralPath (Join-Path $taskRoot $taskPath)){throw 'Uncaptured expected file unexpectedly present'}}
 $taskControlPaths=@($PSCommandPath,$taskCi,$taskClassifier,$taskOuter,$taskCompilerAuthority,(Join-Path $PSScriptRoot 'README.md'),(Join-Path $PSScriptRoot 'negative-original.json'),(Join-Path $PSScriptRoot 'root-grant.template.json'),(Join-Path $PSScriptRoot 'prepared-manifest.json'),(Join-Path $taskProof 'root-grant.json'),(Join-Path $taskContainer '.pi-zig-workspace.json'),(Join-Path $taskContainer 'path-relocations.json'),$taskGit,'C:\Program Files\PowerShell\7\pwsh.exe')
 $taskSeal=[ordered]@{candidate_head=$taskHead;source=@(Get-CiRows $taskRoot $taskPaths);compiler=@($taskCompilerInventory.rows);controls=@($taskControlPaths|ForEach-Object {[ordered]@{path=$_;sha256=(Get-FileHash -LiteralPath $_).Hash}});expected_absences=$taskExpectedAbsent;utc=[DateTimeOffset]::UtcNow.ToString('o')}
 Write-TaskJson $taskSeal "$Name.json";return $taskSeal
}
function Assert-TaskSeal {
 param($Actual,$Expected)
 if($Actual.candidate_head -cne $Expected.candidate_head){throw 'Source head drift'}
 foreach($taskGroup in @('source','compiler','controls')){
  $taskLeft=@($Expected[$taskGroup]|ForEach-Object {$(if($taskGroup -ceq 'controls'){$_.path}else{$_.relative})+' '+$_.sha256})
  $taskRight=@($Actual[$taskGroup]|ForEach-Object {$(if($taskGroup -ceq 'controls'){$_.path}else{$_.relative})+' '+$_.sha256})
  if(@(Compare-Object $taskLeft $taskRight -CaseSensitive).Count){throw "$taskGroup inventory/hash drift"}
 }
}
$taskResult=[ordered]@{status='running';source_head=$taskExpectedHead;scope='C2 compile/link of actual83 bodies only';cache_mode=$taskGrant.cache_mode;runtime_executed=$false;metadata_executed=$false;node_executed=$false;compile=$null;postseal=$false;artifacts_verified=$false;native_roots_after=$null;owner_absence_verified=$false}
$taskBefore=$null;$taskArtifacts=$null;$taskCompileAttempted=$false
try {
 if((Get-FileHash -LiteralPath $taskZig).Hash -cne '086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864'){throw 'Pinned Zig0.16 differs'}
 Write-TaskJson (Assert-TaskAdmission) 'initial-admission.json'
 $taskBefore=Get-TaskSeal 'before'
 Write-TaskJson (Assert-TaskAdmission) 'compile-admission.json'
 $taskPrefix=Join-Path $taskProof 'out';$taskCache=Join-Path $taskProof 'cache';$taskGlobalCache=Join-Path $taskProof 'global-cache'
 foreach($taskFresh in @($taskPrefix,$taskCache,$taskGlobalCache)){if(Test-Path -LiteralPath $taskFresh){throw 'Fresh artifact/cache paths required'}}
 if($taskGrant.cache_mode -ceq 'reuse_exact_unsealed'){$taskCache=$taskReusableCache;$taskGlobalCache=$taskReusableGlobalCache}
 $taskArgs=@('build','build-jiti-controls-compile-only-artifact','-Doptimize=Debug','-Duse-llvm=true','-Ddiagnostic-tests=false','-j1','--prefix',$taskPrefix,'--cache-dir',$taskCache,'--global-cache-dir',$taskGlobalCache,'--summary','all')
 Write-TaskJson @{executable=$taskZig;arguments=$taskArgs;timeout_seconds=1320;pipe_settle_seconds=10;cache_mode=$taskGrant.cache_mode;cache_directory=$taskCache;global_cache_directory=$taskGlobalCache;cache_content_sealed=$false;output_prefix_fresh=$true} 'compile-plan.json'
 $taskCompileAttempted=$true
 $taskResult.compile=Invoke-CiOwnedProcess $taskZig $taskArgs $taskRoot (Join-Path $taskProof 'compile') 1320
 $taskArtifacts=Get-CiInventory $taskPrefix;Write-TaskJson $taskArtifacts 'artifacts-before.json'
 $taskRoles=@($taskArtifacts.rows|ForEach-Object {$_.relative.Replace([char]92,[char]47)}|Sort-Object -CaseSensitive)
 if($taskRoles.Count -ne 2 -or ($taskRoles -join '|') -cne 'bin/test.exe|bin/test.pdb'){throw 'Exactly fresh bin/test.exe and bin/test.pdb roles required'}
 foreach($taskRole in $taskRoles){if((Get-Item -LiteralPath (Join-Path $taskPrefix $taskRole)).Length -le 0){throw 'Nonempty EXE/PDB required'}}
 $taskResult.artifacts_verified=$true;$taskResult.status='compile_only_passed'
}catch{$taskResult.status='failed';$taskResult.error=$_.Exception.Message}
finally {
 try{$taskFinal=Get-TaskSeal 'final';if($null -eq $taskBefore){throw 'Before baseline unavailable; final retained only'};Assert-TaskSeal $taskFinal $taskBefore;$taskResult.postseal=$true}catch{$taskResult.status='failed_postseal';$taskResult.postseal_error=$_.Exception.Message}
 try{if($null -ne $taskArtifacts){Assert-CiInventory $taskArtifacts (Join-Path $taskProof 'artifacts-final.json')}elseif(Test-Path -LiteralPath (Join-Path $taskProof 'out')){Write-TaskJson (Get-CiInventory (Join-Path $taskProof 'out')) 'artifacts-negative.json'}}catch{$taskResult.status='failed_artifacts';$taskResult.artifacts_error=$_.Exception.Message}
 try{$taskCensus=Get-TaskCensus;Write-TaskJson $taskCensus 'process-census-final.json';$taskResult.native_roots_after=$taskCensus.candidates.Count;if($taskCensus.candidates.Count){throw 'Native candidates remain'}}catch{$taskResult.status='failed_native_census';$taskResult.census_error=$_.Exception.Message}
 try{
  $taskReceipt=Join-Path $taskProof 'compile.json'
  if($taskCompileAttempted -and !(Test-Path -LiteralPath $taskReceipt)){throw 'Attempted compile has no durable owner receipt; independent reconciliation required'}
  $taskAbsent=@(if(Test-Path -LiteralPath $taskReceipt){$taskOwner=Get-Content -Raw -LiteralPath $taskReceipt|ConvertFrom-Json;if(!$taskOwner.pid -or !$taskOwner.created_utc){throw 'Incomplete original compile owner identity'};$taskLive=@(Get-CimInstance Win32_Process -Filter "ProcessId = $($taskOwner.pid)" -OperationTimeoutSec 3 -ErrorAction Stop);[ordered]@{phase='compile';owner_receipt=$taskReceipt;pid=$taskOwner.pid;recorded_created_utc=$taskOwner.created_utc;current=$taskLive;absent=($taskLive.Count -eq 0)}})
  Write-TaskJson $taskAbsent 'owner-absence.json'
  if(@($taskAbsent|Where-Object {!$_.absent}).Count){throw 'Original owner PID still present or reused; Root reconciliation required'}
  $taskResult.owner_absence_verified=(!$taskCompileAttempted -or $taskAbsent.Count -eq 1)
 }catch{$taskResult.status='failed_absence';$taskResult.absence_error=$_.Exception.Message}
 $taskResult.admission_probes=$taskAdmissionHistory.ToArray();$taskResult.completed_utc=[DateTimeOffset]::UtcNow.ToString('o');Write-TaskJson $taskResult 'result.json'
}
$taskResult|ConvertTo-Json -Depth 16
if($taskResult.status -cne 'compile_only_passed'){throw 'Jiti compile-only gate failed'}

