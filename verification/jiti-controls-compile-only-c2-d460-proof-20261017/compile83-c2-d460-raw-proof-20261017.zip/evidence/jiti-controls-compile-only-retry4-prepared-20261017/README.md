# Prospective C2 jiti body compile/link gate

SOURCE ONLY. No execution is authorized by this packet or its template grant.
Root must review the exact driver hash and issue one fresh grant for its RunId.
Candidate: worktrees/jiti-compile-only atd460a3258903fb4b4e724c4ddc7b266e394315fe,
11101 tracked files. This intentionally retains reviewed263 C2 component source;
it does not claim later C3 source or product parity.

The ONLY candidate process launch is pinned Zig0.16 build with target
build-jiti-controls-compile-only-artifact, Debug, use-llvm=true, diagnostic-tests=false,
-j1 and a fresh RunId/out. The default uses fresh RunId/cache and global-cache;
only exact new Root permission admits the two original unsealed cache paths.
Exact successful installed roles are bin/test.exe and bin/test.pdb,
both nonempty and inventoried before/final. The artifact is NEVER launched.
No metadata protocol, test protocol, Node child, Source capture or generator is
invoked. Existing seven selected test bodies plus sentinel are compiled only;
actual metadata is not queried. The83 actual exported calls retain dormant bodies.

Inner owner is unchanged CI607; compile1320s, pipe settlement10s. Root's external
deadline is1800s using the unchanged outer53 owner included here. Process/CIM/file
hashing are synchronous OS operations: these controls do not invent a hard
wall-clock guarantee for a stalled OS query. Canonical owner cleanup is unchanged.
Fresh available16GiB and zero native candidates are required; admission uses
successful nonempty bounded3s CIM requests and the reviewed3413 classifier,
including incomplete known-native identities. Each admission window is54s.
The initial exact Root grant has a maximum300s validity interval; it authorizes
the bounded pair of preparation/build, not a renewable or indefinite lease.

Before/final seals cover all11101 tracked source files, clean exact head, all19546
compiler files compared to immutable DEE original authority, the driver/CI owner/
classifier/outer/compiler authority/packet files/grant/container paths/Git/pwsh.
C2 C2FA2/H341 pins are checked in every seal. Uncaptured utils/options expected
files must remain absent. Initial and precompile admission histories are durable.
Finally independently attempts full seal, output inventory, complete process
census/classification and original compile PID absence; negatives remain saved.
Missing owner receipts or live/reused original PID fail closed. Root must also
independently verify outer runner and descendant absence after terminal return.

Root's future invocation shape (not executed here):

    . <this-directory>/outer-owned-process.ps1
    Invoke-CiOwnedProcess 'C:\Program Files\PowerShell\7\pwsh.exe' @('-NoProfile','-NonInteractive','-File','<this-directory>/Run-JitiCompileOnly.ps1','-RootGrantPath','<fresh-authorized-grant>','-RunId','<fresh-run>') 'C:\Users\adyba\pi-zig' '<external-receipt>' 1800

The copied outer SHA is53E522C8397B5F7EE9AF721D8160B227E97FADA4E1DA36A938656E2403D56B6B.
It is a byte-exact approved owner reuse; no new process supervisor is authored.
Root owns the outer invocation and must preserve its receipt/output/independent
absence alongside the inner raw compile receipt/stdout/stderr/final seals.

Compile success means actual body analysis and linkage only. No runtime behavior,
Source parity, default dependency assembly, current full application or release
qualification follows. Missing physical Subjects/accepted observations and genuine
require/eval/CommonJS/Babel/queued-import/TTY/FIPS composition remain explicit.
Source preparation ran no Node, Zig, compiler, native, generator or formatter job.

Retry source51e2a contains ONLY the Root-authored two-file8+/8- lexical correction:
native_file_stat removes one extraneous semicolon; native_jiti_cjs_lower renames
two text parameters and one imported local plus their uses. The original7746
attempt stopped with four syntax/shadow errors after153/156 dependency steps.
Original driver2C8 and all original proof files remain unchanged; their hashes
are recorded in negative-original.json. This is not a prior successful compile.

Cache policy is explicit in the new Root grant:
- cache_mode=fresh, reuse_unsealed_compile_caches=false, both path fields=null;
  use the new RunId/cache and RunId/global-cache.
- cache_mode=reuse_exact_unsealed, reuse_unsealed_compile_caches=true, and both
  paths must exactly equal the original run's cache and global-cache below.
  Any other path or inconsistent/missing permission fails before build.

C:\Users\adyba\pi-zig\evidence\jiti-controls-compile-only-native-prepared-20261017\root-jiti-83-compile-only-20261017-134316\cache
C:\Users\adyba\pi-zig\evidence\jiti-controls-compile-only-native-prepared-20261017\root-jiti-83-compile-only-20261017-134316\global-cache

These are mutable, UNSEALED compiler caches, explicitly outside source/control
qualification. Root's permission is specific to this build. Cache hashes are not
used as accepted product evidence. Fresh output/EXE/PDB, all source/compiler/
control seals, source-head/C-H pins, ownership/admission and deadlines remain
mandatory. No old out artifact is reused or launched. The compile-plan records
mode and both actual cache paths before launch. No production/control assertion
or expected file is changed by this retry packet.
