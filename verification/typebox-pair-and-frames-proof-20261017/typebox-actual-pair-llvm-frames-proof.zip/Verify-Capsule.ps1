param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop'
$base=[IO.Path]::GetFullPath($Root)
$m=Get-Content -LiteralPath (Join-Path $base 'capsule-manifest.json') -Raw|ConvertFrom-Json
$names=@(Get-ChildItem -LiteralPath $base -File -Recurse|ForEach-Object{[IO.Path]::GetRelativePath($base,$_.FullName).Replace([char]92,[char]47)})
if(@(Compare-Object (@($m.members.member)+@('capsule-manifest.json')) $names -CaseSensitive).Count){throw 'Member inventory differs'}
foreach($r in $m.members){if([IO.Path]::IsPathRooted($r.member)-or$r.member.Split('/')-contains'..'-or$r.member-match'\.(exe|pdb|dll|bin)$'){throw 'Forbidden/unsafe member'};$p=Join-Path $base $r.member;if((Get-Item -LiteralPath $p).Length-ne$r.bytes-or(Get-FileHash -LiteralPath $p).Hash-cne$r.sha256){throw ('Member hash/size differs: '+$r.member)}}
$pair=Get-Content -LiteralPath (Join-Path $base 'pair/actual-pdb-pair.public.json') -Raw|ConvertFrom-Json
$headers=Get-Content -LiteralPath (Join-Path $base 'pair/actual-header-spans.json') -Raw|ConvertFrom-Json
$total=0;foreach($s in $headers.spans){$b=[Convert]::FromHexString($s.hex);if($b.Length-ne$s.bytes-or[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($b))-cne$s.sha256){throw 'Header span bytes/hash differ'};$total+=$b.Length}
if($headers.spans.Count-ne17-or$total-ne32158-or$headers.pair_receipt_sha256-cne'3848AB78428CD458C74345BD2C42EAA4ED29272F416CB448F225A20EC6F685A9'){throw 'Exact accepted header span accounting differs'}
$cv=[Convert]::FromHexString(@($headers.spans|Where-Object artifact_role -CEQ 'PE unique RSDS record')[0].hex)
$info=[Convert]::FromHexString(@($headers.spans|Where-Object artifact_role -CEQ 'PDB stream1 info page')[0].hex)
$cg=[Guid]::new([byte[]]($cv[4..19])).ToString('D');$pg=[Guid]::new([byte[]]($info[12..27])).ToString('D')
if([Text.Encoding]::ASCII.GetString($cv,0,4)-cne'RSDS'-or$cg-cne$pg-or$cg-cne$pair.exe_codeview_guid-or$pg-cne$pair.pdb_info_guid-or[BitConverter]::ToUInt32($cv,20)-ne$pair.exe_age-or[BitConverter]::ToUInt32($info,8)-ne$pair.pdb_age-or$pair.exe_age-ne$pair.pdb_age){throw 'Actual header GUID/age pair differs'}
$frames=@(Get-Content -LiteralPath (Join-Path $base 'analysis/all-fixed-frames.json') -Raw|ConvertFrom-Json)
$byID=@{};$byName=@{};foreach($f in $frames){if($byID.ContainsKey($f.identity)){throw 'Duplicate frame identity'};$byID[$f.identity]=$f;if(!$byName.ContainsKey($f.procedure_name)){$byName[$f.procedure_name]=0};$byName[$f.procedure_name]++}
$reader=[IO.StreamReader]::new((Join-Path $base 'raw/llvm.symbols.path-redacted.txt'));$mod=$null;$cur=$null;$pending=$false;$count=0;$orphan=0;$seen=[Collections.Generic.HashSet[string]]::new();$watch=[Diagnostics.Stopwatch]::StartNew()
try{while($null-ne($line=$reader.ReadLine())){if($watch.Elapsed.TotalSeconds-gt120){throw 'Bounded public-dump verification timeout'}
 if($line-match'^\s*Mod\s+(\d+)\s+\|'){$mod=[int]$Matches[1];$cur=$null;continue}
 if($line-match'^\s*(\d+)\s+\|\s+S_[LG]PROC32(?:_DPC_ID|_DPC|_ID)?\b.*?`([^`]+)`'){$cur=@{record=[long]$Matches[1];name=$Matches[2];address=$null;end=$null};continue}
 if($null-ne$cur-and$line-match'^\s*parent = \d+, end = (\d+), addr = ([0-9A-Fa-f]+:\d+), code size = \d+'){$cur.end=[long]$Matches[1];$cur.address=$Matches[2];continue}
 if($line-match'^\s*\d+\s+\|\s+S_FRAMEPROC\b'){if($null-eq$cur){$orphan++};$pending=$true;continue}
 if($pending-and$line-match'^\s*size = (\d+), padding size = \d+'){$size=[long]$Matches[1];if($null-eq$cur){throw 'Orphan frame'};$id=$mod.ToString()+':'+$cur.record+':'+$cur.address;if(!$byID.ContainsKey($id)-or$byID[$id].frame_bytes-ne$size-or$byID[$id].procedure_name-cne$cur.name-or!$seen.Add($id)){throw 'Dump/analysis frame association differs'};$count++;$pending=$false;continue}
 if($null-ne$cur-and$line-match'^\s*(\d+)\s+\|\s+S_END\b'-and[long]$Matches[1]-eq$cur.end){$cur=$null}
}}finally{$reader.Dispose()}
if($count-ne16985-or$count-ne$frames.Count-or$orphan){throw 'Full frame accounting differs'}
$map=Get-Content -LiteralPath (Join-Path $base 'source/lowering-map.json') -Raw|ConvertFrom-Json
$source=[IO.File]::ReadAllText((Join-Path $base 'source/native_typebox_operators_production.zig'))
$pcs=[regex]::Matches($source,'(?m)^noinline fn (typebox_pc_\d+_\d+)\(')
if($map.heapContinuations.steps.Count-ne34-or$pcs.Count-ne2022){throw 'Actual source census differs'}
foreach($pc in $pcs){if(!$byName.ContainsKey($pc.Groups[1].Value)-or$byName[$pc.Groups[1].Value]-ne1){throw 'PC symbol correspondence differs'}}
$a=Get-Content -LiteralPath (Join-Path $base 'acceptance/independent-acceptance-controller-schema.json') -Raw|ConvertFrom-Json
if((Get-FileHash -LiteralPath (Join-Path $base 'source/native_typebox_operators_production.zig')).Hash-cne$a.generated_native_sha256-or(Get-FileHash -LiteralPath (Join-Path $base 'source/lowering-map.json')).Hash-cne$a.generated_map_sha256){throw 'Accepted source/map byte join differs'}
[ordered]@{status='public_capsule_verified';members=$m.members.Count;header_bytes=$total;procedure_frames=$count;plans=34;pc_symbols=$pcs.Count;ASLR_or_dynamic_peak_claim=$false;child_processes_started=0}|ConvertTo-Json
