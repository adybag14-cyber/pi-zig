# Actual fdf6 TypeBox matching-artifact fixed frames

This is read-only interpretation of the actual retained LLVM dump E405D80A,
51,245,883bytes, for EXE CE0572A0/PDB94B50DE6 at source
fdf6f25e4ef61321abaa4b9884eeb1cf97be6d18. Full hashes and exact input/output
identities are in the adjacent manifest. The accepted generated module is22388C87
and its map186D9248. Pair receipt3848AB78 verifies actual RSDS/MSF stream1
GUID5c2950c8-f252-3f31-4c4c-44205044422e, age1; no filename inference.

The bounded streaming interpretation read1,068,535lines and accounted for all
16,985 S_LPROC32/GPROC32 procedures and16,985 associated FRAMEPROC records.
There are zero orphan/missing frames and unique complete procedure identities.
Each identity retains object/module, record offset, printed section:offset,
procedure/frame lines, code size, type, frame size, saved-register bytes and
visible parameter names/types. Printed short names are not namespaces.

All34 actual source plan declarations and34 step tables join to exactly one
PDB data record each. Every one of2022 source PC declarations/table positions
joins to exactly one procedure/frame symbol, with zero missing/ambiguous names.
The complete per-PC evidence is in pc-symbol-correspondence.json; per-plan
source spans/slots/entry/call counts/data-symbol identities are in
plan-correspondence.json. All1669 legacy f_N callbacks are also retained as
unique PDB names. Their presence does not establish their bodies executed.
The new registry uses f_N as identity/provenance while selecting Plan/PC bodies.

PC fixed frames range56..392bytes. These are static FRAMEPROC values, with saved
register bytes retained separately; they are not dynamic stack samples, full
activation costs or safe values to sum into a peak/depth estimate. No ASLR base,
absolute runtime address, current per-PC execution count or live Source391 path
is inferred. The old instrumented08bd trace is a separate artifact and its
dispatcher frame addresses are not reused as new callback-frame measurements.

## Plan and PC correspondence

| Source callback identity | PC entries | PC fixed frame min..max bytes | Plan/table data matches | Missing/ambiguous PC symbols |
|---|---:|---:|---:|---:|
| f_0 | 20 | 104..328 | 1/1 | 0/0 |
| f_1 | 47 | 104..376 | 1/1 | 0/0 |
| f_9 | 716 | 104..376 | 1/1 | 0/0 |
| f_30 | 13 | 104..392 | 1/1 | 0/0 |
| f_31 | 18 | 104..328 | 1/1 | 0/0 |
| f_32 | 3 | 104..312 | 1/1 | 0/0 |
| f_33 | 35 | 104..376 | 1/1 | 0/0 |
| f_296 | 24 | 104..328 | 1/1 | 0/0 |
| f_297 | 16 | 104..392 | 1/1 | 0/0 |
| f_298 | 13 | 104..328 | 1/1 | 0/0 |
| f_303 | 16 | 104..344 | 1/1 | 0/0 |
| f_450 | 21 | 104..392 | 1/1 | 0/0 |
| f_451 | 24 | 104..376 | 1/1 | 0/0 |
| f_625 | 354 | 104..376 | 1/1 | 0/0 |
| f_628 | 92 | 104..376 | 1/1 | 0/0 |
| f_637 | 18 | 104..328 | 1/1 | 0/0 |
| f_638 | 36 | 104..392 | 1/1 | 0/0 |
| f_642 | 59 | 104..376 | 1/1 | 0/0 |
| f_660 | 24 | 104..392 | 1/1 | 0/0 |
| f_661 | 27 | 104..328 | 1/1 | 0/0 |
| f_662 | 73 | 56..376 | 1/1 | 0/0 |
| f_663 | 11 | 104..344 | 1/1 | 0/0 |
| f_664 | 22 | 104..376 | 1/1 | 0/0 |
| f_666 | 21 | 104..328 | 1/1 | 0/0 |
| f_667 | 19 | 104..392 | 1/1 | 0/0 |
| f_668 | 19 | 104..328 | 1/1 | 0/0 |
| f_669 | 4 | 104..328 | 1/1 | 0/0 |
| f_670 | 45 | 104..392 | 1/1 | 0/0 |
| f_671 | 31 | 104..376 | 1/1 | 0/0 |
| f_672 | 27 | 104..376 | 1/1 | 0/0 |
| f_673 | 43 | 104..376 | 1/1 | 0/0 |
| f_674 | 65 | 104..376 | 1/1 | 0/0 |
| f_675 | 13 | 104..344 | 1/1 | 0/0 |
| f_686 | 53 | 104..328 | 1/1 | 0/0 |

## Native kernel and Node bridge signature profiles

The following source labels use exact short name plus ordered visible parameter names, corroborated by printed parameter-type prefixes. All14 profiles have one matching symbol. Full same-name candidate sets remain in common-symbol-candidates.json (for example prepare has274 candidates and invokeBody has2). This is a finite signature-profile correlation, not invented full namespace or line-table information. NativeNode.call has an unnamed context parameter which is absent from the visible-name list.

| Source signature profile | Fixed frame bytes | Exact module:record:printed-address identity |
|---|---:|---|
| Machine.run | 1720 | 1:3254044:0001:29768736 |
| Machine.call | 1544 | 1:3253312:0001:29764816 |
| Machine.complete | 1016 | 1:3252248:0001:29761840 |
| Machine.cleanupFailure | 248 | 1:3252992:0001:29764464 |
| heap.prepare | 584 | 1:3251196:0001:29757712 |
| heap.destroy | 664 | 1:3258816:0001:29782000 |
| heap.invokeBody | 920 | 1:3254888:0001:29772672 |
| NativeNode.invokeBody | 376 | 1:3255572:0001:29774688 |
| NativeNode.invoke | 696 | 1:3255872:0001:29775440 |
| NativeNode.call | 672 | 1:3256284:0001:29777376 |
| heap.intercept | 848 | 1:3251632:0001:29759184 |
| heap.captureOwned | 872 | 1:3258304:0001:29780416 |
| heap.failureReason | 488 | 1:3260284:0001:29784640 |
| heap.register | 408 | 1:673744:0001:1561696 |

## Retained artifact comparisons

These are literal-name fixed-frame comparisons with complete parameter/object/record identities retained in JSON. Baseline1f9 is source1f9eee9e/EXEE2E091FC/PDB429C5700/rawDB6EAABE/mapF1D8A2DD. Callstep283 is source283a0aee/EXE5E791F30/PDBA7C019D2/raw59E0F2C3/mapD0FDAE44. All old raw hashes were checked before and after selective streaming; no qualification transfers between these builds.

| Symbol | Baseline1f9 bytes | Callstep283 bytes | Current fdf6 bytes |
|---|---:|---:|---:|
| f_1 | 1392 | 1392 | 1392 |
| f_9 | 1432 | 1432 | 1432 |
| f_625 | 1784 | 1624 | 1624 |
| f_628 | 3400 | 3096 | 3096 |
| f_642 | 2536 | 2232 | 2232 |
| f_660 | 1688 | 1544 | 1544 |
| f_661 | 1928 | 1768 | 1768 |
| f_662 | 1976 | 1720 | 1720 |
| f_674 | 5320 | 5320 | 5320 |
| f_591 | 2232 | 2232 | 2232 |
| try_block_0 | 1064 | 632 | 632 |
| JS_CallInternal | 144 | 144 | 144 |
| JS_CallBytecode | 2112 | 2112 | 2032 |
| JS_Call | 128 | 128 | 128 |
| js_call_c_function | 272 | 272 | 272 |
| js_array_reduce | 416 | 416 | 416 |

f_591 is uniquely2232bytes, agreeing with Root's independent actual-dump example.
Legacy f_628/f_642 remain3096/2232bytes, identical to callstep283; this result must
not be described as those legacy bodies disappearing or shrinking again.
The structural change is explicit heap activation/continuation dispatch with
small noinline PC steps. Native/private-call continuations can retire VM/native
frames before the next step while actual external/builtin/proxy/constructor
calls preserve their real VM semantics. Those semantics are source-code and
functional-test evidence, not a dynamic peak measurement from these symbols.

The current unique C symbols include JS_CallInternal144bytes, JS_CallBytecode
2032bytes, JS_Call128bytes, js_call_c_function272bytes, js_array_reduce416bytes.
JS_CallInternalBody is absent: its missing entry is retained explicitly rather
than replaced by another similar name. The baseline Bytecode frame is2112bytes;
the80byte static difference has multiple source/build changes and is not
attributed solely to heap continuations. Do not sum these values into a budget.

The largest globally linked frames include updateTask2,128,424bytes and other
large Windows-related symbols. This dump alone does not place those procedures
on the Source396 recursive path, so they establish no Source391 peak or failure.

## Functional evidence is separate

The actual original product4 runtime result A521AD00 at the same fdf6/CE0572
artifact completed all4 flags0 and all80/52/396 parity markers, with fullpost and
owned absence. The unchanged expected row391, generic-default-instantiation-
limit-recovery, contains ordinary Error("Type instantiation is excessively deep
and possibly infinite"), the recovered Literal, and assign129/create792. Full
Source396 row equality establishes that original semantic result. It does not
measure physical peak stack. Guard1MiB and PE reserve16MiB were unchanged;
there is no threshold/counter/golden normalization, ASLR or whole-application
qualification implied by this static analysis. GPA/Cmalloc exhaustiveness and
later source successors remain separate scopes.

## Preserved derivation history

The first derivation directory is retained unchanged. It had correct frame
association/size identities but lost parameter type/flag fields because a
second PowerShell -match overwrote Matches. SelectedV2 uses Regex.IsMatch,
restores those fields, and validates zero drift in all16985 frame identities,
frame sizes, frame-record offsets and saved-register values. No raw dump,
source, fixture, artifact, baseline or earlier proof was edited. No LLVM,
Node, compiler, native test or other child process was launched for analysis.