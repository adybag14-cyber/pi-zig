$ErrorActionPreference='Stop'
$taskEvidence=$PSScriptRoot
$taskPackage='C:/Users/adyba/pi-upstream-source-4954d76-20261015/packages/coding-agent/package.json'
$taskFrozen=Join-Path $taskEvidence 'auth-storage-production-4954-source47-first-20261015-package-frozen.json'
$taskMetadata=Join-Path $taskEvidence 'auth-storage-production-4954-source47-first-20261015-package-before.json'
if(Test-Path -LiteralPath $taskFrozen){throw 'Refuse package guard replay'}
$taskHash=(Get-FileHash -LiteralPath $taskPackage).Hash
$taskSourceRows=@(Get-Content -LiteralPath (Join-Path $taskEvidence 'source4954-full-manifest-20261015.json') -Raw|ConvertFrom-Json)
$taskPackageRows=@($taskSourceRows|Where-Object {[IO.Path]::GetFullPath($_.path) -ceq [IO.Path]::GetFullPath($taskPackage)})
if($taskPackageRows.Count -ne 1 -or $taskPackageRows[0].sha256 -cne $taskHash){throw 'Consumed ordinary package data must match Source1970 pin'}
Copy-Item -LiteralPath $taskPackage -Destination $taskFrozen
$taskData=Get-Content -LiteralPath $taskFrozen -Raw|ConvertFrom-Json
if($taskData.name -cne '@earendil-works/pi-coding-agent' -or $taskData.version -cne '1.3.0'){throw 'Actual Source package role/version changed'}
$taskGuardHash=(Get-FileHash -LiteralPath $PSCommandPath).Hash
@{role='actual original 4954 Source coding-agent package metadata selected by explicit PI_PACKAGE_DIR';ordinary_data=$true;environment_override='C:/Users/adyba/pi-upstream-source-4954d76-20261015/packages/coding-agent';path=$taskPackage;frozen_path=$taskFrozen;sha256=$taskHash;name=$taskData.name;version=$taskData.version;piConfig=$taskData.piConfig;source_manifest_contains_exact_data=$true;source_manifest_files=$taskSourceRows.Count;guard_sha256=$taskGuardHash;candidate_head='6489aeab46cf17a9e29177c08b3408bc0e43750b';recorded_utc=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $taskMetadata -Encoding utf8NoBOM
$taskMetadataHash=(Get-FileHash -LiteralPath $taskMetadata).Hash
$taskFailure=$null
try{& (Join-Path $taskEvidence 'Run-AuthStorageProductionSource47-20261015.ps1') -Attempt first -CandidateHead '6489aeab46cf17a9e29177c08b3408bc0e43750b'}catch{$taskFailure=$_.Exception.Message}
$taskDrift=@()
foreach($taskPair in @(@{path=$taskPackage;hash=$taskHash},@{path=$taskFrozen;hash=$taskHash},@{path=$taskMetadata;hash=$taskMetadataHash},@{path=$PSCommandPath;hash=$taskGuardHash})){
 if(!(Test-Path -LiteralPath $taskPair.path -PathType Leaf) -or (Get-FileHash -LiteralPath $taskPair.path).Hash -cne $taskPair.hash){$taskDrift+=$taskPair.path}
}
@{package_data_drift=$taskDrift;role='actual original 4954 Source coding-agent package metadata selected by explicit PI_PACKAGE_DIR';version=$taskData.version;sha256=$taskHash;owner_failure=$taskFailure;completed_utc=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $taskEvidence 'auth-storage-production-4954-source47-first-20261015-package-post.json') -Encoding utf8NoBOM
if($taskDrift.Count){throw 'Consumed package ordinary data/control drift'}
if($taskFailure){throw $taskFailure}
