$ErrorActionPreference='Stop'
$taskContainer='C:\Users\adyba\pi-zig'
$taskRoot=Join-Path $taskContainer 'worktrees\typebox'
$taskProof=$PSScriptRoot
$taskNode='C:\Program Files\nodejs\node.exe'
$taskOwner=Join-Path $taskContainer 'main\tools\ci\native_qualification_ci.ps1'
$taskManifest=Join-Path $taskContainer 'evidence\source4954-node-tools-before-20261015.json'
$taskTest=Join-Path $taskRoot 'verification\typebox-operators-production-20261016\outline-call-setup.test.mjs'
$taskPostpass=Join-Path $taskRoot 'verification\typebox-operators-production-20261016\outline-call-setup.mjs'
$taskHead='65acae3ec38d3661c13973fae9f9b023841d41f0'
if(Test-Path -LiteralPath (Join-Path $taskProof 'grant.json')){throw 'Refuse proof overwrite'}
if((Get-FileHash -LiteralPath $taskOwner).Hash -cne '607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285'){throw 'Owner identity differs'}
if((Get-FileHash -LiteralPath $taskTest).Hash -cne '9B7B80E4DACF47D9505D688D1EE5DB09BD93E3C611427128E4EFF1932676CE2C'){throw 'Test identity differs'}
if((Get-FileHash -LiteralPath $taskPostpass).Hash -cne '8F32672D834F4D63740622C0F1E29C3BC13DE893F41D5787F6004DED09FEFA27'){throw 'Postpass identity differs'}
. $taskOwner
function Assert-TaskAdmission {
 $taskOs=Get-CimInstance Win32_OperatingSystem
 $taskRoots=@(Get-CimInstance Win32_Process|Where-Object{$_.Name -in @('zig.exe','build.exe','test.exe') -or ($_.ExecutablePath -and $_.ExecutablePath -match '\\(?:\.zig-cache|zig-out)\\')})
 if($taskRoots.Count -or $taskOs.FreePhysicalMemory -lt 16777216){throw 'Fresh16GiB and native-zero required'}
 return @{free_kib=$taskOs.FreePhysicalMemory;native_roots=0;utc=[DateTimeOffset]::UtcNow.ToString('o')}
}
function Get-TaskSeal([string]$Name){
 $taskCurrentHead=([string](git -C $taskRoot rev-parse HEAD)).Trim()
 if($LASTEXITCODE -ne 0 -or $taskCurrentHead -cne $taskHead){throw 'Exact candidate head required'}
 if(@(git -C $taskRoot status --porcelain).Count -or $LASTEXITCODE -ne 0){throw 'Clean candidate required'}
 $taskOriginal=@(Get-Content -LiteralPath $taskManifest -Raw|ConvertFrom-Json)
 if($taskOriginal.Count -ne 1774 -or (Get-FileHash -LiteralPath $taskManifest).Hash -cne 'F834312AAC6AC8D79EF4B49CCB806096D80E92FCA403CC650A05E901D4C280DD'){throw 'Original Node1774 authority differs'}
 $taskNpm=Get-CiInventory 'C:\Program Files\nodejs\node_modules\npm'
 $taskExpected=@($taskOriginal|ForEach-Object{[IO.Path]::GetRelativePath('C:\Program Files\nodejs',$_.path).Replace('\','/')+' '+$_.sha256})
 $taskActual=@('node.exe '+(Get-FileHash -LiteralPath $taskNode).Hash)+@($taskNpm.rows|ForEach-Object{'node_modules/npm/'+$_.relative.Replace('\','/')+' '+$_.sha256})
 if($taskActual.Count -ne 1774 -or @(Compare-Object $taskExpected $taskActual -CaseSensitive).Count){throw 'Complete Node1774 hash/inventory drift'}
 $taskPaths=@($taskTest,$taskPostpass,$taskOwner,$taskManifest,$PSCommandPath,(Join-Path $taskContainer '.pi-zig-workspace.json'),(Join-Path $taskContainer 'path-relocations.json'),(Join-Path $taskContainer 'main\tools\workspace\Resolve-PiZigWorkspace.ps1'))
 $taskSeal=[ordered]@{head=$taskCurrentHead;scope='Two pure tooling modules; Node executable and npm subtree1774, not all Node install files';files=@($taskPaths|ForEach-Object{[ordered]@{path=$_;sha256=(Get-FileHash -LiteralPath $_).Hash}});node=@($taskActual|Sort-Object -CaseSensitive)}
 $taskSeal|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $taskProof ($Name+'.json')) -Encoding utf8NoBOM
 return $taskSeal
}
$taskBefore=Get-TaskSeal 'before'
$taskAdmission=Assert-TaskAdmission
@{scope='Nine authored static tooling controls only; no TypeBox reference/native parity or runtime recovery';source_head=$taskHead;admission=$taskAdmission;timeout_seconds=60;pipe_settle_seconds=10;expected=9}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $taskProof 'grant.json') -Encoding utf8NoBOM
$taskResult=@{status='running';postseal=$false;owned_absent=$false}
try{
 $null=Invoke-CiOwnedProcess $taskNode @('--max-old-space-size=256',$taskTest,'--tooling-controls','--owned-start') $taskRoot (Join-Path $taskProof 'owner') 60 ([Text.Encoding]::UTF8.GetBytes("TYPEBOX_TOOLING_CONTROLS_OWNED_START`n"))
 $taskOwned=Get-Content -LiteralPath (Join-Path $taskProof 'owner.json') -Raw|ConvertFrom-Json
 if($taskOwned.status -cne 'passed' -or $taskOwned.exit_code -ne 0){throw 'Owner did not pass'}
 $taskExpectedLines=@('TAP version 13','ok 1 - nested callee descriptors preserve original call boundaries and flags','ok 2 - free enclosing optional local rejects','ok 3 - numeric-start slice free endpoint rejects','ok 4 - marker-start slice foreign owner endpoint rejects','ok 5 - allocator free ownership rejects','ok 6 - JS_FreeValueRT ownership rejects','ok 7 - defer ownership rejects','ok 8 - errdefer ownership rejects','ok 9 - region-owned local and quoted cleanup text remain admissible','1..9')
 $taskText=[Text.Encoding]::UTF8.GetString([IO.File]::ReadAllBytes((Join-Path $taskProof 'owner.stdout.bin'))).Replace("`r`n","`n")
 if($taskText.EndsWith("`n",[StringComparison]::Ordinal)){$taskText=$taskText.Substring(0,$taskText.Length-1)}
 if($taskText -cne ($taskExpectedLines -join "`n") -or (Get-Item -LiteralPath (Join-Path $taskProof 'owner.stderr.log')).Length){throw 'Exact nine-case TAP/empty stderr required'}
 $taskResult.status='passed';$taskResult.cases=9
}catch{$taskResult.status='failed';$taskResult.error=$_.Exception.Message}
finally{
 try{
  $taskAfter=Get-TaskSeal 'final'
  $taskBeforeJson=$taskBefore|ConvertTo-Json -Depth 6 -Compress
  $taskAfterJson=$taskAfter|ConvertTo-Json -Depth 6 -Compress
  if($taskBeforeJson -cne $taskAfterJson){throw 'Input seal differs'}
  $taskResult.postseal=$true
 }catch{$taskResult.status='failed_postseal';$taskResult.postseal_error=$_.Exception.Message}
 if(Test-Path -LiteralPath (Join-Path $taskProof 'owner.json')){
  $taskOwned=Get-Content -LiteralPath (Join-Path $taskProof 'owner.json') -Raw|ConvertFrom-Json
  $taskLive=@(Get-CimInstance Win32_Process -Filter "ProcessId=$($taskOwned.pid)")
  $taskResult.owned_absent=($taskLive.Count -eq 0)
 }
 $taskResult.native_roots_after=@(Get-CimInstance Win32_Process|Where-Object{$_.Name -in @('zig.exe','build.exe','test.exe') -or ($_.ExecutablePath -and $_.ExecutablePath -match '\\(?:\.zig-cache|zig-out)\\')}).Count
 if(!$taskResult.owned_absent -or $taskResult.native_roots_after){$taskResult.status='failed_absence'}
 $taskResult.completed_utc=[DateTimeOffset]::UtcNow.ToString('o')
 $taskResult|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $taskProof 'result.json') -Encoding utf8NoBOM
}
$taskResult|ConvertTo-Json -Depth 5
if($taskResult.status -cne 'passed'){throw 'Pure tooling gate failed'}
