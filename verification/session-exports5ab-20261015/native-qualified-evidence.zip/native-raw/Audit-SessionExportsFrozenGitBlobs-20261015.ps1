$ErrorActionPreference='Stop'
$root='C:\Users\adyba\pi-zig-session-exports-20261015'
$evidence=$PSScriptRoot
$head='671e2285ee8cd2a5c7dc9c657249b2e01313018e'
$rows=@(Get-Content -LiteralPath (Join-Path $evidence 'ordinary-session-exports5ab-native-compile-third-20261015-native-before.json') -Raw|ConvertFrom-Json)
$git=(Get-Command git.exe -CommandType Application|Select-Object -First 1).Source
$start=[Diagnostics.ProcessStartInfo]::new();$start.FileName=$git;$start.WorkingDirectory=$root;$start.UseShellExecute=$false;$start.CreateNoWindow=$true;$start.RedirectStandardInput=$true;$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true;$start.ArgumentList.Add('cat-file');$start.ArgumentList.Add('--batch')
$process=[Diagnostics.Process]::new();$process.StartInfo=$start
if(!$process.Start()){throw 'Git blob reader did not start'}
$pidOwned=$process.Id;$created=$process.StartTime.ToUniversalTime().ToString('o')
$errors=$process.StandardError.ReadToEndAsync()
$requests=($rows|ForEach-Object{"${head}:$($_.relative)"}) -join "`n"
$writing=$process.StandardInput.WriteAsync($requests+"`n")
$stream=$process.StandardOutput.BaseStream
$buffer=[byte[]]::new(65536);$matched=0;$bytesTotal=[long]0;$details=[Collections.Generic.List[object]]::new()
foreach($row in $rows){
 $line=[Collections.Generic.List[byte]]::new()
 while(($byte=$stream.ReadByte()) -ne 10){if($byte -lt 0){throw 'Unexpected Git header EOF'};$line.Add([byte]$byte)}
 $header=[Text.Encoding]::ASCII.GetString($line.ToArray())
 if($header -notmatch '^([0-9a-f]{40}) blob ([0-9]+)$'){throw "Invalid Git blob header for $($row.relative): $header"}
 $oid=$Matches[1];$size=[long]$Matches[2];$remaining=$size
 $hash=[Security.Cryptography.IncrementalHash]::CreateHash([Security.Cryptography.HashAlgorithmName]::SHA256)
 try{while($remaining -gt 0){$read=$stream.Read($buffer,0,[int][math]::Min($buffer.Length,$remaining));if($read -le 0){throw 'Unexpected Git blob EOF'};$hash.AppendData($buffer,0,$read);$remaining-=$read};$digest=[Convert]::ToHexString($hash.GetHashAndReset())}finally{$hash.Dispose()}
 if($stream.ReadByte() -ne 10){throw 'Missing Git blob separator'}
 if($digest -cne $row.sha256){throw "Frozen compiled input differs from exact Git blob: $($row.relative)"}
 $matched++;$bytesTotal+=$size;$details.Add([ordered]@{relative=$row.relative;git_blob=$oid;sha256=$digest;bytes=$size})
}
$writing.GetAwaiter().GetResult();$process.StandardInput.Close()
if(!$process.WaitForExit(30000)){throw 'Git blob reader did not terminate within final30s'}
$stderr=$errors.GetAwaiter().GetResult();if($process.ExitCode -ne 0 -or $stderr){throw "Git blob reader failure: $stderr"}
if(Get-CimInstance Win32_Process -Filter "ProcessId=$pidOwned"){throw 'Owned Git reader remains'}
$details|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $evidence 'ordinary-session-exports5ab-native-git-blob-audit-files-20261015.json') -Encoding utf8NoBOM
[ordered]@{status='all_frozen_inputs_match_exact_git_blobs';candidate=$head;files=$matched;bytes=$bytesTotal;owned_pid=$pidOwned;created_utc=$created;owned_pid_absent=$true;git_executable=$git;git_sha256=(Get-FileHash -LiteralPath $git).Hash;completed_utc=[datetime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $evidence 'ordinary-session-exports5ab-native-git-blob-audit-20261015.json') -Encoding utf8NoBOM
Get-Content -LiteralPath (Join-Path $evidence 'ordinary-session-exports5ab-native-git-blob-audit-20261015.json')