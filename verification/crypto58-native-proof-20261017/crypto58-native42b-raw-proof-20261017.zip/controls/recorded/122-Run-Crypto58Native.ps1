param([Parameter(Mandatory)][string]$RootGrantPath,[Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9][A-Za-z0-9._-]{0,100}$')][string]$RunId)
$ErrorActionPreference='Stop'
$taskRoot='C:\Users\adyba\pi-zig\worktrees\root-crypto58-qualification'
$taskExpectedHead='42b8ea7007b1307276067339144b334590cb4046'
$taskProof=Join-Path $PSScriptRoot $RunId
$taskCompiler='C:\Users\adyba\pi-zig\toolchain\zig-x86_64-windows-0.16.0'
$taskZig=Join-Path $taskCompiler 'zig.exe'
$taskGit='C:\Program Files\Git\cmd\git.exe'
$taskCi=Join-Path $taskRoot 'tools\ci\native_qualification_ci.ps1'
$taskProtocol=Join-Path $taskRoot 'tools\ci\Invoke-NativeTestProtocol.ps1'
$taskContainer='C:\Users\adyba\pi-zig'
$taskClassifier=Join-Path $PSScriptRoot 'Get-ModelsNativeCandidates.ps1'
$taskMetadataAuthority=Join-Path $PSScriptRoot 'crypto-selected-tests.authority.json'
$taskCompilerAuthority=Join-Path $taskContainer 'evidence/durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
$taskDriverHash=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash
$taskGrant=Get-Content -Raw -LiteralPath $RootGrantPath | ConvertFrom-Json
$taskNow=[DateTimeOffset]::UtcNow
if($taskGrant.scope -cne 'ROOT-CRYPTO58-NATIVE6-SERIAL' -or $taskGrant.run_id -cne $RunId -or $taskGrant.candidate_head -cne $taskExpectedHead -or $taskGrant.driver_sha256 -cne $taskDriverHash -or $taskGrant.authorized -ne $true){throw 'Exact reviewed Root grant required'}
$taskIssued=[DateTimeOffset]$taskGrant.issued_utc;$taskExpires=[DateTimeOffset]$taskGrant.expires_utc
if($taskIssued -gt $taskNow -or $taskNow -gt $taskExpires -or $taskExpires -le $taskIssued -or ($taskExpires-$taskIssued).TotalSeconds -gt 300){throw 'Fresh bounded Root grant required'}
if((Get-FileHash -LiteralPath $taskCi).Hash -cne '607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285' -or (Get-FileHash -LiteralPath $taskProtocol).Hash -cne '39F273D35A5B28E9D60FBE93355828314458A67FB472D60E0A8A6D4DD1FB704D'){throw 'Canonical CI607/Protocol39F identity differs'}
. $taskCi
. $taskProtocol
if((Get-FileHash -LiteralPath $taskClassifier).Hash -cne '3413A2A50B4D4C3BFF8709E4EE08C76BE449AAB1EDCB1E0C5C167DC7A804E301' -or (Get-FileHash -LiteralPath $taskMetadataAuthority).Hash -cne 'E81E7222D1C071EF389FC375BE576D3F620B32DFA7580C456CA05C225FB47DCF'){throw 'Reviewed classifier or exact six-name metadata authority differs'}
. $taskClassifier
New-Item -ItemType Directory -Path $taskProof -ErrorAction Stop | Out-Null
Copy-Item -LiteralPath $RootGrantPath -Destination (Join-Path $taskProof 'root-grant.json') -ErrorAction Stop
$taskAdmissionHistory=[Collections.Generic.List[object]]::new()
$taskExpectedTests=@((Get-Content -LiteralPath $taskMetadataAuthority -Raw|ConvertFrom-Json).tests)
if($taskExpectedTests.Count -ne 6 -or @($taskExpectedTests|Sort-Object -Unique).Count -ne 6){throw 'Six distinct exact metadata names required'}
function Write-TaskJson {param($Value,[string]$Name) ConvertTo-Json -InputObject $Value -Depth 14|Set-Content -LiteralPath (Join-Path $taskProof $Name) -Encoding utf8NoBOM}
function Get-TaskNativeRoots {
 $taskRows=@(Get-CimInstance Win32_Process -OperationTimeoutSec 3 -ErrorAction Stop)
 if(!$taskRows.Count){throw 'Nonempty successful native process census required'}
 @(Get-ModelsNativeCandidates -Rows $taskRows -Container $taskContainer)
}
function Assert-TaskAdmission {
 $taskWait=[Diagnostics.Stopwatch]::StartNew();$taskProbes=[Collections.Generic.List[object]]::new()
 do {
  $taskOs=Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 3 -ErrorAction Stop;$taskRoots=@(Get-TaskNativeRoots)
  $taskProbe=[ordered]@{free_kib=[long]$taskOs.FreePhysicalMemory;minimum_kib=16777216;native_roots=$taskRoots.Count;native_candidates=$taskRoots;utc=[DateTimeOffset]::UtcNow.ToString('o')}
  $taskProbes.Add($taskProbe);$taskAdmissionHistory.Add($taskProbe)
  if($taskRoots.Count){throw 'Another native root prevents serial admission'}
  if($taskWait.Elapsed.TotalSeconds -ge 54){throw 'Fresh16GiB admission expired after bounded54s'}
  if($taskOs.FreePhysicalMemory -ge 16777216){return @{probe=$taskProbe;wait_seconds=$taskWait.Elapsed.TotalSeconds;probes=$taskProbes.ToArray()}}
  $taskRemainingMs=54000-$taskWait.ElapsedMilliseconds;if($taskRemainingMs -gt 0){Start-Sleep -Milliseconds ([int][Math]::Min(1000,$taskRemainingMs))}
 }while($true)
}
function Get-TaskSeal {
 param([string]$Name)
 $taskPaths=@(& $taskGit -c core.fsmonitor=false -c core.hooksPath=NUL -C $taskRoot ls-files);if($LASTEXITCODE -ne 0 -or $taskPaths.Count -ne 10818){throw 'Exact full10818 tracked candidate inventory required'}
 $taskHead=([string](& $taskGit -c core.fsmonitor=false -c core.hooksPath=NUL -C $taskRoot rev-parse HEAD)).Trim();if($LASTEXITCODE -ne 0 -or $taskHead -cne $taskExpectedHead){throw 'Exact Root source head differs'}
 $taskStatus=@(& $taskGit -c core.fsmonitor=false -c core.hooksPath=NUL -C $taskRoot status --porcelain);if($LASTEXITCODE -ne 0 -or $taskStatus.Count){throw 'Clean Root qualification composition required'}
 $taskCompilerInventory=Get-CiInventory $taskCompiler;if($taskCompilerInventory.rows.Count -ne 19546){throw 'Complete compiler19546 required'}
 if((Get-FileHash -LiteralPath $taskCompilerAuthority).Hash -cne 'DEE259F171F720AB2C08E8DD473975E22C876417CD62E4F016C71A7C662794EB'){throw 'Immutable original compiler authority differs'}
 $taskOriginalCompiler=Get-Content -LiteralPath $taskCompilerAuthority -Raw|ConvertFrom-Json
 $taskAuthorityRows=@($taskOriginalCompiler.inputs|ForEach-Object {if(!$_.path.StartsWith($taskOriginalCompiler.root+[IO.Path]::DirectorySeparatorChar,[StringComparison]::Ordinal)){throw 'Compiler authority path outside original root'};$_.path.Substring($taskOriginalCompiler.root.Length+1).Replace([char]92,[char]47)+' '+$_.sha256})
 $taskCompilerRows=@($taskCompilerInventory.rows|ForEach-Object {$_.relative.Replace([char]92,[char]47)+' '+$_.sha256})
 if($taskAuthorityRows.Count -ne 19546 -or @($taskAuthorityRows|Sort-Object -Unique).Count -ne 19546 -or @($taskCompilerRows|Sort-Object -Unique).Count -ne 19546 -or @(Compare-Object $taskAuthorityRows $taskCompilerRows -CaseSensitive).Count){throw 'Full compiler19546 differs from immutable original authority'}
 $taskControlPaths=@($PSCommandPath,$taskCi,$taskProtocol,$taskClassifier,$taskMetadataAuthority,$taskCompilerAuthority,(Join-Path $PSScriptRoot 'README.md'),(Join-Path $PSScriptRoot 'root-grant.template.json'),(Join-Path $PSScriptRoot 'prepared-manifest.json'),(Join-Path $taskProof 'root-grant.json'),(Join-Path $taskContainer '.pi-zig-workspace.json'),(Join-Path $taskContainer 'path-relocations.json'),$taskGit,'C:\Program Files\PowerShell\7\pwsh.exe')
 $taskControls=@($taskControlPaths|ForEach-Object {[ordered]@{path=$_;sha256=(Get-FileHash -LiteralPath $_).Hash}})
 $taskSeal=[ordered]@{candidate_head=$taskHead;source=@(Get-CiRows $taskRoot $taskPaths);fixture_count=@($taskPaths|Where-Object {$_.StartsWith('src/extensions/fixtures/',[StringComparison]::Ordinal)}).Count;controls=$taskControls;compiler=@($taskCompilerInventory.rows);driver_sha256=(Get-FileHash -LiteralPath $PSCommandPath).Hash;ci_owner_sha256=(Get-FileHash -LiteralPath $taskCi).Hash;protocol_sha256=(Get-FileHash -LiteralPath $taskProtocol).Hash;root_grant_sha256=(Get-FileHash -LiteralPath (Join-Path $taskProof 'root-grant.json')).Hash;utc=[DateTimeOffset]::UtcNow.ToString('o')}
 Write-TaskJson $taskSeal "$Name.json";return $taskSeal
}
function Assert-TaskSeal {
 param($Actual,$Expected)
 foreach($taskKey in @('candidate_head','driver_sha256','ci_owner_sha256','protocol_sha256','root_grant_sha256')){if($Actual[$taskKey] -cne $Expected[$taskKey]){throw "$taskKey drift"}}
 foreach($taskGroup in @('source','compiler','controls')){if(@(Compare-Object @($Expected[$taskGroup]|ForEach-Object{$(if($taskGroup -ceq 'controls'){$_.path}else{$_.relative})+' '+$_.sha256}) @($Actual[$taskGroup]|ForEach-Object{$(if($taskGroup -ceq 'controls'){$_.path}else{$_.relative})+' '+$_.sha256}) -CaseSensitive).Count){throw "$taskGroup inventory/hash drift"}}
}
function Read-TaskActualMetadata {
 param([string]$Binary)
 $taskReceipt=Join-Path $taskProof 'metadata'
 # Same query/exit bytes and canonical CI607 owner as Read-CiTestMetadata.
 # Require the actual query to report all six exact ordered authority names.
 $taskOwned=Invoke-CiOwnedProcess $Binary @('--listen=-') $taskRoot $taskReceipt 30 ([byte[]](4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0))
 $taskBytes=[IO.File]::ReadAllBytes("$taskReceipt.stdout.bin");$taskOffset=0;$taskVersion=$null;$taskNames=$null
 while($taskOffset -lt $taskBytes.Length){
  if($taskBytes.Length-$taskOffset -lt 8){throw 'Truncated metadata header'}
  $taskTag=[BitConverter]::ToUInt32($taskBytes,$taskOffset);$taskLength=[BitConverter]::ToUInt32($taskBytes,$taskOffset+4);$taskOffset+=8
  if($taskLength -gt 1MB -or $taskLength -gt $taskBytes.Length-$taskOffset){throw 'Invalid metadata body length'}
  if($taskTag -eq 0){if($null -ne $taskVersion -or $null -ne $taskNames){throw 'Duplicate or late metadata version'};$taskVersion=[Text.Encoding]::UTF8.GetString($taskBytes,$taskOffset,$taskLength)}
  elseif($taskTag -eq 3){
   if($taskVersion -cne '0.16.0' -or $null -ne $taskNames -or $taskLength -lt 8){throw 'Unexpected metadata array'}
   $taskStrings=[BitConverter]::ToUInt32($taskBytes,$taskOffset);$taskCount=[BitConverter]::ToUInt32($taskBytes,$taskOffset+4)
   if($taskCount -ne 6 -or $taskLength -ne 8+8*$taskCount+$taskStrings){throw 'Exactly six required crypto/storage metadata names allowed'}
   $taskStringStart=$taskOffset+8+8*$taskCount;$taskNames=@()
   for($taskIndex=0;$taskIndex -lt $taskCount;$taskIndex++){
    $taskNameOffset=[BitConverter]::ToUInt32($taskBytes,$taskOffset+8+4*$taskIndex);$taskPanic=[BitConverter]::ToUInt32($taskBytes,$taskOffset+8+4*$taskCount+4*$taskIndex)
    if($taskPanic -ne 0 -or $taskNameOffset -ge $taskStrings){throw 'Invalid panic/name metadata'}
    $taskEnd=$taskNameOffset;while($taskEnd -lt $taskStrings -and $taskBytes[$taskStringStart+$taskEnd] -ne 0){$taskEnd++};if($taskEnd -eq $taskStrings){throw 'Unterminated metadata name'}
    $taskNames+=[Text.Encoding]::UTF8.GetString($taskBytes,$taskStringStart+$taskNameOffset,$taskEnd-$taskNameOffset)
   }
  }else{throw "Unexpected metadata tag $taskTag"};$taskOffset+=$taskLength
 }
 if($taskVersion -cne '0.16.0' -or $null -eq $taskNames){throw 'Missing metadata/version'}
 if(([string]::Join([char]0,[string[]]$taskNames)) -cne ([string]::Join([char]0,[string[]]$taskExpectedTests))){throw 'Actual metadata must match every exact six-name authority entry in order'}
 if((Get-Item -LiteralPath "$taskReceipt.stderr.log").Length -ne 0){throw 'Empty metadata stderr required'}
 $taskMetadata=[ordered]@{binary=$Binary;binary_sha256=$taskOwned.executable_sha256;version=$taskVersion;actual_count=$taskNames.Count;tests=$taskNames;required_tests=$taskExpectedTests;expected_count_known_before_metadata=6;method='Actual query4/exit0 only; no run_test; exact six ordered names; canonical CI607 owner30s'}
 Write-TaskJson $taskMetadata 'selected-tests.json';return $taskMetadata
}
$taskResult=[ordered]@{status='running';source_head=$taskExpectedHead;planned_tests=6;actual_metadata_count=$null;compile=$null;metadata=$null;runtime=$null;between_seal=$false;postseal=$false;native_roots_after=$null}
$taskBefore=$null;$taskArtifacts=$null
try {
 if((Get-FileHash -LiteralPath $taskZig).Hash -cne '086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864'){throw 'Pinned Zig0.16 differs'}
 if((Get-FileHash -LiteralPath (Join-Path $taskRoot 'vendor/quickjs/quickjs.c')).Hash -cne '2FA2E26E35B7D5C45D1FFD3F6F10EE3A5DE9A984738486128399A20BD8E4D88D' -or (Get-FileHash -LiteralPath (Join-Path $taskRoot 'vendor/quickjs/quickjs.h')).Hash -cne '341CF06F8041B8311D49767026C85C7B859BCFEE3088380F3FFE6D77527052AB'){throw 'Reviewed C/H identity differs'}
 $taskPins=@{'src/extensions/native_node_crypto_hash.zig'='91FBAD6661EE2345F64E5F3166A27C6C0870278DEA5072E2DA79CF70F34C7487';'src/extensions/fixtures/node-crypto-sha256-package.input.txt'='A9722654D1FCF6B3F00638B59F9D4EAA829549CC996EE7BE36808E24D7E2DA26';'src/extensions/fixtures/node-crypto-sha256-package.json'='5062712D48821C749D5D9E416A9DC1CB6A7F15748AB5F64F9D2DC17AB3481074'}
 foreach($taskPin in $taskPins.GetEnumerator()){if((Get-FileHash -LiteralPath (Join-Path $taskRoot $taskPin.Key)).Hash -cne $taskPin.Value){throw "Accepted crypto source/input/fixture pin differs: $($taskPin.Key)"}}
 Write-TaskJson (Assert-TaskAdmission) 'initial-admission.json'
 $taskBefore=Get-TaskSeal 'before'
 Write-TaskJson (Assert-TaskAdmission) 'compile-admission.json'
 $taskPrefix=Join-Path $taskProof 'out'
 $taskArgs=@('build','build-native-node-crypto-sha256-artifact','-Doptimize=Debug','-Duse-llvm=true','-Ddiagnostic-tests=false','-j1','--prefix',$taskPrefix,'--cache-dir','C:\Users\adyba\pi-zig\evidence\root-crypto58-native-prepared-20261017\root-crypto58-native6-20261017-113959\cache','--global-cache-dir','C:\Users\adyba\pi-zig\evidence\root-crypto58-native-prepared-20261017\root-crypto58-native6-20261017-113959\global-cache','--summary','all')
 $taskResult.compile=Invoke-CiOwnedProcess $taskZig $taskArgs $taskRoot (Join-Path $taskProof 'compile') 1320
 if(@(Get-TaskNativeRoots).Count){throw 'Native root remains after compile'}
 $taskBinary=Join-Path $taskPrefix 'bin/test.exe';$taskPdb=Join-Path $taskPrefix 'bin/test.pdb'
 if(!(Test-Path -LiteralPath $taskBinary -PathType Leaf) -or !(Test-Path -LiteralPath $taskPdb -PathType Leaf)){throw 'Installed exact test.exe and Debug PDB required'}
 $taskArtifacts=Get-CiInventory $taskPrefix;Write-TaskJson $taskArtifacts 'artifacts-before.json';if($taskArtifacts.rows.Count -ne 2){throw 'Exactly new test.exe and Debug PDB output required'}
 Write-TaskJson (Assert-TaskAdmission) 'metadata-admission.json'
 $taskResult.metadata=Read-TaskActualMetadata $taskBinary;$taskResult.actual_metadata_count=$taskResult.metadata.actual_count
 if(@(Get-TaskNativeRoots).Count){throw 'Native root remains after metadata'}
 Assert-TaskSeal (Get-TaskSeal 'between') $taskBefore;$taskResult.between_seal=$true
 Assert-CiInventory $taskArtifacts (Join-Path $taskProof 'artifacts-between.json')
 Write-TaskJson (Assert-TaskAdmission) 'runtime-admission.json'
 # Canonical Protocol39F runtime is120s. Run every exact validated index0..5.

 $taskResult.runtime=Invoke-NativeTestProtocol $taskBinary $taskRoot (Join-Path $taskProof 'runtime') $taskResult.actual_metadata_count
 if((Get-Item -LiteralPath (Join-Path $taskProof 'runtime.stderr.log')).Length -ne 0){throw 'Empty runtime stderr required'}
 $taskResult.status='passed'
}catch{$taskResult.status='failed';$taskResult.error=$_.Exception.Message}
finally {
 try{$taskFinal=Get-TaskSeal 'final';if($null -eq $taskBefore){throw 'Before baseline unavailable; final retained only'};Assert-TaskSeal $taskFinal $taskBefore;$taskResult.postseal=$true}catch{$taskResult.status='failed_postseal';$taskResult.postseal_error=$_.Exception.Message}
 try{if($null -ne $taskArtifacts){Assert-CiInventory $taskArtifacts (Join-Path $taskProof 'artifacts-final.json')}elseif(Test-Path -LiteralPath (Join-Path $taskProof 'out')){Write-TaskJson (Get-CiInventory (Join-Path $taskProof 'out')) 'artifacts-negative.json'}}catch{$taskResult.status='failed_artifacts';$taskResult.artifact_error=$_.Exception.Message}
 try{$taskRoots=@(Get-TaskNativeRoots);Write-TaskJson $taskRoots 'native-roots-final.json';$taskResult.native_roots_after=$taskRoots.Count;if($taskRoots.Count){throw 'Native roots remain'}}catch{$taskResult.status='failed_native_roots';$taskResult.native_roots_error=$_.Exception.Message}
 try{$taskAbsences=@(foreach($taskPhase in @('compile','metadata','runtime')){$taskReceipt=Join-Path $taskProof "$taskPhase.json";if(Test-Path -LiteralPath $taskReceipt){$taskRecord=Get-Content -Raw -LiteralPath $taskReceipt|ConvertFrom-Json;$taskLive=@(Get-CimInstance Win32_Process -Filter "ProcessId = $($taskRecord.pid)" -OperationTimeoutSec 3 -ErrorAction Stop);[ordered]@{phase=$taskPhase;owner_receipt=$taskReceipt;pid=$taskRecord.pid;recorded_created_utc=$taskRecord.created_utc;current=$taskLive;absent=($taskLive.Count -eq 0)}}});Write-TaskJson $taskAbsences 'owner-absence.json';if(@($taskAbsences|Where-Object{!$_.absent}).Count){throw 'Owner PID still present or reused; Root independent reconciliation required'}
 }catch{$taskResult.status='failed_absence';$taskResult.absence_error=$_.Exception.Message}
 $taskResult.admission_probes=$taskAdmissionHistory.ToArray();$taskResult.completed_utc=[DateTimeOffset]::UtcNow.ToString('o');Write-TaskJson $taskResult 'result.json'
}
$taskResult|ConvertTo-Json -Depth 14
if($taskResult.status -cne 'passed'){throw 'Crypto58 native six-test gate failed'}