param([string]$Container='C:\Users\adyba\pi-zig')
$ErrorActionPreference='Stop'
$v1=Join-Path $Container 'evidence/root-crypto58-native-prepared-20261017'
$v2=Join-Path $Container 'evidence/root-crypto58-native-v2-prepared-20261017'
$id1='root-crypto58-native6-20261017-113959'
$id2='root-crypto58-native6-v2-20261017-114903'
$r1=Join-Path $v1 $id1;$r2=Join-Path $v2 $id2
$outer=Join-Path $Container 'evidence/root-crypto58-native-outer-prepared-20261017'
$qual=Join-Path $Container 'worktrees/root-crypto58-qualification'
function Read-Json([string]$Path){Get-Content -LiteralPath $Path -Raw|ConvertFrom-Json}
function Require([bool]$Condition,[string]$Message){if(!$Condition){throw $Message}}
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash}
function Frames([string]$Path){
 $bytes=[IO.File]::ReadAllBytes($Path);$at=0;$rows=@()
 while($at-lt$bytes.Length){
  Require ($bytes.Length-$at-ge8) 'Truncated frame header'
  $tag=[BitConverter]::ToUInt32($bytes,$at);$length=[BitConverter]::ToUInt32($bytes,$at+4);$at+=8
  Require ($length-le1MB-and$length-le$bytes.Length-$at) 'Truncated or oversized frame'
  $body=[byte[]]::new($length);[Array]::Copy($bytes,$at,$body,0,$length)
  $rows+=@{tag=$tag;body=$body};$at+=$length
 }
 return ,$rows
}
function Row-Map($Rows,[string]$Key){
 $map=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::Ordinal)
 foreach($row in $Rows){Require (![string]::IsNullOrEmpty($row.$Key)) 'Empty inventory key';$map.Add($row.$Key,$row.sha256)}
 return ,$map
}
function Compare-Rows($Expected,$Actual,[string]$Key){
 $a=Row-Map $Expected $Key;$b=Row-Map $Actual $Key;Require ($a.Count-eq$b.Count) 'Inventory count drift'
 foreach($name in $a.Keys){Require ($b.ContainsKey($name)-and$b[$name]-ceq$a[$name]) ('Inventory/hash drift: '+$name)}
 return $a.Count
}
$manifest=Read-Json (Join-Path $v2 'prepared-manifest.json')
Require ((Hash (Join-Path $v2 'prepared-manifest.json'))-ceq'EC8971E54AA4BD23802B6DDBBCC3BB0F0C9D8658701E5D97D6C99F462A2B46C2') 'Unreviewed v2 manifest'
foreach($row in $manifest.controls){Require ((Hash (Join-Path $v2 $row.relative))-ceq$row.sha256) 'Control drift'}
foreach($row in $manifest.original_negative){Require ((Hash $row.path)-ceq$row.sha256) 'Original negative mutated'}
$authority=Read-Json (Join-Path $v2 'crypto-selected-tests.authority.json')
$utf8=[Text.UTF8Encoding]::new($false,$true)
$meta=Frames (Join-Path $r2 'metadata.stdout.bin')
Require ($meta.Count-eq2-and$meta[0].tag-eq0-and$utf8.GetString($meta[0].body)-ceq'0.16.0'-and$meta[1].tag-eq3) 'Metadata frame shape'
$body=$meta[1].body;$strings=[BitConverter]::ToUInt32($body,0);$count=[BitConverter]::ToUInt32($body,4)
Require ($count-eq6-and$body.Length-eq8+8*$count+$strings) 'Metadata dimensions'
$names=@()
for($i=0;$i-lt$count;$i++){
 $off=[BitConverter]::ToUInt32($body,8+4*$i);$panic=[BitConverter]::ToUInt32($body,8+4*$count+4*$i)
 Require ($panic-eq0-and$off-lt$strings) 'Metadata offset/panic'
 $end=$off;while($end-lt$strings-and$body[8+8*$count+$end]-ne0){$end++}
 Require ($end-lt$strings) 'Unterminated metadata name'
 $names+=$utf8.GetString($body,8+8*$count+$off,$end-$off)
}
Require ([string]::Join([char]0,$names)-ceq[string]::Join([char]0,[string[]]$authority.tests)) 'Exact metadata names/order'
$frames=Frames (Join-Path $r2 'runtime.stdout.bin')
Require ($frames.Count-eq13-and$frames[0].tag-eq0-and$utf8.GetString($frames[0].body)-ceq'0.16.0') 'Runtime frame shape'
$results=@()
for($i=0;$i-lt6;$i++){
 $start=$frames[1+2*$i];$result=$frames[2+2*$i]
 Require ($start.tag-eq5-and$start.body.Length-eq0-and$result.tag-eq4-and$result.body.Length-eq12) 'Zig0.16 start/result ABI'
 $index=[BitConverter]::ToUInt32($result.body,0);$flags=[BitConverter]::ToUInt64($result.body,4)
 Require ($index-eq$i-and$flags-eq0) 'Runtime index or full64-bit flags'
 $results+=@{index=$index;flags=$flags}
}
$before=Read-Json (Join-Path $r2 'before.json');$between=Read-Json (Join-Path $r2 'between.json');$final=Read-Json (Join-Path $r2 'final.json')
$comparisons=@()
foreach($group in @('source','compiler','controls')){
 $key=if($group-eq'controls'){'path'}else{'relative'}
 $n=Compare-Rows $before.$group $between.$group $key
 [void](Compare-Rows $before.$group $final.$group $key)
 $comparisons+=@{group=$group;count=$n;before_between_drift=0;before_final_drift=0}
}
Require ($before.source.Count-eq10818-and$before.compiler.Count-eq19546-and$before.fixture_count-eq1004) 'Full source/compiler/fixture count'
foreach($seal in @($before,$between,$final)){Require ($seal.candidate_head-ceq'42b8ea7007b1307276067339144b334590cb4046') 'Exact source head';foreach($row in $seal.controls){Require ((Hash $row.path)-ceq$row.sha256) 'Retained control no longer exact'}}
$compilerAuthorityPath=Join-Path $Container 'evidence/durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
Require ((Hash $compilerAuthorityPath)-ceq'DEE259F171F720AB2C08E8DD473975E22C876417CD62E4F016C71A7C662794EB') 'Compiler original authority pin'
$compilerAuthority=Read-Json $compilerAuthorityPath
$expectedCompiler=@($compilerAuthority.inputs|ForEach-Object{
 Require ($_.path.StartsWith($compilerAuthority.root+[IO.Path]::DirectorySeparatorChar,[StringComparison]::Ordinal)) 'Original compiler path escape'
 [pscustomobject]@{relative=$_.path.Substring($compilerAuthority.root.Length+1).Replace([char]92,[char]47);sha256=$_.sha256}
})
$actualCompiler=@($before.compiler|ForEach-Object{[pscustomobject]@{relative=$_.relative.Replace([char]92,[char]47);sha256=$_.sha256}})
Require ((Compare-Rows $expectedCompiler $actualCompiler 'relative')-eq19546) 'Compiler original complete inventory'
$artifacts=Read-Json (Join-Path $r2 'artifacts-before.json')
[void](Compare-Rows $artifacts.rows (Read-Json (Join-Path $r2 'artifacts-between.json')).rows 'relative')
[void](Compare-Rows $artifacts.rows (Read-Json (Join-Path $r2 'artifacts-final.json')).rows 'relative')
Require ($artifacts.rows.Count-eq2) 'Exact EXE/PDB artifact count'
foreach($row in $artifacts.rows){Require ((Hash $row.path)-ceq$row.sha256) 'Local excluded artifact drift'}
$exe=($artifacts.rows|Where-Object relative -ceq 'bin/test.exe').sha256
Require ($exe-ceq'7E85B8B8954CC01C397B830E2FECB56B87B3A412379FC0D4EC54134196FA7538') 'Exact executable pin'
$owners=@()
foreach($phase in @('compile','metadata','runtime')){
 $o=Read-Json (Join-Path $r2 ($phase+'.json'))
 Require ($o.status-ceq'passed'-and$o.exit_code-eq0-and$o.pid-eq$o.live_identity.pid-and$o.created_utc-ceq$o.live_identity.created_utc-and$o.retained_handle-gt0) 'Owned phase identity/terminal'
 if($phase-ne'compile'){Require ($o.executable_sha256-ceq$exe) 'Metadata/runtime executable identity';Require ((Get-Item -LiteralPath (Join-Path $r2 ($phase+'.stderr.log'))).Length-eq0) 'Empty unit stderr'}
 $owners+=@{phase=$phase;pid=$o.pid;created_utc=$o.created_utc;exit_code=$o.exit_code;executable_sha256=$o.executable_sha256}
}
$absence=@(Read-Json (Join-Path $r2 'owner-absence.json'))
Require ($absence.Count-eq3-and@($absence|Where-Object{!$_.absent-or@($_.current).Count}).Count-eq0) 'Three recorded owned absences'
foreach($o in $owners){$a=@($absence|Where-Object phase -ceq $o.phase);Require ($a.Count-eq1-and$a[0].pid-eq$o.pid-and$a[0].recorded_created_utc-ceq$o.created_utc) 'Absence owner binding'}
$outerRecord=Read-Json (Join-Path $outer ($id2+'.json'));$outerAbsence=Read-Json (Join-Path $outer ($id2+'-absence.json'))
Require ($outerRecord.status-ceq'passed'-and$outerRecord.exit_code-eq0-and$outerRecord.pid-eq51712-and$outerRecord.live_identity.pid-eq$outerRecord.pid-and$outerRecord.live_identity.created_utc-ceq$outerRecord.created_utc-and$outerRecord.retained_handle-gt0) 'Outer identity/terminal'
Require ($outerAbsence.absent-and@($outerAbsence.current).Count-eq0-and$outerAbsence.recorded_pid-eq$outerRecord.pid-and$outerAbsence.recorded_birth-ceq$outerRecord.created_utc) 'Outer recorded absence'
Require ((Get-Item -LiteralPath (Join-Path $outer ($id2+'.stderr.log'))).Length-eq0) 'Empty outer stderr'
Require ((Hash (Join-Path $outer ($id2+'.stdout.bin')))-ceq(Hash (Join-Path $r2 'result.json'))) 'Outer raw stdout differs from preserved result'
$grant=Read-Json (Join-Path $r2 'root-grant.json')
Require ($grant.authorized-and$grant.scope-ceq'ROOT-CRYPTO58-NATIVE6-SERIAL'-and$grant.run_id-ceq$id2-and$grant.candidate_head-ceq'42b8ea7007b1307276067339144b334590cb4046'-and$grant.driver_sha256-ceq'8349540805BFA1F12E5B8D38800CF080FBF2FC66EF0ECF9D7EF2E652BAC4E668') 'Actual exact grant binding'
Require ((Hash (Join-Path $r2 'root-grant.json'))-ceq(Hash (Join-Path $outer ($id2+'-grant.json')))) 'Outer/native grant bytes differ'
$issued=[DateTimeOffset]$grant.issued_utc;$expires=[DateTimeOffset]$grant.expires_utc;$birth=[DateTimeOffset]$outerRecord.created_utc
Require ($issued-le$birth-and$birth-le$expires-and($expires-$issued).TotalSeconds-le300) 'Actual grant issue/start/expiry'
$outerPrepared=Read-Json (Join-Path $outer 'prepared.json')
$canonical=[IO.File]::ReadAllText((Join-Path $qual 'tools/ci/native_qualification_ci.ps1'))
$derived=[IO.File]::ReadAllText((Join-Path $outer 'outer-owned-process.ps1'))
Require ((Hash (Join-Path $outer 'outer-owned-process.ps1'))-ceq$outerPrepared.derived_owner_sha256) 'Outer helper identity'
Require ($derived.Replace("@('pwsh.exe')","@('zig','zig.exe','node','node.exe','test','test.exe')")-ceq$canonical) 'Outer helper has unexpected non-allowlist delta'
$summary=Read-Json (Join-Path $r2 'result.json')
Require ($summary.status-ceq'passed'-and$summary.actual_metadata_count-eq6-and$summary.between_seal-and$summary.postseal-and$summary.native_roots_after-eq0) 'Native terminal summary'
Require ($summary.compile.Count-eq2-and@($summary.compile[0].PSObject.Properties).Count-eq0) 'Preserve original compile-array empty-object quirk'
foreach($probe in $summary.admission_probes){Require ($probe.free_kib-ge16777216-and$probe.native_roots-eq0-and@($probe.native_candidates).Count-eq0) 'Recorded fresh16GiB/nativezero admission'}
Require (@(Read-Json (Join-Path $r2 'native-roots-final.json')).Count-eq0) 'Recorded final native census'
$oldBefore=Read-Json (Join-Path $r1 'before.json');$oldFinal=Read-Json (Join-Path $r1 'final.json');$oldSummary=Read-Json (Join-Path $r1 'result.json')
foreach($group in @('source','compiler','controls')){[void](Compare-Rows $oldBefore.$group $oldFinal.$group $(if($group-eq'controls'){'path'}else{'relative'}))}
Require ($oldSummary.status-ceq'failed'-and$null-eq$oldSummary.actual_metadata_count-and$null-eq$oldSummary.runtime-and$oldSummary.postseal-and$oldSummary.native_roots_after-eq0) 'Original compile negative boundary'
$oldErrors=@(Select-String -LiteralPath (Join-Path $r1 'compile.stderr.log') -Pattern 'error:.*shadow')
Require ($oldErrors.Count-eq3) 'Original three compiler shadow errors'
$oldOuter=Read-Json (Join-Path $outer ($id1+'.json'));$oldOuterAbsent=Read-Json (Join-Path $outer ($id1+'-absence.json'))
Require ($oldOuter.status-ceq'failed'-and$oldOuter.exit_code-eq1-and$oldOuterAbsent.absent-and@($oldOuterAbsent.current).Count-eq0-and$oldOuterAbsent.recorded_pid-eq$oldOuter.pid-and$oldOuterAbsent.recorded_birth-ceq$oldOuter.created_utc) 'First negative outer terminal/absence'
$originalPacket=Join-Path $Container 'evidence/crypto58-independent-public-packet-20261017'
$original=Read-Json (Join-Path $originalPacket 'packet-manifest.json')
foreach($row in $original.files){Require ((Hash (Join-Path $originalPacket $row.relative))-ceq$row.sha256) 'Accepted original58 packet drift'}
$qual=Join-Path $Container 'worktrees/root-crypto58-qualification'
$fixture=Join-Path $qual 'src/extensions/fixtures/node-crypto-sha256-package.json'
Require ((Hash $fixture)-ceq$original.raw_sha256-and$original.raw_sha256-ceq'5062712D48821C749D5D9E416A9DC1CB6A7F15748AB5F64F9D2DC17AB3481074') 'Accepted original58 bytes differ'
[ordered]@{
 status='independent_raw_component_audit_passed';source_head=$summary.source_head;run_id=$id2
 metadata_names=$names;raw_runtime_results=$results;raw_runtime_frame_count=$frames.Count
 full_seal_comparisons=$comparisons;compiler_original_rows=19546;fixture_count=1004
 artifact_rows=2;executable_sha256=$exe;owners=$owners;recorded_inner_absences=3
 recorded_outer_pid=$outerRecord.pid;outer_created_utc=$outerRecord.created_utc;outer_exit_code=$outerRecord.exit_code;recorded_outer_absent=$true
 actual_grant_bound=$true;outer_owner_only_allowlist_diff=$true;first_negative_outer_pid=$oldOuter.pid;first_negative_outer_exit=$oldOuter.exit_code
 original_negative_hashes_verified=$manifest.original_negative.Count;original_compile_shadow_errors=3
 original58_packet_files_verified=$original.files.Count;original58_sha256=$original.raw_sha256
 compile_summary_quirk='Unmodified result.json compile contains [{}, receipt]; compile.json is authoritative'
 audit_script_sha256=Hash $PSCommandPath
 native_jobs_started_by_auditor=$false;fresh_process_census_performed_by_auditor=$false
 qualified_scope='Exact original58 package-used SHA256 adapter plus the six actual selected tests at exact42b'
 limitations=@('No broader Node crypto, package manager, default SDK graph, current full Main/version or release qualification','Recorded absence is audited at the original receipt times; no new runtime/absence claim','Disposable compiler caches are mutable non-authority; local EXE/PDB excluded from public payload')
}
