param([string]$Container='C:\Users\adyba\pi-zig')
$ErrorActionPreference='Stop'
$audit=Join-Path $Container 'evidence/root-crypto58-native-v2-independent-audit-20261017'
$stage=Join-Path $audit 'public-payload'
$zip=Join-Path $audit 'crypto58-native42b-raw-proof-20261017.zip'
if((Test-Path -LiteralPath $stage)-or(Test-Path -LiteralPath $zip)){throw 'Fresh packet destinations required'}
[void][IO.Directory]::CreateDirectory($stage)
$entries=[Collections.Generic.List[object]]::new()
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash}
function Add-File([string]$Source,[string]$Relative,[string]$Kind){
 $relativePath=$Relative.Replace('\','/')
 $target=[IO.Path]::GetFullPath((Join-Path $stage $relativePath))
 if(!$target.StartsWith($stage+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Packet path escape'}
 if([IO.Path]::GetExtension($Source)-in@('.exe','.pdb','.dll','.lib','.obj','.o','.a','.node')){throw 'Local binary cannot enter public packet'}
 [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))
 [IO.File]::Copy($Source,$target,$false)
 $sha=Hash $Source;if((Hash $target)-cne$sha){throw 'Copy drift'}
 $entries.Add([ordered]@{relative=$relativePath;original=$Source;sha256=$sha;bytes=(Get-Item -LiteralPath $target).Length;kind=$Kind})
}
$v1=Join-Path $Container 'evidence/root-crypto58-native-prepared-20261017'
$v2=Join-Path $Container 'evidence/root-crypto58-native-v2-prepared-20261017'
$id1='root-crypto58-native6-20261017-113959';$id2='root-crypto58-native6-v2-20261017-114903'
$r1=Join-Path $v1 $id1;$r2=Join-Path $v2 $id2
$outer=Join-Path $Container 'evidence/root-crypto58-native-outer-prepared-20261017'
$qual=Join-Path $Container 'worktrees/root-crypto58-qualification'
foreach($pair in @(@($v1,'native-v1/controls'),@($v2,'native-v2/controls'),@($r1,'native-v1/run'),@($r2,'native-v2/run'),@($outer,'outer'))){
 foreach($file in Get-ChildItem -LiteralPath $pair[0] -File){Add-File $file.FullName ($pair[1]+'/'+$file.Name) 'raw-owned-evidence'}
}
$originalPacket=Join-Path $Container 'evidence/crypto58-independent-public-packet-20261017'
foreach($file in Get-ChildItem -LiteralPath $originalPacket -File -Recurse){
 Add-File $file.FullName ('original58/'+$file.FullName.Substring($originalPacket.Length+1)) 'accepted-original58-packet'
}
$seal=Get-Content -LiteralPath (Join-Path $r2 'before.json') -Raw|ConvertFrom-Json
$sourceMap=@{};foreach($row in $seal.source){$sourceMap[$row.relative]=$row.sha256}
$sourcePaths=@('LICENSE','build.zig','src/config.zig','src/native_node_crypto_hash_test.zig','src/extensions/native_node_crypto_hash.zig','src/extensions/native_node_function.zig','src/extensions/native_async_body.zig','src/extensions/native_async_function.zig','src/extensions/native_class.zig','src/extensions/native_js_values.zig','src/extensions/engine.zig','src/extensions/native_durable_harness.zig','src/extensions/native_durable_host_inputs.zig','src/extensions/native_durable_storage.zig','src/durable/process_probe.c','src/extensions/fixtures/node-crypto-sha256-package.input.txt','src/extensions/fixtures/node-crypto-sha256-package.json','vendor/quickjs/quickjs.c','vendor/quickjs/quickjs.h')
foreach($path in $sourcePaths){
 $source=Join-Path $qual $path
 if(!$sourceMap.ContainsKey($path)-or(Hash $source)-cne$sourceMap[$path]){throw ('Exact source seal mismatch: '+$path)}
 Add-File $source ('source/qualification42b/'+$path) 'exact-sealed-relevant-source'
}
foreach($file in Get-ChildItem -LiteralPath (Join-Path $qual 'vendor/quickjs') -File -Filter '*LICENSE*'){
 $path='vendor/quickjs/'+$file.Name
 if($sourcePaths-notcontains$path){Add-File $file.FullName ('source/qualification42b/'+$path) 'dependency-license'}
}
foreach($row in $seal.controls){
 if([IO.Path]::GetExtension($row.path)-eq'.exe'){continue}
 Add-File $row.path ('controls/recorded/'+([string]$entries.Count)+'-'+[IO.Path]::GetFileName($row.path)) 'sealed-control-dependency'
}
foreach($name in @('Audit-RawCrypto58.ps1','Package-RawCrypto58.ps1','raw-audit.json','raw-audit-complete.json')){Add-File (Join-Path $audit $name) ('audit/'+$name) 'independent-audit'}
Add-File (Join-Path $audit 'README-PUBLIC.md') 'README.md' 'scope-and-limitations'
Add-File (Join-Path $audit 'a45-to-42b-shadow-only.patch') 'source/a45-to-42b-shadow-only.patch' 'exact-source-delta'
Add-File (Join-Path $audit 'qualification42b-commit.txt') 'source/qualification42b-commit.txt' 'git-source-identity'
$localArtifacts=@(foreach($row in (Get-Content -LiteralPath (Join-Path $r2 'artifacts-before.json') -Raw|ConvertFrom-Json).rows){
 [ordered]@{path=$row.path;sha256=Hash $row.path;bytes=(Get-Item -LiteralPath $row.path).Length;public_bytes_included=$false}
})
$cacheRoots=@(Get-Content -LiteralPath (Join-Path $v2 'prepared-manifest.json') -Raw|ConvertFrom-Json).disposable_caches
$caches=@(foreach($cache in $cacheRoots){
 $files=@(Get-ChildItem -LiteralPath $cache -File -Recurse)
 [ordered]@{root=$cache;kind='mutable-disposable-compiler-state-not-authority';file_count=$files.Count;total_bytes=($files|Measure-Object Length -Sum).Sum;rows=@($files|ForEach-Object{[ordered]@{relative=$_.FullName.Substring($cache.Length+1);bytes=$_.Length;last_write_utc=$_.LastWriteTimeUtc.ToString('o')}});content_hashes_not_claimed=$true;public_bytes_included=$false}
})
[ordered]@{scope='Local excluded outputs only; not public evidence payload';artifacts=$localArtifacts;caches=$caches;excluded_control_binaries=@($seal.controls|Where-Object{[IO.Path]::GetExtension($_.path)-eq'.exe'});no_runtime_authority_from_cache=$true}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $audit 'LOCAL-excluded-ledger.json') -Encoding utf8NoBOM
$manifest=[ordered]@{schema=1;status='independently-audited-exact-component-proof';source_head='42b8ea7007b1307276067339144b334590cb4046';public_branch_publication='Root-controlled; not independently queried';run_id=$id2;files=$entries.ToArray();whole_source_tree_payload=$false;complete_source_inventory_rows=10818;complete_compiler_inventory_rows=19546;actual_tests=6;actual_results_flags='all full64-bit flags zero';excluded=@('executable/library binaries','PDB','mutable cache','mutable global-cache','compiler and host executable bytes');local_excluded_ledger_in_public_payload=$false;broader_node_crypto_or_package_or_default_sdk_or_full_main_qualified=$false;new_native_jobs_by_auditor=$false}
$manifest|ConvertTo-Json -Depth 14|Set-Content -LiteralPath (Join-Path $stage 'packet-manifest.json') -Encoding utf8NoBOM
[IO.Compression.ZipFile]::CreateFromDirectory($stage,$zip,[IO.Compression.CompressionLevel]::Optimal,$false)
$archive=[IO.Compression.ZipFile]::OpenRead($zip)
try{
 $wanted=@{};foreach($row in $entries){$wanted[$row.relative]=$row}
 $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
 foreach($entry in $archive.Entries){
  if(!$seen.Add($entry.FullName)){throw 'Duplicate ZIP entry'}
  if($entry.FullName-eq'packet-manifest.json'){continue}
  $row=$wanted[$entry.FullName];if($null-eq$row-or$entry.Length-ne$row.bytes){throw 'ZIP member inventory mismatch'}
  $stream=$entry.Open();try{$sha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()}
  if($sha-cne$row.sha256){throw 'ZIP byte hash mismatch'}
 }
 if($seen.Count-ne$entries.Count+1){throw 'Missing ZIP members'}
 $manifestEntry=$archive.GetEntry('packet-manifest.json');$stream=$manifestEntry.Open();try{$manifestSha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()}
 if($manifestSha-cne(Hash (Join-Path $stage 'packet-manifest.json'))){throw 'ZIP manifest mismatch'}
}finally{$archive.Dispose()}
[ordered]@{zip=$zip;sha256=Hash $zip;bytes=(Get-Item -LiteralPath $zip).Length;members=$entries.Count+1;all_members_rehashed=$true;manifest_sha256=Hash (Join-Path $stage 'packet-manifest.json');local_ledger_sha256=Hash (Join-Path $audit 'LOCAL-excluded-ledger.json');new_native_jobs=$false;main_edited=$false}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $audit 'package-receipt.json') -Encoding utf8NoBOM
Get-Content -LiteralPath (Join-Path $audit 'package-receipt.json') -Raw
