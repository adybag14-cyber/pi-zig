# Crypto58 native six-test gate — source-only preparation

The exact clean qualification tree is
C:/Users/adyba/pi-zig/worktrees/root-crypto58-qualification at
 a45abd95e6335346eb1e860a7a5a0677df0b5148,10818tracked files.
No Main or qualification file is changed by this packet. No Zig/compiler/native,
Node/sourcecapture, formatter, probe or liveCIM job ran. The original builtin58
capture is independently accepted and adopted by Root; this packet does not
itself establish native or PackageManager parity.

Run-Crypto58Native.ps1 adapts the closed5EC/AB344 retry gate directly, retaining
canonical CI607 (607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285)
and Protocol39F (39F273D35A5B28E9D60FBE93355828314458A67FB472D60E0A8A6D4DD1FB704D).
No owner, shared protocol, C/H, Engine or native source changes are introduced.
The already reviewed3413 native-census classifier is copied byte-exact; successful
nonempty bounded CIM is required, and candidate identities/incompleteness remain
in admission/final evidence. RAM admission is>=16GiB with native-candidate zero,
rechecked before each child in the existing54second window. CIM operations have
3second operation caps; exhausted/failed windows remain negative, never admitted.
The script bounds attempts, not synchronous OS/file/hash latency. Root's retained
external supervisor must provide its own lifetime/absence handoff as for retry.

Build step: build-native-node-crypto-sha256-artifact, Debug, LLVM, diagnostics=false,
-j1. Compile owner bound1320seconds. Metadata query4/exit0 bound30seconds. Runtime
uses unchanged Protocol39F120seconds and executes every validated index0..5. The
actual metadata must report exactly the following six full names in this order,
using the unchanged old root-components-v2 crypto-selected-tests.json authority:

1. native_node_crypto_hash_test.test.native node crypto SHA256 replays actual original58 observations
2. native_node_crypto_hash_test.test.native node crypto SHA256 retains independent opaque state and module roots through GC
3. native_node_crypto_hash_test.test.native node crypto SHA256 explicitly rejects algorithms and options beyond package usage
4. native_node_crypto_hash_test.test.native node crypto SHA256 every Zig allocation releases partial owner hash byte and encoding roots
5. native_node_crypto_hash_test.test.native node crypto SHA256 retains exact fresh native allocation identity through digest coercion
6. extensions.native_durable_storage.test_0

crypto-selected-tests.authority.json is a byte-exact copy, SHA
E81E7222D1C071EF389FC375BE576D3F620B32DFA7580C456CA05C225FB47DCF.
Its old binary path/hash is historical metadata provenance only. No old artifact
is selected or run. New metadata must independently confirm the exact set/order;
unknown extra/missing/reordered names fail. Both metadata/runtime stderr must be
empty, runtime flags zero, and all six starts/results complete in order.

Use FRESH per-RunId cache, global-cache and out paths below this prepared folder.
No historical root-components/root-tla/retry cache or output is reused. Old EXE,
PDB and receipts remain untouched. A fresh proof directory is acquired with
CreateNew semantics; replay is refused. New out/bin/test.exe and Debug test.pdb
are mandatory and the complete two-file output inventory is sealed before,
between and final, with negative artifacts retained on failures.

Full seals before/between/final cover all10818tracked source files (including
all1004 fixture-directory files), complete19546 compiler inventory/hashes and
explicit control/grant/workspace/relocation/Git/PowerShell files. Compiler paths
are projected relative to the immutable original DEE259F1 authority root, using
explicit char92-to-char47 normalization; no historical manifest is rewritten.
Every full compiler seal must match that original19546inventory. Source pins:

- C2 C 2FA2E26E35B7D5C45D1FFD3F6F10EE3A5DE9A984738486128399A20BD8E4D88D
- H 341CF06F8041B8311D49767026C85C7B859BCFEE3088380F3FFE6D77527052AB
- Module 91FBAD6661EE2345F64E5F3166A27C6C0870278DEA5072E2DA79CF70F34C7487
- Input58 A9722654D1FCF6B3F00638B59F9D4EAA829549CC996EE7BE36808E24D7E2DA26
- Accepted fixture 5062712D48821C749D5D9E416A9DC1CB6A7F15748AB5F64F9D2DC17AB3481074

Failure always attempts the final input/output seals, native-candidate census
and separate owner-PID absence record. A failed native census cannot skip the
owner-absence attempt. Live or reused owner PIDs remain negative and require
Root's independent scoped reconciliation; this adapter adds no kill authority.
Canonical CI607 retains its existing exact-child timeout/pipe settlement. Root
must independently audit raw metadata/runtime frames, output and full seals,
owner identities/absence, and the external supervising owner before acceptance.

The grant template is unauthorized and creates no execution permission. A fresh
Root grant must bind scope, unique RunId, exact head, driverSHA and a<=300second
issued/expiry interval. Root supervises this launch separately:

    pwsh.exe -NoLogo -NoProfile -NonInteractive -File <this directory>/Run-Crypto58Native.ps1 -RootGrantPath <freshRootGrant> -RunId <newUniqueRun>

Source review is pending. This preparation cannot claim the native58 comparison,
GC/fatal/GPA controls, storage test, complete Node crypto, PackageManager or public
API selection passed. No default registration/activation is changed.
