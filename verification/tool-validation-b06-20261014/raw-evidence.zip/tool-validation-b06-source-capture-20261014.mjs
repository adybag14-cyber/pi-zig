import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const sourceHead = 'b06c1f2cf1dea6af8748ddeee18c23587d2cb7c6';
const { validateToolArguments } = await import('file:///C:/Users/adyba/pi-upstream-source-b06c1f2-20261014/packages/ai/src/utils/validation.ts');
globalThis.validationB06 = validateToolArguments;
const input = readFileSync(new URL('./tool-validation-b06-caller-20261014.mjs', import.meta.url));
await import('data:text/javascript,' + encodeURIComponent(input.toString('utf8')));
writeFileSync(process.argv[2], JSON.stringify({ sourceHead,
  actualNode: { version: process.version, executable: process.execPath },
  inputSha256: createHash('sha256').update(input).digest('hex'), cases: validationB06Rows.length,
  scope: 'Actual upstream argumentsError guard and observable early validation order; caller-owned dependencies; not complete provider or application qualification',
  rows: validationB06Rows,
}, null, 2));
