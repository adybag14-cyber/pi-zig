$ErrorActionPreference='Stop'
$container='C:\Users\adyba\pi-zig'
$run=Join-Path $container 'evidence\root-retry698-native-v2-prepared-20261016\root-native-retry160-v2-20261016-225410'
$candidate=Join-Path $container 'worktrees\root-retry698-qualification'
function ReadJson($path){Get-Content -Raw -LiteralPath $path|ConvertFrom-Json}
function Assert($condition,$message){if(!$condition){throw $message}}
function Hash($path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}
$before=ReadJson "$run\before.json"
$result=ReadJson "$run\result.json"
Assert ($result.status -ceq 'passed' -and $result.source_head -ceq 'd72194c600abd19da9a125ec0d3a1969656a27e2') 'Wrong result/head'
$sealChecks=@(foreach($phase in @('between','final')){
 $seal=ReadJson "$run\$phase.json"
 foreach($key in @('candidate_head','driver_sha256','ci_owner_sha256','protocol_sha256','root_grant_sha256')){Assert ($seal.$key -ceq $before.$key) "$phase $key drift"}
 foreach($group in @('source','compiler')){
  $expected=@($before.$group|ForEach-Object{$_.relative+' '+$_.sha256})
  $actual=@($seal.$group|ForEach-Object{$_.relative+' '+$_.sha256})
  $count=if($group -eq 'source'){10637}else{19546}
  Assert ($actual.Count -eq $count -and @($seal.$group.relative|Sort-Object -Unique).Count -eq $count) "$phase $group incomplete"
  $drift=@(Compare-Object $expected $actual -CaseSensitive).Count
  Assert ($drift -eq 0) "$phase $group drift"
  [ordered]@{phase=$phase;group=$group;count=$count;drift=$drift}
 }
})
$compilerManifest=Join-Path $container 'evidence\durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
Assert ((Hash $compilerManifest) -ceq 'DEE259F171F720AB2C08E8DD473975E22C876417CD62E4F016C71A7C662794EB') 'Compiler authority changed'
$compiler=ReadJson $compilerManifest
$authority=@($compiler.inputs|ForEach-Object{$_.path.Substring($compiler.root.Length+1).Replace('\','/')+' '+$_.sha256})
Assert (@(Compare-Object $authority @($before.compiler|ForEach-Object{$_.relative+' '+$_.sha256}) -CaseSensitive).Count -eq 0) 'Compiler authority mismatch'
$pins=[ordered]@{
 'src/native_upstream_698a_retry_test.zig'='02A472157A8103981056AA5D28FB3E07A509AABDADAA2E746F4EFCA019F6825F'
 'src/extensions/fixtures/upstream-698a-retry-source160.json'='C7A60845D59D505EF09FC4038E0B05AFCC13F18364C4BD4178D1EA1F93C00530'
 'src/extensions/fixtures/upstream-698a-retry-source160.input.mjs'='84C373D351B8D348EE03A922663DC6C74BC2E5479C29BEB760E4B2AD91248392'
 'vendor/quickjs/quickjs.c'='2FA2E26E35B7D5C45D1FFD3F6F10EE3A5DE9A984738486128399A20BD8E4D88D'
 'vendor/quickjs/quickjs.h'='341CF06F8041B8311D49767026C85C7B859BCFEE3088380F3FFE6D77527052AB'
}
foreach($pin in $pins.GetEnumerator()){
 $row=@($before.source|Where-Object relative -CEQ $pin.Key)
 Assert ($row.Count -eq 1 -and $row[0].sha256 -ceq $pin.Value -and (Hash (Join-Path $candidate $pin.Key)) -ceq $pin.Value) "Source pin changed $($pin.Key)"
}
# Parse raw metadata independently of selected-tests.json.
$bytes=[IO.File]::ReadAllBytes("$run\metadata.stdout.bin");$offset=0;$version=$null;$names=@()
while($offset -lt $bytes.Length){
 Assert ($bytes.Length-$offset -ge 8) 'Truncated metadata'
 $tag=[BitConverter]::ToUInt32($bytes,$offset);$length=[BitConverter]::ToUInt32($bytes,$offset+4);$offset+=8
 Assert ($length -le $bytes.Length-$offset) 'Bad metadata length'
 if($tag -eq 0){Assert ($null -eq $version -and $names.Count -eq 0) 'Metadata version order';$version=[Text.Encoding]::UTF8.GetString($bytes,$offset,$length)}
 elseif($tag -eq 3){
  Assert ($version -ceq '0.16.0' -and $names.Count -eq 0 -and $length -ge 8) 'Metadata array order'
  $strings=[BitConverter]::ToUInt32($bytes,$offset);$count=[BitConverter]::ToUInt32($bytes,$offset+4)
  Assert ($count -eq 3 -and $length -eq 8+8*$count+$strings) 'Metadata count/length'
  $start=$offset+8+8*$count
  for($i=0;$i -lt $count;$i++){
   $n=[BitConverter]::ToUInt32($bytes,$offset+8+4*$i);$panic=[BitConverter]::ToUInt32($bytes,$offset+8+4*$count+4*$i)
   Assert ($n -lt $strings -and $panic -eq 0) 'Metadata name/panic'
   $end=$n;while($end -lt $strings -and $bytes[$start+$end] -ne 0){$end++};Assert ($end -lt $strings) 'Metadata unterminated'
   $names+=[Text.Encoding]::UTF8.GetString($bytes,$start+$n,$end-$n)
  }
 }else{throw 'Unknown metadata tag'}
 $offset+=$length
}
$selected=ReadJson "$run\selected-tests.json"
Assert (($names -join "`n") -ceq ($selected.tests -join "`n") -and $names.Count -eq 3 -and $selected.actual_count -eq 3) 'Metadata mismatch'
Assert ($names[0] -ceq 'native_upstream_698a_retry_test.test.native upstream698 retry compares all160 genuine getter coercion regexp and function observations') 'Wrong160 name'
Assert ($names[1] -ceq 'native_upstream_698a_retry_test.test.native upstream698 typed retry compares36 genuine error stop string observations') 'Wrong36 name'
Assert ($names[2] -ceq 'extensions.native_durable_storage.test_0') 'Wrong storage name'
# Parse every raw runtime frame, requiring ordered start/result pairs.
$bytes=[IO.File]::ReadAllBytes("$run\runtime.stdout.bin");$offset=0;$version=$null;$started=0;$completed=0;$frames=@()
while($offset -lt $bytes.Length){
 Assert ($bytes.Length-$offset -ge 8) 'Truncated runtime'
 $tag=[BitConverter]::ToUInt32($bytes,$offset);$length=[BitConverter]::ToUInt32($bytes,$offset+4);$offset+=8
 Assert ($length -le $bytes.Length-$offset) 'Bad runtime length'
 switch($tag){
  0 {Assert ($null -eq $version -and $started -eq 0) 'Runtime version order';$version=[Text.Encoding]::UTF8.GetString($bytes,$offset,$length)}
  5 {Assert ($version -ceq '0.16.0' -and $length -eq 0 -and $started -eq $completed -and $started -lt 3) 'Runtime start order';$started++}
  4 {Assert ($length -eq 12 -and $started -eq $completed+1) 'Runtime result order';$index=[BitConverter]::ToUInt32($bytes,$offset);$flags=[BitConverter]::ToUInt64($bytes,$offset+4);Assert ($index -eq $completed -and $flags -eq 0) 'Runtime result/flags';$completed++;$frames+=,[ordered]@{index=$index;flags=$flags}}
  default {throw 'Unknown runtime frame'}
 }
 $offset+=$length
}
Assert ($version -ceq '0.16.0' -and $started -eq 3 -and $completed -eq 3) 'Incomplete runtime'
Assert ((Get-Item -LiteralPath "$run\runtime.stderr.log").Length -eq 0 -and (Get-Item -LiteralPath "$run\metadata.stderr.log").Length -eq 0) 'Unexpected runtime/metadata stderr'
$artifactChecks=@(foreach($phase in @('before','between','final')){
 $inventory=ReadJson "$run\artifacts-$phase.json"
 Assert ($inventory.rows.Count -eq 2) 'Artifact count'
 foreach($row in $inventory.rows){Assert ((Hash $row.path) -ceq $row.sha256) "Artifact mismatch $phase"}
 if($phase -ne 'before'){Assert ($inventory.hash_drift.Count -eq 0 -and $inventory.path_drift.Count -eq 0) 'Artifact drift'}
 [ordered]@{phase=$phase;count=2;drift=0}
})
$exeHash='AE3D937BF9B142DD72239FA56DC8C46D11BCF0C45A81AC19357AF6B68230889B'
Assert ((Hash "$run\out\bin\test.exe") -ceq $exeHash) 'Wrong binary'
$ownerChecks=@(foreach($phase in @('compile','metadata','runtime')){
 $owner=ReadJson "$run\$phase.json"
 Assert ($owner.status -ceq 'passed' -and $owner.exit_code -eq 0 -and $owner.retained_handle -gt 0) 'Owner not successful'
 Assert ($owner.pid -eq $owner.live_identity.pid -and $owner.executable -ceq $owner.live_identity.executable -and $owner.created_utc -ceq $owner.live_identity.created_utc -and $owner.live_identity.command_line_method -ceq 'Win32_Process.CommandLine') 'Owner identity mismatch'
 $deadline=switch($phase){compile{1320}metadata{30}runtime{120}}
 Assert ($owner.timeout_seconds -eq $deadline) 'Wrong deadline'
 $expectedSha=if($phase -eq 'compile'){'086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864'}else{$exeHash}
 Assert ($owner.executable_sha256 -ceq $expectedSha) 'Owner binary identity'
 $elapsed=([DateTimeOffset]$owner.completed_utc-[DateTimeOffset]$owner.created_utc).TotalSeconds
 Assert ($elapsed -ge 0 -and $elapsed -le $deadline) 'Owner exceeded deadline'
 Assert (@(Get-CimInstance Win32_Process -Filter "ProcessId = $($owner.pid)").Count -eq 0) 'Original PID present/reused'
 [ordered]@{phase=$phase;pid=$owner.pid;created_utc=$owner.created_utc;exit_code=0;elapsed_seconds=$elapsed;deadline_seconds=$deadline;currently_absent=$true;actual_command_line=$owner.live_identity.command_line}
})
foreach($phase in @('initial','compile','metadata','runtime')){
 $admission=ReadJson "$run\$phase-admission.json"
 Assert ($admission.probe.free_kib -ge 16777216 -and $admission.probe.native_roots -eq 0) "Admission $phase"
}
$manifest=ReadJson (Join-Path $container 'evidence\root-retry698-native-v2-prepared-20261016\prepared-manifest.json')
foreach($row in $manifest.protected_prior_run_files){Assert ((Hash $row.path) -ceq $row.sha256 -and (Get-Item -LiteralPath $row.path).Length -eq $row.bytes) 'Original proof changed'}
$source=ReadJson (Join-Path $candidate 'src/extensions/fixtures/upstream-698a-retry-source160.json')
Assert ($source.cases -eq 160 -and $source.rows.Count -eq 160 -and @($source.rows|Where-Object{$_.id.StartsWith('error/')}).Count -eq 36) 'Fixture counts'
Assert (@($source.rows|Where-Object{$_.id.StartsWith('error/') -and $_.result -isnot [bool]}).Count -eq 0) 'Typed result kind'
$test=[IO.File]::ReadAllText((Join-Path $candidate 'src/native_upstream_698a_retry_test.zig'))
Assert ($test.Contains('JSON.stringify(actual[index])!==JSON.stringify(expected[index])') -and $test.Contains('json.asInteger') -and $test.Contains('try std.testing.expectEqual(@as(usize, 36), checked)')) 'Required full comparisons missing'
Assert ($result.between_seal -eq $true -and $result.postseal -eq $true -and $result.native_roots_after -eq 0) 'Final state'
Assert ((ReadJson "$run\native-roots-final.json").Count -eq 0) 'Historical native roots not empty'
$receipt=[ordered]@{status='accepted_exact_retry_component';audited_utc=[DateTimeOffset]::UtcNow.ToString('o');run=$run;candidate_head=$result.source_head;binary_sha256=$exeHash;raw_metadata_names=$names;raw_runtime_started=$started;raw_runtime_completed=$completed;raw_runtime_results=$frames;runtime_stderr_bytes=0;metadata_stderr_bytes=0;seals=$sealChecks;compiler_original_authority_drift=0;artifacts=$artifactChecks;owners=$ownerChecks;protected_original_files=$manifest.protected_prior_run_files.Count;protected_original_drift=0;source160_rows=160;typed36_rows=36;source_pins=$pins;limits=@('Exact retry component only; no full SDK/latest Models/full application qualification','No runtime restoration claim','Full saved source/compiler inventories audited; current targeted pins and artifacts rehashed; no fresh full compiler rehash','Original v1 remains negative before classification; no prior pass reused','No jobs launched by this audit')}
ConvertTo-Json -InputObject $receipt -Depth 14|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'acceptance.json') -Encoding utf8NoBOM
[pscustomobject]@{status=$receipt.status;acceptance_sha256=Hash (Join-Path $PSScriptRoot 'acceptance.json');started=$started;completed=$completed;protected_count=$manifest.protected_prior_run_files.Count}|ConvertTo-Json
