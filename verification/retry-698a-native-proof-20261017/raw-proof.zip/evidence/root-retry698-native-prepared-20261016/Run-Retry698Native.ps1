param([Parameter(Mandatory)][string]$RootGrantPath,[Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9][A-Za-z0-9._-]{0,100}$')][string]$RunId)
$ErrorActionPreference='Stop'
$taskRoot='C:\Users\adyba\pi-zig\worktrees\root-retry698-qualification'
$taskExpectedHead='b44c9b34fcd57d8e293f7ecdc4d034aaff35c019'
$taskProof=Join-Path $PSScriptRoot $RunId
$taskCompiler='C:\Users\adyba\pi-zig\toolchain\zig-x86_64-windows-0.16.0'
$taskZig=Join-Path $taskCompiler 'zig.exe'
$taskGit='C:\Program Files\Git\cmd\git.exe'
$taskCi=Join-Path $taskRoot 'tools\ci\native_qualification_ci.ps1'
$taskProtocol=Join-Path $taskRoot 'tools\ci\Invoke-NativeTestProtocol.ps1'
$taskDriverHash=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash
$taskGrant=Get-Content -Raw -LiteralPath $RootGrantPath | ConvertFrom-Json
$taskNow=[DateTimeOffset]::UtcNow
if($taskGrant.scope -cne 'ROOT-RETRY698-NATIVE160-TYPED36-SERIAL' -or $taskGrant.run_id -cne $RunId -or $taskGrant.candidate_head -cne $taskExpectedHead -or $taskGrant.driver_sha256 -cne $taskDriverHash -or $taskGrant.authorized -ne $true){throw 'Exact reviewed Root grant required'}
$taskIssued=[DateTimeOffset]$taskGrant.issued_utc;$taskExpires=[DateTimeOffset]$taskGrant.expires_utc
if($taskIssued -gt $taskNow -or $taskNow -gt $taskExpires -or $taskExpires -le $taskIssued -or ($taskExpires-$taskIssued).TotalSeconds -gt 300){throw 'Fresh bounded Root grant required'}
if((Get-FileHash -LiteralPath $taskCi).Hash -cne '607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285' -or (Get-FileHash -LiteralPath $taskProtocol).Hash -cne '39F273D35A5B28E9D60FBE93355828314458A67FB472D60E0A8A6D4DD1FB704D'){throw 'Canonical CI607/Protocol39F identity differs'}
. $taskCi
. $taskProtocol
New-Item -ItemType Directory -Path $taskProof -ErrorAction Stop | Out-Null
Copy-Item -LiteralPath $RootGrantPath -Destination (Join-Path $taskProof 'root-grant.json') -ErrorAction Stop
$taskAdmissionHistory=[Collections.Generic.List[object]]::new()
$taskExpectedNamed=@('native_upstream_698a_retry_test.test.native upstream698 retry compares all160 genuine getter coercion regexp and function observations','native_upstream_698a_retry_test.test.native upstream698 typed retry compares36 genuine error stop string observations')
$taskAllowedAnonymous='extensions.native_durable_storage.test_0'
function Write-TaskJson {param($Value,[string]$Name) ConvertTo-Json -InputObject $Value -Depth 14|Set-Content -LiteralPath (Join-Path $taskProof $Name) -Encoding utf8NoBOM}
function Get-TaskNativeRoots {
 $taskRows=@(Get-CimInstance Win32_Process -ErrorAction Stop)
 if(!$taskRows.Count){throw 'Native process census unavailable'}
 @($taskRows|Where-Object{$_.Name -in @('zig.exe','build.exe','test.exe') -or ($_.ExecutablePath -and ($_.ExecutablePath -match '\\(?:\.zig-cache|zig-out)\\' -or $_.ExecutablePath.StartsWith($taskProof+'\',[StringComparison]::OrdinalIgnoreCase)))})
}
function Assert-TaskAdmission {
 $taskWait=[Diagnostics.Stopwatch]::StartNew();$taskProbes=[Collections.Generic.List[object]]::new()
 do {
  $taskOs=Get-CimInstance Win32_OperatingSystem -ErrorAction Stop;$taskRoots=@(Get-TaskNativeRoots)
  $taskProbe=[ordered]@{free_kib=[long]$taskOs.FreePhysicalMemory;minimum_kib=16777216;native_roots=$taskRoots.Count;native_candidates=$taskRoots;utc=[DateTimeOffset]::UtcNow.ToString('o')}
  $taskProbes.Add($taskProbe);$taskAdmissionHistory.Add($taskProbe)
  if($taskRoots.Count){throw 'Another native root prevents serial admission'}
  if($taskWait.Elapsed.TotalSeconds -ge 54){throw 'Fresh16GiB admission expired after bounded54s'}
  if($taskOs.FreePhysicalMemory -ge 16777216){return @{probe=$taskProbe;wait_seconds=$taskWait.Elapsed.TotalSeconds;probes=$taskProbes.ToArray()}}
  $taskRemainingMs=54000-$taskWait.ElapsedMilliseconds;if($taskRemainingMs -gt 0){Start-Sleep -Milliseconds ([int][Math]::Min(1000,$taskRemainingMs))}
 }while($true)
}
function Get-TaskSeal {
 param([string]$Name)
 $taskPaths=@(& $taskGit -c core.fsmonitor=false -c core.hooksPath=NUL -C $taskRoot ls-files);if($LASTEXITCODE -ne 0 -or $taskPaths.Count -ne 10637){throw 'Exact full10637 tracked candidate inventory required'}
 $taskHead=([string](& $taskGit -c core.fsmonitor=false -c core.hooksPath=NUL -C $taskRoot rev-parse HEAD)).Trim();if($LASTEXITCODE -ne 0 -or $taskHead -cne $taskExpectedHead){throw 'Exact Root source head differs'}
 $taskStatus=@(& $taskGit -c core.fsmonitor=false -c core.hooksPath=NUL -C $taskRoot status --porcelain);if($LASTEXITCODE -ne 0 -or $taskStatus.Count){throw 'Clean Root qualification composition required'}
 $taskCompilerInventory=Get-CiInventory $taskCompiler;if($taskCompilerInventory.rows.Count -ne 19546){throw 'Complete compiler19546 required'}
 $taskSeal=[ordered]@{candidate_head=$taskHead;source=@(Get-CiRows $taskRoot $taskPaths);compiler=@($taskCompilerInventory.rows);driver_sha256=(Get-FileHash -LiteralPath $PSCommandPath).Hash;ci_owner_sha256=(Get-FileHash -LiteralPath $taskCi).Hash;protocol_sha256=(Get-FileHash -LiteralPath $taskProtocol).Hash;root_grant_sha256=(Get-FileHash -LiteralPath (Join-Path $taskProof 'root-grant.json')).Hash;utc=[DateTimeOffset]::UtcNow.ToString('o')}
 Write-TaskJson $taskSeal "$Name.json";return $taskSeal
}
function Assert-TaskSeal {
 param($Actual,$Expected)
 foreach($taskKey in @('candidate_head','driver_sha256','ci_owner_sha256','protocol_sha256','root_grant_sha256')){if($Actual[$taskKey] -cne $Expected[$taskKey]){throw "$taskKey drift"}}
 foreach($taskGroup in @('source','compiler')){if(@(Compare-Object @($Expected[$taskGroup]|ForEach-Object{$_.relative+' '+$_.sha256}) @($Actual[$taskGroup]|ForEach-Object{$_.relative+' '+$_.sha256}) -CaseSensitive).Count){throw "$taskGroup inventory/hash drift"}}
}
function Read-TaskActualMetadata {
 param([string]$Binary)
 $taskReceipt=Join-Path $taskProof 'metadata'
 # Same query/exit bytes and canonical CI607 owner as Read-CiTestMetadata.
 # Discover actual count once, then validate every full name; do not assume3.
 $taskOwned=Invoke-CiOwnedProcess $Binary @('--listen=-') $taskRoot $taskReceipt 30 ([byte[]](4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0))
 $taskBytes=[IO.File]::ReadAllBytes("$taskReceipt.stdout.bin");$taskOffset=0;$taskVersion=$null;$taskNames=$null
 while($taskOffset -lt $taskBytes.Length){
  if($taskBytes.Length-$taskOffset -lt 8){throw 'Truncated metadata header'}
  $taskTag=[BitConverter]::ToUInt32($taskBytes,$taskOffset);$taskLength=[BitConverter]::ToUInt32($taskBytes,$taskOffset+4);$taskOffset+=8
  if($taskLength -gt 1MB -or $taskLength -gt $taskBytes.Length-$taskOffset){throw 'Invalid metadata body length'}
  if($taskTag -eq 0){if($null -ne $taskVersion -or $null -ne $taskNames){throw 'Duplicate or late metadata version'};$taskVersion=[Text.Encoding]::UTF8.GetString($taskBytes,$taskOffset,$taskLength)}
  elseif($taskTag -eq 3){
   if($taskVersion -cne '0.16.0' -or $null -ne $taskNames -or $taskLength -lt 8){throw 'Unexpected metadata array'}
   $taskStrings=[BitConverter]::ToUInt32($taskBytes,$taskOffset);$taskCount=[BitConverter]::ToUInt32($taskBytes,$taskOffset+4)
   if($taskCount -notin @(2,3) -or $taskLength -ne 8+8*$taskCount+$taskStrings){throw 'Only two required named tests and optional exact storage anonymous test allowed'}
   $taskStringStart=$taskOffset+8+8*$taskCount;$taskNames=@()
   for($taskIndex=0;$taskIndex -lt $taskCount;$taskIndex++){
    $taskNameOffset=[BitConverter]::ToUInt32($taskBytes,$taskOffset+8+4*$taskIndex);$taskPanic=[BitConverter]::ToUInt32($taskBytes,$taskOffset+8+4*$taskCount+4*$taskIndex)
    if($taskPanic -ne 0 -or $taskNameOffset -ge $taskStrings){throw 'Invalid panic/name metadata'}
    $taskEnd=$taskNameOffset;while($taskEnd -lt $taskStrings -and $taskBytes[$taskStringStart+$taskEnd] -ne 0){$taskEnd++};if($taskEnd -eq $taskStrings){throw 'Unterminated metadata name'}
    $taskNames+=[Text.Encoding]::UTF8.GetString($taskBytes,$taskStringStart+$taskNameOffset,$taskEnd-$taskNameOffset)
   }
  }else{throw "Unexpected metadata tag $taskTag"};$taskOffset+=$taskLength
 }
 if($taskVersion -cne '0.16.0' -or $null -eq $taskNames){throw 'Missing metadata/version'}
 foreach($taskName in $taskExpectedNamed){if(@($taskNames|Where-Object{$_ -ceq $taskName}).Count -ne 1){throw 'Both exact named Source160/typed36 tests required once'}}
 $taskExtra=@($taskNames|Where-Object{$_ -cnotin $taskExpectedNamed});if($taskExtra.Count -gt 1 -or ($taskExtra.Count -eq 1 -and $taskExtra[0] -cne $taskAllowedAnonymous)){throw 'Unreviewed imported native test'}
 $taskMetadata=[ordered]@{binary=$Binary;binary_sha256=$taskOwned.executable_sha256;version=$taskVersion;actual_count=$taskNames.Count;tests=$taskNames;required_named=$taskExpectedNamed;imported_anonymous=$taskExtra;count_known_before_metadata=$false;method='Actual query4/exit0 only; no run_test; canonical CI607 owner30s'}
 Write-TaskJson $taskMetadata 'selected-tests.json';return $taskMetadata
}
$taskResult=[ordered]@{status='running';source_head=$taskExpectedHead;planned_named_tests=2;actual_metadata_count=$null;compile=$null;metadata=$null;runtime=$null;between_seal=$false;postseal=$false;native_roots_after=$null}
$taskBefore=$null;$taskArtifacts=$null
try {
 if((Get-FileHash -LiteralPath $taskZig).Hash -cne '086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864'){throw 'Pinned Zig0.16 differs'}
 if((Get-FileHash -LiteralPath (Join-Path $taskRoot 'vendor/quickjs/quickjs.c')).Hash -cne '2FA2E26E35B7D5C45D1FFD3F6F10EE3A5DE9A984738486128399A20BD8E4D88D' -or (Get-FileHash -LiteralPath (Join-Path $taskRoot 'vendor/quickjs/quickjs.h')).Hash -cne '341CF06F8041B8311D49767026C85C7B859BCFEE3088380F3FFE6D77527052AB'){throw 'Reviewed C/H identity differs'}
 if((Get-FileHash -LiteralPath (Join-Path $taskRoot 'src/extensions/fixtures/upstream-698a-retry-source160.json')).Hash -cne 'C7A60845D59D505EF09FC4038E0B05AFCC13F18364C4BD4178D1EA1F93C00530' -or (Get-FileHash -LiteralPath (Join-Path $taskRoot 'src/extensions/fixtures/upstream-698a-retry-source160.input.mjs')).Hash -cne '84C373D351B8D348EE03A922663DC6C74BC2E5479C29BEB760E4B2AD91248392'){throw 'Accepted Source160/caller bytes differ'}
 Write-TaskJson (Assert-TaskAdmission) 'initial-admission.json'
 $taskBefore=Get-TaskSeal 'before'
 Write-TaskJson (Assert-TaskAdmission) 'compile-admission.json'
 $taskPrefix=Join-Path $taskProof 'out'
 $taskArgs=@('build','build-native-upstream-698a-retry','-Doptimize=Debug','-Duse-llvm=true','-Ddiagnostic-tests=false','-j1','--prefix',$taskPrefix,'--cache-dir',(Join-Path $taskProof 'cache'),'--global-cache-dir',(Join-Path $taskProof 'global-cache'),'--summary','all')
 $taskResult.compile=Invoke-CiOwnedProcess $taskZig $taskArgs $taskRoot (Join-Path $taskProof 'compile') 1320
 if(@(Get-TaskNativeRoots).Count){throw 'Native root remains after compile'}
 $taskBinary=Join-Path $taskPrefix 'bin/test.exe';$taskPdb=Join-Path $taskPrefix 'bin/test.pdb'
 if(!(Test-Path -LiteralPath $taskBinary -PathType Leaf) -or !(Test-Path -LiteralPath $taskPdb -PathType Leaf)){throw 'Installed exact test.exe and Debug PDB required'}
 $taskArtifacts=Get-CiInventory $taskPrefix;Write-TaskJson $taskArtifacts 'artifacts-before.json'
 Write-TaskJson (Assert-TaskAdmission) 'metadata-admission.json'
 $taskResult.metadata=Read-TaskActualMetadata $taskBinary;$taskResult.actual_metadata_count=$taskResult.metadata.actual_count
 if(@(Get-TaskNativeRoots).Count){throw 'Native root remains after metadata'}
 Assert-TaskSeal (Get-TaskSeal 'between') $taskBefore;$taskResult.between_seal=$true
 Assert-CiInventory $taskArtifacts (Join-Path $taskProof 'artifacts-between.json')
 Write-TaskJson (Assert-TaskAdmission) 'runtime-admission.json'
 # Canonical Protocol39F runtime is120s, below plan maximum300s. Run every
 # reported/validated test index, including optional exact storage test_0.
 $taskResult.runtime=Invoke-NativeTestProtocol $taskBinary $taskRoot (Join-Path $taskProof 'runtime') $taskResult.actual_metadata_count
 $taskResult.status='passed'
}catch{$taskResult.status='failed';$taskResult.error=$_.Exception.Message}
finally {
 try{$taskFinal=Get-TaskSeal 'final';if($null -eq $taskBefore){throw 'Before baseline unavailable; final retained only'};Assert-TaskSeal $taskFinal $taskBefore;$taskResult.postseal=$true}catch{$taskResult.status='failed_postseal';$taskResult.postseal_error=$_.Exception.Message}
 try{if($null -ne $taskArtifacts){Assert-CiInventory $taskArtifacts (Join-Path $taskProof 'artifacts-final.json')}elseif(Test-Path -LiteralPath (Join-Path $taskProof 'out')){Write-TaskJson (Get-CiInventory (Join-Path $taskProof 'out')) 'artifacts-negative.json'}}catch{$taskResult.status='failed_artifacts';$taskResult.artifact_error=$_.Exception.Message}
 try{$taskRoots=@(Get-TaskNativeRoots);Write-TaskJson $taskRoots 'native-roots-final.json';$taskResult.native_roots_after=$taskRoots.Count;if($taskRoots.Count){throw 'Native roots remain'}
  $taskAbsences=@(foreach($taskPhase in @('compile','metadata','runtime')){$taskReceipt=Join-Path $taskProof "$taskPhase.json";if(Test-Path -LiteralPath $taskReceipt){$taskRecord=Get-Content -Raw -LiteralPath $taskReceipt|ConvertFrom-Json;$taskLive=@(Get-CimInstance Win32_Process -Filter "ProcessId = $($taskRecord.pid)" -ErrorAction Stop);[ordered]@{phase=$taskPhase;owner_receipt=$taskReceipt;pid=$taskRecord.pid;recorded_created_utc=$taskRecord.created_utc;current=$taskLive;absent=($taskLive.Count -eq 0)}}});Write-TaskJson $taskAbsences 'owner-absence.json';if(@($taskAbsences|Where-Object{!$_.absent}).Count){throw 'Owner PID still present or reused; Root independent reconciliation required'}
 }catch{$taskResult.status='failed_absence';$taskResult.absence_error=$_.Exception.Message}
 $taskResult.admission_probes=$taskAdmissionHistory.ToArray();$taskResult.completed_utc=[DateTimeOffset]::UtcNow.ToString('o');Write-TaskJson $taskResult 'result.json'
}
$taskResult|ConvertTo-Json -Depth 14
if($taskResult.status -cne 'passed'){throw 'Source698 native focused gate failed'}