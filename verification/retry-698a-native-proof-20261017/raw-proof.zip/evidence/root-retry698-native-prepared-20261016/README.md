# Source698 native focused gate — prepared, not executed

Exact candidate: b44c9b34fcd57d8e293f7ecdc4d034aaff35c019, expected full10637 tracked paths.
Assigned candidate: C:\Users\adyba\pi-zig\worktrees\root-retry698-qualification.
The canonical CI607 owner and Protocol39F helper remain byte-identical; the driver does not edit them.
Root main/qualification tree and frozen Source81ec controls remain untouched.

Source160 was independently accepted at evidence/source160-independent-async-review-20261016/acceptance.json.
The accepted raw expected C7A60845D59D505EF09FC4038E0B05AFCC13F18364C4BD4178D1EA1F93C00530 and byte-original caller84C373D351B8D348EE03A922663DC6C74BC2E5479C29BEB760E4B2AD91248392 are explicitly pinned.
Full tracked input seals include all historical273 files, typed retry source/tests, C/H/vendor, and accepted proof paths; no runtime/npm/Node reference is needed.
Compiler inventory is full19546. Candidate must remain clean and exact.

Actual compiled metadata count is UNKNOWN. Two required named tests are known from source. The only allowed extra is the exact imported extensions.native_durable_storage.test_0. Metadata query uses canonicalCI607 with query_test_metadata4/exit0 and30seconds; every name is checked, duplicates/unknown extras reject. The protocol runtime receives actual validated count and executes every index, retaining the anonymous test if present. No silent assumption that count equals3 is made.

Bounds: compile1320s; metadata30s; canonical protocol runtime120s (below planned maximum300s); per-test cannot exceed the120s whole runtime; Engine host await10s from exact test source. Debug/LLVM, standard protocol runner and-j1. Fresh16GiB/nativezero before compile, metadata and runtime, bounded54s readmission with all probes retained. Root must independently supervise the driver/serial lease; no new outer process owner is introduced by this adapter. Canonical owner redirected pipes settle within10s.

Before and between full source/compiler/driver/control/grant seals, installed output full inventory with executable/PDB hashes, and unconditional final full seals/absence are retained on positive or negative outcomes. Partial compile output is inventoried on failure. Any baseline absence, input/output drift, nonempty native census, or remaining/reused owner PID is negative. Owner/descendant independent external reconciliation by Root remains required before handoff. This adapter retains the reviewedv4 read-only Git inventory calls and canonical owner behavior; it does not claim a new generic process-owner framework.

Invocation ONLY after Root fresh explicit grant and independent source-review closure:

    & 'C:\Program Files\PowerShell\7\pwsh.exe' -NoLogo -NoProfile -NonInteractive -File 'C:\Users\adyba\pi-zig\evidence\root-retry698-native-prepared-20261016\Run-Retry698Native.ps1' -RootGrantPath '<ROOT-EXACT-GRANT-PATH>' -RunId '<ROOT-FRESH-UNIQUE-RUN>'

Root grant template is unauthorized. Root must set one issued base, expiry <=300s, exact driverSHA/candidate/runID and authorized=true. Run directory is freshly acquired without Force, previous proof runs are never reused. No build, metadata or runtime job has executed from this prepared packet.

Two named tests:
- native_upstream_698a_retry_test.test.native upstream698 retry compares all160 genuine getter coercion regexp and function observations
- native_upstream_698a_retry_test.test.native upstream698 typed retry compares36 genuine error stop string observations

This gate establishes classifier-body ordinary-function observations and typed36 only if actual compile/runtime pass. It does not qualify public namespace/default SDK, restored runtime, extension runtime, TypeBox, hosted profiles or release.