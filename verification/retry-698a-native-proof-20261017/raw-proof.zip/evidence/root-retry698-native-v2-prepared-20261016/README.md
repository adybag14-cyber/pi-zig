# Retry698 native v2 — source-only correction after retained panic

Exact candidate d72194c600abd19da9a125ec0d3a1969656a27e2 (Root main causal commit e6478ec3ca4ec247b56e2f9dd4f1a710274f7691 cherry-picked), clean10637tracked.

The first native run remains immutable at:
C:\Users\adyba\pi-zig\evidence\root-retry698-native-prepared-20261016\root-native-retry160-20261016-222744
Its compile succeeded and actual metadata reported3 tests; runtime panicked at test index0 before Source160 case execution because verifySource directly accessed .integer while durable/backend/json.zig parses JSON numbers as .float. The retained negative is not a classifier mismatch, pass, or execution of the other two tests.

The only native test correction uses checked json.asInteger for cases==160, preserving expected bytes, all160 caller inputs, all assertions and typed36 comparison. Backend asInteger accepts numeric tags through asNumber and checks nonnegative integral u64 conversion. Remaining direct .array accesses correspond to the genuine rows array; .bool is used only for the36 genuine selected result booleans. Actual retained JSON confirms exactly36 boolean results. No other .integer or .float access remains in this test. Root also added the final newline; no product implementation was changed.

V2 driver differs from independently closed5EC only in exact candidate head and two explicitly unsealed cache paths. The local cache and global cache below may be reused as disposable compiler state under Root's specific authorization:
- C:\Users\adyba\pi-zig\evidence\root-retry698-native-prepared-20261016\root-native-retry160-20261016-222744\cache
- C:\Users\adyba\pi-zig\evidence\root-retry698-native-prepared-20261016\root-native-retry160-20261016-222744\global-cache
These directories are NOT protected proof, no cache-derived artifact is accepted without this exact-head fresh compilation. They are not inventoried as immutable authority. No old prefix/output, executable, PDB or receipt path is reused. New unique run directory and new prefix/out are acquired under this v2 prepared folder, preserving originals; protected prior-run file hashes are listed separately in prepared-manifest.json.

Canonical CI607 and Protocol39F remain unchanged. All reviewed admission/bounds/seals/metadata rules remain: fresh16GiB/nativezero, bounded54s readmission before each child; compile1320/metadata30/runtimecanonical120 (maximumplan300, pertest<=120)/hostawait10s; DebugLLVM/-j1; full10637candidate/compiler19546/fixture/driver/grant pre-between-final seals, complete fresh output executable/PDB inventory and failure evidence/absence. Count remains unknown until this executable's actual metadata query; require exact two names and optional only extensions.native_durable_storage.test_0, execute allvalidatedindices. Historical actual3 is evidence, not a substitute for the next query.

No jobs or Main/qualification edits occurred in preparing this packet. Root fresh grant and independent source-review closure remain required. The grant template is unauthorized. Invocation:

    & 'C:\Program Files\PowerShell\7\pwsh.exe' -NoLogo -NoProfile -NonInteractive -File 'C:\Users\adyba\pi-zig\evidence\root-retry698-native-v2-prepared-20261016\Run-Retry698Native.ps1' -RootGrantPath '<ROOT-FRESH-GRANT>' -RunId '<ROOT-NEW-UNIQUE-RUN>'