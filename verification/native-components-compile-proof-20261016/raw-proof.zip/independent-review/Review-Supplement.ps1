$ErrorActionPreference='Stop'
$base='C:\Users\adyba\pi-zig\evidence';$checkout='C:\Users\adyba\pi-zig\worktrees\root-components-qualification'
$output=Join-Path $PSScriptRoot 'review-supplement.json';if(Test-Path -LiteralPath $output){throw 'Refuse supplemental receipt overwrite'}
function Json([string]$Path){Get-Content -LiteralPath $Path -Raw|ConvertFrom-Json}
$mainReceipt=Join-Path $PSScriptRoot 'review.json';if((Get-FileHash -LiteralPath $mainReceipt).Hash -cne '3A6445E64181D7CCAD022472DADA0436CC33DEB2CF4FC0BE6D2E12B1099386CC'){throw 'Primary independent receipt drift'}
$success=@(
 @{packet='root-components-compile-v2-20261016';group='crypto';step='build-native-node-crypto-sha256-artifact'},
 @{packet='root-components-compile-v3-20261016';group='classic';step='build-native-node-stream-classic-artifact'},
 @{packet='root-components-compile-v3-20261016';group='iterator';step='build-native-node-stream-classic-iterator-artifact'},
 @{packet='root-components-compile-v4-20261016';group='writer';step='build-native-node-fs-write-stream-artifact'}
)
foreach($item in $success){
 $owner=Json (Join-Path (Join-Path $base $item.packet) ($item.group+'-compile.json'))
 $prefix=Join-Path (Join-Path $base $item.packet) ($item.group+'-out')
 $args=@('build',$item.step,'-Doptimize=Debug','-Duse-llvm=true','-Ddiagnostic-tests=false','-j1','--prefix',$prefix,'--cache-dir',(Join-Path $base 'root-tla-focused-20261016\cache'),'--global-cache-dir',(Join-Path $base 'root-tla-focused-20261016\global-cache'),'--summary','all')
 if([string]::Join("`n",$owner.arguments) -cne [string]::Join("`n",$args) -or $owner.working_directory -cne $checkout){throw 'Exact compile argv/working directory differs'}
}
$negativeSpecs=@(
 @{packet='root-components-compile-20261016';group='crypto';errors=3;head='2a36a0d847aa8b2455f30c838f288fdd06317f1f'},
 @{packet='root-components-compile-v2-20261016';group='classic';errors=2;head='a17e2bcafde50029a01152118f2406dccda0274c'},
 @{packet='root-components-compile-v3-20261016';group='writer';errors=1;head='67965e9f0ba1f6f10e71f5d51ec03bec010eb55c'}
)
$live=@(Get-CimInstance Win32_Process -ErrorAction Stop);if(!$live.Count){throw 'Census unavailable'};$negatives=@();$files=@($mainReceipt,$PSCommandPath)
foreach($spec in $negativeSpecs){
 $dir=Join-Path $base $spec.packet;$ownerPath=Join-Path $dir ($spec.group+'-compile.json');$owner=Json $ownerPath
 $diagnosticPath=Join-Path $dir ($spec.group+'-compile.stderr.log');$diagnostics=@(Select-String -LiteralPath $diagnosticPath -Pattern '^src.+error:'|ForEach-Object Line)
 if($owner.status -cne 'failed' -or $owner.exit_code -ne 1 -or !$owner.retained_handle -or $owner.pid -ne $owner.live_identity.pid -or $owner.created_utc -cne $owner.live_identity.created_utc -or $owner.executable -cne $owner.live_identity.executable -or !$owner.live_identity.command_line -or $owner.working_directory -cne $checkout -or $owner.executable_sha256 -cne (Get-FileHash -LiteralPath $owner.executable).Hash -or $diagnostics.Count -ne $spec.errors){throw 'Negative owner/diagnostic differs'}
 foreach($process in @($live|Where-Object ProcessId -EQ $owner.pid)){if([Math]::Abs(($process.CreationDate.ToUniversalTime()-([DateTimeOffset]$owner.created_utc).UtcDateTime).TotalMilliseconds) -lt 1){throw 'Negative owner incarnation remains'}}
 $before=Json (Join-Path $dir 'before.json');$final=Json (Join-Path $dir 'final.json')
 if($before.candidate_head -cne $spec.head -or $final.candidate_head -cne $spec.head -or $before.driver_sha256 -cne $final.driver_sha256){throw 'Negative head/driver differs'}
 foreach($kind in @('source','compiler')){
  if(@(Compare-Object @($before.$kind|ForEach-Object{$_.relative+'|'+$_.path+'|'+$_.sha256}) @($final.$kind|ForEach-Object{$_.relative+'|'+$_.path+'|'+$_.sha256}) -CaseSensitive).Count){throw 'Negative complete seal drift'}
 }
 $negatives+=@{packet=$spec.packet;head=$spec.head;pid=$owner.pid;status='failed';exit=1;diagnostics=$diagnostics;postseal_drift=0;historical_owner_absent=$true};$files+=@($ownerPath,$diagnosticPath,(Join-Path $dir 'before.json'),(Join-Path $dir 'final.json'))
}
$repairs=@(
 @{main='c614f674ab3914fc34e74fbaba1d38abc1157f8e';before='2a36a0d847aa8b2455f30c838f288fdd06317f1f';after='a17e2bcafde50029a01152118f2406dccda0274c';paths=@('src/extensions/native_node_stream.zig')},
 @{main='caf73bf211ea0051753003c34ecdd24313682194';before='a17e2bcafde50029a01152118f2406dccda0274c';after='67965e9f0ba1f6f10e71f5d51ec03bec010eb55c';paths=@('src/extensions/native_compression_stream.zig','src/extensions/native_node_stream.zig')},
 @{main='38a8e606c159a8e918142b4e1b5210c4af707ac8';before='67965e9f0ba1f6f10e71f5d51ec03bec010eb55c';after='156e89d14bb2671840d0337cdfbf995c5a8dcdc6';paths=@('src/extensions/native_node_fs_system_error.zig')}
)
foreach($repair in $repairs){
 $changed=@(git -C $checkout diff --name-only $repair.before $repair.after);if($LASTEXITCODE -ne 0 -or @(Compare-Object $changed $repair.paths -CaseSensitive).Count){throw 'Unexpected causal repair paths'}
 foreach($path in $repair.paths){
  $before=[string](git -C $checkout rev-parse ($repair.before+':'+$path));$mainBefore=[string](git -C $checkout rev-parse ($repair.main+'^:'+$path))
  $after=[string](git -C $checkout rev-parse ($repair.after+':'+$path));$mainAfter=[string](git -C $checkout rev-parse ($repair.main+':'+$path))
  if($LASTEXITCODE -ne 0 -or $before -cne $mainBefore -or $after -cne $mainAfter){throw 'Qualification repair blob differs from Root main repair'}
 }
}
$original=Json (Join-Path $base 'root-components-compile-20261016\before.json');$v2=Json (Join-Path $base 'root-components-compile-v2-20261016\before.json')
$map=@{};foreach($row in $original.source){$map[$row.relative]=$row.sha256};$changed=@($v2.source|Where-Object{$map[$_.relative] -cne $_.sha256}|ForEach-Object relative)
if($changed.Count -ne 1 -or $changed[0] -cne 'src/extensions/native_node_stream.zig' -or @(Compare-Object @($original.compiler|ForEach-Object{$_.relative+'|'+$_.sha256}) @($v2.compiler|ForEach-Object{$_.relative+'|'+$_.sha256}) -CaseSensitive).Count){throw 'Original to v2 source/compiler transition differs'}
$receipt=[ordered]@{status='accepted_supplement_preserved_compile_negatives_and_causal_repairs';reviewer='models_auth_resume';reviewed_utc=[DateTimeOffset]::UtcNow.ToString('o');linked_primary_sha256='3A6445E64181D7CCAD022472DADA0436CC33DEB2CF4FC0BE6D2E12B1099386CC';successful_exact_compile_argv_checks=4;negatives=$negatives;negative_full_seal_comparisons=6;causal_repairs_exact_main_blobs=$repairs;unexpected_source_deltas=0;historical_negative_owner_incarnations_live=0;runtime_tests_executed=0;limitations=@('Preserved failed packets are not relabeled as passed','Mixed-head scope and no runtime qualification remain unchanged');artifact_seals=@($files|Sort-Object -Unique|ForEach-Object{@{path=$_;sha256=(Get-FileHash -LiteralPath $_).Hash}})}
$receipt|ConvertTo-Json -Depth 10|Set-Content -LiteralPath $output -Encoding utf8NoBOM
@{status=$receipt.status;negative_owners=3;exact_compile_argv=4;receipt=$output;sha256=(Get-FileHash -LiteralPath $output).Hash}|ConvertTo-Json -Compress
