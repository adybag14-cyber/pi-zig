$ErrorActionPreference='Stop'
$base='C:\Users\adyba\pi-zig\evidence'
$checkout='C:\Users\adyba\pi-zig\worktrees\root-components-qualification'
$output=Join-Path $PSScriptRoot 'review.json'
if(Test-Path -LiteralPath $output){throw 'Refuse independent receipt overwrite'}
function Json([string]$Path){Get-Content -LiteralPath $Path -Raw|ConvertFrom-Json}
function Metadata([string]$Path,[int]$Expected){
 $b=[IO.File]::ReadAllBytes($Path);$offset=0;$tags=@();$version='';$names=@()
 while($offset -lt $b.Length){
  if($b.Length-$offset -lt 8){throw 'Short metadata header'}
  $tag=[BitConverter]::ToUInt32($b,$offset);$length=[BitConverter]::ToUInt32($b,$offset+4);$offset+=8;$tags+=$tag
  if($length -gt 1MB -or $length -gt $b.Length-$offset){throw 'Short metadata body'}
  if($tag -eq 0 -and $tags.Count -eq 1){$version=[Text.Encoding]::UTF8.GetString($b,$offset,$length)}
  elseif($tag -eq 3 -and $tags.Count -eq 2){
   if($length -lt 8){throw 'Short metadata array'}
   $strings=[BitConverter]::ToUInt32($b,$offset);$count=[BitConverter]::ToUInt32($b,$offset+4)
   if($count -ne $Expected -or $length -ne 8+8*$count+$strings){throw 'Wrong metadata count/layout'}
   $start=$offset+8+8*$count
   for($i=0;$i -lt $count;$i++){
    $name=[BitConverter]::ToUInt32($b,$offset+8+4*$i);$panic=[BitConverter]::ToUInt32($b,$offset+8+4*$count+4*$i)
    if($panic -ne 0 -or $name -ge $strings){throw 'Metadata panic/offset'}
    $end=$name;while($end -lt $strings -and $b[$start+$end] -ne 0){$end++}
    if($end -eq $strings){throw 'Metadata name unterminated'}
    $names+=[Text.Encoding]::UTF8.GetString($b,$start+$name,$end-$name)
   }
  }else{throw 'Nonmetadata/repeated/out-of-order protocol frame'}
  $offset+=$length
 }
 if($version -cne '0.16.0' -or $tags.Count -ne 2 -or $names.Count -ne $Expected){throw 'Incomplete metadata stream'}
 return @{version=$version;tags=$tags;names=$names;test_start_frames=0;test_result_frames=0}
}
$packets=@(
 @{name='root-components-compile-v2-20261016';head='a17e2bcafde50029a01152118f2406dccda0274c';status='failed';groups=@(@{name='crypto';count=6});failed='classic'},
 @{name='root-components-compile-v3-20261016';head='67965e9f0ba1f6f10e71f5d51ec03bec010eb55c';status='failed';groups=@(@{name='classic';count=6},@{name='iterator';count=8});failed='writer'},
 @{name='root-components-compile-v4-20261016';head='156e89d14bb2671840d0337cdfbf995c5a8dcdc6';status='passed';groups=@(@{name='writer';count=9});failed=$null}
)
$ci='607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285'
$protocol='39F273D35A5B28E9D60FBE93355828314458A67FB472D60E0A8A6D4DD1FB704D'
$zig='086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864'
$groups=@();$owners=@();$seals=@();$files=@();$admissions=@();$packetRows=@();$previous=$null
foreach($packet in $packets){
 $dir=Join-Path $base $packet.name;$grant=Json (Join-Path $dir 'grant.json');$result=Json (Join-Path $dir 'result.json');$before=Json (Join-Path $dir 'before.json')
 if($grant.source_head -cne $packet.head -or $before.candidate_head -cne $packet.head -or $grant.status -cne 'admitted' -or $result.status -cne $packet.status -or !$result.postseal -or $result.native_roots_after -ne 0 -or $before.source.Count -ne 10623 -or $before.compiler.Count -ne 19546 -or $grant.ci_owner_sha256 -cne $ci -or $grant.protocol_sha256 -cne $protocol){throw 'Packet identity/state differs'}
 $driver=Join-Path $dir 'Run-CompileMetadata.ps1';$driverText=Get-Content -LiteralPath $driver -Raw
 if((Get-FileHash -LiteralPath $driver).Hash -cne $before.driver_sha256 -or $driverText -match 'Invoke-NativeTestProtocol\s' -or $driverText -notmatch '\$taskRuntime=\$null' -or $driverText -notmatch "'-Ddiagnostic-tests=false'"){throw 'Driver hash/runtime boundary differs'}
 $sealNames=@($packet.groups|ForEach-Object{$_.name+'-after'})+@('final')
 foreach($sealName in $sealNames){
  $sealPath=Join-Path $dir ($sealName+'.json');$seal=Json $sealPath
  if($seal.candidate_head -cne $packet.head -or $seal.driver_sha256 -cne $before.driver_sha256){throw 'Seal head/driver differs'}
  foreach($kind in @('source','compiler')){
   $left=@($before.$kind|ForEach-Object{$_.relative+'|'+$_.path+'|'+$_.sha256});$right=@($seal.$kind|ForEach-Object{$_.relative+'|'+$_.path+'|'+$_.sha256})
   if(@(Compare-Object $left $right -CaseSensitive).Count -or @($seal.$kind.relative|Sort-Object -Unique).Count -ne $seal.$kind.Count){throw 'Full seal drift/duplicates'}
   $seals+=@{packet=$packet.name;seal=$sealName;kind=$kind;count=$seal.$kind.Count;drift=0}
  };$files+=$sealPath
 }
 foreach($control in @(@{path='vendor/quickjs/quickjs.c';hash='2FA2E26E35B7D5C45D1FFD3F6F10EE3A5DE9A984738486128399A20BD8E4D88D'},@{path='vendor/quickjs/quickjs.h';hash='341CF06F8041B8311D49767026C85C7B859BCFEE3088380F3FFE6D77527052AB'},@{path='tools/ci/native_qualification_ci.ps1';hash=$ci},@{path='tools/ci/Invoke-NativeTestProtocol.ps1';hash=$protocol})){
  $row=@($before.source|Where-Object relative -CEQ $control.path);if($row.Count -ne 1 -or $row[0].sha256 -cne $control.hash){throw 'Sealed C/header/helper identity differs'}
 }
 if($previous){
  $left=@($previous.compiler|ForEach-Object{$_.relative+'|'+$_.sha256});$right=@($before.compiler|ForEach-Object{$_.relative+'|'+$_.sha256});if(@(Compare-Object $left $right -CaseSensitive).Count){throw 'Cross-packet compiler drift'}
  $map=@{};foreach($row in $previous.source){$map[$row.relative]=$row.sha256};$changed=@($before.source|Where-Object{$map[$_.relative] -cne $_.sha256}|ForEach-Object relative)
  $expected=if($packet.name -like '*v3-*'){@('src/extensions/native_compression_stream.zig','src/extensions/native_node_stream.zig')}else{@('src/extensions/native_node_fs_system_error.zig')}
  if(@(Compare-Object $changed $expected -CaseSensitive).Count){throw 'Unexpected cross-head source delta'}
 };$previous=$before
 foreach($group in $packet.groups){
  $name=$group.name;$selected=Json (Join-Path $dir ($name+'-selected-tests.json'));$raw=Metadata (Join-Path $dir ($name+'-metadata.stdout.bin')) $group.count
  $reported=@($result.groups|Where-Object name -CEQ $name)
  if($reported.Count -ne 1 -or $reported[0].runtime -ne $null -or $reported[0].runtime_tests_executed -ne 0 -or !$reported[0].compile_and_metadata_only -or [string]::Join("`n",$raw.names) -cne [string]::Join("`n",$selected.tests) -or [string]::Join("`n",$raw.names) -cne [string]::Join("`n",$reported[0].metadata.tests)){throw 'Selected/report metadata or runtime differs'}
  $binary=Join-Path $dir ($name+'-out\bin\test.exe');$hash=(Get-FileHash -LiteralPath $binary).Hash
  if($selected.binary -cne $binary -or $selected.binary_sha256 -cne $hash -or $reported[0].metadata.binary_sha256 -cne $hash -or (Get-Item -LiteralPath (Join-Path $dir ($name+'-metadata.stderr.log'))).Length -ne 0 -or (Get-Item -LiteralPath (Join-Path $dir ($name+'-compile.stdout.bin'))).Length -ne 0){throw 'Artifact/output differs'}
  foreach($stage in @('compile','metadata')){
   $ownerPath=Join-Path $dir ($name+'-'+$stage+'.json');$owner=Json $ownerPath
   if($owner.status -cne 'passed' -or $owner.exit_code -ne 0 -or !$owner.retained_handle -or $owner.pid -ne $owner.live_identity.pid -or $owner.created_utc -cne $owner.live_identity.created_utc -or $owner.executable -cne $owner.live_identity.executable -or !$owner.live_identity.command_line -or (Get-FileHash -LiteralPath $owner.executable).Hash -cne $owner.executable_sha256){throw 'Owner identity/terminal differs'}
   if($stage -eq 'compile'){if($owner.executable_sha256 -cne $zig -or '-j1' -cnotin $owner.arguments -or '-Ddiagnostic-tests=false' -cnotin $owner.arguments -or $owner.timeout_seconds -ne 1320){throw 'Compile ownership policy differs'}}else{if($owner.executable -cne $binary -or $owner.executable_sha256 -cne $hash -or $owner.arguments.Count -ne 1 -or $owner.arguments[0] -cne '--listen=-' -or $owner.timeout_seconds -ne 30){throw 'Metadata ownership differs'}}
   $owners+=@{packet=$packet.name;group=$name;stage=$stage;pid=$owner.pid;created_utc=$owner.created_utc;executable=$owner.executable;sha256=$owner.executable_sha256;handle=$owner.retained_handle;command_line=$owner.live_identity.command_line;status='passed';exit=0};$files+=$ownerPath
  }
  if(Test-Path -LiteralPath (Join-Path $dir ($name+'-runtime.stdout.bin'))){throw 'Unexpected runtime stream'}
  $groups+=@{packet=$packet.name;candidate=$packet.head;name=$name;count=$group.count;binary=$binary;sha256=$hash;metadata=$raw;runtime_tests_executed=0}
  $files+=@($binary,(Join-Path $dir ($name+'-selected-tests.json')),(Join-Path $dir ($name+'-metadata.stdout.bin')),(Join-Path $dir ($name+'-metadata.stderr.log')),(Join-Path $dir ($name+'-compile.stdout.bin')),(Join-Path $dir ($name+'-compile.stderr.log')))
 }
 if($packet.failed){$failedPath=Join-Path $dir ($packet.failed+'-compile.json');$failed=Json $failedPath;if($failed.status -cne 'failed' -or $failed.exit_code -eq 0){throw 'Preserved negative differs'};$files+=@($failedPath,(Join-Path $dir ($packet.failed+'-compile.stderr.log')))}
 $last=[long]0;foreach($probe in $result.admission_probes){$tick=([DateTimeOffset]$probe.utc).UtcTicks;if($probe.minimum_kib -ne 16777216 -or $probe.free_kib -lt 16777216 -or $probe.native_roots -ne 0 -or $tick -le $last){throw 'Admission differs'};$last=$tick;$admissions+=$probe}
 $packetRows+=@{packet=$packet.name;head=$packet.head;status=$result.status;postseal=$true;native_roots_after=0;driver_sha256=$before.driver_sha256};$files+=@($driver,(Join-Path $dir 'grant.json'),(Join-Path $dir 'result.json'),(Join-Path $dir 'before.json'))
}
$live=@(Get-CimInstance Win32_Process -ErrorAction Stop);if(!$live.Count){throw 'Process census unavailable'};$reuse=@()
foreach($owner in $owners){foreach($process in @($live|Where-Object ProcessId -EQ $owner.pid)){if([Math]::Abs(($process.CreationDate.ToUniversalTime()-([DateTimeOffset]$owner.created_utc).UtcDateTime).TotalMilliseconds) -lt 1){throw 'Historical owner remains'};$reuse+=@{pid=$process.ProcessId;name=$process.Name;created_utc=$process.CreationDate.ToUniversalTime().ToString('o')}}}
$native=@($live|Where-Object{$_.Name -in @('zig.exe','build.exe','test.exe') -or ($_.ExecutablePath -and $_.ExecutablePath -match '\\(?:\.zig-cache|zig-out)\\')});if($native.Count){throw 'Native process remains'}
if(([string](git -C $checkout rev-parse HEAD)).Trim() -cne $packets[-1].head -or @(git -C $checkout status --porcelain).Count){throw 'Current qualification tree differs'}
$original=Join-Path $base 'root-components-compile-20261016';$originalResult=Json (Join-Path $original 'result.json');if($originalResult.status -cne 'failed' -or !$originalResult.postseal -or $originalResult.native_roots_after -ne 0){throw 'Original negative differs'}
$files+=@((Join-Path $original 'result.json'),(Join-Path $original 'crypto-compile.json'),(Join-Path $original 'crypto-compile.stderr.log'),$PSCommandPath)
$receipt=[ordered]@{status='accepted_mixed_head_component_compilation_and_metadata_only';reviewer='models_auth_resume';reviewed_utc=[DateTimeOffset]::UtcNow.ToString('o');packets=$packetRows;groups=$groups;metadata_entries=29;runtime_tests_executed=0;source_files_per_packet=10623;compiler_files_per_packet=19546;full_seal_checks=$seals;all_drift=0;owners=$owners;historical_owners_live=0;native_roots_after=0;unrelated_pid_reuse=$reuse;admission_probes=$admissions;minimum_free_kib=($admissions.free_kib|Measure-Object -Minimum).Minimum;causal_repairs=@('c614f674: only rename state and callback locals that shadow declarations','caf73bf2: propagate nativeError into !Input then unreachable after guaranteed JS_Throw; cast nonnegative Kind enum index to usize','38a8e606: sentinel accessor name to std.mem.span slice for existing text copy');preserved_negatives=@('original3shadowing','v2classic2typeerrors','v3writer1pointer_slice');limitations=@('Mixed heads: no same-final-head rebuild of crypto/classic/iterator is established','29 metadata entries =25 named declarations plus4 overlapping imported storage entries; zero test-body executions','Full packet statuses v2/v3 remain failed; only their recorded earlier completed groups accepted','Standalone owner receipts are authority; result.compile arrays include an extra serialized empty object','No whole Main, Node, Source160, stream semantic/runtime or application qualification','No compiler/native/Node/Source job or product edit during independent audit');artifact_seals=@($files|Sort-Object -Unique|ForEach-Object{@{path=$_;sha256=(Get-FileHash -LiteralPath $_).Hash}})}
$receipt|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $output -Encoding utf8NoBOM
@{status=$receipt.status;metadata_entries=29;runtime_tests_executed=0;owners=$owners.Count;seal_checks=$seals.Count;admissions=$admissions.Count;minimum_free_kib=$receipt.minimum_free_kib;receipt=$output;sha256=(Get-FileHash -LiteralPath $output).Hash}|ConvertTo-Json -Compress
