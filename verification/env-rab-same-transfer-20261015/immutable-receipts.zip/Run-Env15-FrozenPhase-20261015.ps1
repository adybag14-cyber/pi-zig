param([Parameter(Mandatory)][ValidateSet('source','compile','runtime')][string]$Phase,[Parameter(Mandatory)][string]$Attempt)
$ErrorActionPreference='Stop'
$taskRoot=$PSScriptRoot
$taskCandidate='C:/Users/adyba/pi-zig-env-node-ownership-f232312-20261014'
$taskOriginal='C:/Users/adyba/pi-upstream-source-5ab7fe7-20261015'
$taskCompiler='C:/Users/adyba/pi-zig-toolchain-20261003/zig-x86_64-windows-0.16.0/zig.exe'
$taskNode='C:/Program Files/nodejs/node.exe'
$taskOwner=Join-Path $taskRoot 'Invoke-Env15-OwnedJob-20261015.ps1'
$taskName="env15-rab-same-$Phase-$Attempt-20261015"
$taskBase=Join-Path $taskRoot $taskName
if(Test-Path -LiteralPath "$taskBase-frozen.json"){throw 'Immutable phase name already exists'}
function Tree-Rows([string]$tree){
 @(git -C $tree ls-files --cached --others --exclude-standard|Sort-Object -Unique|ForEach-Object{$taskPath=Join-Path $tree $_;[ordered]@{path=$taskPath;sha256=(Get-FileHash -LiteralPath $taskPath).Hash}})
}
function Check-Rows($rows){@($rows|Where-Object{!(Test-Path -LiteralPath $_.path -PathType Leaf) -or (Get-FileHash -LiteralPath $_.path).Hash -cne $_.sha256})}
function Controls{
 @(Get-ChildItem Env:|Where-Object{$_.Name -match '^(PI_|ZIG_)' -or $_.Name -in @('UV_THREADPOOL_SIZE','NODE_OPTIONS','NODE_PATH')}|Sort-Object Name|ForEach-Object{[ordered]@{name=$_.Name;sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($_.Value)))}})
}
if((git -C $taskCandidate rev-parse HEAD).Trim() -cne 'f23231231a057e9a1f0c2194371b5f6039cfbb55'){throw 'Saved Env head drift'}
if((git -C $taskOriginal rev-parse HEAD).Trim() -cne '5ab7fe74c400097b386662205cd93900695b8a71'){throw 'Latest original Source head drift'}
$taskCandidateRows=Tree-Rows $taskCandidate
$taskOriginalRows=Tree-Rows $taskOriginal
$taskToolsManifest=Join-Path $taskRoot 'durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
$taskTools=@((Get-Content -LiteralPath $taskToolsManifest -Raw|ConvertFrom-Json).inputs)
if($taskTools.Count -ne 19546 -or @(Check-Rows $taskTools).Count){throw 'Complete pinned compiler drift'}
$taskNodeToolsManifest=Join-Path $taskRoot 'root-current8a-npm-tools-before.json'
$taskNodeTools=@(Get-Content -LiteralPath $taskNodeToolsManifest -Raw|ConvertFrom-Json)
if($taskNodeTools.Count -ne 1774 -or @(Check-Rows $taskNodeTools).Count){throw 'Complete pinned Node tools drift'}
$taskUv=Get-Content -LiteralPath (Join-Path $taskCandidate 'vendor/libuv/PI-UPSTREAM-PROVENANCE.json') -Raw|ConvertFrom-Json
$taskUvRows=@($taskUv.files|ForEach-Object{[ordered]@{path=(Join-Path $taskCandidate ('vendor/libuv/'+$_.path));sha256=$_.sha256}})
if($taskUvRows.Count -ne 416 -or @(Check-Rows $taskUvRows).Count){throw 'Pinned libuv drift'}
$taskReferences=@('env-node-ownership-reference-v8-builtins-arraybuffer-cc-f657bb8-20261014.txt','env-node-ownership-reference-v8-backing-store-cc-f657bb8-20261014.txt','env-node-ownership-reference-v8-platform-win32-cc-f657bb8-20261014.txt','env-node-ownership-reference-v8-manifest-20261014.json','env-node-builtin-internal-fs-promises-24-20261013.js','env-node-filehandle-pending-view-source-body-24-20261014.txt','env-node-filehandle-pending-view-source-data-24-20261014.json','env-node-filehandle-full-io-source-body-24-20261014.txt','env-node-filehandle-full-io-source-data-24-20261014.json')|ForEach-Object{$taskPath=Join-Path $taskRoot $_;[ordered]@{path=$taskPath;sha256=(Get-FileHash -LiteralPath $taskPath).Hash}}
$taskControls=@($PSCommandPath,$taskOwner,(Join-Path $taskRoot 'env-rab-same-source-capture-20261015.mjs'),$taskToolsManifest,$taskNodeToolsManifest)|ForEach-Object{[ordered]@{path=$_;sha256=(Get-FileHash -LiteralPath $_).Hash}}
$taskEnvironment=Controls
$taskGroups=[ordered]@{candidate=$taskCandidateRows;original=$taskOriginalRows;compiler=$taskTools;node_tools=$taskNodeTools;libuv=$taskUvRows;references=@($taskReferences);controls=@($taskControls);environment=$taskEnvironment}
$taskGroups|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskBase-frozen.json" -Encoding utf8NoBOM
$taskFrozenHash=(Get-FileHash -LiteralPath "$taskBase-frozen.json").Hash
[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect()
$taskFree=(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory
$taskMinimum=if($Phase -ceq 'source'){2MB}else{16MB}
$taskTimeout=if($Phase -ceq 'compile'){1320}else{300}
[ordered]@{phase=$Phase;slot=3;maximum_roots=4;free_kib=$taskFree;minimum_kib=$taskMinimum;compiler_jobs=1;node_heap_mib=256;outer_seconds=$taskTimeout;test_seconds=120;host_await_seconds=10;frozen_sha256=$taskFrozenHash;checked_utc=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath "$taskBase-admission.json" -Encoding utf8NoBOM
if($taskFree -lt $taskMinimum){throw 'Fresh resource admission refused after full prehash'}
$taskBody=Join-Path $taskCandidate 'src/extensions/fixtures/env-node-rab-same-transfer-source-24.input.txt'
$taskFailure=$null
try{
 if($Phase -ceq 'source'){
  & $taskOwner -Executable $taskNode -WorkingDirectory $taskRoot -Arguments @('--max-old-space-size=256','--expose-gc',(Join-Path $taskRoot 'env-rab-same-source-capture-20261015.mjs'),$taskBody,"$taskBase-output.json","$taskBase-proof.json") -ReceiptBase $taskBase -TimeoutSeconds $taskTimeout -EnvironmentOverrides @{UV_THREADPOOL_SIZE='1';NODE_OPTIONS='';NODE_PATH=''}
 }else{
  $taskSteps=if($Phase -ceq 'compile'){@('build-hosted-native-env-io-lease-transitions','build-hosted-native-env-filehandle-transfer-source')}else{@('test-native-env-io-lease-transitions','test-native-env-filehandle-transfer-source')}
  & $taskOwner -Executable $taskCompiler -WorkingDirectory $taskCandidate -Arguments (@('build')+$taskSteps+@('-Doptimize=Debug','-Duse-llvm=true','-Ddiagnostic-tests=true','-j1','--test-timeout','120s','--summary','all')) -ReceiptBase $taskBase -TimeoutSeconds $taskTimeout
 }
}catch{$taskFailure=$_}finally{
 $taskChecks=@()
 foreach($taskKey in @('candidate','original','compiler','node_tools','libuv','references','controls')){$taskDrift=@(Check-Rows $taskGroups[$taskKey]);$taskChecks+=[ordered]@{group=$taskKey;count=@($taskGroups[$taskKey]).Count;drift=$taskDrift.Count;first_drift=if($taskDrift.Count){$taskDrift[0].path}else{$null}}}
 $taskCandidateAfter=Tree-Rows $taskCandidate;$taskOriginalAfter=Tree-Rows $taskOriginal
 $taskCandidatePaths=@(Compare-Object @($taskCandidateRows.path) @($taskCandidateAfter.path))
 $taskOriginalPaths=@(Compare-Object @($taskOriginalRows.path) @($taskOriginalAfter.path))
 $taskEnvironmentAfter=Controls
 $taskEnvironmentDrift=@(Compare-Object @($taskEnvironment|ForEach-Object{"$($_.name):$($_.sha256)"}) @($taskEnvironmentAfter|ForEach-Object{"$($_.name):$($_.sha256)"}))
 $taskFrozenDrift=(Get-FileHash -LiteralPath "$taskBase-frozen.json").Hash -cne $taskFrozenHash
 [ordered]@{checks=$taskChecks;candidate_path_drift=$taskCandidatePaths.Count;original_path_drift=$taskOriginalPaths.Count;environment_drift=$taskEnvironmentDrift.Count;frozen_drift=$taskFrozenDrift;completed_utc=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskBase-posthash.json" -Encoding utf8NoBOM
 if(@($taskChecks|Where-Object drift).Count -or $taskCandidatePaths.Count -or $taskOriginalPaths.Count -or $taskEnvironmentDrift.Count -or $taskFrozenDrift){throw 'Full frozen input post drift'}
}
if($taskFailure){throw $taskFailure}
Write-Output "ENV15_FROZEN_PHASE_PASSED phase=$Phase candidate=$($taskCandidateRows.Count) original=$($taskOriginalRows.Count) frozen=$taskFrozenHash"
