$ErrorActionPreference='Stop'
$taskRoot=$PSScriptRoot
$taskCandidate='C:/Users/adyba/pi-zig-env-node-ownership-f232312-20261014'
$taskAuditPath=Join-Path $taskRoot 'env15-rab-same-qualified-debug-audit-20261015.json'
if(Test-Path -LiteralPath $taskAuditPath){throw 'Refuse qualification audit replay'}
$taskPhases=@('source-first','compile-first','compile-second','compile-third','runtime-first')
$taskRows=@()
foreach($taskPhase in $taskPhases){
 $taskBase=Join-Path $taskRoot "env15-rab-same-$taskPhase-20261015"
 $taskOwner=Get-Content -LiteralPath "$taskBase.process.json" -Raw|ConvertFrom-Json
 $taskPost=Get-Content -LiteralPath "$taskBase-posthash.json" -Raw|ConvertFrom-Json
 if(@($taskPost.checks|Where-Object drift).Count -or $taskPost.candidate_path_drift -or $taskPost.original_path_drift -or $taskPost.environment_drift -or $taskPost.frozen_drift){throw "Frozen post drift in $taskPhase"}
 if(!$taskOwner.owned_root_absent -or $taskOwner.owned_timeout_descendants_remaining){throw "Owner did not establish absence in $taskPhase"}
 $taskLive=Get-CimInstance Win32_Process -Filter "ProcessId = $($taskOwner.pid)"
 if($taskLive -and [Math]::Abs((([DateTimeOffset]$taskLive.CreationDate).UtcDateTime-([DateTimeOffset]$taskOwner.created_utc).UtcDateTime).Ticks) -le 10){throw "Owned root remains in $taskPhase"}
 $taskWanted=if($taskPhase -in @('compile-first','compile-second')){'failed'}else{'passed'}
 if($taskOwner.status -cne $taskWanted){throw "Unexpected terminal $taskPhase/$($taskOwner.status)"}
 $taskRows+=[ordered]@{phase=$taskPhase;status=$taskOwner.status;pid=$taskOwner.pid;created_utc=$taskOwner.created_utc;exit_code=$taskOwner.exit_code;owned_identity_absent=$true;pid_currently_reused=[bool]$taskLive;owner_sha256=(Get-FileHash -LiteralPath "$taskBase.process.json").Hash;post_sha256=(Get-FileHash -LiteralPath "$taskBase-posthash.json").Hash;frozen_sha256=(Get-FileHash -LiteralPath "$taskBase-frozen.json").Hash;post_checks=$taskPost.checks}
}
$taskCompile=$taskRows|Where-Object phase -CEQ 'compile-third'
$taskRuntime=$taskRows|Where-Object phase -CEQ 'runtime-first'
if($taskCompile.frozen_sha256 -cne $taskRuntime.frozen_sha256){throw 'Successful compile/runtime inputs differ'}
$taskLog=Get-Content -LiteralPath (Join-Path $taskRoot 'env15-rab-same-runtime-first-20261015.stderr.log') -Raw
$taskLeaseMatch=[regex]::Match($taskLog,'ENV_IO_LEASE_TRANSITION_TEST_INVENTORY=(\[[^\r\n]+\])')
$taskSourceMatch=[regex]::Match($taskLog,'ENV_FILE_HANDLE_TRANSFER_SOURCE_TEST_INVENTORY=(\[[^\r\n]+\])')
if(!$taskLeaseMatch.Success -or !$taskSourceMatch.Success){throw 'Actual compiled inventories missing'}
$taskLeaseInventory=@($taskLeaseMatch.Groups[1].Value|ConvertFrom-Json)
$taskSourceInventory=@($taskSourceMatch.Groups[1].Value|ConvertFrom-Json)
if($taskLeaseInventory.Count -ne 6 -or $taskSourceInventory.Count -ne 3 -or $taskLog -notmatch 'All 6 tests passed\.' -or $taskLog -notmatch 'All 3 tests passed\.' -or $taskLog -notmatch 'Build Summary: 235/235 steps succeeded' -or $taskLog -match '(?im)\b(SKIP|FAIL|panic|leaked)\b'){throw 'Actual runtime acceptance mismatch'}
$taskProof=Get-Content -LiteralPath (Join-Path $taskRoot 'env15-rab-same-source-first-20261015-proof.json') -Raw|ConvertFrom-Json
$taskInput=Join-Path $taskCandidate 'src/extensions/fixtures/env-node-rab-same-transfer-source-24.input.txt'
$taskExpected=Join-Path $taskCandidate 'src/extensions/fixtures/env-node-rab-same-transfer-source-24.json'
$taskSourceOutput=Join-Path $taskRoot 'env15-rab-same-source-first-20261015-output.json'
if($taskProof.node -cne '24.14.0' -or $taskProof.platform -cne 'win32' -or $taskProof.fields.Count -ne 2 -or $taskProof.blockers -ne 2 -or !$taskProof.real_gc -or $taskProof.pool_size -cne '1' -or $taskProof.input_sha256 -cne (Get-FileHash -LiteralPath $taskInput).Hash -or $taskProof.output_sha256 -cne (Get-FileHash -LiteralPath $taskExpected).Hash -or $taskProof.output_sha256 -cne (Get-FileHash -LiteralPath $taskSourceOutput).Hash){throw 'Genuine source/candidate expected identity mismatch'}
$taskFrozen=Get-Content -LiteralPath (Join-Path $taskRoot 'env15-rab-same-runtime-first-20261015-frozen.json') -Raw|ConvertFrom-Json
$taskCurrentDrift=@($taskFrozen.candidate|Where-Object{!(Test-Path -LiteralPath $_.path) -or (Get-FileHash -LiteralPath $_.path).Hash -cne $_.sha256})
if($taskCurrentDrift.Count){throw 'Successful candidate drifted before handoff'}
$taskLeafNames=@('vendor/quickjs/pi-io-lease.inc','src/extensions/native_env_io_lease.zig','src/native_env_io_lease_transition_test.zig','src/native_env_filehandle_transfer_source_test.zig','src/extensions/fixtures/env-node-rab-same-transfer-source-24.input.txt','src/extensions/fixtures/env-node-rab-same-transfer-source-24.json','build.zig')
$taskLeaves=@($taskLeafNames|ForEach-Object{$taskPath=Join-Path $taskCandidate $_;[ordered]@{path=$taskPath;sha256=(Get-FileHash -LiteralPath $taskPath).Hash}})
[ordered]@{status='selected_private_debug_qualified';candidate_head='f23231231a057e9a1f0c2194371b5f6039cfbb55';candidate_files=$taskFrozen.candidate.Count;candidate_current_drift=0;latest_source_head='5ab7fe74c400097b386662205cd93900695b8a71';successful_compile_runtime_frozen_sha256=$taskRuntime.frozen_sha256;phases=$taskRows;lease_actual_inventory=$taskLeaseInventory;source_actual_inventory=$taskSourceInventory;compiled_tests_passed=9;selected_tests_passed=7;imported_discovery_tests_passed=2;skipped=0;source_packet_sha256=$taskProof.output_sha256;source_input_sha256=$taskProof.input_sha256;leaves=$taskLeaves;public_activation=$false;full_env_qualified=$false;full_filehandle_qualified=$false;releasesafe_qualified=$false;posix_qualified=$false;allocation_sweep_qualified=$false;completed_utc=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $taskAuditPath -Encoding utf8NoBOM
Write-Output "ENV15_SELECTED_PRIVATE_DEBUG_QUALIFIED tests=9 selected=7 skipped=0 candidate=$($taskFrozen.candidate.Count) source_packet=$($taskProof.output_sha256)"
