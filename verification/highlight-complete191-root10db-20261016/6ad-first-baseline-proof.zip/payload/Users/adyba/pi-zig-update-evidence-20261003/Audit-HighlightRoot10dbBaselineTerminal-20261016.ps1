param([Parameter(Mandatory)][string]$Target,[Parameter(Mandatory)][ValidateSet('compile','runtime')][string]$Phase)
$ErrorActionPreference='Stop'
$head='6ad290967f74ad471600d25a3f7da3f30fe12bc3'
$e='C:/Users/adyba/pi-zig-update-evidence-20261003'
$prefix=Join-Path $e "highlight-root10db-$Target-$Phase-first-20261016"
$compile=Join-Path $e "highlight-root10db-$Target-compile-first-20261016"
$owner=Get-Content -LiteralPath "$prefix.process.json" -Raw|ConvertFrom-Json
$probe=Get-Content -LiteralPath "$compile-metadata-probe.json" -Raw|ConvertFrom-Json
$meta=Get-Content -LiteralPath "$compile-metadata.json" -Raw|ConvertFrom-Json
$post=Get-Content -LiteralPath "$prefix-posthash.json" -Raw|ConvertFrom-Json
$artifacts=@(Get-Content -LiteralPath "$compile-artifacts.json" -Raw|ConvertFrom-Json)
$artifactDrift=@($artifacts|Where-Object {!(Test-Path -LiteralPath $_.path -PathType Leaf) -or (Get-FileHash -LiteralPath $_.path).Hash -cne $_.sha256})
$live=@(foreach($owned in @($owner,$probe)){Get-CimInstance Win32_Process -Filter "ProcessId=$($owned.pid)"|Select-Object ProcessId,ParentProcessId,ExecutablePath,CommandLine,CreationDate})
$native=@(Get-CimInstance Win32_Process -Filter "Name='zig.exe' OR Name='build.exe' OR Name='test.exe'"|Select-Object ProcessId,ParentProcessId,ExecutablePath,CommandLine,CreationDate)
$summary=$null
if($Phase -ceq 'runtime'){
 $matches=[regex]::Matches([IO.File]::ReadAllText("$prefix.stderr.log"),'Build Summary:[^\r\n]*; (\d+)/(\d+) tests passed')
 if(!$matches.Count){throw 'Actual runtime summary absent'}
 $summary=@{passed=[int]$matches[-1].Groups[1].Value;total=[int]$matches[-1].Groups[2].Value}
 if($summary.passed -ne $meta.count -or $summary.total -ne $meta.count){throw 'Actual complete metadata/runtime total mismatch'}
}
$record=@{head=$post.head;target=$Target;phase=$Phase;owner=$owner;metadata_probe=$probe;metadata_count=$meta.count;tests=$meta.tests;runtime=$summary;binary=$meta.binary;binary_sha256=$meta.binary_sha256;candidate_before=$post.candidate_before;candidate_after=$post.candidate_after;candidate_drift=$post.candidate_drift.Count;manifests=@($post.manifests|ForEach-Object {@{name=$_.name;count=$_.count;drift=$_.drift.Count}});inventories=@($post.inventories|ForEach-Object {@{name=$_.name;count=$_.count;drift=$_.drift.Count}});control_drift=$post.control_drift.Count;absence_drift=$post.absence_drift.Count;artifact_drift=$artifactDrift;owned_live=$live;native_live=$native;observed_utc=[DateTimeOffset]::UtcNow.ToString('o')}
$record|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$prefix-independent-terminal.json" -Encoding utf8NoBOM
if($owner.status -cne 'passed' -or $null -eq $owner.exit_code -or $owner.exit_code -ne 0 -or $probe.status -cne 'passed' -or $null -eq $probe.exit_code -or $probe.exit_code -ne 0 -or $post.head -cne $head -or $meta.candidate -cne $head -or $post.candidate_drift.Count -or @($post.manifests|Where-Object {$_.drift.Count}).Count -or @($post.inventories|Where-Object {$_.drift.Count}).Count -or $post.control_drift.Count -or $post.absence_drift.Count -or $artifactDrift.Count -or $live.Count -or $native.Count){throw 'Independent terminal/fullpost/artifact/absence audit negative'}
@{head=$head;target=$Target;phase=$Phase;status='passed';exit_code=$owner.exit_code;owner_pid=$owner.pid;metadata_pid=$probe.pid;metadata_count=$meta.count;runtime=$summary;binary_sha256=$meta.binary_sha256;fullpost_drift=0;artifact_drift=0;owned_live=0;native_live=0}|ConvertTo-Json -Depth 4
