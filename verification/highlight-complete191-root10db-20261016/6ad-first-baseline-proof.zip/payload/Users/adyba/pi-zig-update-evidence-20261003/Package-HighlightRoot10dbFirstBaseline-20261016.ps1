$ErrorActionPreference='Stop'
$tree='C:/Users/adyba/pi-zig-highlight-complete191-root10db-20261016'
$e='C:/Users/adyba/pi-zig-update-evidence-20261003'
$destination=Join-Path $tree 'verification/highlight-complete191-root10db-20261016'
$zipPath=Join-Path $destination '6ad-first-baseline-proof.zip'
$manifestPath=Join-Path $destination '6ad-first-baseline-proof-manifest.json'
if((Test-Path -LiteralPath $zipPath) -or (Test-Path -LiteralPath $manifestPath)){throw 'Preserve existing proof packet; refusing overwrite'}
$paths=@(Get-ChildItem -LiteralPath $e -Filter 'highlight-root10db-*-first-20261016*' -File|ForEach-Object FullName)
foreach($control in @(Get-ChildItem -LiteralPath $e -Filter 'highlight-root10db-*-first-20261016-controls.json' -File)){
 $paths+=@((Get-Content -LiteralPath $control.FullName -Raw|ConvertFrom-Json).path)
}
$paths+=@((Get-Content -LiteralPath (Join-Path $e 'highlight-root10db-foundation-compile-first-20261016-artifacts.json') -Raw|ConvertFrom-Json).path)
$paths+=@((Get-ChildItem -LiteralPath (Join-Path $tree 'src/extensions/fixtures') -Filter 'sdk-highlight-complete191-10_7_3.*' -File).FullName)
$paths+=@((Join-Path $tree 'vendor/quickjs/quickjs.c'),(Join-Path $tree 'vendor/quickjs/quickjs.h'),(Join-Path $e 'Audit-HighlightRoot10dbBaselineTerminal-20261016.ps1'),$PSCommandPath,(Join-Path $e 'highlight-root10db-6ad29096-public-readback-20261016.json'))
$paths=@($paths|ForEach-Object {[IO.Path]::GetFullPath($_)}|Sort-Object -Unique)
$rows=@(foreach($path in $paths){
 if(!(Test-Path -LiteralPath $path -PathType Leaf)){throw "Missing retained authority: $path"}
 @{path=$path;entry=('payload/'+$path.Substring(3).Replace('\','/'));sha256=(Get-FileHash -LiteralPath $path).Hash;bytes=(Get-Item -LiteralPath $path).Length}
})
$manifest=@{tested_head='6ad290967f74ad471600d25a3f7da3f30fe12bc3';foundation_runtime='passed6/6';async26_compile='failed_exit1_inherited_inline_for_runtime_continue';async26_metadata_started=$false;async26_runtime_started=$false;later_gates_started=$false;successor_native_qualified=$false;all_original_bytes_preserved=$true;payload_count=$rows.Count;payloads=$rows}
$manifest|ConvertTo-Json -Depth 7|Set-Content -LiteralPath $manifestPath -Encoding utf8NoBOM
$archive=[IO.Compression.ZipFile]::Open($zipPath,[IO.Compression.ZipArchiveMode]::Create)
try{
 foreach($row in $rows){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$row.path,$row.entry,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
 [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$manifestPath,'manifest.json',[IO.Compression.CompressionLevel]::Optimal)|Out-Null
}finally{$archive.Dispose()}
$checked=0
$archive=[IO.Compression.ZipFile]::OpenRead($zipPath)
try{
 foreach($row in $rows){$entry=$archive.GetEntry($row.entry);if($null -eq $entry -or $entry.Length -ne $row.bytes){throw 'Archived payload absent/size mismatch'};$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()};if($hash -cne $row.sha256){throw 'Archived payload byte mismatch'};$checked++}
}finally{$archive.Dispose()}
@{archive=$zipPath;archive_sha256=(Get-FileHash -LiteralPath $zipPath).Hash;archive_bytes=(Get-Item -LiteralPath $zipPath).Length;manifest_sha256=(Get-FileHash -LiteralPath $manifestPath).Hash;payloads=$rows.Count;verified_payloads=$checked}|ConvertTo-Json -Depth 4
