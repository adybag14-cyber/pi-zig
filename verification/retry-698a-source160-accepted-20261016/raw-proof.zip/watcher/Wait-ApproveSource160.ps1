param([Parameter(Mandatory)][string]$RunId,[Parameter(Mandatory)][string]$CandidateHead,[Parameter(Mandatory)][string]$RootGrant)
$ErrorActionPreference='Stop'
$taskContainer='C:\Users\adyba\pi-zig'
$taskRun=Join-Path $taskContainer ('evidence\retry698a-runtime-free-captures\'+$RunId)
if($RunId -cnotmatch '^[A-Za-z0-9-]{1,70}$' -or $CandidateHead -cnotmatch '^[0-9a-f]{40}$'){throw 'Exact Root run/head required'}
$taskGrant=Get-Content -LiteralPath $RootGrant -Raw|ConvertFrom-Json
if(!$taskGrant.authorized -or $taskGrant.scope -cne 'runtime-free-source160-only' -or $taskGrant.run_id -cne $RunId -or $taskGrant.candidate_head -cne $CandidateHead){throw 'Root conditional approval grant differs'}
$taskSelf=Get-CimInstance Win32_Process -Filter "ProcessId=$PID"
if(!$taskSelf -or !$taskSelf.CommandLine -or !$taskSelf.ExecutablePath){throw 'Approver self identity unavailable'}
$taskLedger=Join-Path $PSScriptRoot ($RunId+'-approver.json')
if(Test-Path -LiteralPath $taskLedger){throw 'Approver replay refused'}
[ordered]@{pid=$PID;parent_pid=$taskSelf.ParentProcessId;executable=$taskSelf.ExecutablePath;command_line=$taskSelf.CommandLine;created_utc=$taskSelf.CreationDate.ToUniversalTime().ToString('o');status='waiting';run_id=$RunId;candidate_head=$CandidateHead}|ConvertTo-Json -Depth 4|Set-Content -LiteralPath $taskLedger -Encoding utf8NoBOM
$taskClock=[Diagnostics.Stopwatch]::StartNew()
$taskRequestPath=Join-Path $taskRun 'admission\source160.request.json'
while(!(Test-Path -LiteralPath $taskRequestPath)){
 if($taskClock.Elapsed.TotalSeconds -ge 60){throw 'Root conditional approval watcher expired without request'}
 if(Test-Path -LiteralPath (Join-Path $taskRun 'pause.flag')){throw 'Root capture paused'}
 Start-Sleep -Milliseconds 200
}
$taskRequest=Get-Content -LiteralPath $taskRequestPath -Raw|ConvertFrom-Json
$taskAll=@(Get-CimInstance Win32_Process -ErrorAction Stop)
if(!$taskAll.Count){throw 'Native census unavailable'}
$taskNative=@($taskAll|Where-Object{$_.Name -in @('zig.exe','build.exe','test.exe') -or ($_.ExecutablePath -and $_.ExecutablePath -match '\\(?:\.zig-cache|zig-out)\\')})
$taskFree=(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory
$taskNow=[DateTimeOffset]::UtcNow
if($taskClock.Elapsed.TotalSeconds -ge 60){throw 'Root approval watcher deadline expired before admission'}
if($taskRequest.kind -cne 'source160' -or $taskRequest.run_id -cne $RunId -or $taskRequest.candidate_head -cne $CandidateHead -or $taskRequest.nonce -cnotmatch '^[a-f0-9]{32}$' -or ([DateTimeOffset]$taskRequest.issued_utc) -lt ([DateTimeOffset]$taskGrant.issued_utc) -or ([DateTimeOffset]$taskRequest.issued_utc) -gt $taskNow -or $taskNow -ge ([DateTimeOffset]$taskRequest.expires_utc) -or $taskNow -ge ([DateTimeOffset]$taskGrant.expires_utc) -or $taskFree -lt 16777216 -or $taskNative.Count){throw 'Root fresh exact approval conditions failed'}
if(Test-Path -LiteralPath (Join-Path $taskRun 'pause.flag')){throw 'Root capture paused'}
$taskApproval=[ordered]@{kind='source160';run_id=$RunId;candidate_head=$CandidateHead;nonce=$taskRequest.nonce;approved=$true;manual_fresh_16gib=$true;issued_utc=$taskNow.ToString('o');expires_utc=$taskRequest.expires_utc;free_kib=$taskFree;native_roots=0;root_conditional_watcher_sha256=(Get-FileHash -LiteralPath $PSCommandPath).Hash}
$taskApprovalPath=Join-Path $taskRun 'admission\source160.approval.json'
$taskBytes=[Text.Encoding]::UTF8.GetBytes(($taskApproval|ConvertTo-Json -Depth 4))
$taskStream=[IO.File]::Open($taskApprovalPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
try{$taskStream.Write($taskBytes,0,$taskBytes.Length);$taskStream.Flush($true)}finally{$taskStream.Dispose()}
[ordered]@{status='approved';pid=$PID;created_utc=$taskSelf.CreationDate.ToUniversalTime().ToString('o');approval_sha256=(Get-FileHash -LiteralPath $taskApprovalPath).Hash;completed_utc=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $PSScriptRoot ($RunId+'-approver-terminal.json')) -Encoding utf8NoBOM
$taskApproval|ConvertTo-Json -Depth 4
