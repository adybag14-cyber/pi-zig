$ErrorActionPreference='Stop'
$container='C:\Users\adyba\pi-zig'
$build=Join-Path $container 'evidence/root-typebox-product4-buildquery-20261017-181950'
$runtime=Join-Path $container 'evidence/root-typebox-product4-runtime-20261017-182754'
$candidate=Join-Path $container 'worktrees/root-typebox-heap-qualification'
$head='fdf6f25e4ef61321abaa4b9884eeb1cf97be6d18'
$exe='CE0572A0D774533F3187972E51EAA0500C3AD2428E93A5DE1E71C3DF43A21A06'
$pdb='94B50DE6101A9E10FB82D7965C48BB03317E0BCFD5F86271D25E5C0ED9E80935'
function Read([string]$path){Get-Content -Raw -LiteralPath $path|ConvertFrom-Json -DateKind String}
function Need([bool]$condition,[string]$message){if(!$condition){throw $message}}
function Sha([string]$path){$stream=[IO.File]::OpenRead($path);try{[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()}}
function Pin([string]$path){[ordered]@{path=$path;bytes=(Get-Item -LiteralPath $path).Length;sha256=(Sha $path)}}
function EqualArray($left,$right,[string]$where){$count=@($left).Count;Need ($count-eq@($right).Count) "count $where";for($i=0;$i-lt$count;$i++){if([string]$left[$i]-cne[string]$right[$i]){throw "array $where index$i"}}}
function Canon($rows){$strings=[string[]]@($rows|ForEach-Object{$_.relative+' '+$_.sha256});[Array]::Sort($strings,[StringComparer]::Ordinal);return ,$strings}
$baseBuild=Read (Join-Path $build 'before.json');$baseRuntime=Read (Join-Path $runtime 'before.json')
$sealChecks=@();$groups=@('source','tree','vendor','compiler','controls')
foreach($item in @(@{root=$build;base=$baseBuild;files=@('before.json','compile-before.json','compile-after.json','metadata-before.json','metadata-after.json','final.json');controls=16},@{root=$runtime;base=$baseRuntime;files=@('before.json','runtime-before.json','runtime-after.json','final.json');controls=19})){
 foreach($name in $item.files){
  $path=Join-Path $item.root $name;$seal=Read $path
  Need ($seal.candidate_head-ceq$head-and$seal.clean-eq$true-and@($seal.errors).Count-eq0) "seal state $path"
  Need (@($seal.source).Count-eq11698-and@($seal.tree).Count-eq11698-and@($seal.vendor).Count-eq1339-and@($seal.compiler).Count-eq19546-and@($seal.controls).Count-eq$item.controls) "seal counts $path"
  foreach($group in $groups){EqualArray (Canon $item.base.$group) (Canon $seal.$group) "$name/$group"}
  $sealChecks+=Pin $path
  Write-Output "Compared full seal $path"
 }
}
foreach($group in @('source','tree','vendor','compiler')){EqualArray (Canon $baseBuild.$group) (Canon $baseRuntime.$group) "BuildQuery/RuntimeOnly $group"}
Write-Output 'All ten complete source/tree/vendor/compiler/control seals agree within phase; shared source/tool sets agree across modes.'
$authorityPath=Join-Path $container 'evidence/durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
Need ((Sha $authorityPath)-ceq'DEE259F171F720AB2C08E8DD473975E22C876417CD62E4F016C71A7C662794EB') 'compiler authority'
$authority=Read $authorityPath;$authorityRows=@($authority.inputs|ForEach-Object{$relative=$_.path.Substring($authority.root.Length).TrimStart('\','/').Replace('\','/');[pscustomobject]@{relative=$relative;sha256=$_.sha256}})
EqualArray (Canon $authorityRows) (Canon $baseBuild.compiler) 'original compiler19546 authority after declared relocation'
Need ((& git -C $candidate rev-parse HEAD).Trim()-ceq$head) 'current exact head'
Need ([string]::IsNullOrWhiteSpace((& git -C $candidate status --porcelain|Out-String))) 'current clean checkout'
$tracked=@(& git -C $candidate ls-files);Need ($LASTEXITCODE-eq0-and$tracked.Count-eq11698) 'tracked count'
EqualArray ([string[]]($tracked|Sort-Object -CaseSensitive)) ([string[]]($baseBuild.source.relative|Sort-Object -CaseSensitive)) 'complete tracked membership'
$current=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach($rows in @($baseBuild.source,$baseBuild.compiler,$baseBuild.controls,$baseRuntime.controls)){
 foreach($row in $rows){if($current.ContainsKey($row.path)){Need ($current[$row.path]-ceq$row.sha256) "cross-group same-path hash $($row.path)"}else{$current.Add($row.path,$row.sha256)}}
}
$hashed=0;foreach($entry in $current.GetEnumerator()){Need ((Sha $entry.Key)-ceq$entry.Value) "current immutable byte mismatch $($entry.Key)";$hashed++;if($hashed%5000-eq0){Write-Output "Rehashed $hashed/$($current.Count) unique current source/tool/control files."}}
$intakePath=Join-Path $container 'evidence/typebox-heap-root-fdf6-qualification-prepared-20261017/actual-intake-fdf6.json'
Need ((Sha $intakePath)-ceq'DCB8DE188D677AB8CBAC5A2062D1A65B07912349CD6921ADD339B55260B85257') 'actual intake pin'
$intake=Read $intakePath;Need ($intake.candidate_head-ceq$head-and$intake.candidate_root-ceq$candidate-and$intake.selected_callbacks-eq34-and@($intake.source_files).Count-eq13-and$intake.runtime_restoration_claim-eq$false) 'intake scope'
$joins=@();foreach($row in $intake.source_files){$path=Join-Path $candidate $row.path;Need ((Sha $path)-ceq$row.sha256-and(Get-Item -LiteralPath $path).Length-eq$row.bytes) "intake bytes $($row.path)";Need ((& git -C $candidate rev-parse "$($head):$($row.path)").Trim()-ceq$row.git_blob_sha1) "intake Git blob $($row.path)";Need ($row.sha256-ceq$row.git_blob_payload_sha256) 'qualified checkout/blob byte equality';$joins+=$row}
$acceptance=Read $intake.generated_acceptance_path;Need ((Sha $intake.generated_acceptance_path)-ceq$intake.generated_acceptance_sha256-and$acceptance.selected_callbacks-eq34-and$acceptance.original_metadata_drift-eq0-and$acceptance.generated_native_sha256-ceq'22388C87878FB42B5AEE58C87FBCF1955D985922EBCB2D040698F2A502D1E08D') 'actual generated34 output binding'
$testPath=Join-Path $candidate 'src/native_typebox_compile_production_test.zig';Need ((Sha $testPath)-ceq'194F848EEF6FBB27D4AE5A9E17015EAA1893A5930929AE0AF1856EBE108E128F') 'unchanged genuine replay194F'
$engineText=[IO.File]::ReadAllText((Join-Path $candidate 'src/extensions/engine.zig'));$testText=[IO.File]::ReadAllText($testPath)
Need ($engineText-match'stack_limit:\s*usize\s*=\s*1024\s*\*\s*1024'-and$testText-notmatch'\.stack_limit\s*='-and[regex]::Matches($testText,'\.host_await_timeout_ms\s*=\s*10000').Count-eq3) 'unchanged source guard and three10second awaits'
$fixtureRows=@();foreach($relative in @('src/extensions/fixtures/typebox-compile-production.json','src/extensions/fixtures/ai-model-schemas-partial-4954.json','src/extensions/fixtures/typebox-operators-production.expected.json')){$value=Read (Join-Path $candidate $relative);$fixtureRows+=[ordered]@{path=$relative;rows=@($value.rows).Count;sha256=(Sha (Join-Path $candidate $relative))}}
EqualArray @($fixtureRows.rows) @(80,52,396) 'complete unchanged Source fixture row counts'
function Frames([string]$path){
 $bytes=[IO.File]::ReadAllBytes($path);$offset=0;$frames=@()
 while($offset-lt$bytes.Length){Need ($bytes.Length-$offset-ge8) 'raw truncated header';$tag=[BitConverter]::ToUInt32($bytes,$offset);$length=[BitConverter]::ToUInt32($bytes,$offset+4);$offset+=8;Need ($length-le1MB-and$length-le$bytes.Length-$offset) 'raw body length';$payload=[byte[]]::new($length);[Array]::Copy($bytes,$offset,$payload,0,$length);$frames+=,[pscustomobject]@{tag=$tag;length=$length;payload=$payload};$offset+=$length};return ,$frames
}
$metadata=Frames (Join-Path $build 'metadata.stdout.bin');EqualArray @($metadata.tag) @(0,3) 'metadata-only tags';Need ([Text.Encoding]::UTF8.GetString($metadata[0].payload)-ceq'0.16.0') 'metadata version'
$body=$metadata[1].payload;$strings=[BitConverter]::ToUInt32($body,0);$count=[BitConverter]::ToUInt32($body,4);Need ($count-eq4-and$body.Length-eq8+8*$count+$strings) 'actual metadata4'
$names=@();for($i=0;$i-lt4;$i++){$index=[BitConverter]::ToUInt32($body,8+4*$i);$panic=[BitConverter]::ToUInt32($body,8+4*$count+4*$i);Need ($panic-eq0-and$index-lt$strings) 'metadata offset/panic';$end=$index;while($end-lt$strings-and$body[8+8*$count+$end]-ne0){$end++};Need ($end-lt$strings) 'metadata NUL';$names+=[Text.Encoding]::UTF8.GetString($body,8+8*$count+$index,$end-$index)}
$selected=Read (Join-Path $build 'selected-tests.json');$commandsBuild=Read (Join-Path $build 'commands.json');$commandsRun=Read (Join-Path $runtime 'commands.json');EqualArray $names @($selected.tests) 'raw metadata/selected';EqualArray $names @($commandsBuild.expected_names) 'raw metadata/planned';EqualArray $names @($commandsRun.expected_names) 'runtime names';Need ($selected.binary_sha256-ceq$exe) 'selected binary hash'
$raw=Frames (Join-Path $runtime 'runtime.stdout.bin');EqualArray @($raw.tag) @(0,5,4,5,4,5,4,5,4) 'exact four runtime starts/results';Need ([Text.Encoding]::UTF8.GetString($raw[0].payload)-ceq'0.16.0') 'runtime version'
$rawResults=@();for($i=0;$i-lt4;$i++){$start=$raw[1+2*$i];$frame=$raw[2+2*$i];Need ($start.length-eq0-and$frame.length-eq12) 'start/result length';$index=[BitConverter]::ToUInt32($frame.payload,0);$flags=[BitConverter]::ToUInt64($frame.payload,4);Need ($index-eq$i-and$flags-eq0) 'raw ordered flags';$rawResults+=[ordered]@{index=$index;flags=$flags;name=$names[$index]}}
$summary=Read (Join-Path $runtime 'runtime.results.json');Need ($summary.expected-eq4-and$summary.started-eq4-and$summary.completed-eq4-and$summary.status-ceq'passed'-and$summary.failed_or_skipped_or_logged_or_leaked-eq0-and$summary.binary_sha256-ceq$exe) 'canonical result binding'
$stderr=[IO.File]::ReadAllText((Join-Path $runtime 'runtime.stderr.log'));$lines=@($stderr-split'\r?\n'|Where-Object{$_-cne''});Need ($lines.Count-eq3) 'only three allowed parity stderr markers';EqualArray $lines @('TYPEBOX_COMPILE_SOURCE_PARITY cases=80 actual_shared_graph=true native_ir=true full_HOST_GPA=false C_malloc_exhaustive=false','TYPEBOX_PROVIDER_SCHEMA_SOURCE_PARITY cases=52 actual_shared_graph=true full_HOST_GPA=false C_malloc_exhaustive=false','TYPEBOX_OPERATOR_SOURCE_PARITY cases=396 actual_shared_graph=true full_HOST_GPA=false C_malloc_exhaustive=false') 'exact honest parity stderr'
Need ((Get-Item -LiteralPath (Join-Path $build 'metadata.stderr.log')).Length-eq0-and(Get-Item -LiteralPath (Join-Path $build 'compile.stdout.bin')).Length-eq0) 'metadata/compile empty streams'
$compileText=[IO.File]::ReadAllText((Join-Path $build 'compile.stderr.log'));Need ($compileText.Contains('Build Summary: 156/156 steps succeeded')-and$compileText-notmatch'(?m)^.*error:') 'actual compile summary'
$artifacts=Read (Join-Path $build 'build-artifacts.json');Need (@($artifacts.installed).Count-eq2-and@($artifacts.cached_executables).Count-eq1-and@($artifacts.errors).Count-eq0) 'artifact roles'
foreach($row in $artifacts.installed){Need ((Sha $row.path)-ceq$row.sha256-and(Get-Item -LiteralPath $row.path).Length-eq$row.bytes) 'installed artifact bytes'}
Need ($artifacts.installed[0].sha256-ceq$exe-and$artifacts.installed[1].sha256-ceq$pdb-and$artifacts.cached_executables[0].sha256-ceq$exe-and(Sha $artifacts.cached_executables[0].path)-ceq$exe) 'EXE/PDB/cache identities'
Need ($artifacts.pe.reserved_stack_bytes-eq16777216-and$artifacts.pe.Engine_guard_bytes-eq1048576-and$artifacts.pe.dynamic_stack_measured-eq$false) 'recorded stack/guard scope'
$artifactChecks=@();foreach($item in @(@{root=$build;files=@('build-artifacts.json','compile-after-artifacts.json','metadata-before-artifacts.json','metadata-after-artifacts.json','final-artifacts.json')},@{root=$runtime;files=@('runtime-prerequisite-artifacts.json','runtime-before-artifacts.json','runtime-after-artifacts.json','final-artifacts.json')})){foreach($name in $item.files){$path=Join-Path $item.root $name;Need ((Sha $path)-ceq(Sha (Join-Path $build 'build-artifacts.json'))) "artifact ledger drift $path";$artifactChecks+=Pin $path}}
$ownerChecks=@();$resultChecks=@();$grantChecks=@()
foreach($item in @(@{root=$build;prefix='root-typebox-product4-buildquery-20261017-181950';mode='BuildQuery';status='passed_build_query';phases=@('compile','metadata');outer_seconds=1800},@{root=$runtime;prefix='root-typebox-product4-runtime-20261017-182754';mode='RuntimeOnly';status='passed_typebox_product4';phases=@('runtime');outer_seconds=600})){
 $result=Read (Join-Path $item.root 'result.json');Need ($result.status-ceq$item.status-and$result.mode-ceq$item.mode-and$result.candidate_head-ceq$head-and$result.postseal-eq$true-and@($result.errors).Count-eq0-and@($result.absence.native_roots).Count-eq0) 'result closure'
 $grantPath=Join-Path $container ('evidence/'+$item.prefix+'-grant.json');$grant=Read $grantPath;$outerPath=Join-Path $container ('evidence/'+$item.prefix+'-outer.json');$outer=Read $outerPath;$absent=Read (Join-Path $container ('evidence/'+$item.prefix+'-outer-absence.json'))
 Need ($grant.execution_authorized-eq$true-and$grant.mode-ceq$item.mode-and$grant.candidate_head-ceq$head-and$grant.candidate_root-ceq$candidate-and$grant.minimum_free_kib-eq16777216-and$grant.initial_grant_max_age_seconds-eq300-and$grant.owner_settle_seconds-eq10-and$grant.outer_controller_seconds-eq$item.outer_seconds-and$grant.reuse_unsealed_original_compile_caches-eq$false-and$grant.runtime_restoration_claim-eq$false) 'actual fresh grant scope'
 Need ($outer.status-ceq'passed'-and$outer.exit_code-eq0-and$outer.timeout_seconds-eq$item.outer_seconds-and$outer.retained_handle-gt0-and$outer.executable_sha256-ceq'BFB46AF89433268872DDB43D1CA7A3F433452EE91ED356A9786940F90118E285') 'outer owner'
 Need ($outer.pid-eq$outer.live_identity.pid-and$outer.created_utc-ceq$outer.live_identity.created_utc-and$outer.executable-ceq$outer.live_identity.executable-and$outer.live_identity.command_line) 'outer live identity'
 Need ($absent.pid-eq$outer.pid-and!$absent.fresh_pid_present-and$absent.terminal.created_utc-ceq$outer.created_utc-and$absent.terminal.exit_code-eq0) 'outer saved absence'
 $outerElapsed=([DateTimeOffset]$outer.completed_utc-[DateTimeOffset]$outer.created_utc).TotalSeconds;Need ($outerElapsed-ge0-and$outerElapsed-le$item.outer_seconds) 'outer actual deadline'
 EqualArray @($outer.arguments) @('-NoLogo','-NoProfile','-NonInteractive','-File',(Join-Path $container 'evidence/typebox-heap-execution-prepared-20261017/Run-HeapProduct4V7Fdf6.ps1'),'-RootGrant',$grantPath,'-Mode',$item.mode) 'outer exact argv'
 Need ((Get-Item -LiteralPath ($outerPath.Replace('.json','.stderr.log'))).Length-eq0) 'outer empty stderr'
 Need ((Sha (Join-Path $item.root 'result.json'))-ceq(Sha ($outerPath.Replace('.json','.stdout.bin')))) 'outer verbatim result stdout'
 $first=$null
 foreach($phase in $item.phases){
  $owner=Read (Join-Path $item.root ($phase+'.json'));$deadline=@{compile=1320;metadata=30;runtime=120}[$phase]
  Need ($owner.status-ceq'passed'-and$owner.exit_code-eq0-and$owner.timeout_seconds-eq$deadline-and$owner.retained_handle-gt0-and$owner.working_directory-ceq$candidate-and$owner.pid-eq$owner.live_identity.pid-and$owner.created_utc-ceq$owner.live_identity.created_utc-and$owner.executable-ceq$owner.live_identity.executable-and$owner.live_identity.command_line) "phase owner $phase"
  $ownerElapsed=([DateTimeOffset]$owner.completed_utc-[DateTimeOffset]$owner.created_utc).TotalSeconds;Need ($ownerElapsed-ge0-and$ownerElapsed-le$deadline) "phase deadline $phase"
  $expectedExe=if($phase-eq'compile'){'086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864'}else{$exe};Need ($owner.executable_sha256-ceq$expectedExe) 'phase executable'
  $expectedArgs=if($phase-eq'compile'){$commandsBuild.compile}else{@('--listen=-')};EqualArray @($owner.arguments) @($expectedArgs) "phase exact argv $phase"
  $evidence=Read (Join-Path $item.root ($phase+'-absence.json'));Need ($evidence.status-ceq'closed'-and$evidence.evidence.valid-eq$true-and$evidence.evidence.owner.pid-eq$owner.pid-and$evidence.evidence.owner.created_utc-ceq$owner.created_utc-and$evidence.evidence.current_owner_pid_present-eq0-and@($evidence.evidence.current_owned_descendants).Count-eq0-and!$evidence.evidence.absence_error-and@($evidence.global_native).Count-eq0) 'phase saved global/owned absence'
  foreach($rawPin in $evidence.evidence.raw_outputs){Need ((Sha $rawPin.path)-ceq$rawPin.sha256-and(Get-Item -LiteralPath $rawPin.path).Length-eq$rawPin.bytes) 'raw output owner pin'}
  $part=$result.phases.$phase;Need (!$part.failure-and!$part.original_execution_failure-and$part.postchecks.evidence_valid-eq$true-and$part.postchecks.owner_bound-eq$true-and$part.postchecks.source_sealed-eq$true-and$part.postchecks.artifacts_bound-eq$true-and$part.postchecks.absence_closed-eq$true-and@($part.postchecks.errors).Count-eq0) 'phase result joins'
  $admit=Read (Join-Path $item.root ($phase+'-admission.json'));Need ($admit.status-ceq'admitted'-and$admit.probe.minimum_kib-eq16777216-and$admit.probe.free_kib-ge16777216-and$admit.probe.native_roots-eq0-and@($admit.probe.native).Count-eq0) 'recorded fresh admission'
  if($null-eq$first){$first=$owner;$age=([DateTimeOffset]$owner.created_utc-[DateTimeOffset]$grant.issued_utc).TotalSeconds;Need ($age-ge0-and$age-le300) 'fresh initial grant'}
  $ownerChecks+=[ordered]@{phase=$phase;pid=$owner.pid;created_utc=$owner.created_utc;deadline_seconds=$deadline;elapsed_seconds=$ownerElapsed;exit_code=$owner.exit_code;saved_owned_descendants=0;saved_global_native=0;recorded_free_kib=$admit.probe.free_kib}
 }
 Need ((Sha (Join-Path $container 'evidence/typebox-heap-execution-prepared-20261017/Run-HeapProduct4V7Fdf6.ps1'))-ceq$grant.driver_sha256-and$result.driver_sha256-ceq$grant.driver_sha256) 'driver grant/result pin'
 $grantChecks+=[ordered]@{mode=$item.mode;path=$grantPath;sha256=(Sha $grantPath);initial_child_age_seconds=$age;outer_pid=$outer.pid;outer_deadline=$outer.timeout_seconds;outer_elapsed_seconds=$outerElapsed;saved_fresh_absence=$true}
 $resultChecks+=Pin (Join-Path $item.root 'result.json')
}
$runtimeGrant=Read (Join-Path $container 'evidence/root-typebox-product4-runtime-20261017-182754-grant.json');foreach($pair in @(@{path=$runtimeGrant.build_result_path;sha=$runtimeGrant.build_result_sha256},@{path=$runtimeGrant.build_artifacts_path;sha=$runtimeGrant.build_artifacts_sha256},@{path=$runtimeGrant.build_metadata_path;sha=$runtimeGrant.build_metadata_sha256})){Need ((Sha $pair.path)-ceq$pair.sha) 'RuntimeOnly exact BuildQuery prerequisite join'}
$report=[ordered]@{status='accepted_finite_actual_TypeBox_Product4_build_query_and_runtime';candidate_head=$head;candidate_root=$candidate;actual_metadata_names=$names;raw_results=$rawResults;raw_metadata=(Pin (Join-Path $build 'metadata.stdout.bin'));raw_runtime=(Pin (Join-Path $runtime 'runtime.stdout.bin'));raw_runtime_stderr=(Pin (Join-Path $runtime 'runtime.stderr.log'));actual_Source_rows=@(80,52,396);genuine_replay194F_unchanged=$true;fixture_rows=$fixtureRows;selected_generated_callbacks=34;thirteen_actual_intake_joins=$joins;full_seals=$sealChecks;sealed_counts=@{source=11698;tree=11698;vendor=1339;compiler=19546;build_controls=16;runtime_controls=19};full_seal_drift=0;current_unique_source_tool_control_files_rehashed=$hashed;current_rehash_mismatches=0;compiler_authority19546_original_relocation_join=$true;artifact_ledgers=$artifactChecks;installed_artifacts=$artifacts.installed;raw_owner_checks=$ownerChecks;fresh_actual_grants=$grantChecks;result_joins=$resultChecks;unchanged_Engine_guard_bytes=1048576;recorded_PE_reserve_bytes=16777216;PE_PDB_pair_analysis='Assigned separately to Root/Compiler; this audit hashes artifact bytes and verifies existing ledgers, not frame/codeview interpretation';scope='Exact fdf6 component and CE0572/94B50 artifacts through real unchanged80/52/396 and storage metadata4. No qualification transfer to newer Main or whole application.';limits=@('Recorded owner/global absences audited; no new CIM/resource/process probe performed','No full HOST GPA or exhaustive C malloc claim; original stderr explicitly false','No dynamic stack measurement, full application/frame/codeview claim or default activation','No Node/native/compiler/parser/AST/LLVM/sentinel execution by auditor; no Main edits')}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'independent-acceptance.json'),($report|ConvertTo-Json -Depth 12).Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
Write-Output ([ordered]@{status=$report.status;source=11698;compiler=19546;seals=$sealChecks.Count;rehashed=$hashed;intake=$joins.Count;actual_metadata=4;raw_flags=@($rawResults.flags);receipt_sha256=(Sha (Join-Path $PSScriptRoot 'independent-acceptance.json'))}|ConvertTo-Json -Depth 5)
