# Graph0 C3 focused native driver: prepared, not executed

Exact candidate: d2ab9d32dacc0ffb448152818921d93ebd0d57c0, clean 10,658 tracked
paths at worktrees/root-graph0-c3-qualification. Its tree is the prepared virtual
fa98ee3fb83aa021d50b289f20111b25eb2ad79a. Main remains on C2; this packet neither
intakes nor activates C3 there.

Run-Graph0C3Native.ps1 adapts corrected, independently closed retry driver
5EC31C47CECC405D9F059FCA2745DCBA20E994448D8D3F12891863DFA2320BB9.
The canonical process owner CI607 and protocol39F are unchanged. It adds no new
owner/controller framework. Root must independently supervise its outer driver,
serial lease, descendants and final owner reconciliation.

The two groups use only the installed targets:

- queued: build-native-dynamic-import-graph0; seven exact named controls.
- binding: build-native-graph0-binding; two exact named actual-binding controls.

Each actual metadata count is UNKNOWN before compilation/query. Metadata query
sends query4/exit0 only; version/layout/panic offsets and every exact full name
are validated. Each group must include every required named test exactly once.
The only permitted extra is one exact extensions.native_durable_storage.test_0.
No anonymous test is assumed or silently excluded. Runtime39F runs every actual
validated index and requires all results to pass without skips/log-errors/leaks.

Bounds per group: compile 1,320s, metadata 30s, runtime 120s, canonical redirected
pipe settlement 10s. Builds use Debug/LLVM, -j1 and the standard --listen runner.
Both groups reuse one run-private cache/global-cache pair. Each group has its
own prefix with canonical bin/test.exe and required Debug test.pdb. Complete
installed-output inventories are checked before/between/after and unconditionally
at final cleanup, with partial output inventoried after failed compilation.

Fresh 16 GiB and zero native roots are required before each child. Readmission
waits at most 54s, fails immediately for another native root and retains every
probe. No template grants a job: Root must issue a fresh <=300s source/driver/run
bound authorized grant after resource review. Run directories are newly acquired
without Force and cannot overwrite previous proof runs.

Full candidate 10,658/compiler 19,546/driver/CI/protocol/copied-grant seals are
retained before execution, between metadata and runtime, after each group, and
unconditionally at the end. C/H must match exact reviewed DA14/A79. Baseline
absence, source/output drift, census failure and remaining/reused owner PID are
negative. Empty lists serialize as []; grant clocks use DateTimeOffset casts.
Every available compile/metadata/runtime owner receipt is reconciled against the
current PID census conservatively; unrelated PID reuse requires Root review,
with no inferred ownership or broad termination.

Invocation only after independent driver review and Root's separate fresh grant:

    & 'C:\Program Files\PowerShell\7\pwsh.exe' -NoLogo -NoProfile -NonInteractive -File 'C:\Users\adyba\pi-zig\evidence\root-graph0-c3-native-prepared-20261016\Run-Graph0C3Native.ps1' -RootGrantPath '<ROOT-EXACT-GRANT-PATH>' -RunId '<ROOT-FRESH-UNIQUE-RUN>'

This focused packet covers only the reviewed queued Graph0 ABI, actual raw SDK
binding and its selected controls if they execute successfully. It does not
qualify inherited import enqueue/loader/INIT/allocation-fatal policy, private
Graph2 caller isolation, complete jiti/virtual authorities, default SDK selection
or application parity. The previously retained 34 focused +116 core selected
executions must later be rebuilt/requalified on C3 under a separate grant; they
are not run by this driver and are not transitive C3 evidence.

No compiler, metadata process, native runtime, Node, Source or generator job was
launched in preparation. Only static PowerShell parsing and read-only source/hash
checks occurred. The template is unauthorized and all runtime counts/results are
unknown. No Main or qualification/product files were edited.
