# Graph0 C3 focused v2: prepared only, no grant or execution

Exact qualification candidate: 8a530f772b734d9a4ff3ffe45e940c6ad5185562,
clean 10,658 tracked paths in worktrees/root-graph0-c3-qualification.
C/H remain exact reviewed DA14/A79. Main remains C2; this packet does not
activate C3 or qualify the retained 150 selected regressions.

The v2 driver differs from closed predecessor
57BD735AD1D6622AAC437E4BF27BC97232F3B138B8B2B92D94806008B924861B only in:

1. Exact candidate head d2ab9d32 -> 8a530f77.
2. Both compiler cache arguments use the original run's explicitly unsealed
   cache/global-cache directories.
3. The corresponding explanatory cache comment.

Every artifact prefix, owner receipt and proof file remains in a newly acquired
v2 run directory under this prepared folder. No original output or receipt is
overwritten. Only these original cache paths are mutable reuse:

    C:\Users\adyba\pi-zig\evidence\root-graph0-c3-native-prepared-20261016\root-graph0-c3-20261016-230927\cache
    C:\Users\adyba\pi-zig\evidence\root-graph0-c3-native-prepared-20261016\root-graph0-c3-20261016-230927\global-cache

The original packet remains FAILED overall. Its queued target compiled and
reported eight metadata entries (seven named controls plus storage test_0),
then completed eight runtime results with flags zero. Binding compilation failed
at the control's bool comparison; there was no binding metadata or runtime.
Those historical observations are not a full focused C3 pass or a v2 result.
Independent raw audit of that retained packet is separately requested.

The sole candidate source change is test control line 9:

    c.JS_IsAsyncFunction(function) == 0
    !c.JS_IsAsyncFunction(function)

The actual API returns bool. This preserves the ordinary-function assertion and
does not alter production binding, vendor C/H, Engine, inputs, names or expected
results. Original source/proof bytes remain preserved.

V2 replays BOTH installed targets, queued and binding, using canonical CI607
and Protocol39F unchanged. Counts remain unknown before each actual metadata
query; the driver requires all seven/two exact named controls and permits only
the optional exact extensions.native_durable_storage.test_0. It runs every
validated actual index, with no partial reuse of an old runtime outcome.

Unchanged bounds: compile 1,320s, metadata 30s and runtime 120s per group;
Debug/LLVM/-j1; fresh 16 GiB/native zero before each child; at most 54s resource
readmission; complete source 10,658/compiler 19,546/driver/control/grant seals,
per-group executable/PDB/output inventories, unconditional final/negative
observations and exact owner reconciliation. Empty JSON arrays and grant clock
casts retain the reviewed corrections.

Invocation only after independent source review and a fresh Root grant:

    & 'C:\Program Files\PowerShell\7\pwsh.exe' -NoLogo -NoProfile -NonInteractive -File 'C:\Users\adyba\pi-zig\evidence\root-graph0-c3-native-v2-prepared-20261017\Run-Graph0C3Native.ps1' -RootGrantPath '<ROOT-EXACT-GRANT-PATH>' -RunId '<ROOT-FRESH-UNIQUE-RUN>'

The template is unauthorized. No job has launched from this packet. Preparation
performed only source/hash/diff checks and static PowerShell parsing, with no
Main/product/qualification edit, compiler, metadata, native, Node or Source job.
C3 inherited-policy, SDK/default, private Graph2 and whole-application scopes
remain separate. The C2 retained 34+116 regression requalification is not granted.
