$ErrorActionPreference='Stop'
$container='C:\Users\adyba\pi-zig'
$members=[Collections.Generic.List[object]]::new()
function Add-ProofFile([string]$Path,[string]$Role){
 $full=[IO.Path]::GetFullPath($Path);if(!$full.StartsWith($container+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Input escapes container'}
 $item=Get-Item -LiteralPath $full;if($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Regular file required'}
 $name=$full.Substring($container.Length+1).Replace('\','/');if(@($members|Where-Object member -CEQ $name).Count){return}
 $members.Add([ordered]@{member=$name;original_path=$full;role=$Role;bytes=$item.Length;sha256=(Get-FileHash -LiteralPath $full).Hash})
}
foreach($relative in @('evidence/root-graph0-c3-native-prepared-20261016','evidence/root-graph0-c3-native-prepared-20261016/root-graph0-c3-20261016-230927','evidence/root-graph0-c3-native-v2-prepared-20261017','evidence/root-graph0-c3-native-v2-prepared-20261017/root-graph0-c3-v2-20261016-234029','evidence/graph0-c3-two-run-independent-async-review-20261017')){
 foreach($file in Get-ChildItem -LiteralPath (Join-Path $container $relative) -File){Add-ProofFile $file.FullName 'unchanged original control/manifest/raw receipt or independent audit'}
}
$prepared=Get-Content -Raw -LiteralPath (Join-Path $container 'evidence/root-graph0-c3-native-v2-prepared-20261017/prepared.json')|ConvertFrom-Json
$candidate=Join-Path $container 'worktrees/root-graph0-c3-qualification'
foreach($row in $prepared.controls){$path=Join-Path $candidate $row.path;if((Get-FileHash -LiteralPath $path).Hash -cne $row.sha256){throw 'Prepared source leaf drift'};Add-ProofFile $path 'exact tested C3/ABI/binding/control/build/owner leaf'}
Add-ProofFile (Join-Path $container 'evidence/durable-latest89-full-inspect-53ae-tool-prehash-20261011.json') 'complete original compiler authority manifest; historical paths retained'
$readme=@'
# Graph0 C3 focused two-run proof

The original v1 and v2 execution/control files in this packet are byte-exact originals. This packet is prepared for public retention; packaging is not proof of publication. Original manifests and READMEs describe their earlier prepared/unexecuted status and remain unchanged. Actual run receipts plus independent raw audit establish later results.

V1 exact d2ab9d32dacc0ffb448152818921d93ebd0d57c0 FAILED overall. The queued group reported eight genuine metadata entries, ran all eight with zero flags, and exited0 with empty runtime stderr. Binding compilation then failed because JS_IsAsyncFunction returns bool and the control compared it with integer0. Binding metadata/runtime did not execute. Neither the queued subgroup pass nor v1 compilation of the queued target is a full C3 pass.

The sole successor source correction preserves the ordinary-function assertion by replacing JS_IsAsyncFunction(function)==0 with !JS_IsAsyncFunction(function). Production C/H/binding/Engine were unchanged. Only the two explicitly disposable original compiler caches were reused, with fresh v2 output/receipt paths; all33 protected v1 receipt/output members retain original hashes.

V2 exact8a530f772b734d9a4ff3ffe45e940c6ad5185562 PASSED the focused queued and binding groups. Raw metadata contains eight queued entries (seven named controls plus storage test_0) and three binding entries (two named controls plus storage test_0). Raw runtime streams contain all eleven ordered starts/results with zero flags and empty runtime stderr. These are nine named controls plus TWO executions of the imported storage entry. They are not eleven unique named controls.

IMPORTANT SUMMARY LIMITATION: original v2 result.json has actual_metadata_total:null. It is preserved unchanged. The independent audit derives actual total11 from raw metadata8+3 and confirms execution from raw runtime frames. Null is not treated as zero, an unknown result is not treated as passed, and the original summary is not rewritten to make it appear complete.

V2 queued executable SHA2567BEF1492432D0F63ED2A6B3559C0F8D44DD8D62615CC9C4A511B756FA8A0B738; binding executable SHA25633807BF615DD7D5F7301785208D278C2B5D0AE303C674D5014CACF0E7A5A75DA. Exact C3 C/H are DA14DFBB7E73DED032E9FCD742FD2E49FDAF45273F48D24D6089018539601614 and A79E75A40D34C9E7CAFB9AB31359B7EE925FE205636603F2022CF764CFC18346.

Audit checks complete saved source10658/compiler19546 phase/final seals and original compiler authority, owner identity/deadlines/admissions, raw metadata/results, current executable/PDB hashes and phase inventories, all original owner PIDs absent, and original33 protected members unchanged. Historical v1 and v2 observations remain separate; no older pass is reused as a v2 execution. The original actual_metadata_total:null is explicitly disclosed in the audit.

Scope is focused C3 only. C3 is not accepted into Main by this packet; retained150 regression remains required. No full SDK/default/private Graph2/full application/runtime restoration acceptance is established. Raw jobctx lifetime, inherited ignored enqueue/loader fatal/INIT policies remain the prior explicitly disclosed separate boundaries.

Executable/PDB payloads, compiler payloads, and mutable cache contents are EXCLUDED from this ZIP. Those payloads remain local, identified by artifact receipts, and are not durably stored here. This is not a binary/debugger reproduction claim. Exact tested source/control leaves and complete source/compiler inventories are included. No original history/receipt/fixture is rewritten. No build/test/Node/native job or Main edit is performed by this audit/package.

member-manifest.json inventories every payload by length and SHA256. The archive additionally contains this manifest. All members are decompressed and hashed before package-verification.json is issued.
'@
$readmePath=Join-Path $PSScriptRoot 'README.md';if(Test-Path -LiteralPath $readmePath){throw 'Existing package refused'}
$readme|Set-Content -LiteralPath $readmePath -Encoding utf8NoBOM
Add-ProofFile $readmePath 'new honest scope and exclusions'
Add-ProofFile $PSCommandPath 'new packaging source'
$manifest=[ordered]@{schema=1;created_utc=[DateTimeOffset]::UtcNow.ToString('o');status='prepared_public_proof_not_publication';scope='focused C3 v2 queued8+binding3 raw pass; v1 binding compile negative retained';payload_count=$members.Count;excluded=@('Installed executable/PDB payloads from both runs','Compiler payloads','Mutable compiler caches');members=$members.ToArray()}
$manifestPath=Join-Path $PSScriptRoot 'member-manifest.json'
ConvertTo-Json -InputObject $manifest -Depth 12|Set-Content -LiteralPath $manifestPath -Encoding utf8NoBOM
$zipPath=Join-Path $PSScriptRoot 'raw-proof.zip'
$stream=[IO.File]::Open($zipPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
try{$zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true);try{foreach($row in $members){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$row.original_path,$row.member,[IO.Compression.CompressionLevel]::Optimal)|Out-Null};[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$manifestPath,'member-manifest.json',[IO.Compression.CompressionLevel]::Optimal)|Out-Null}finally{$zip.Dispose()}}finally{$stream.Dispose()}
$verified=@();$zip=[IO.Compression.ZipFile]::OpenRead($zipPath)
try{
 if($zip.Entries.Count -ne $members.Count+1){throw 'ZIP count mismatch'}
 foreach($row in @($members.ToArray())+@([ordered]@{member='member-manifest.json';bytes=(Get-Item -LiteralPath $manifestPath).Length;sha256=(Get-FileHash -LiteralPath $manifestPath).Hash})){
  $entry=$zip.GetEntry($row.member);if(!$entry -or $entry.Length -ne $row.bytes){throw 'Missing/length mismatch'}
  $input=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($input))}finally{$input.Dispose()}
  if($hash -cne $row.sha256){throw 'Decompression hash mismatch'}
  $verified+=,[ordered]@{member=$row.member;bytes=$entry.Length;sha256=$hash;match=$true}
 }
}finally{$zip.Dispose()}
$receipt=[ordered]@{status='passed';zip_bytes=(Get-Item -LiteralPath $zipPath).Length;zip_sha256=(Get-FileHash -LiteralPath $zipPath).Hash;manifest_sha256=(Get-FileHash -LiteralPath $manifestPath).Hash;payload_count=$members.Count;zip_count=$verified.Count;decompression_hash_drift=0;verified=$verified;published=$false;new_native_or_node_jobs=0}
ConvertTo-Json -InputObject $receipt -Depth 10|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'package-verification.json') -Encoding utf8NoBOM
[pscustomobject]$receipt|Select-Object status,zip_bytes,zip_sha256,manifest_sha256,payload_count,zip_count,decompression_hash_drift|ConvertTo-Json
