$ErrorActionPreference='Stop'
$container='C:\Users\adyba\pi-zig'
function Read-AuditJson($p){Get-Content -Raw -LiteralPath $p|ConvertFrom-Json}
function Get-AuditHash($p){(Get-FileHash -LiteralPath $p).Hash}
function Assert-Audit($condition,$message){if(!$condition){throw $message}}
function Get-Rows($rows){@($rows|ForEach-Object{$_.relative+' '+$_.sha256})}
function Read-RawProtocol($path,[bool]$metadata,[int]$expected){
 $b=[IO.File]::ReadAllBytes($path);$o=0;$version=$null;$names=@();$starts=0;$results=@()
 while($o -lt $b.Length){
  Assert-Audit ($b.Length-$o -ge 8) 'Truncated header';$tag=[BitConverter]::ToUInt32($b,$o);$n=[BitConverter]::ToUInt32($b,$o+4);$o+=8
  Assert-Audit ($n -le $b.Length-$o -and $n -le 1MB) 'Bad body'
  if($tag -eq 0){Assert-Audit ($null -eq $version -and $starts -eq 0 -and $names.Count -eq 0) 'Version order';$version=[Text.Encoding]::UTF8.GetString($b,$o,$n)}
  elseif($metadata -and $tag -eq 3){
   Assert-Audit ($version -ceq '0.16.0' -and $names.Count -eq 0 -and $n -ge 8) 'Metadata order';$strings=[BitConverter]::ToUInt32($b,$o);$count=[BitConverter]::ToUInt32($b,$o+4)
   Assert-Audit ($count -eq $expected -and $n -eq 8+8*$count+$strings) 'Metadata length/count';$start=$o+8+8*$count
   for($i=0;$i -lt $count;$i++){$at=[BitConverter]::ToUInt32($b,$o+8+4*$i);Assert-Audit ($at -lt $strings -and [BitConverter]::ToUInt32($b,$o+8+4*$count+4*$i) -eq 0) 'Name/panic';$end=$at;while($end -lt $strings -and $b[$start+$end] -ne 0){$end++};Assert-Audit ($end -lt $strings) 'Unterminated name';$names+=[Text.Encoding]::UTF8.GetString($b,$start+$at,$end-$at)}
  }elseif(!$metadata -and $tag -eq 5){Assert-Audit ($version -ceq '0.16.0' -and $n -eq 0 -and $starts -eq $results.Count -and $starts -lt $expected) 'Start order';$starts++}
  elseif(!$metadata -and $tag -eq 4){Assert-Audit ($n -eq 12 -and $starts -eq $results.Count+1) 'Result order';$i=[BitConverter]::ToUInt32($b,$o);$flags=[BitConverter]::ToUInt64($b,$o+4);Assert-Audit ($i -eq $results.Count -and $flags -eq 0) 'Result index/flags';$results+=,[ordered]@{index=$i;flags=$flags}}
  else{throw "Unknown tag $tag"};$o+=$n
 }
 Assert-Audit ($version -ceq '0.16.0') 'Wrong version';if($metadata){Assert-Audit ($names.Count -eq $expected) 'Incomplete metadata'}else{Assert-Audit ($starts -eq $expected -and $results.Count -eq $expected) 'Incomplete runtime'}
 return [ordered]@{bytes=$b.Length;version=$version;names=$names;starts=$starts;results=$results;sha256=Get-AuditHash $path}
}
$compilerPath=Join-Path $container 'evidence\durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
Assert-Audit ((Get-AuditHash $compilerPath) -ceq 'DEE259F171F720AB2C08E8DD473975E22C876417CD62E4F016C71A7C662794EB') 'Compiler authority'
$compiler=Read-AuditJson $compilerPath;$compilerRows=@($compiler.inputs|ForEach-Object{$_.path.Substring($compiler.root.Length+1).Replace('\','/')+' '+$_.sha256})
$prepared=Read-AuditJson "$container\evidence\root-graph0-c3-native-v2-prepared-20261017\prepared.json"
foreach($row in $prepared.protected_original_files){Assert-Audit ((Get-AuditHash $row.path) -ceq $row.sha256) 'Protected original changed'}
$reports=@()
foreach($entry in @(@{folder='root-graph0-c3-native-prepared-20261016';run='root-graph0-c3-20261016-230927';head='d2ab9d32dacc0ffb448152818921d93ebd0d57c0';negative=$true},@{folder='root-graph0-c3-native-v2-prepared-20261017';run='root-graph0-c3-v2-20261016-234029';head='8a530f772b734d9a4ff3ffe45e940c6ad5185562';negative=$false})){
 $run=Join-Path $container "evidence\$($entry.folder)\$($entry.run)";$before=Read-AuditJson "$run\before.json";$result=Read-AuditJson "$run\result.json"
 Assert-Audit ($before.candidate_head -ceq $entry.head -and $result.source_head -ceq $entry.head -and $before.source.Count -eq 10658 -and $before.compiler.Count -eq 19546) 'Wrong source/count'
 Assert-Audit (@(Compare-Object (Get-Rows $before.compiler) $compilerRows -CaseSensitive).Count -eq 0) 'Compiler original drift'
 $seals=@(foreach($file in Get-ChildItem -LiteralPath $run -File|Where-Object{$_.Name -match '^(queued|binding)-(between|after)\.json$|^final\.json$'}){
  $seal=Read-AuditJson $file.FullName
  foreach($key in @('candidate_head','driver_sha256','ci_owner_sha256','protocol_sha256','root_grant_sha256')){Assert-Audit ($seal.$key -ceq $before.$key) "Seal $key drift"}
  foreach($group in @('source','compiler')){Assert-Audit (@($seal.$group.relative|Sort-Object -Unique).Count -eq $seal.$group.Count -and @(Compare-Object (Get-Rows $before.$group) (Get-Rows $seal.$group) -CaseSensitive).Count -eq 0) "Seal $group drift"}
  [ordered]@{phase=$file.Name;source_count=$seal.source.Count;compiler_count=$seal.compiler.Count;drift=0}
 })
 Assert-Audit ($seals.Count -eq $(if($entry.negative){3}else{5})) 'Missing phase seals'
 Assert-Audit ($before.ci_owner_sha256 -ceq '607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285' -and $before.protocol_sha256 -ceq '39F273D35A5B28E9D60FBE93355828314458A67FB472D60E0A8A6D4DD1FB704D') 'Canonical controls'
 Assert-Audit ((Get-AuditHash "$container\evidence\$($entry.folder)\Run-Graph0C3Native.ps1") -ceq $before.driver_sha256 -and (Get-AuditHash "$run\root-grant.json") -ceq $before.root_grant_sha256) 'Driver/grant drift'
 $groups=@();$groupNames=if($entry.negative){@('queued')}else{@('queued','binding')}
 foreach($group in $groupNames){
  $count=if($group -eq 'queued'){8}else{3};$selected=Read-AuditJson "$run\$group-selected-tests.json";$metadata=Read-RawProtocol "$run\$group-metadata.stdout.bin" $true $count;$runtime=Read-RawProtocol "$run\$group-runtime.stdout.bin" $false $count
  Assert-Audit (($metadata.names -join "`n") -ceq ($selected.tests -join "`n") -and $selected.actual_count -eq $count) 'Metadata summary mismatch'
  Assert-Audit ($metadata.names[-1] -ceq 'extensions.native_durable_storage.test_0' -and ($metadata.names[0..($count-2)] -join "`n") -ceq ($selected.required_named -join "`n")) 'Required named/storage entries'
  Assert-Audit ((Get-Item -LiteralPath "$run\$group-runtime.stderr.log").Length -eq 0 -and (Get-Item -LiteralPath "$run\$group-metadata.stderr.log").Length -eq 0) 'Unexpected stderr'
  $baseline=Read-AuditJson "$run\$group-artifacts-before.json"
  foreach($row in $baseline.rows){Assert-Audit ((Get-AuditHash $row.path) -ceq $row.sha256) 'Current installed artifact drift'}
  $exe=@($baseline.rows|Where-Object relative -CEQ 'bin/test.exe');Assert-Audit ($exe.Count -eq 1 -and $exe[0].sha256 -ceq $selected.binary_sha256) 'Selected executable identity'
  foreach($operation in @('metadata','runtime')){$owner=Read-AuditJson "$run\$group-$operation.json";Assert-Audit ($owner.executable_sha256 -ceq $exe[0].sha256 -and $owner.executable -ceq $exe[0].path -and ($owner.arguments -join ' ') -ceq '--listen=-') 'Raw protocol owner executable binding'}
  foreach($phase in @('between','after','final')){$artifact=Read-AuditJson "$run\$group-artifacts-$phase.json";Assert-Audit ($artifact.rows.Count -eq 2 -and $artifact.hash_drift.Count -eq 0 -and $artifact.path_drift.Count -eq 0 -and @(Compare-Object (Get-Rows $baseline.rows) (Get-Rows $artifact.rows) -CaseSensitive).Count -eq 0) 'Artifact phase drift'}
  $groups+=,[ordered]@{name=$group;raw_metadata=$metadata;raw_runtime=$runtime;artifact_rows=$baseline.rows;runtime_stderr_bytes=0;metadata_stderr_bytes=0}
 }
 $ownerChecks=@(foreach($file in Get-ChildItem -LiteralPath $run -File|Where-Object{$_.Name -match '^(queued|binding)-(compile|metadata|runtime)\.json$'}){
  $owner=Read-AuditJson $file.FullName;$isFailed=$entry.negative -and $file.Name -ceq 'binding-compile.json';$deadline=if($file.Name -match '-compile'){1320}elseif($file.Name -match '-metadata'){30}else{120}
  Assert-Audit ($owner.retained_handle -gt 0 -and $owner.timeout_seconds -eq $deadline -and $owner.pid -eq $owner.live_identity.pid -and $owner.executable -ceq $owner.live_identity.executable -and $owner.created_utc -ceq $owner.live_identity.created_utc -and $owner.live_identity.command_line_method -ceq 'Win32_Process.CommandLine') 'Owner identity/bounds'
  Assert-Audit ($(if($isFailed){$owner.status -ceq 'failed' -and $owner.exit_code -ne 0}else{$owner.status -ceq 'passed' -and $owner.exit_code -eq 0})) 'Owner terminal'
  $elapsed=([DateTimeOffset]$owner.completed_utc-[DateTimeOffset]$owner.created_utc).TotalSeconds;Assert-Audit ($elapsed -ge 0 -and $elapsed -le $deadline) 'Elapsed bounds'
  Assert-Audit (@(Get-CimInstance Win32_Process -Filter "ProcessId = $($owner.pid)").Count -eq 0) 'Owner PID present/reused'
  [ordered]@{phase=$file.BaseName;pid=$owner.pid;created_utc=$owner.created_utc;status=$owner.status;exit_code=$owner.exit_code;deadline_seconds=$deadline;elapsed_seconds=$elapsed;currently_absent=$true;binary_sha256=$owner.executable_sha256;live_command_line=$owner.live_identity.command_line}
 })
 Assert-Audit ($ownerChecks.Count -eq $(if($entry.negative){4}else{6})) 'Wrong owner count'
 foreach($admission in Get-ChildItem -LiteralPath $run -File -Filter '*-admission.json'){$a=Read-AuditJson $admission.FullName;Assert-Audit ($a.probe.free_kib -ge 16777216 -and $a.probe.native_roots -eq 0) 'Admission'}
 foreach($absence in Read-AuditJson "$run\owner-absence.json"){Assert-Audit ($absence.absent -eq $true -and $absence.current.Count -eq 0) 'Historical absence'}
 Assert-Audit ($result.postseal -eq $true -and $result.native_roots_after -eq 0 -and (Read-AuditJson "$run\native-roots-final.json").Count -eq 0) 'Final scope'
 if($entry.negative){Assert-Audit ($result.status -ceq 'failed' -and !(Test-Path -LiteralPath "$run\binding-runtime.json") -and !(Test-Path -LiteralPath "$run\binding-metadata.json")) 'Negative preserved';Assert-Audit ([IO.File]::ReadAllText("$run\binding-compile.stderr.log").Contains("incompatible types: 'bool' and 'comptime_int'")) 'Wrong negative cause'}else{Assert-Audit ($result.status -ceq 'passed' -and $null -eq $result.actual_metadata_total) 'Expected original null summary field'}
 $reports+=,[ordered]@{run=$run;head=$entry.head;status=$result.status;raw_derived_actual_metadata_total=($groups|ForEach-Object{$_.raw_metadata.names.Count}|Measure-Object -Sum).Sum;original_actual_metadata_total=$result.actual_metadata_total;summary_null_not_rewritten=$true;groups=$groups;seals=$seals;owners=$ownerChecks;postseal=$true;compiler_original_authority_drift=0}
}
foreach($row in $prepared.controls){Assert-Audit ((Get-AuditHash (Join-Path $container "worktrees\root-graph0-c3-qualification\$($row.path)")) -ceq $row.sha256) 'Prepared tested leaf changed'}
$report=[ordered]@{status='focused_C3_v2_raw_pass_accepted_v1_negative_preserved';audited_utc=[DateTimeOffset]::UtcNow.ToString('o');runs=$reports;v2_named_controls=9;v2_actual_metadata_entries=11;v2_imported_storage_entries=2;v2_all_flags_zero=$true;protected_v1_files=$prepared.protected_original_files.Count;protected_v1_drift=0;summary_defect='Original v2 actual_metadata_total is null; independent raw counts8+3=11; original JSON remains unchanged';limits=@('Focused C3 only, not main integration; retained150 regressions still required','No full SDK/default/Graph2/full application or runtime-restoration claim','No tests/builds/compiler/Node jobs; no main edits','Complete saved source/compiler seals plus current prepared leaves/artifacts checked; no fresh full compiler rehash')}
ConvertTo-Json -InputObject $report -Depth 25|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'audit.json') -Encoding utf8NoBOM
[pscustomobject]@{status=$report.status;sha256=Get-AuditHash (Join-Path $PSScriptRoot 'audit.json');actual_v2_count=11;original_summary_count=$null}|ConvertTo-Json
