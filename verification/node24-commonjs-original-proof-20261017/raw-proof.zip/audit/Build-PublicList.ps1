$ErrorActionPreference='Stop'
$container='C:\Users\adyba\pi-zig'
$run=Join-Path $container 'evidence/root-node-c8-original-20261017-132606'
$controls=Join-Path $container 'evidence/root-node-jiti-commonjs-c8-source-prepared-20261017'
$candidate=Join-Path $container 'worktrees/node-jiti-commonjs-seams'
$rows=[Collections.Generic.List[object]]::new()
function Add-Public([string]$Source,[string]$Destination){
 $file=Get-Item -LiteralPath $Source
 if($file.PSIsContainer){throw 'Explicit public file required'}
 if($file.Extension-in@('.exe','.pdb','.dll','.lib','.a','.tgz','.zip')-or$Source.StartsWith('C:\Program Files\',[StringComparison]::OrdinalIgnoreCase)-or$Source-match'[\\/](?:\.zig-cache|zig-out)[\\/]'){throw 'Excluded public payload'}
 $rows.Add([pscustomobject][ordered]@{public_path=$Destination;source_path=$file.FullName;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash})
}
foreach($file in Get-ChildItem -LiteralPath $run -File -Recurse){Add-Public $file.FullName ('capture/'+[IO.Path]::GetRelativePath($run,$file.FullName).Replace('\','/'))}
foreach($file in Get-ChildItem -LiteralPath $controls -File -Recurse){Add-Public $file.FullName ('controls/'+[IO.Path]::GetRelativePath($controls,$file.FullName).Replace('\','/'))}
$before=Get-Content (Join-Path $run 'before.json') -Raw|ConvertFrom-Json
foreach($row in $before.controls){
 if($row.path.StartsWith($controls+'\',[StringComparison]::OrdinalIgnoreCase)-or$row.path.StartsWith('C:\Program Files\',[StringComparison]::OrdinalIgnoreCase)){continue}
 Add-Public $row.path ('authority-controls/'+[IO.Path]::GetRelativePath($container,$row.path).Replace('\','/'))
}
foreach($name in @('README.md','CAPTURE-PLAN.md')){Add-Public (Join-Path $candidate ('verification/node-jiti-commonjs-seams-sourceonly-20261017/'+$name)) ('observer/'+$name)}
$authority=Join-Path $candidate 'verification/node-module-constructor-sourceonly-20261016/authority'
foreach($file in Get-ChildItem -LiteralPath $authority -File){Add-Public $file.FullName ('Node24-primary/'+$file.Name)}
Add-Public (Join-Path $container 'evidence/root-crypto58-native-outer-prepared-20261017/outer-owned-process.ps1') 'outer/outer-owned-process.ps1'
foreach($name in @('Audit-C8.ps1','raw-audit.json','README.md','Build-PublicList.ps1')){Add-Public (Join-Path $PSScriptRoot $name) ('audit/'+$name)}
$destinations=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($row in $rows){if(!$destinations.Add([string]$row.public_path)){throw "Duplicate public destination: $($row.public_path)"}}
$manifest=[ordered]@{scope='Accepted original Node24 C8 observations only';candidate_head='37e27a0d34cd77611363b24c1e309a437e713e98';raw_original_sha256='F982B6E1D49128FFE78478DCD6F2FA04D298F7CBDE79BC9EE8288E40864AE967';file_count=$rows.Count;bytes=($rows|Measure-Object bytes -Sum).Sum;files=$rows.ToArray();exclusions=@('All Node installation payloads, executable/PDB/library/archive/cache/output payloads','Unrelated whole10873-source payload; complete inventories and exact commit retained');raw_stdout_bin_is_UTF8_observation_not_executable=$true;native_qualification=$false;expected_generated=$false;remote_published_by_auditor=$false}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'public-files.json'),($manifest|ConvertTo-Json -Depth 8)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllLines((Join-Path $PSScriptRoot 'public-paths.txt'),[string[]]@($rows|ForEach-Object{$_.public_path}),[Text.UTF8Encoding]::new($false))
[ordered]@{file_count=$rows.Count;bytes=$manifest.bytes;manifest_sha256=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'public-files.json') -Algorithm SHA256).Hash}|ConvertTo-Json
