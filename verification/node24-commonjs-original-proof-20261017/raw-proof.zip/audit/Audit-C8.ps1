$ErrorActionPreference='Stop'
$container='C:\Users\adyba\pi-zig'
$run=Join-Path $container 'evidence/root-node-c8-original-20261017-132606'
$controls=Join-Path $container 'evidence/root-node-jiti-commonjs-c8-source-prepared-20261017'
$candidate=Join-Path $container 'worktrees/node-jiti-commonjs-seams'
function ReadJson([string]$Path){Get-Content -LiteralPath $Path -Raw|ConvertFrom-Json}
function Require([bool]$Condition,[string]$Message){if(!$Condition){throw $Message}}
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash}
function RowKeys($Rows){@($Rows|ForEach-Object{$_.relative+' '+$_.sha256})}
function CompareRows($Left,$Right,[string]$Name){Require (@(Compare-Object @($Left) @($Right) -CaseSensitive).Count-eq0) "$Name differs"}
$result=ReadJson (Join-Path $run 'result.json')
$plan=ReadJson (Join-Path $run 'plan.json')
$node=ReadJson (Join-Path $run 'node.json')
$absence=ReadJson (Join-Path $run 'absence.json')
$grant=ReadJson (Join-Path $controls 'root-node-c8-original-20261017-132606-grant.json')
$outer=ReadJson (Join-Path $controls 'root-node-c8-original-20261017-132606-outer.json')
$outerAbsence=ReadJson (Join-Path $controls 'root-node-c8-original-20261017-132606-outer-absence.json')
$original=ReadJson (Join-Path $run 'original-output.json')
$before=ReadJson (Join-Path $run 'before.json')
$sealReports=@(foreach($phase in @('before','before-node','after-node','final')){
 $seal=ReadJson (Join-Path $run "$phase.json")
 Require ($seal.head-ceq'37e27a0d34cd77611363b24c1e309a437e713e98'-and$seal.clean-and!$seal.errors.Count) "$phase head/clean/errors"
 Require ($seal.source.Count-eq10873-and$seal.tree.Count-eq10873-and$seal.node1838.Count-eq1838-and$seal.node1774.Count-eq1774-and$seal.controls.Count-eq14) "$phase complete inventory counts"
 CompareRows (RowKeys $seal.source) (RowKeys $seal.tree) "$phase source/tree"
 CompareRows (RowKeys $seal.source) (RowKeys $before.source) "$phase source"
 CompareRows $seal.node1838 $before.node1838 "$phase Node1838"
 CompareRows $seal.node1774 $before.node1774 "$phase Node1774"
 CompareRows @($seal.controls|ForEach-Object{$_.path+' '+$_.sha256}) @($before.controls|ForEach-Object{$_.path+' '+$_.sha256}) "$phase controls"
 [ordered]@{phase=$phase;source=$seal.source.Count;tree=$seal.tree.Count;node1838=$seal.node1838.Count;node1774=$seal.node1774.Count;controls=$seal.controls.Count;drift=0;sha256=Hash (Join-Path $run "$phase.json")}
})
$original1774=@(ReadJson (Join-Path $container 'evidence/source4954-node-tools-before-20261015.json'))
$original1838=@((ReadJson (Join-Path $container 'evidence/typebox-heap-scope-args-static-second49d-20261016-frozen.json')).node_complete)
function NodeKeys($Rows){@($Rows|ForEach-Object{[IO.Path]::GetRelativePath('C:\Program Files\nodejs',[string]$_.path).Replace('\','/')+' '+$_.sha256})}
CompareRows $before.node1774 (NodeKeys $original1774) 'Original Node1774'
CompareRows $before.node1838 (NodeKeys $original1838) 'Original Node1838'
foreach($row in $before.controls){Require ((Hash $row.path)-ceq$row.sha256) "Current control differs: $($row.path)"}
$currentSourceDrift=@(foreach($row in $before.source){if((Hash (Join-Path $candidate $row.relative))-cne$row.sha256){$row.relative}})
Require (!$currentSourceDrift.Count) 'Current complete source differs'
Require (([string](git --no-optional-locks -C $candidate rev-parse HEAD)).Trim()-ceq$before.head) 'Current head differs'
Require (@(git --no-optional-locks -C $candidate status --porcelain).Count-eq0) 'Current candidate is dirty'
Require ($result.status-ceq'passed_original_capture'-and!$result.errors.Count-and$result.postseal-and!$result.expected_created-and!$result.candidate_implementation_executed-and!$result.native_qualified-and!$result.runtime_restoration_claim) 'Capture result is not a bounded original-only pass'
Require ($node.status-ceq'passed'-and$node.exit_code-eq0-and$node.timeout_seconds-eq60-and$node.pid-eq39560-and$node.executable_sha256-ceq'63C259C81E5D472B5F11C8D506070130CB04A1ECF84B80377A34ED6EC9048088') 'Actual Node owner mismatch'
Require ($node.live_identity.pid-eq$node.pid-and([DateTimeOffset]$node.live_identity.created_utc)-eq([DateTimeOffset]$node.created_utc)-and$node.live_identity.executable-ceq$node.executable-and$node.live_identity.command_line_method-ceq'Win32_Process.CommandLine') 'Actual Node live identity mismatch'
CompareRows $node.arguments $plan.arguments 'Owner/plan arguments'
Require ($node.arguments[0]-ceq'--max-old-space-size=256'-and$node.arguments[2]-ceq$grant.stdin_nonce-and$node.arguments[3]-ceq(Join-Path $candidate 'verification/node-jiti-commonjs-seams-sourceonly-20261017/reference-input.mjs')) 'Actual original caller/fence arguments differ'
Require ($grant.authorized-and$grant.driver_sha256-ceq'F203C444A0A5E1653B7C599472CE4A3CCB0B809A998EA9F63EE2C82DF78A679A'-and([DateTimeOffset]$node.created_utc)-ge([DateTimeOffset]$grant.issued_utc)-and([DateTimeOffset]$node.created_utc)-lt([DateTimeOffset]$grant.expires_utc)) 'Actual issued grant mismatch'
Require ($outer.status-ceq'passed'-and$outer.exit_code-eq0-and$outer.timeout_seconds-eq600-and$outer.pid-eq33940-and$outer.live_identity.pid-eq$outer.pid-and([DateTimeOffset]$outer.created_utc)-eq([DateTimeOffset]$outer.live_identity.created_utc)) 'Outer terminal/live owner mismatch'
$outerHelper=Join-Path $container 'evidence/root-crypto58-native-outer-prepared-20261017/outer-owned-process.ps1'
Require ((Hash $outerHelper)-ceq'53E522C8397B5F7EE9AF721D8160B227E97FADA4E1DA36A938656E2403D56B6B'-and(Hash $outer.executable)-ceq'BFB46AF89433268872DDB43D1CA7A3F433452EE91ED356A9786940F90118E285') 'Outer owner source/image pin differs'
$ciText=[IO.File]::ReadAllText((Join-Path $container 'main/tools/ci/native_qualification_ci.ps1'))
$outerText=[IO.File]::ReadAllText($outerHelper)
Require ($outerText.Replace("@('pwsh.exe')","@('zig','zig.exe','node','node.exe','test','test.exe')")-ceq$ciText) 'Outer helper differs beyond exact executable allowlist'
Require ($outer.live_identity.command_line-ceq('"'+$outer.executable+'" '+($outer.arguments-join' '))-and$node.live_identity.command_line-ceq('"'+$node.executable+'" '+($node.arguments-join' '))) 'Live command lines differ from actual requested arguments'
Require ($outerAbsence.pid-eq$outer.pid-and$outerAbsence.absent-and([DateTimeOffset]$outerAbsence.utc)-ge([DateTimeOffset]$outer.completed_utc)) 'Outer recorded absence mismatch'
Require (!$absence.node.owner_pid_present-and!$absence.node.observed_descendants_by_parent_pid.Count-and!$absence.node.absence_error-and!$absence.global_native.Count) 'Recorded Node/descendant/native absence failed'
Require ((Get-Item (Join-Path $run 'node.stderr.log')).Length-eq0-and(Get-Item (Join-Path $controls 'root-node-c8-original-20261017-132606-outer.stderr.log')).Length-eq0) 'Nonempty stderr'
$rawHash=Hash (Join-Path $run 'node.stdout.bin')
Require ($rawHash-ceq'F982B6E1D49128FFE78478DCD6F2FA04D298F7CBDE79BC9EE8288E40864AE967'-and$rawHash-ceq(Hash (Join-Path $run 'original-output.json'))-and(Get-Item (Join-Path $run 'node.stdout.bin')).Length-eq22201) 'Original raw output identity differs'
Require ((Hash (Join-Path $run 'result.json'))-ceq(Hash (Join-Path $controls 'root-node-c8-original-20261017-132606-outer.stdout.bin'))) 'Outer stdout/result bytes differ'
Require ($original.authority-ceq'original-Node24.14.0-CommonJS'-and$original.initial.nodeVersion-ceq'v24.14.0'-and$original.initial.execPath-ceq$node.executable-and$original.rows.Count-eq36) 'Original identity/count differs'
for($i=0;$i-lt36;$i++){Require ($original.rows[$i].id-ceq$plan.expected_input_ids[$i]-and$original.rows[$i].status-in@('returned','thrown')) "Original row $i schema/order differs"}
Require ($original.originalBuiltinList.Count-eq72-and$original.initial.builtinModules.Count-eq72-and$original.initial.builtinFrozen-and$original.initial.builtinSameDefaultExport) 'Original builtin identity/freeze/count differs'
for($i=0;$i-lt72;$i++){Require ($original.originalBuiltinList[$i]-is[string]-and$original.originalBuiltinList[$i]-ceq$original.initial.builtinModules[$i]) "Original builtin index $i differs"}
Require (@($original.originalBuiltinList|Sort-Object -Unique).Count-eq72) 'Duplicate builtin id'
Require ($original.initial.extensionNullPrototype-and$original.initial.extensionsSameModule-and$original.initial.extensionsShared-and$original.initial.cacheShared-and!$original.initial.resolveShared-and!$original.initial.pathsShared-and$original.initial.mainSame) 'Original handler/cache/function identities differ'
Require (($original.initial.extensions-join',')-ceq'.js,.json,.node') 'Original handler list differs from captured Node setup'
foreach($row in $original.initial.extensionFunctions){Require ($row.length-eq2-and$row.ownsPrototype-and$row.prototypeConstructor-and$row.descriptor.enumerable-and$row.descriptor.configurable-and$row.descriptor.writable-and!$row.descriptor.hasGet-and!$row.descriptor.hasSet) 'Original handler descriptors invalid'}
$dispatch=@($original.rows|Where-Object id -CEQ 'extensions-real-dispatch')[0]
Require ($dispatch.status-ceq'returned'-and$dispatch.value.parentIdentity-and$dispatch.value.marker-ceq'real-handler') 'Original actual custom handler dispatch not observed'
$fixtures=ReadJson (Join-Path $run 'fixture-inventory.json')
Require ($fixtures.Count-eq14) 'Original fixture count differs'
foreach($row in $fixtures){Require ((Hash $row.path)-ceq$row.sha256) "Owned fixture changed: $($row.relative)"}
$admission=ReadJson (Join-Path $run 'node-admission.json')
$probe=@($admission.probes)[-1]
Require ($admission.status-ceq'admitted'-and$probe.free_kib-ge16777216-and!$probe.native.Count-and$admission.accepted_elapsed_seconds-lt54-and([DateTimeOffset]$probe.utc)-le([DateTimeOffset]$node.created_utc)) 'Fresh resource admission differs'
$audit=[ordered]@{status='accepted_original_C8_authority';candidate_head=$before.head;raw_bytes=22201;raw_sha256=$rawHash;ordered_rows=36;ordered_builtin_ids=72;seals=$sealReports;original_node_authority_drift=0;current_complete_source_drift=0;current_controls_drift=0;fixture_files=14;node_pid=$node.pid;node_elapsed_seconds=(([DateTimeOffset]$node.completed_utc)-([DateTimeOffset]$node.created_utc)).TotalSeconds;outer_pid=$outer.pid;outer_elapsed_seconds=(([DateTimeOffset]$outer.completed_utc)-([DateTimeOffset]$outer.created_utc)).TotalSeconds;outer_helper_sha256=Hash $outerHelper;outer_helper_only_difference='pwsh.exe-only executable allowlist';recorded_owned_absence=$true;fresh_cim_census_by_auditor=$false;free_kib=$probe.free_kib;preserved_raw_quirks=@('result.node_owner is [empty object, authoritative node receipt]','Equivalent UTC/local-offset completed timestamps in duplicated absence owner');candidate_executed=$false;native_qualified=$false;runtime_restoration_claim=$false;expected_created=$false;audit_jobs_launched=$false}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'raw-audit.json'),($audit|ConvertTo-Json -Depth 12)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
$audit|ConvertTo-Json -Depth 5
