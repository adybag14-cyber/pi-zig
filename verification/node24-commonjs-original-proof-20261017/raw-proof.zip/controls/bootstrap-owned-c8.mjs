// Builtin-only owned-start fence. It imports the unchanged original caller
// only after the owner has bound its live native PID/executable/UTC/command.
import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
if (process.argv.length !== 5 || !/^[A-F0-9]{64}$/.test(process.argv[2]))
  throw new Error('Exact owned C8 bootstrap arguments required');
const token = process.argv[2] + '\n';
if (readFileSync(0, 'utf8') !== token) throw new Error('Owned C8 stdin fence mismatch');
const caller = process.argv[3];
const fixtures = process.argv[4];
process.argv = [process.execPath, caller, fixtures];
await import(pathToFileURL(caller).href);
