Prepared source only. No capture grant is issued and nothing has been executed.

Run-OriginalC8.ps1 adapts the reviewed PureTooling27 full-seal/admission pattern
for one original Node invocation. It requires a separate authorized Root grant,
the clean exact37e27a0d34cd77611363b24c1e309a437e713e98 worktree and all10873
tracked files. Its original subject caller remains exactC8A44058689AEA991DAE49ED8C7014BE1A653CD4580452CC5CDD1EDD41992417.
The supplemental correction caller and all native candidate code are not run.

Actual launcher: byte-original CI607 native_qualification_ci.ps1, providing the
retained native handle, exact live PID/executable/UTC/full-command identity,
60-second Node deadline, owned identity-checked cleanup and ten-second pipe
settlement. Historical Source owner96BE is sealed as an unchanged control only:
it has no stdin parameter, so it is not copied or extended into a new owner.
The builtin-only bootstrap waits for the exact stdin token before importing the
unchanged actual caller, and sets process.argv to [actualNode, caller, fixtures].
No implementation shim, candidate subject, transform, npm or runtime package is
evaluated. This file is a review packet, not authorization to launch anything.

Root must invoke the driver in a dedicated PowerShell -File process. The driver
verifies that form before removing only process-local Node/debug/coverage/config
environment keys with NullString.Value. Neither the caller's shared session nor
ProcessStartInfo.Environment is modified by this reset. The canonical CI owner
still sets its three documented empty Node child values unchanged. C8 then sets
HOME/USERPROFILE to contained synthetic paths, deletes NODE_PATH and calls real
Module._initPaths before any observable lookup lists. Further NODE_PATH values
are synthetic. No inherited environment value is printed or saved.

Before/before-node/after-node/final seals cover full tracked source, its complete
fresh tree, original complete Node1838 and Node1774 inventories and all controls.
Node.exe must match63C259C81E5D472B5F11C8D506070130CB04A1ECF84B80377A34ED6EC9048088.
Fresh16GiB/native-zero admission immediately precedes launch, with the reviewed
bounded54-second RAM readmission/history and immediate foreign-native refusal.
Output and fixtures use a fresh contained non-reparse proof root; no existing
work is removed. Negative branches retain raw output, receipts and final seals.
Root remains responsible for the exclusive serial lease and external owner.

The driver validates terminal zero, empty stderr and all36 input observation ids
in source order, preserving the caller's two intentional typeof-object ids for
null and object inputs. It does not invent expected returned/thrown outcomes.
The ordered builtin arrays must agree with each other and be the genuine frozen
Module export; their observed count is recorded only from actual output. Raw
stdout is copied unchanged to original-output.json only after complete final
postseals and independent owner/descendant/global-native absence pass. No expected
golden is created, and no runtime restoration or native qualification is claimed.

Grant template is false. Root must author a fresh issued/unexpired grant with
its own unique proof directory and 32-byte uppercase hex stdin nonce, bind the
reviewed driver/control hashes, wait for the serial lane and explicitly grant
execution. Preparation and PowerShell syntax parsing are not execution evidence.
