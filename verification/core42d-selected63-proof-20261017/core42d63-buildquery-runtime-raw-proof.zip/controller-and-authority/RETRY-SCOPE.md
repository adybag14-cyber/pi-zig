This is a source-only successor to the actual terminal8da compilation negative.
The historical2203 controller, all original evidence and the failed compile remain unchanged.
Only four invalid JSString storage accesses change, using the actual existing str8/str16 accessors.
The retained caches are UNSEALED private build output from exactly Root190111. They are not authority, and this retry is not fresh-cache reproduction.
Only new-combined BuildQuery may use this exception. Root must explicitly set both execution authority and the separate cache exception true in a fresh grant.
Every output prefix/proof is fresh. Canonical607/39F/53,19546 compiler inventory, full source/control seals, fresh16GiB/native0 admission and1320/30/120/10 deadlines remain unchanged.
All19 groups and original ordered authority remain present; actual metadata/runtime counts remain unknown.
Root must perform its real controller parse check and issue a new serial grant after independent Source review. No execution is authorized by this packet.
CJS, the inert stackTraceLimit proposal, EventStream, defaults and Main remain outside this unit.