import{readFileSync,writeFileSync}from'node:fs';import{createHash}from'node:crypto';
const{AgentSession}=await import('file:///C:/Users/adyba/pi-upstream-source-b06c1f2-20261014/packages/coding-agent/src/core/agent-session.ts');
globalThis.checkCompactionB06=AgentSession.prototype._checkCompaction;
const input=readFileSync(new URL('./sdk-check-compaction-b06-caller-20261014.mjs',import.meta.url));
await import('data:text/javascript,'+encodeURIComponent(input.toString('utf8')));
writeFileSync(process.argv[2],JSON.stringify({sourceHead:'b06c1f2cf1dea6af8748ddeee18c23587d2cb7c6',actualNode:{version:process.version,executable:process.execPath},inputSha256:createHash('sha256').update(input).digest('hex'),cases:checkCompactionB06Rows.length,scope:'Actual checkCompaction body with genuine imported classifiers and estimates; caller-owned receiver collaborators; no full factory qualification',rows:checkCompactionB06Rows},null,2));
