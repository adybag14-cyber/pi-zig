$ErrorActionPreference='Stop'
$taskRoot='C:\Users\adyba\pi-zig\worktrees\root-runtime-owner-compile'
$taskCompiler='C:\Users\adyba\pi-zig\toolchain\zig-x86_64-windows-0.16.0'
$taskZig=Join-Path $taskCompiler 'zig.exe'
$taskOwner='C:\Users\adyba\pi-zig\main\tools\ci\native_qualification_ci.ps1'
$taskMap='C:\Users\adyba\pi-zig\evidence\root-runtime-owner-compile-secondda24-20261017\controller-source-map.json'
$taskHead='da240c54626c13e086a016f803ed5a82050f641b'
if((Get-FileHash $taskOwner).Hash -cne '607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285' -or (Get-FileHash $taskMap).Hash -cne '6B05EAD5FCF62FE6C9866AD45EA3F926C8C7B76A21207E32175A45DC70CB1668' -or (Get-FileHash $taskZig).Hash -cne '086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864'){throw 'Reviewed source/compiler/owner identity differs'}
. $taskOwner
if(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'root-grant.json')){throw 'Refuse proof overwrite'}
function Save-Task($Value,[string]$Name){ConvertTo-Json -InputObject $Value -Depth 8|Set-Content -LiteralPath (Join-Path $PSScriptRoot $Name) -Encoding utf8NoBOM}
function Get-TaskNative {
 $rows=@(Get-CimInstance Win32_Process -OperationTimeoutSec 5 -ErrorAction Stop)
 if(!$rows.Count){throw 'Process census unavailable'}
 @($rows|Where-Object{$_.Name -in @('zig.exe','test.exe','build.exe','llvm-pdbutil.exe') -or ($_.ExecutablePath -and ($_.ExecutablePath -match '\\(?:\.zig-cache|zig-out)\\' -or $_.ExecutablePath.StartsWith($PSScriptRoot+'\',[StringComparison]::OrdinalIgnoreCase)))})
}
function Assert-TaskAdmission {
 $os=Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 5 -ErrorAction Stop
 $roots=@(Get-TaskNative)
 if($null -eq $os.FreePhysicalMemory -or $os.FreePhysicalMemory -lt 16777216 -or $roots.Count){throw 'Fresh16GiB/exclusive compilation admission denied'}
 return @{free_kib=$os.FreePhysicalMemory;minimum_kib=16777216;native_roots=0;utc=[DateTimeOffset]::UtcNow.ToString('o')}
}
function Get-TaskSeal([string]$Name){
 $head=([string](git -C $taskRoot rev-parse HEAD)).Trim()
 if($LASTEXITCODE -ne 0 -or $head -cne $taskHead -or @(git -C $taskRoot status --porcelain).Count){throw 'Clean exact isolated controller source required'}
 $paths=@(git -C $taskRoot ls-files)
 if($LASTEXITCODE -ne 0 -or $paths.Count -ne 10126){throw 'Exact full tracked inventory required'}
 $compiler=Get-CiInventory $taskCompiler
 if($compiler.rows.Count -ne 19546){throw 'Compiler19546 required'}
 $seal=@{head=$head;source=@(Get-CiRows $taskRoot $paths);compiler=@($compiler.rows);driver=(Get-FileHash $PSCommandPath).Hash;owner=(Get-FileHash $taskOwner).Hash;map=(Get-FileHash $taskMap).Hash}
 $pins=(Get-Content $taskMap -Raw|ConvertFrom-Json).files
 if($pins.Count -ne 35){throw 'Exact closed controller35 map required'}
 foreach($pin in $pins){if((Get-FileHash (Join-Path $taskRoot $pin.relative)).Hash -cne $pin.sha256){throw 'Closed production-controller file differs'}}
 Save-Task $seal "$Name.json"
 return $seal
}
$taskBefore=Get-TaskSeal 'before'
$taskAdmission=Assert-TaskAdmission
Save-Task @{authorized=$true;scope='Compilation only of source-reviewed standalone runtime owner; no executable/control/Node/npm/reproduction launch';head=$taskHead;controller_files=35;admission=$taskAdmission;compile_seconds=1320;pipe_settle_seconds=10;issued_utc=[DateTimeOffset]::UtcNow.ToString('o')} 'root-grant.json'
$taskResult=@{status='running';executable_run=$false;controls_run=$false;runtime_restored=$false;postseal=$false;native_roots_after=$null}
try{
 $args=@('build','--build-file','verification/runtime_job_owner/build.zig','-Doptimize=Debug','-j1','--prefix',(Join-Path $PSScriptRoot 'out'),'--cache-dir',(Join-Path $PSScriptRoot 'cache'),'--global-cache-dir',(Join-Path $PSScriptRoot 'global-cache'),'--summary','all')
 [void](Invoke-CiOwnedProcess $taskZig $args $taskRoot (Join-Path $PSScriptRoot 'compile') 1320)
 $taskResult.status='compiled_pending_independent_review'
}catch{$taskResult.status='failed';$taskResult.error=$_.Exception.Message}
finally{
 try{$after=Get-TaskSeal 'final';if(($taskBefore|ConvertTo-Json -Depth 8 -Compress) -cne ($after|ConvertTo-Json -Depth 8 -Compress)){throw 'Full source/compiler/control drift'};$taskResult.postseal=$true}catch{$taskResult.status='failed_postseal';$taskResult.postseal_error=$_.Exception.Message}
 try{$roots=@(Get-TaskNative);$taskResult.native_roots_after=$roots.Count;Save-Task $roots 'native-roots-final.json';if($roots.Count){throw 'Native roots remain'};if(Test-Path (Join-Path $PSScriptRoot 'compile.json')){$record=Get-Content (Join-Path $PSScriptRoot 'compile.json') -Raw|ConvertFrom-Json;$live=@(Get-CimInstance Win32_Process -Filter "ProcessId=$($record.pid)" -OperationTimeoutSec 5 -ErrorAction Stop);Save-Task @{recorded_pid=$record.pid;recorded_birth=$record.created_utc;current=$live;absent=($live.Count -eq 0)} 'owner-absence.json';if($live.Count){throw 'Original PID present or reused; reconcile independently'}}}catch{$taskResult.status='failed_absence';$taskResult.absence_error=$_.Exception.Message}
 if(Test-Path (Join-Path $PSScriptRoot 'out')){Save-Task (Get-CiInventory (Join-Path $PSScriptRoot 'out')) 'artifacts.json'}
 $taskResult.completed_utc=[DateTimeOffset]::UtcNow.ToString('o');Save-Task $taskResult 'result.json'
}
$taskResult|ConvertTo-Json -Depth 5
if($taskResult.status -ne 'compiled_pending_independent_review'){throw 'Standalone owner compile failed'}
