$ErrorActionPreference='Stop'
$evidence='C:\Users\adyba\pi-zig\evidence'
$sourceRoot='C:\Users\adyba\pi-zig\worktrees\root-runtime-owner-compile'
$compilerRoot='C:\Users\adyba\pi-zig\toolchain\zig-x86_64-windows-0.16.0'
$canonical='C:\Users\adyba\pi-zig\main\tools\ci\native_qualification_ci.ps1'
$authorityPath=Join-Path $evidence 'durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
function SHA([string]$p){(Get-FileHash -Algorithm SHA256 -LiteralPath $p).Hash}
function Need($ok,[string]$message){if(!$ok){throw $message}}
function Json([string]$p){Get-Content -Raw -LiteralPath $p|ConvertFrom-Json}
function Save($value,[string]$p){$value|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $p -Encoding utf8NoBOM}
function StreamSHA($stream){$hash=[Security.Cryptography.SHA256]::Create();try{[Convert]::ToHexString($hash.ComputeHash($stream))}finally{$hash.Dispose()}}
Need ((SHA $canonical)-ceq'607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285') 'Canonical CI607 drift'
Need ((SHA $authorityPath)-ceq'DEE259F171F720AB2C08E8DD473975E22C876417CD62E4F016C71A7C662794EB') 'Original compiler authority drift'
$original=Json $authorityPath
Need ($original.inputs.Count-eq19546) 'Original compiler must have19546 rows'
$compilerExpected=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::Ordinal)
foreach($r in $original.inputs){$relative=$r.path.Substring($original.root.Length+1).Replace('\','/');$compilerExpected.Add($relative,$r.sha256)}
$specs=@(
 @{name='first9ab';head='9abf40630710a037faf85ad900279808c21f22c8';errors=4;map=(Join-Path $evidence 'runtime-job-owner-design-20261016/controller-source-corrections-9abf4063-20261017.json')},
 @{name='secondda24';head='da240c54626c13e086a016f803ed5a82050f641b';errors=2;map=(Join-Path $evidence 'root-runtime-owner-compile-secondda24-20261017/controller-source-map.json')},
 @{name='third4b69';head='4b69e7fcf15d01ba60fda763165d367485fccb3f';errors=0;map=(Join-Path $evidence 'root-runtime-owner-compile-third4b69-20261017/controller-source-map.json')}
)
$members=[Collections.Generic.List[object]]::new();$snapshots=@();$auditRuns=@();$local=@();$third=$null
function AddFile([string]$path,[string]$member){$item=Get-Item -LiteralPath $path;[void]$members.Add([ordered]@{member=$member;path=$path;bytes=$item.Length;sha256=(SHA $path);kind='file'})}
[void](New-Item -ItemType Directory -Path (Join-Path $PSScriptRoot 'source-snapshots'))
foreach($spec in $specs){
 $dir=Join-Path $evidence ('root-runtime-owner-compile-'+$spec.name+'-20261017')
 $before=Json (Join-Path $dir 'before.json');$owner=Json (Join-Path $dir 'compile.json');$grant=Json (Join-Path $dir 'root-grant.json');$result=Json (Join-Path $dir 'result.json');$absence=Json (Join-Path $dir 'owner-absence.json');$map=Json $spec.map
 Need ((SHA (Join-Path $dir 'before.json'))-ceq(SHA (Join-Path $dir 'final.json'))) 'Raw complete before/final seals differ'
 Need ($before.head-ceq$spec.head-and$grant.head-ceq$spec.head-and$before.source.Count-eq10126-and$before.compiler.Count-eq19546-and$map.files.Count-eq35) 'Exact head/full inventories/map required'
 foreach($r in $before.compiler){Need ($compilerExpected.ContainsKey($r.relative)-and$compilerExpected[$r.relative]-ceq$r.sha256) ('Original DEE compiler mismatch '+$r.relative)}
 $names=@(git -C $sourceRoot ls-tree -r --name-only $spec.head)
 Need ($LASTEXITCODE-eq0-and$names.Count-eq10126-and@(Compare-Object @($before.source.relative|Sort-Object -CaseSensitive) @($names|Sort-Object -CaseSensitive) -CaseSensitive).Count-eq0) 'Git tree/source inventory mismatch'
 $hashes=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::Ordinal);foreach($r in $before.source){$hashes.Add($r.relative,$r.sha256)}
 foreach($pin in $map.files){Need ($hashes[$pin.relative]-ceq$pin.sha256) 'Controller map/source seal mismatch'}
 Need ($before.driver-ceq(SHA (Join-Path $dir 'Run-Compile.ps1'))-and$before.owner-ceq(SHA $canonical)-and$before.map-ceq(SHA $spec.map)) 'Control seal drift'
 Need ($owner.executable-ceq(Join-Path $compilerRoot 'zig.exe')-and$owner.executable_sha256-ceq'086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864'-and$owner.pid-eq$owner.live_identity.pid-and$owner.executable-ceq$owner.live_identity.executable-and$owner.live_identity.command_line_method-ceq'Win32_Process.CommandLine'-and$owner.live_identity.command_line-ceq('"'+$owner.executable+'" '+($owner.arguments-join' '))-and([DateTimeOffset]$owner.created_utc).UtcDateTime-eq([DateTimeOffset]$owner.live_identity.created_utc).UtcDateTime-and$owner.retained_handle-gt0-and$owner.timeout_seconds-eq1320) 'Owned live identity mismatch'
 $argsExpected=@('build','--build-file','verification/runtime_job_owner/build.zig','-Doptimize=Debug','-j1','--prefix',(Join-Path $dir 'out'),'--cache-dir',(Join-Path $dir 'cache'),'--global-cache-dir',(Join-Path $dir 'global-cache'),'--summary','all')
 Need (($owner.arguments|ConvertTo-Json -Compress)-ceq($argsExpected|ConvertTo-Json -Compress)-and$owner.working_directory-ceq$sourceRoot) 'Compile invocation differs'
 $ageMs=(([DateTimeOffset]$owner.created_utc)-([DateTimeOffset]$grant.admission.utc)).TotalMilliseconds
 Need ($grant.authorized-and$grant.controller_files-eq35-and$grant.compile_seconds-eq1320-and$grant.pipe_settle_seconds-eq10-and$grant.admission.free_kib-ge16777216-and$grant.admission.minimum_kib-eq16777216-and$grant.admission.native_roots-eq0-and$ageMs-ge0-and$ageMs-lt5000) 'Fresh exclusive admission mismatch'
 Need ($result.postseal-and!$result.executable_run-and!$result.controls_run-and!$result.runtime_restored-and$result.native_roots_after-eq0-and$absence.absent-and$absence.current.Count-eq0-and$absence.recorded_pid-eq$owner.pid-and([DateTimeOffset]$absence.recorded_birth).UtcDateTime-eq([DateTimeOffset]$owner.created_utc).UtcDateTime-and@(Json (Join-Path $dir 'native-roots-final.json')).Count-eq0) 'Postseal/absence/scope mismatch'
 $stderr=[IO.File]::ReadAllText((Join-Path $dir 'compile.stderr.log'));$errors=@($stderr-split'\r?\n'|Where-Object {$_-match'^verification.*: error:'})
 Need ($errors.Count-eq$spec.errors) 'Original negative error count mismatch'
 if($spec.errors){Need ($owner.status-ceq'failed'-and$owner.exit_code-eq1-and$result.status-ceq'failed') 'Negative terminal mismatch'}else{Need ($owner.status-ceq'passed'-and$owner.exit_code-eq0-and$result.status-ceq'compiled_pending_independent_review'-and$stderr.Contains('Build Summary: 3/3 steps succeeded')) 'Actual compile success missing';$third=$before}
 foreach($file in Get-ChildItem -LiteralPath $dir -File){AddFile $file.FullName ('runs/'+$spec.name+'/'+$file.Name)}
 if($spec.name-ceq'first9ab'){AddFile $spec.map 'controls/controller-source-map-first9ab.json'}
 $snapshot=Join-Path $PSScriptRoot ('source-snapshots/'+$spec.name+'.zip')
 git -c gc.auto=0 -c maintenance.auto=false -C $sourceRoot archive --format=zip --output=$snapshot $spec.head verification/runtime_job_owner
 Need ($LASTEXITCODE-eq0) 'Read-only Git source archive failed'
 $z=[IO.Compression.ZipFile]::OpenRead($snapshot)
 try{
  $entries=@($z.Entries|Where-Object {!$_.FullName.EndsWith('/')});Need ($entries.Count-eq35) 'Exact source35 archive required'
  foreach($entry in $entries){
   $pin=$map.files|Where-Object {$_.relative-ceq$entry.FullName};Need ($null-ne$pin) 'Unexpected source archive member'
   $stream=$entry.Open();try{$hash=StreamSHA $stream}finally{$stream.Dispose()}
   Need ($hash-ceq$pin.sha256-and$entry.Length-eq$pin.bytes) 'Git snapshot/source byte mismatch'
   [void]$members.Add([ordered]@{member=('source/'+$spec.name+'/'+$entry.FullName);archive=$snapshot;entry=$entry.FullName;bytes=$entry.Length;sha256=$hash;kind='zip-source'})
  }
 }finally{$z.Dispose()}
 $snapshots+=[ordered]@{name=$spec.name;head=$spec.head;files=35;sha256=(SHA $snapshot)}
 foreach($leaf in 'cache','global-cache','out'){
  $path=Join-Path $dir $leaf;$files=if(Test-Path -LiteralPath $path){@(Get-ChildItem -LiteralPath $path -Recurse -File -Force)}else{@()}
  $local+=[ordered]@{run=$spec.name;path=$path;status='LOCAL_NOT_PACKAGED';files=$files.Count;bytes=($files|Measure-Object Length -Sum).Sum}
 }
 if(Test-Path -LiteralPath (Join-Path $dir 'artifacts.json')){
  foreach($artifact in (Json (Join-Path $dir 'artifacts.json')).rows){Need ((SHA $artifact.path)-ceq$artifact.sha256) 'Local artifact drift';$local+=[ordered]@{run=$spec.name;path=$artifact.path;sha256=$artifact.sha256;bytes=(Get-Item -LiteralPath $artifact.path).Length;status='LOCAL_NOT_PACKAGED';executed=$false}}
 }
 $auditRuns+=[ordered]@{name=$spec.name;head=$spec.head;pid=$owner.pid;retained_handle=$owner.retained_handle;created_utc=$owner.created_utc;exit_code=$owner.exit_code;terminal=$owner.status;summary=if($spec.errors){'0/3 failed'}else{'3/3 succeeded'};errors=$errors;source_files=10126;compiler_files=19546;controller_files=35;raw_before_final_byte_drift=0;original_DEE_compiler_drift=0;controller_map_drift=0;control_drift=0;owned_identity_argv_match=$true;free_kib=$grant.admission.free_kib;minimum_free_kib=16777216;admission_age_ms=$ageMs;recorded_owner_absence=$true;recorded_native_roots_after=0;controller_executed=$false;controls_executed=$false;runtime_restored=$false}
}
Need ((git -C $sourceRoot rev-parse HEAD).Trim()-ceq$specs[2].head-and@(git -C $sourceRoot status --porcelain).Count-eq0) 'Current isolated source is not clean exact4b69'
foreach($r in $third.source){Need ((SHA $r.path)-ceq$r.sha256) ('Current isolated source drift '+$r.relative)}
foreach($r in $third.compiler){Need ((SHA $r.path)-ceq$r.sha256) ('Current compiler drift '+$r.relative)}
Need (@(Get-ChildItem -LiteralPath $compilerRoot -Recurse -File -Force).Count-eq19546) 'Current complete compiler inventory drift'
Need (@(Get-ChildItem -LiteralPath $compilerRoot -Recurse -Force|Where-Object {$_.Attributes-band[IO.FileAttributes]::ReparsePoint}).Count-eq0) 'Current compiler reparse point'
$artifacts=Json (Join-Path $evidence 'root-runtime-owner-compile-third4b69-20261017/artifacts.json')
Need ($artifacts.rows.Count-eq2-and$artifacts.rows[0].sha256-ceq'04C5C0D2633758D879CCC67E6DDC460AFBAD6D84BEC55B3A6BD6A504BAC29528'-and$artifacts.rows[1].sha256-ceq'3CB83D0898CD493AA7D208FDB39BB8FFCAE416F22A045964A20F5938E30881FE') 'Exact EXE/PDB receipt differs'
foreach($pair in @(@{file='first-to-second-source.patch';a=0;b=1},@{file='second-to-third-source.patch';a=1;b=2})){
 $path=Join-Path $PSScriptRoot $pair.file
 git -c gc.auto=0 -c maintenance.auto=false -C $sourceRoot diff --binary --full-index --output=$path $specs[$pair.a].head $specs[$pair.b].head -- verification/runtime_job_owner
 Need ($LASTEXITCODE-eq0) 'Corrective source diff failed'
}
Save $local (Join-Path $PSScriptRoot 'LOCAL-artifacts-and-cache.json')
Save ([ordered]@{schema=1;status='accepted_standalone_compile_only';reviewer='/root/minimatch_native_resume';compiled_head=$specs[2].head;runs=$auditRuns;canonical_ci_sha256=(SHA $canonical);original_compiler_authority_sha256=(SHA $authorityPath);current_source_hash_drift=0;current_compiler_hash_drift=0;current_compiler_files=19546;current_compiler_reparse_points=0;source_snapshots=$snapshots;local_artifacts=$artifacts.rows;source_scope='Entire35-file standalone controller closure at each exact run commit; full10126 tracked source inventories in raw seals';controller_executed=$false;controls_executed=$false;runtime_restored=$false;newer_google36_successor_qualified=$false;reviewer_started_compile_or_native_jobs=$false;main_modified=$false;reviewed_utc=[DateTimeOffset]::UtcNow.ToString('o')}) (Join-Path $PSScriptRoot 'independent-audit.json')
$readme=[string]::Join([Environment]::NewLine,@(
 '# Standalone runtime-owner compile proof only','',
 'Exact4b69e7fcf15d01ba60fda763165d367485fccb3f built successfully: actual3/3 Debug build, -j1, owned Zig exit0. The controller executable and controls were not run. Runtime restoration and newer Google36-source successors are not qualified.','',
 'The public ZIP preserves original complete before/final source10126/compiler19546 seals for all three runs; driver/grant/owner/absence/stdout/stderr/result receipts; all35 controller source/control files at each exact Git commit; source maps; corrective diffs; canonical CI607; original DEE compiler authority; and this independent audit/packager. Original statuses remain byte-identical, not relabeled.','',
 'First9ab is a retained negative: four identifier errors (two frame shadows and two resume-keyword accesses), exit1. Secondda24 is a retained negative: discarded error-set capture and comptime check argument, exit1. Third4b69 is the accepted compile-only successor. All runs have identical before/final seals, source35 map identity, fresh16GiB/exclusive admission and recorded owner/global-native absence. Every compiler row matches original DEE19546. Current isolated4b69 source and complete compiler were independently rehashed with zero drift.','',
 'Source snapshots contain the entire standalone35-file compilation source closure, not the whole repository/toolchain. Complete tracked repository and compiler path/hash inventories are retained in original seals. Compiler/library bytes are identified by the full original compiler manifest rather than redistributed.','',
 'Executables, PDBs and build/global caches are LOCAL_NOT_PACKAGED. The LOCAL ledger retains paths/hashes/counts. Local EXE SHA04C5C0D2633758D879CCC67E6DDC460AFBAD6D84BEC55B3A6BD6A504BAC29528; PDB SHA3CB83D0898CD493AA7D208FDB39BB8FFCAE416F22A045964A20F5938E30881FE. Empty original stdout.bin files are raw logs, not executable artifacts.','',
 'Packaging used only read/hash/JSON/Git-archive/ZIP operations. No compiler/controller/Node/reproduction/test/formatter/runtime job ran. Main and historical receipts/local caches were not edited or deleted. This artifact is prepared for Root publication; packaging alone does not publish it.'
))
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'README.md'),$readme+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
AddFile $canonical 'controls/native_qualification_ci.ps1'
AddFile $authorityPath 'controls/original-compiler-DEE259-manifest.json'
foreach($name in 'Audit-And-Package.ps1','independent-audit.json','LOCAL-artifacts-and-cache.json','README.md','first-to-second-source.patch','second-to-third-source.patch'){AddFile (Join-Path $PSScriptRoot $name) $name}
$publicRows=@($members|ForEach-Object{[ordered]@{member=$_.member;bytes=$_.bytes;sha256=$_.sha256}})
Save ([ordered]@{schema=1;files=$publicRows;self_excluded='member-manifest.json';binaries_or_cache_included=$false}) (Join-Path $PSScriptRoot 'member-manifest.json')
AddFile (Join-Path $PSScriptRoot 'member-manifest.json') 'member-manifest.json'
$zipPath=Join-Path $PSScriptRoot 'runtime-owner-compile-first9ab-secondda24-third4b69-raw-proof.zip'
Need (!(Test-Path -LiteralPath $zipPath)) 'Fresh public ZIP required'
$zipStream=[IO.File]::Open($zipPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite,[IO.FileShare]::Read)
$zip=[IO.Compression.ZipArchive]::new($zipStream,[IO.Compression.ZipArchiveMode]::Create,$false)
try{
 foreach($member in $members){
  $entry=$zip.CreateEntry($member.member,[IO.Compression.CompressionLevel]::Optimal);$target=$entry.Open()
  try{
   if($member.kind-ceq'file'){$memberStream=[IO.File]::OpenRead($member.path);try{$memberStream.CopyTo($target)}finally{$memberStream.Dispose()}}
   else{$archive=[IO.Compression.ZipFile]::OpenRead($member.archive);try{$memberStream=$archive.GetEntry($member.entry).Open();try{$memberStream.CopyTo($target)}finally{$memberStream.Dispose()}}finally{$archive.Dispose()}}
  }finally{$target.Dispose()}
 }
}finally{$zip.Dispose()}
$verify=[IO.Compression.ZipFile]::OpenRead($zipPath)
try{
 Need ($verify.Entries.Count-eq$members.Count) 'ZIP member count drift'
 foreach($member in $members){
  Need ($member.member-notmatch'\.(exe|pdb|o|obj|a|lib|dll|so|dylib)$'-and$member.member-notmatch'^runs/[^/]+/(cache|global-cache|out)/') 'Forbidden binary/cache member'
  $entry=$verify.GetEntry($member.member);Need ($null-ne$entry-and$entry.Length-eq$member.bytes) 'ZIP member identity/size drift'
  $stream=$entry.Open();try{$hash=StreamSHA $stream}finally{$stream.Dispose()};Need ($hash-ceq$member.sha256) 'ZIP member hash drift'
  if($member.kind-ceq'file'){Need ((SHA $member.path)-ceq$member.sha256) 'Original file changed during packaging'}
 }
}finally{$verify.Dispose()}
Save ([ordered]@{status='verified_public_raw_compile_only_package';zip=$zipPath;zip_sha256=(SHA $zipPath);zip_bytes=(Get-Item -LiteralPath $zipPath).Length;members=$members.Count;controller_source_members=105;member_hash_or_size_drift=0;original_file_hash_drift=0;forbidden_binary_or_cache_members=0;binary_and_cache_status='LOCAL_NOT_PACKAGED';compiled_head=$specs[2].head;controller_run=$false;controls_run=$false;runtime_restored=$false;newer_google36_qualified=$false;reviewer_jobs_started=0;main_modified=$false}) (Join-Path $PSScriptRoot 'package-verification.json')
Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'package-verification.json')
