$ErrorActionPreference='Stop'
$taskRoot='C:\Users\adyba\pi-zig\worktrees\root-tla-qualification'
$taskProof=$PSScriptRoot
$taskCompiler='C:\Users\adyba\pi-zig\toolchain\zig-x86_64-windows-0.16.0'
$taskZig=Join-Path $taskCompiler 'zig.exe'
$taskCi=Join-Path $taskRoot 'tools\ci\native_qualification_ci.ps1'
$taskProtocol=Join-Path $taskRoot 'tools\ci\Invoke-NativeTestProtocol.ps1'
. $taskCi
. $taskProtocol
if(Test-Path -LiteralPath (Join-Path $taskProof 'grant.json')){throw 'Refuse focused proof overwrite'}
function Get-TaskNativeRoots {
 @(Get-CimInstance Win32_Process | Where-Object {
  $_.Name -in @('zig.exe','build.exe','test.exe') -or
  ($_.ExecutablePath -and ($_.ExecutablePath -match '\\(?:\.zig-cache|zig-out)\\' -or $_.ExecutablePath.StartsWith($taskProof+'\',[StringComparison]::OrdinalIgnoreCase)))
 })
}
function Assert-TaskAdmission {
 $taskOs=Get-CimInstance Win32_OperatingSystem
 $taskRoots=Get-TaskNativeRoots
 if($taskOs.FreePhysicalMemory -lt 16777216 -or $taskRoots.Count){throw 'Fresh16GiB and zero other native roots required'}
 return [ordered]@{free_kib=$taskOs.FreePhysicalMemory;minimum_kib=16777216;native_roots=0;utc=[DateTimeOffset]::UtcNow.ToString('o')}
}
function Get-TaskSeal {
 param([string]$Name)
 $taskSourcePaths=@(git -C $taskRoot ls-files)
 if($LASTEXITCODE -ne 0){throw 'Candidate tracked inventory unavailable'}
 $taskCompilerInventory=Get-CiInventory $taskCompiler
 if($taskCompilerInventory.rows.Count -ne 19546){throw 'Complete compiler19546 inventory required'}
 $taskSeal=[ordered]@{
  candidate_head=([string](git -C $taskRoot rev-parse HEAD)).Trim()
  source=@(Get-CiRows $taskRoot $taskSourcePaths)
  compiler=@($taskCompilerInventory.rows)
  driver_sha256=(Get-FileHash -LiteralPath $PSCommandPath).Hash
 }
 $taskSeal|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $taskProof "$Name.json") -Encoding utf8NoBOM
 return $taskSeal
}
function Assert-TaskSeal {
 param($Actual,$Expected)
 if($Actual.candidate_head -cne $Expected.candidate_head -or $Actual.driver_sha256 -cne $Expected.driver_sha256){throw 'Candidate/driver changed'}
 foreach($taskGroup in @('source','compiler')){
  $taskExpectedRows=@($Expected[$taskGroup]|ForEach-Object{$_.relative+' '+$_.sha256})
  $taskActualRows=@($Actual[$taskGroup]|ForEach-Object{$_.relative+' '+$_.sha256})
  if(@(Compare-Object $taskExpectedRows $taskActualRows).Count){throw "$taskGroup hash or inventory drift"}
 }
}
if(@(git -C $taskRoot status --porcelain).Count){throw 'Clean exact Root qualification composition required'}
if((Get-FileHash -LiteralPath (Join-Path $taskRoot 'vendor\quickjs\quickjs.c')).Hash -cne 'F06F1F2A23CB024FF381DB02CF43D1C249DE5848689D005918F7D1FB80BE9B5E'){throw 'Reviewed C identity differs'}
if((Get-FileHash -LiteralPath (Join-Path $taskRoot 'vendor\quickjs\quickjs.h')).Hash -cne '341CF06F8041B8311D49767026C85C7B859BCFEE3088380F3FFE6D77527052AB'){throw 'Reviewed header differs'}
if((Get-FileHash -LiteralPath $taskZig).Hash -cne '086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864'){throw 'Pinned Zig0.16 identity differs'}
$taskBefore=Get-TaskSeal 'before'
$taskGrant=[ordered]@{scope='Root focused self-contained START/resumed TLA tests; no deleted runtime/Node/Source capture or default application qualification';source_head=$taskBefore.candidate_head;source_files=$taskBefore.source.Count;compiler_files=$taskBefore.compiler.Count;ci_owner_sha256=(Get-FileHash -LiteralPath $taskCi).Hash;protocol_sha256=(Get-FileHash -LiteralPath $taskProtocol).Hash;groups=@(@{name='start';metadata=8},@{name='resumed';metadata=7});runtime_scope='Actual --listen=- run_test protocol, every selected index, flags allzero, 120s total per group, owner pipe settle10s';admission=$null;status='pending'}
try{$taskGrant.admission=Assert-TaskAdmission;$taskGrant.status='admitted'}catch{$taskGrant.status='admission_denied';$taskGrant.error=$_.Exception.Message}
$taskGrant|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $taskProof 'grant.json') -Encoding utf8NoBOM
if($taskGrant.status -cne 'admitted'){throw 'Focused native grant admission denied'}
$taskResult=[ordered]@{status='running';groups=@();postseal=$false;native_roots_after=$null}
try {
 foreach($taskGroup in @(@{name='start';step='build-native-tla-fatal-delivery';count=8},@{name='resumed';step='build-native-tla-resumed-fatal-delivery';count=7})){
  $null=Assert-TaskAdmission
  $taskPrefix=Join-Path $taskProof ($taskGroup.name+'-out')
  $taskArgs=@('build',$taskGroup.step,'-Doptimize=Debug','-Duse-llvm=true','-j1','--prefix',$taskPrefix,'--cache-dir','C:\Users\adyba\pi-zig\evidence\root-tla-focused-20261016\cache','--global-cache-dir','C:\Users\adyba\pi-zig\evidence\root-tla-focused-20261016\global-cache','--summary','all')
  $taskCompile=Invoke-CiOwnedProcess $taskZig $taskArgs $taskRoot (Join-Path $taskProof ($taskGroup.name+'-compile')) 1320
  if((Get-TaskNativeRoots).Count){throw 'Native roots remain after compile'}
  $taskBinary=Join-Path $taskPrefix 'bin\test.exe'
  $taskMetadata=Read-CiTestMetadata $taskBinary $taskRoot (Join-Path $taskProof ($taskGroup.name+'-metadata')) $taskGroup.count
  $taskMetadata|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $taskProof ($taskGroup.name+'-selected-tests.json')) -Encoding utf8NoBOM
  $null=Assert-TaskAdmission
  $taskRuntime=Invoke-NativeTestProtocol $taskBinary $taskRoot (Join-Path $taskProof ($taskGroup.name+'-runtime')) $taskMetadata.tests.Count
  $taskResult.groups+=,[ordered]@{name=$taskGroup.name;compile=$taskCompile;metadata=$taskMetadata;runtime=$taskRuntime}
  Assert-TaskSeal (Get-TaskSeal ($taskGroup.name+'-after')) $taskBefore
 }
 $taskResult.status='passed'
}catch{$taskResult.status='failed';$taskResult.error=$_.Exception.Message}
finally {
 try{Assert-TaskSeal (Get-TaskSeal 'final') $taskBefore;$taskResult.postseal=$true}catch{$taskResult.status='failed_postseal';$taskResult.postseal_error=$_.Exception.Message}
 $taskResult.native_roots_after=(Get-TaskNativeRoots).Count
 if($taskResult.native_roots_after){$taskResult.status='failed_absence'}
 $taskResult.completed_utc=[DateTimeOffset]::UtcNow.ToString('o')
 $taskResult|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $taskProof 'result.json') -Encoding utf8NoBOM
}
$taskResult|ConvertTo-Json -Depth 12
if($taskResult.status -cne 'passed'){throw 'Focused TLA gate failed'}
