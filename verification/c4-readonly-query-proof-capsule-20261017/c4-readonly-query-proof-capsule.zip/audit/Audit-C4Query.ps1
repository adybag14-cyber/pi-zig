$ErrorActionPreference='Stop'
$container='C:\Users\adyba\pi-zig'
$base=Join-Path $container 'evidence/root-module-graph-tla-query-fixture-fix-native-prepared-20261017'
$buildName='root-module-tla-fixturefix-build-query-20261017-151452'
$runName='root-module-tla-fixturefix-runtime-20261017-152118'
$build=Join-Path $base $buildName;$run=Join-Path $base $runName
function J([string]$Path){Get-Content -LiteralPath $Path -Raw|ConvertFrom-Json}
function HashFile([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash}
function Need([bool]$Condition,[string]$Message){if(!$Condition){throw $Message}}
function Keys($Rows,[string]$Key='relative'){@($Rows|ForEach-Object{$_.$Key+' '+$_.sha256})}
function EqualRows($Left,$Right,[string]$Name){Need (@(Compare-Object @($Left) @($Right) -CaseSensitive).Count-eq0) "$Name drift"}
$source=Join-Path $container 'worktrees/runtime-module-tla-query-fixture-fix'
$before=J (Join-Path $build 'before.json');$compiled=J (Join-Path $build 'result.json');$runtime=J (Join-Path $run 'result.json')
$phases=@(foreach($dir in @($build,$run)){
 foreach($phase in @('before','between','final')){
  $seal=J (Join-Path $dir "$phase.json")
  Need ($seal.candidate_head-ceq'b814eac64992b3dfbdbb7cbd9c3d469b610e9682'-and$seal.source.Count-eq10666-and$seal.compiler.Count-eq19546-and$seal.controls.Count-eq$(if($dir-ceq$build){16}else{30})) 'Full counts/head'
  EqualRows (Keys $seal.source) (Keys $before.source) 'Full10666 crossphase source'
  EqualRows (Keys $seal.compiler) (Keys $before.compiler) 'Full19546 crossphase compiler'
  EqualRows (Keys $seal.controls 'path') (Keys (J (Join-Path $dir 'before.json')).controls 'path') 'Full16 phase controls'
  [ordered]@{run=[IO.Path]::GetFileName($dir);phase=$phase;source=10666;compiler=19546;controls=$seal.controls.Count;drift=0;sha256=HashFile (Join-Path $dir "$phase.json")}
 }
})
$authorityPath=Join-Path $container 'evidence/durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
Need ((HashFile $authorityPath)-ceq'DEE259F171F720AB2C08E8DD473975E22C876417CD62E4F016C71A7C662794EB') 'Original compiler authority'
$authority=J $authorityPath
EqualRows @($authority.inputs|ForEach-Object{[IO.Path]::GetRelativePath($authority.root,$_.path).Replace('\','/')+' '+$_.sha256}) @($before.compiler|ForEach-Object{$_.relative.Replace('\','/')+' '+$_.sha256}) 'Original DEE compiler'
foreach($row in @($before.source)+@($before.compiler)){Need ((HashFile $row.path)-ceq$row.sha256) "Current sealed file $($row.relative)"}
foreach($dir in @($build,$run)){foreach($row in (J (Join-Path $dir 'before.json')).controls){Need ((HashFile $row.path)-ceq$row.sha256) "Current control $($row.path)"}}
Need ((git -C $source rev-parse HEAD)-ceq'b814eac64992b3dfbdbb7cbd9c3d469b610e9682'-and@(git -C $source status --porcelain).Count-eq0) 'Current exact source/clean'
$allow=J (Join-Path $base 'metadata-allowlist.json');$expected=@($allow.names)+@($allow.optional_only)
$bytes=[IO.File]::ReadAllBytes((Join-Path $build 'metadata.stdout.bin'));$position=0;$names=@();$version=$null
while($position-lt$bytes.Length){
 Need ($bytes.Length-$position-ge8) 'Metadata frame header';$tag=[BitConverter]::ToUInt32($bytes,$position);$length=[BitConverter]::ToUInt32($bytes,$position+4);$position+=8;Need ($length-le$bytes.Length-$position) 'Metadata frame body'
 if($tag-eq0){Need ($null-eq$version) 'Version uniqueness';$version=[Text.Encoding]::UTF8.GetString($bytes,$position,$length)}
 elseif($tag-eq3){$stringBytes=[BitConverter]::ToUInt32($bytes,$position);$count=[BitConverter]::ToUInt32($bytes,$position+4);Need ($count-eq15-and$length-eq8+8*$count+$stringBytes) 'Actual15 metadata shape';$table=$position+8+8*$count;for($index=0;$index-lt$count;$index++){$offset=[BitConverter]::ToUInt32($bytes,$position+8+4*$index);Need ([BitConverter]::ToUInt32($bytes,$position+8+4*$count+4*$index)-eq0-and$offset-lt$stringBytes) 'Actual metadata panic/offset';$end=$offset;while($end-lt$stringBytes-and$bytes[$table+$end]-ne0){$end++};Need ($end-lt$stringBytes) 'Terminated actual name';$names+=[Text.Encoding]::UTF8.GetString($bytes,$table+$offset,$end-$offset)}}else{throw 'Unexpected metadata protocol tag'};$position+=$length
}
Need ($version-ceq'0.16.0'-and($names-join"`0")-ceq($expected-join"`0")) 'Original14 plus storage exact ordered actualmetadata'
foreach($dir in @($build,$run)){$selected=J (Join-Path $dir 'selected-tests.json');Need ($selected.actual_count-eq15-and($selected.tests-join"`0")-ceq($names-join"`0")) 'Actual selected metadata binding'}
$raw=[IO.File]::ReadAllBytes((Join-Path $run 'runtime.stdout.bin'));$position=0;$started=0;$results=@();$version=$null
while($position-lt$raw.Length){Need ($raw.Length-$position-ge8) 'Runtime header';$tag=[BitConverter]::ToUInt32($raw,$position);$length=[BitConverter]::ToUInt32($raw,$position+4);$position+=8;Need ($length-le$raw.Length-$position) 'Runtime body';switch($tag){0{Need ($null-eq$version) 'Runtime version uniqueness';$version=[Text.Encoding]::UTF8.GetString($raw,$position,$length)}5{Need ($length-eq0-and$started-eq$results.Count) 'Actual ordered start';$started++}4{Need ($length-eq12-and$started-eq$results.Count+1) 'Actual result followsstart';$index=[BitConverter]::ToUInt32($raw,$position);$flags=[BitConverter]::ToUInt64($raw,$position+4);Need ($index-eq$results.Count-and$flags-eq0) 'Actual ordered zero flags';$results+=[ordered]@{index=$index;flags=$flags}}default{throw 'Unexpected runtime/log protocol frame'}};$position+=$length}
Need ($version-ceq'0.16.0'-and$started-eq15-and$results.Count-eq15) 'Every actual15 completed'
$protocol=J (Join-Path $run 'runtime.results.json');Need ($protocol.status-ceq'passed'-and$protocol.started-eq15-and$protocol.completed-eq15-and$protocol.failed_or_skipped_or_logged_or_leaked-eq0) 'Saved protocol receipt'
foreach($dir in @($build,$run)){
 foreach($phase in @('between','final')){$artifact=J (Join-Path $dir "artifacts-$phase.json");Need (!$artifact.path_drift.Count-and!$artifact.hash_drift.Count-and$artifact.rows.Count-eq2) 'Full artifact seal';foreach($row in $artifact.rows){Need ((HashFile $row.path)-ceq$row.sha256) 'Current artifact hash'}}
 $result=J (Join-Path $dir 'result.json');Need ($result.postseal-and$result.between_seal-and$result.owner_absence_verified-and$result.native_roots_after-eq0-and$result.actual_metadata_count-eq15) 'Terminal fullpost/absence gates'
 $absence=@(J (Join-Path $dir 'owner-absence.json'));foreach($entry in $absence){Need ($entry.absent-and!$entry.current.Count) 'Owned recorded absence'}
 $census=J (Join-Path $dir 'process-census-final.json');Need (!$census.candidates.Count) 'Recorded final native census'
 foreach($row in $absence){$owner=J $row.owner_receipt;Need ($owner.status-ceq'passed'-and$owner.exit_code-eq0-and$owner.pid-eq$owner.live_identity.pid-and([DateTimeOffset]$owner.created_utc)-eq([DateTimeOffset]$owner.live_identity.created_utc)-and$owner.executable-ceq$owner.live_identity.executable-and$owner.live_identity.command_line-ceq('"'+$owner.executable+'" '+($owner.arguments-join' '))) 'Owner live/terminal identity';Need ((HashFile $owner.executable)-ceq$owner.executable_sha256) 'Owner image still exact'}
 $name=[IO.Path]::GetFileName($dir);$outer=J (Join-Path $base "$name-outer.json");$outerAbsent=J (Join-Path $base "$name-outer-absence.json");Need ($outer.status-ceq'passed'-and$outer.exit_code-eq0-and$outerAbsent.pid-eq$outer.pid-and$outerAbsent.fresh_pid_present-eq0-and$outerAbsent.owner_sha256-ceq(HashFile (Join-Path $base "$name-outer.json"))) 'Outer terminal+absence';Need ($outer.pid-eq$outer.live_identity.pid-and([DateTimeOffset]$outer.created_utc)-eq([DateTimeOffset]$outer.live_identity.created_utc)-and$outer.live_identity.command_line-ceq('"'+$outer.executable+'" '+($outer.arguments-join' '))) 'Outer live identity';Need ((HashFile (Join-Path $base "$name-outer.stdout.bin"))-ceq(HashFile (Join-Path $dir 'result.json'))-and(Get-Item -LiteralPath (Join-Path $base "$name-outer.stderr.log")).Length-eq0) 'Outer rawstreams'
 $grant=J (Join-Path $dir 'root-grant.json');Need ($grant.authorized-and$grant.candidate_head-ceq'b814eac64992b3dfbdbb7cbd9c3d469b610e9682'-and$grant.driver_sha256-ceq'FE730D4AB2F43CCCD82BDBDD001BB5C4C534C9251602276689EE9EAEA5B0E5ED'-and([DateTimeOffset]$outer.created_utc)-ge([DateTimeOffset]$grant.issued_utc)-and([DateTimeOffset]$outer.created_utc)-lt([DateTimeOffset]$grant.expires_utc)) 'Actual issued grant'
 foreach($file in Get-ChildItem -LiteralPath $dir -Filter '*admission.json'){$probe=J $file.FullName;Need ($probe.free_kib-ge16777216-and$probe.native_roots-eq0-and!$probe.native_candidates.Count) 'Fresh resource admission'}
}
$runtimeGrant=J (Join-Path $run 'root-grant.json');foreach($property in $runtimeGrant.build_inputs.PSObject.Properties){Need ((HashFile (Join-Path $build $property.Name))-ceq$property.Value) 'Runtime exact build proof binding'}
Need ($compiled.status-ceq'build_query_passed'-and$runtime.status-ceq'runtime_passed') 'BuildQuery and RuntimeOnly success'
foreach($path in @((Join-Path $build 'metadata.stderr.log'),(Join-Path $run 'runtime.stderr.log'))){Need ((Get-Item -LiteralPath $path).Length-eq0) 'No VM stderr logs'}
$receipt=[ordered]@{status='accepted_exact_C4_b814_build_metadata_and_all15_runtime_controls';source_head='b814eac64992b3dfbdbb7cbd9c3d469b610e9682';binary_sha256='8A8296AD9DFE0C5AA0DF2F8D6A5291505ABAD63F28F26E60483C2099A4F31E14';pdb_sha256='0EED8F08E9686F3A76505C4843884A3FA7A1E86574589A36EF04D4694526C9E8';actual_ordered_metadata=$names;actual_starts=15;actual_results=$results;logged_skipped_failed_leaked=0;full_seals=$phases;compiler_original_DEE19546_matched=$true;current_full_source_compiler_controls_artifacts_rehashed_drift=0;recorded_native_and_owned_absence=$true;auditor_fresh_process_census=$false;compile_pid=57380;metadata_pid=53160;runtime_pid=54652;outer_runtime_pid=12104;raw_compile_array_quirk_preserved=$true;raw_runtime_stdout_sha256=HashFile (Join-Path $run 'runtime.stdout.bin');raw_metadata_stdout_sha256=HashFile (Join-Path $build 'metadata.stdout.bin');scope='Finite actual readonly Module Graph TLA query+C4 fixture correction, not whole runtime/default SDK/CLI/Jiti qualification';reviewer_native_Node_compiler_AST_jobs=$false;reviewer_Main_product_edits=$false}
$receiptPath=Join-Path $PSScriptRoot 'raw-audit.json';[IO.File]::WriteAllText($receiptPath,($receipt|ConvertTo-Json -Depth 12)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
[ordered]@{status=$receipt.status;receipt=$receiptPath;sha256=HashFile $receiptPath}|ConvertTo-Json
