param([Parameter(Mandatory)][ValidateSet('BuildQuery','RuntimeOnly')][string]$Phase,[Parameter(Mandatory)][string]$RootGrantPath,[Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9][A-Za-z0-9._-]{0,100}$')][string]$RunId)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$true
$taskContainer='C:\Users\adyba\pi-zig'
$taskRoot=Join-Path $taskContainer 'worktrees/runtime-module-tla-query-fixture-fix'
$taskExpectedHead='b814eac64992b3dfbdbb7cbd9c3d469b610e9682'
$taskProof=Join-Path $PSScriptRoot $RunId
$taskCompiler=Join-Path $taskContainer 'toolchain/zig-x86_64-windows-0.16.0'
$taskZig=Join-Path $taskCompiler 'zig.exe'
$taskGit='C:\Program Files\Git\cmd\git.exe'
$taskCi=Join-Path $taskRoot 'tools/ci/native_qualification_ci.ps1'
$taskProtocol=Join-Path $taskRoot 'tools/ci/Invoke-NativeTestProtocol.ps1'
$taskClassifier=Join-Path $PSScriptRoot 'Get-ModelsNativeCandidates.ps1'
$taskOuter=Join-Path $PSScriptRoot 'outer-owned-process.ps1'
$taskAuthority=Join-Path $PSScriptRoot 'metadata-allowlist.json'
$taskCompilerAuthority=Join-Path $taskContainer 'evidence/durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
$taskDriverHash=(Get-FileHash -LiteralPath $PSCommandPath).Hash
$taskGrant=Get-Content -Raw -LiteralPath $RootGrantPath|ConvertFrom-Json
$taskNow=[DateTimeOffset]::UtcNow
if($taskGrant.authorized -isnot [bool] -or !$taskGrant.authorized -or $taskGrant.scope -cne 'ROOT-MODULE-GRAPH-TLA-QUERY-SERIAL' -or $taskGrant.phase -cne $Phase -or $taskGrant.run_id -cne $RunId -or $taskGrant.candidate_head -cne $taskExpectedHead -or $taskGrant.driver_sha256 -cne $taskDriverHash){throw 'Exact separate-phase Root grant required'}
$taskIssued=[DateTimeOffset]$taskGrant.issued_utc;$taskExpires=[DateTimeOffset]$taskGrant.expires_utc
if($taskIssued -gt $taskNow -or $taskExpires -lt $taskNow -or $taskExpires -le $taskIssued -or ($taskExpires-$taskIssued).TotalSeconds -gt 300){throw 'Fresh initial Root grant bounded to300s required'}
if($taskGrant.cache_mode -cne 'fresh'){throw 'Only fresh private build caches admitted by this packet'}
$taskPins=@{}
$taskPins[$taskCi]='607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285'
$taskPins[$taskProtocol]='39F273D35A5B28E9D60FBE93355828314458A67FB472D60E0A8A6D4DD1FB704D'
$taskPins[$taskClassifier]='3413A2A50B4D4C3BFF8709E4EE08C76BE449AAB1EDCB1E0C5C167DC7A804E301'
$taskPins[$taskOuter]='53E522C8397B5F7EE9AF721D8160B227E97FADA4E1DA36A938656E2403D56B6B'
$taskPins[$taskAuthority]='EB2C523037ACE034E851764273782EF18E168265AF7EF7CD2D8DEFB5F61A57EF'
foreach($taskPin in $taskPins.GetEnumerator()){if((Get-FileHash -LiteralPath $taskPin.Key).Hash -cne $taskPin.Value){throw 'Canonical owner/protocol/census/outer/authority drift'}}
. $taskCi
. $taskProtocol
. $taskClassifier
$taskAuthorityValue=Get-Content -Raw -LiteralPath $taskAuthority|ConvertFrom-Json
$taskNamed=@($taskAuthorityValue.names)
$taskAllowedAnonymous='extensions.native_durable_storage.test_0'
if($taskNamed.Count -ne 14 -or @($taskNamed|Sort-Object -Unique -CaseSensitive).Count -ne 14 -or $taskAuthorityValue.optional_only -cne $taskAllowedAnonymous){throw 'Frozen14 distinct named tests plus only exact optional storage test required'}
New-Item -ItemType Directory -Path $taskProof -ErrorAction Stop|Out-Null
Copy-Item -LiteralPath $RootGrantPath -Destination (Join-Path $taskProof 'root-grant.json') -ErrorAction Stop
$taskAdmissionHistory=[Collections.Generic.List[object]]::new()
$taskBuildInputPaths=@()

function Write-TaskJson {param($Value,[string]$Name) ConvertTo-Json -InputObject $Value -Depth 16|Set-Content -LiteralPath (Join-Path $taskProof $Name) -Encoding utf8NoBOM}
function Get-TaskCensus {
 $taskRows=@(Get-CimInstance Win32_Process -OperationTimeoutSec 3 -ErrorAction Stop)
 if(!$taskRows.Count){throw 'Successful nonempty process census required'}
 return @{rows=$taskRows;candidates=@(Get-ModelsNativeCandidates -Rows $taskRows -Container $taskContainer)}
}
function Assert-TaskAdmission {
 $taskWait=[Diagnostics.Stopwatch]::StartNew()
 do {
  $taskOs=@(Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 3 -ErrorAction Stop)
  if($taskOs.Count -ne 1 -or $null -eq $taskOs[0].FreePhysicalMemory){throw 'One OS row with available RAM required'}
  $taskCensus=Get-TaskCensus
  $taskProbe=[ordered]@{free_kib=[long]$taskOs[0].FreePhysicalMemory;minimum_kib=16777216;native_roots=$taskCensus.candidates.Count;native_candidates=$taskCensus.candidates;census_count=$taskCensus.rows.Count;utc=[DateTimeOffset]::UtcNow.ToString('o')}
  $taskAdmissionHistory.Add($taskProbe)
  if($taskCensus.candidates.Count){throw 'Another native candidate prevents serial admission'}
  if($taskWait.Elapsed.TotalSeconds -ge 54){throw 'Fresh16GiB admission expired after bounded54s'}
  if($taskProbe.free_kib -ge 16777216){return $taskProbe}
  $taskRemainingMs=54000-$taskWait.ElapsedMilliseconds
  if($taskRemainingMs -gt 0){Start-Sleep -Milliseconds ([int][Math]::Min(1000,$taskRemainingMs))}
 }while($true)
}
function Get-TaskSeal {
 param([string]$Name)
 $taskPaths=@(& $taskGit -c core.fsmonitor=false -c core.hooksPath=NUL -C $taskRoot ls-files)
 if($LASTEXITCODE -ne 0 -or $taskPaths.Count -ne 10666 -or @($taskPaths|Sort-Object -Unique -CaseSensitive).Count -ne 10666){throw 'Exact full10666 tracked candidate paths required'}
 $taskHead=([string](& $taskGit -c core.fsmonitor=false -c core.hooksPath=NUL -C $taskRoot rev-parse HEAD)).Trim()
 if($LASTEXITCODE -ne 0 -or $taskHead -cne $taskExpectedHead){throw 'Exact query candidate head differs'}
 $taskStatus=@(& $taskGit -c core.fsmonitor=false -c core.hooksPath=NUL -C $taskRoot status --porcelain)
 if($LASTEXITCODE -ne 0 -or $taskStatus.Count){throw 'Clean exact candidate required'}
 $taskCompilerInventory=Get-CiInventory $taskCompiler
 if($taskCompilerInventory.rows.Count -ne 19546){throw 'Complete compiler19546 required'}
 if((Get-FileHash -LiteralPath $taskCompilerAuthority).Hash -cne 'DEE259F171F720AB2C08E8DD473975E22C876417CD62E4F016C71A7C662794EB'){throw 'Immutable compiler authority differs'}
 $taskOriginal=Get-Content -Raw -LiteralPath $taskCompilerAuthority|ConvertFrom-Json
 $taskAuthorityRows=@($taskOriginal.inputs|ForEach-Object {if(!$_.path.StartsWith($taskOriginal.root+'\',[StringComparison]::Ordinal)){throw 'Compiler authority path escapes original root'};$_.path.Substring($taskOriginal.root.Length+1).Replace([char]92,[char]47)+' '+$_.sha256})
 $taskCompilerRows=@($taskCompilerInventory.rows|ForEach-Object {$_.relative.Replace([char]92,[char]47)+' '+$_.sha256})
 if($taskAuthorityRows.Count -ne 19546 -or @($taskAuthorityRows|Sort-Object -Unique -CaseSensitive).Count -ne 19546 -or @($taskCompilerRows|Sort-Object -Unique -CaseSensitive).Count -ne 19546 -or @(Compare-Object $taskAuthorityRows $taskCompilerRows -CaseSensitive).Count){throw 'Full compiler differs from original19546 authority'}
 $taskCPins=@{'vendor/quickjs/quickjs.c'='650336151E9AF8080931C85CB64CDDC5A432247921B5A8916E10B4F6FA819692';'vendor/quickjs/quickjs.h'='B87AD9DD32E266C02F9EF9FE6FFF8A2C57A2A96AB5E1A0187F647DE2DE489E29';'tools/ci/native_qualification_ci.ps1'='607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285'}
 foreach($taskPin in $taskCPins.GetEnumerator()){if((Get-FileHash -LiteralPath (Join-Path $taskRoot $taskPin.Key)).Hash -cne $taskPin.Value){throw "Exact reviewed C83/owner pin differs: $($taskPin.Key)"}}
 $taskControlPaths=@($PSCommandPath,$taskCi,$taskProtocol,$taskAuthority,$taskClassifier,$taskOuter,$taskCompilerAuthority,(Join-Path $PSScriptRoot 'README.md'),(Join-Path $PSScriptRoot 'build-query-grant.template.json'),(Join-Path $PSScriptRoot 'runtime-only-grant.template.json'),(Join-Path $PSScriptRoot 'prepared-manifest.json'),(Join-Path $taskProof 'root-grant.json'),(Join-Path $taskContainer '.pi-zig-workspace.json'),(Join-Path $taskContainer 'path-relocations.json'),$taskGit,'C:\Program Files\PowerShell\7\pwsh.exe')
 if($Phase -ceq 'RuntimeOnly'){$taskControlPaths+=@($taskBuildInputPaths)}
 $taskSeal=[ordered]@{candidate_head=$taskHead;source=@(Get-CiRows $taskRoot $taskPaths);compiler=@($taskCompilerInventory.rows);controls=@($taskControlPaths|ForEach-Object {[ordered]@{path=$_;sha256=(Get-FileHash -LiteralPath $_).Hash}});expected_absences=@();utc=[DateTimeOffset]::UtcNow.ToString('o')}
 Write-TaskJson $taskSeal "$Name.json";return $taskSeal
}
function Assert-TaskSeal {
 param($Actual,$Expected)
 if($Actual.candidate_head -cne $Expected.candidate_head){throw 'Source head drift'}
 foreach($taskGroup in @('source','compiler','controls')){
  $taskLeft=@($Expected[$taskGroup]|ForEach-Object {$(if($taskGroup -ceq 'controls'){$_.path}else{$_.relative})+' '+$_.sha256})
  $taskRight=@($Actual[$taskGroup]|ForEach-Object {$(if($taskGroup -ceq 'controls'){$_.path}else{$_.relative})+' '+$_.sha256})
  if(@(Compare-Object $taskLeft $taskRight -CaseSensitive).Count){throw "$taskGroup inventory/hash drift"}
 }
}
function Read-TaskActualMetadata {
 param([string]$Binary,[byte[]]$taskBytes,[string]$BinaryHash)
 # Same query/exit bytes and canonical CI607 owner as Read-CiTestMetadata.
 # Discover each actual count; optional anonymous entries are never assumed.

 $taskOffset=0;$taskVersion=$null;$taskNames=$null
 while($taskOffset -lt $taskBytes.Length){
  if($taskBytes.Length-$taskOffset -lt 8){throw 'Truncated metadata header'}
  $taskTag=[BitConverter]::ToUInt32($taskBytes,$taskOffset);$taskLength=[BitConverter]::ToUInt32($taskBytes,$taskOffset+4);$taskOffset+=8
  if($taskLength -gt 1MB -or $taskLength -gt $taskBytes.Length-$taskOffset){throw 'Invalid metadata body length'}
  if($taskTag -eq 0){if($null -ne $taskVersion -or $null -ne $taskNames){throw 'Duplicate or late metadata version'};$taskVersion=[Text.Encoding]::UTF8.GetString($taskBytes,$taskOffset,$taskLength)}
  elseif($taskTag -eq 3){
   if($taskVersion -cne '0.16.0' -or $null -ne $taskNames -or $taskLength -lt 8){throw 'Unexpected metadata array'}
   $taskStrings=[BitConverter]::ToUInt32($taskBytes,$taskOffset);$taskCount=[BitConverter]::ToUInt32($taskBytes,$taskOffset+4)
   if(($taskCount -ne $taskNamed.Count -and $taskCount -ne ($taskNamed.Count+1)) -or $taskLength -ne 8+8*$taskCount+$taskStrings){throw 'Every required named test and optional exact storage anonymous test only'}
   $taskStringStart=$taskOffset+8+8*$taskCount;$taskNames=@()
   for($taskIndex=0;$taskIndex -lt $taskCount;$taskIndex++){
    $taskNameOffset=[BitConverter]::ToUInt32($taskBytes,$taskOffset+8+4*$taskIndex);$taskPanic=[BitConverter]::ToUInt32($taskBytes,$taskOffset+8+4*$taskCount+4*$taskIndex)
    if($taskPanic -ne 0 -or $taskNameOffset -ge $taskStrings){throw 'Invalid panic/name metadata'}
    $taskEnd=$taskNameOffset;while($taskEnd -lt $taskStrings -and $taskBytes[$taskStringStart+$taskEnd] -ne 0){$taskEnd++};if($taskEnd -eq $taskStrings){throw 'Unterminated metadata name'}
    $taskNames+=[Text.Encoding]::UTF8.GetString($taskBytes,$taskStringStart+$taskNameOffset,$taskEnd-$taskNameOffset)
   }
  }else{throw "Unexpected metadata tag $taskTag"};$taskOffset+=$taskLength
 }
 if($taskVersion -cne '0.16.0' -or $null -eq $taskNames){throw 'Missing metadata/version'}
 if(@($taskNames|Sort-Object -Unique -CaseSensitive).Count -ne $taskNames.Count){throw 'Duplicate actual metadata name'}
 if((@($taskNames|Where-Object{$_ -cin $taskNamed}) -join [char]0) -cne ($taskNamed -join [char]0)){throw 'Frozen named metadata order differs'}
 foreach($taskName in $taskNamed){if(@($taskNames|Where-Object{$_ -ceq $taskName}).Count -ne 1){throw 'Every exact named Graph0 control required once'}}
 $taskExtra=@($taskNames|Where-Object{$_ -cnotin $taskNamed});if($taskExtra.Count -gt 1 -or ($taskExtra.Count -eq 1 -and $taskExtra[0] -cne $taskAllowedAnonymous)){throw 'Unreviewed imported native test'}
 $taskMetadata=[ordered]@{binary=$Binary;binary_sha256=$BinaryHash;version=$taskVersion;actual_count=$taskNames.Count;tests=$taskNames;required_named=$taskNamed;imported_anonymous=$taskExtra;count_known_before_metadata=$false;method='Actual query4/exit0 only; no run_test; canonical CI607 owner30s'}
 Write-TaskJson $taskMetadata 'selected-tests.json';return $taskMetadata
}
function Assert-TaskSourceCompiler {
 param($Actual,$Expected)
 if($Actual.candidate_head -cne $Expected.candidate_head){throw 'Build/runtime source head differs'}
 foreach($taskGroup in @('source','compiler')){if(@(Compare-Object @($Actual[$taskGroup]|ForEach-Object {$_.relative+' '+$_.sha256}) @($Expected.$taskGroup|ForEach-Object {$_.relative+' '+$_.sha256}) -CaseSensitive).Count){throw 'Build/runtime full source or compiler differs'}}
}
function Assert-TaskArtifacts {
 param($Inventory)
 $taskRoles=@($Inventory.rows|ForEach-Object {$_.relative.Replace([char]92,[char]47)}|Sort-Object -CaseSensitive)
 if($taskRoles.Count -ne 2 -or ($taskRoles -join '|') -cne 'bin/test.exe|bin/test.pdb'){throw 'Exactly canonical test.exe and Debug PDB required'}
 foreach($taskRole in $taskRoles){if((Get-Item -LiteralPath (Join-Path $Inventory.root $taskRole)).Length -le 0){throw 'Nonempty EXE/PDB required'}}
}
$taskResult=[ordered]@{status='running';phase=$Phase;source_head=$taskExpectedHead;planned_named_tests=14;actual_metadata_count=$null;compile=$null;metadata=$null;runtime=$null;between_seal=$false;postseal=$false;native_roots_after=$null;owner_absence_verified=$false}
$taskBefore=$null;$taskArtifacts=$null;$taskAttempted=[Collections.Generic.List[string]]::new();$taskBuildProof=$null
try {
 if((Get-FileHash -LiteralPath $taskZig).Hash -cne '086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864'){throw 'Pinned Zig0.16 differs'}
 if($Phase -ceq 'RuntimeOnly'){
  if($taskGrant.build_run_id -isnot [string] -or $taskGrant.build_run_id -cnotmatch '^[A-Za-z0-9][A-Za-z0-9._-]{0,100}$' -or $taskGrant.build_run_id -ceq $RunId){throw 'Distinct exact BuildQuery RunId required'}
  $taskBuildProof=Join-Path $PSScriptRoot $taskGrant.build_run_id
  $taskBuildNames=@('result.json','before.json','between.json','final.json','artifacts-before.json','artifacts-final.json','selected-tests.json','metadata.json','metadata.stdout.bin','metadata.stderr.log','root-grant.json','compile.json','owner-absence.json','process-census-final.json')
  if(@($taskGrant.build_inputs.PSObject.Properties).Count -ne $taskBuildNames.Count){throw 'Every exact BuildQuery input hash must be granted'}
  foreach($taskName in $taskBuildNames){$taskPath=Join-Path $taskBuildProof $taskName;if($taskGrant.build_inputs.$taskName -cne (Get-FileHash -LiteralPath $taskPath).Hash){throw "Granted BuildQuery input differs: $taskName"};$taskBuildInputPaths+=,$taskPath}
  $taskBuilt=Get-Content -Raw -LiteralPath (Join-Path $taskBuildProof 'result.json')|ConvertFrom-Json
  if($taskBuilt.phase -cne 'BuildQuery' -or $taskBuilt.status -cne 'build_query_passed' -or $taskBuilt.source_head -cne $taskExpectedHead -or !$taskBuilt.postseal -or !$taskBuilt.between_seal -or !$taskBuilt.owner_absence_verified -or $taskBuilt.native_roots_after -ne 0){throw 'Accepted exact BuildQuery terminal proof required'}
 }
 Write-TaskJson (Assert-TaskAdmission) 'initial-admission.json'
 $taskBefore=Get-TaskSeal 'before'
 if($Phase -ceq 'BuildQuery'){
  $taskPrefix=Join-Path $taskProof 'out';$taskCache=Join-Path $taskProof 'cache';$taskGlobalCache=Join-Path $taskProof 'global-cache'
  foreach($taskFresh in @($taskPrefix,$taskCache,$taskGlobalCache)){if(Test-Path -LiteralPath $taskFresh){throw 'Fresh output and private caches required'}}
  Write-TaskJson (Assert-TaskAdmission) 'compile-admission.json'
  $taskArgs=@('build','build-native-module-graph-tla-query-artifact','-Doptimize=Debug','-Duse-llvm=true','-Ddiagnostic-tests=false','-j1','--prefix',$taskPrefix,'--cache-dir',$taskCache,'--global-cache-dir',$taskGlobalCache,'--summary','all')
  $taskAttempted.Add('compile');$taskResult.compile=Invoke-CiOwnedProcess $taskZig $taskArgs $taskRoot (Join-Path $taskProof 'compile') 1320
  $taskArtifacts=Get-CiInventory $taskPrefix;Assert-TaskArtifacts $taskArtifacts;Write-TaskJson $taskArtifacts 'artifacts-before.json'
  $taskBinary=Join-Path $taskPrefix 'bin/test.exe'
  Write-TaskJson (Assert-TaskAdmission) 'metadata-admission.json'
  $taskAttempted.Add('metadata');$taskQuery=Invoke-CiOwnedProcess $taskBinary @('--listen=-') $taskRoot (Join-Path $taskProof 'metadata') 30 ([byte[]](4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0))
  if((Get-Item -LiteralPath (Join-Path $taskProof 'metadata.stderr.log')).Length -ne 0){throw 'Empty metadata stderr required'}
  $taskResult.metadata=Read-TaskActualMetadata $taskBinary ([IO.File]::ReadAllBytes((Join-Path $taskProof 'metadata.stdout.bin'))) $taskQuery.executable_sha256
  $taskResult.actual_metadata_count=$taskResult.metadata.actual_count
  Assert-CiInventory $taskArtifacts (Join-Path $taskProof 'artifacts-between.json')
  Assert-TaskSeal (Get-TaskSeal 'between') $taskBefore;$taskResult.between_seal=$true
  $taskResult.status='build_query_passed'
 }else{
  $taskBuildFinal=Get-Content -Raw -LiteralPath (Join-Path $taskBuildProof 'final.json')|ConvertFrom-Json
  Assert-TaskSourceCompiler $taskBefore $taskBuildFinal
  $taskArtifacts=Get-Content -Raw -LiteralPath (Join-Path $taskBuildProof 'artifacts-before.json')|ConvertFrom-Json
  if($taskArtifacts.root -cne (Join-Path $taskBuildProof 'out')){throw 'Canonical accepted build output root required'}
  Assert-TaskArtifacts $taskArtifacts;Assert-CiInventory $taskArtifacts (Join-Path $taskProof 'artifacts-before.json')
  $taskBinary=Join-Path $taskBuildProof 'out/bin/test.exe'
  $taskMetadataOwner=Get-Content -Raw -LiteralPath (Join-Path $taskBuildProof 'metadata.json')|ConvertFrom-Json
  if($taskMetadataOwner.status -cne 'passed' -or $taskMetadataOwner.exit_code -ne 0 -or $taskMetadataOwner.executable_sha256 -cne (Get-FileHash -LiteralPath $taskBinary).Hash -or (Get-Item -LiteralPath (Join-Path $taskBuildProof 'metadata.stderr.log')).Length -ne 0){throw 'Actual successful metadata owner must bind this binary'}
  $taskMetadata=Read-TaskActualMetadata $taskBinary ([IO.File]::ReadAllBytes((Join-Path $taskBuildProof 'metadata.stdout.bin'))) $taskMetadataOwner.executable_sha256
  $taskSavedMetadata=Get-Content -Raw -LiteralPath (Join-Path $taskBuildProof 'selected-tests.json')|ConvertFrom-Json
  if(($taskMetadata.tests -join [char]0) -cne ($taskSavedMetadata.tests -join [char]0) -or $taskMetadata.actual_count -ne $taskSavedMetadata.actual_count){throw 'Raw metadata and accepted selected names differ'}
  $taskResult.metadata=$taskMetadata;$taskResult.actual_metadata_count=$taskMetadata.actual_count
  Assert-TaskSeal (Get-TaskSeal 'between') $taskBefore;$taskResult.between_seal=$true
  Assert-CiInventory $taskArtifacts (Join-Path $taskProof 'artifacts-between.json')
  Write-TaskJson (Assert-TaskAdmission) 'runtime-admission.json'
  $taskAttempted.Add('runtime');$taskResult.runtime=Invoke-NativeTestProtocol $taskBinary $taskRoot (Join-Path $taskProof 'runtime') $taskMetadata.actual_count
  if((Get-Item -LiteralPath (Join-Path $taskProof 'runtime.stderr.log')).Length -ne 0){throw 'Empty runtime stderr required'}
  $taskResult.status='runtime_passed'
 }
}catch{$taskResult.status='failed';$taskResult.error=$_.Exception.Message}
finally {
 try{$taskFinal=Get-TaskSeal 'final';if($null -eq $taskBefore){throw 'Before baseline unavailable; final retained only'};Assert-TaskSeal $taskFinal $taskBefore;$taskResult.postseal=$true}catch{$taskResult.status='failed_postseal';$taskResult.postseal_error=$_.Exception.Message}
 try{if($null -ne $taskArtifacts){Assert-CiInventory $taskArtifacts (Join-Path $taskProof 'artifacts-final.json')}elseif(Test-Path -LiteralPath (Join-Path $taskProof 'out')){Write-TaskJson (Get-CiInventory (Join-Path $taskProof 'out')) 'artifacts-negative.json'}}catch{$taskResult.status='failed_artifacts';$taskResult.artifact_error=$_.Exception.Message}
 try{$taskCensus=Get-TaskCensus;Write-TaskJson $taskCensus 'process-census-final.json';$taskResult.native_roots_after=$taskCensus.candidates.Count;if($taskCensus.candidates.Count){throw 'Native candidates remain'}}catch{$taskResult.status='failed_native_census';$taskResult.census_error=$_.Exception.Message}
 try{
  $taskReceiptPaths=@(foreach($taskAttempt in $taskAttempted){$taskPath=Join-Path $taskProof "$taskAttempt.json";if(!(Test-Path -LiteralPath $taskPath)){throw 'Attempted process missing durable owner receipt'};$taskPath})
  if($Phase -ceq 'RuntimeOnly' -and $null -ne $taskBuildProof){$taskReceiptPaths+=@(Join-Path $taskBuildProof 'compile.json';Join-Path $taskBuildProof 'metadata.json')}
  $taskAbsent=@(foreach($taskPath in $taskReceiptPaths){$taskOwner=Get-Content -Raw -LiteralPath $taskPath|ConvertFrom-Json;if(!$taskOwner.pid -or !$taskOwner.created_utc){throw 'Incomplete owner identity'};$taskLive=@(Get-CimInstance Win32_Process -Filter "ProcessId = $($taskOwner.pid)" -OperationTimeoutSec 3 -ErrorAction Stop);[ordered]@{owner_receipt=$taskPath;pid=$taskOwner.pid;recorded_created_utc=$taskOwner.created_utc;current=$taskLive;absent=($taskLive.Count -eq 0)}})
  Write-TaskJson $taskAbsent 'owner-absence.json';if(@($taskAbsent|Where-Object {!$_.absent}).Count){throw 'Original owner PID present or reused; independent Root reconciliation required'};$taskResult.owner_absence_verified=$true
 }catch{$taskResult.status='failed_absence';$taskResult.absence_error=$_.Exception.Message}
 $taskResult.admission_probes=$taskAdmissionHistory.ToArray();$taskResult.completed_utc=[DateTimeOffset]::UtcNow.ToString('o');Write-TaskJson $taskResult 'result.json'
}
$taskResult|ConvertTo-Json -Depth 16
if($taskResult.status -cne $(if($Phase -ceq 'BuildQuery'){'build_query_passed'}else{'runtime_passed'})){throw 'Module graph TLA query selected phase failed'}
