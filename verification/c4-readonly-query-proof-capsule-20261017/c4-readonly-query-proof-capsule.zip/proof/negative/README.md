# Prospective readonly module-graph TLA query qualification

SOURCE ONLY; false templates grant no execution. Candidate09e488135bcc118531203fb4b7d704573ae6c7f4
at worktrees/runtime-module-tla-query,10664 tracked files, C650336/HB87AD.
The frozen EB2C metadata authority lists14 source-authored names before any query.
Static source-name derivation independently matches root basename + .test. + test
declaration, as the existing actual C3 Graph0 metadata format. Compiled total is
UNKNOWN: accept14 named entries or14 plus ONLY extensions.native_durable_storage.test_0.
Every named entry occurs once in frozen relative order; no duplicates/extra tests.

Run-ModuleGraphTlaQuery.ps1 requires an explicit phase and a fresh exact Root grant
valid initially for no more than300s. Each phase uses a fresh unique RunId.

BuildQuery builds ONLY build-native-module-graph-tla-query-artifact, Debug/LLVM,
diagnostic-tests=false/-j1, fresh RunId/out/cache/global-cache. Historical cache
reuse is not admitted. Unchanged CI607 owns compile1320s then query30s; actual
query4/exit0 bytes derive names/count. This phase NEVER sends run_test. Installed
roles must be exactly nonempty bin/test.exe and bin/test.pdb. It writes raw query
stdout/stderr, original process receipts, selected names and full seals.

RuntimeOnly NEVER compiles or starts a metadata query. A separate fresh Root grant
binds a distinct accepted BuildQuery RunId plus every SHA of14 required evidence
inputs (listed in the template). The driver requires successful BuildQuery terminal
status, source/compiler consistency and canonical artifact root; rehashes the actual
EXE/PDB; reparses the granted original raw query bytes; and compares derived names
with the granted selected-tests JSON. It readmits native0/16GiB immediately before
unchanged Protocol39F executes every actual validated index in ONE120s TOTAL run.
All native result flags must be zero through the canonical protocol. RuntimeOnly
includes the14 original build proof inputs in before/between/final control seals.
An exit0 without exact protocol results cannot be a passing runtime result.

Both phases use successful nonempty process census, the byte-exact3413 classifier,
fresh16GiB/native0 bounded54s admission, bounded3s explicit CIM requests and full
10664 source/19546 compiler/control seals before/between/final. Compiler rows must
match immutable DEE original authority. C/H, canonical CI607 and Zig executable
are pinned; protocol39F, authority, copied outer53, classifier, packet/grant,
container path records, Git and pwsh are controls. EXE/PDB are rehashed between
and final. Finally independently attempts seals, artifacts, census and original
compile/query/runtime owner PID absence, preserving failure receipts. Missing
attempted owner receipts or a live/reused PID fail closed. Root separately verifies
external runner and descendant absence. No broad process operations are added.

Root owns separate outer53 invocations: external1800s for BuildQuery, external300s
for RuntimeOnly; canonical pipe settlement10s. The approved outer is byte-exact
53E522C8397B5F7EE9AF721D8160B227E97FADA4E1DA36A938656E2403D56B6B.
These are process/wait bounds, not a hard guarantee for stalled OS/CIM/hash calls.

Future Root invocation shape, NOT executed during preparation:

    . <packet>/outer-owned-process.ps1
    Invoke-CiOwnedProcess 'C:\Program Files\PowerShell\7\pwsh.exe' @('-NoProfile','-NonInteractive','-File','<packet>/Run-ModuleGraphTlaQuery.ps1','-Phase','BuildQuery','-RootGrantPath','<actual-fresh-grant>','-RunId','<fresh-run>') 'C:\Users\adyba\pi-zig' '<outer-receipt>' 1800

Runtime uses Phase RuntimeOnly and external300; it requires the independently
accepted build proof hashes rather than the unauthorized template placeholders.

No Node/runtime restoration/Source reference capture/default application or release
claim follows from this packet. It does not change product, C/H, assertions or
original fixtures. No parser, AST, compiler, native, Node, generator or execution
job ran in preparation. functions.draft.txt is an unused retained authoring draft,
not an executable control or input to the final driver.
