# Source prototype: synchronous TypeBox heap activations

This checkpoint implements the finite B7FC/7E836 design in an isolated worktree
from `08bd3b5fa6f162fc5bc86c3af604beafdabd887a`. It is **source only**. No Node,
generator, Zig formatter/parser/compiler, native test or LLVM process ran.
Original product14C, its mapD0FD, genuine Source80/52/396 inputs and expected
rows, the actual08bd C/H sources, 1 MiB Engine guard and 16 MiB PE reserve remain
unchanged. This checkout's exact C/H hashes are31A110282BDA00332436312B18A544A95D319B000AAAFA3B61AE3B52D8D02D37
and5A9101C613BC61052F1F20D1E9ED71D390532A1BF29B647976DA0996B1F75B50.
These are the actual08bd checkout bytes; historical C2/H341 hash labels do not
substitute for the current source inventory and no native qualification transfers.
The retained product result remains negative at Source396 case391.

## Implemented path

`native_typebox_continuation.zig` owns a per-Engine weak exact-object registry.
Registration occurs only at explicit `createPlanned` calls. Public callback ABI,
function name/length/capture shape, arrow behavior and constructor receiver and
returned-object rules remain in NativeNode. Private invokeBody receives the
actual callable and State, rather than discovering a closure by callback name.
The finalizer removes registration before State destruction. Registry storage
survives JS_FreeRuntime finalizers in normal deinit and Engine.init error unwind.

Private ordinary calls still execute the real JS_Call for its actual VM poll and
class dispatch. A one-shot exact-object/State/class/callback/capture/receiver/
argv/Engine/thread request can prepare a child using native allocation and
refcount increments only, then return a private undefined acknowledgement.
The native caller disarms on every VM return. A real pre-dispatch exception is
propagated even when the request was never consumed. Logical suppression is
committed only after a valid successful acknowledgement. Environment creation,
binding and guest-capable operations are generated Steps after that transition.
The acknowledgement is never stored in the caller Scope as a guest result.

Heap activation storage includes the original Scope, original operand slots,
appended original argument/descriptor ranges, PC and owned pending completion.
Each private child returns to the iterative Machine instead of retaining its
generated caller/branch/bridge stack. Proxy, bound, constructor, builtin and
unregistered calls use the real VM; real Array.reduce and its callback reentry
remain. Nested machines save/restore the outer runtime machine and request.

The authoring source starts with the exact reviewed3c tools (lower-authority
88E68E and postpass685DFE), then adds typed records DURING the original single
Acorn lowering. It does not evaluate TypeBox or parse/re-lower generated Zig.
Separate CFG PCs consume those records after original IDs/flags/slot allocation
are frozen. Exactly34 original callbacks are pinned: the original14+10 modules,
all9 resolve_arguments callbacks, and f33 ShiftLeft. Original1669/585/oneTry,
165 preparation regions and330 descriptor slots remain guarded provenance.
Unsupported native temporaries, optional/spread calls, iterator controls,
foreign ranges, unknown records and nested/foreign finally shapes fail closed.
No new generated product exists yet, so Step/call counts are not observations.
Original165 call-step scope has0 constructs; the broader34 source scope includes
the real `new Error` in AssertArgumentExtends, which remains VM construction.

## Completion and cleanup

Each fallible Step/VM boundary classifies only current private allocation tags
and already trusted uncatchable reasons. Historical allocation tags remain
ordinary. Direct host OOM uses the current qualified uncatchable reason transport
once. No nativeAllocationError conversion clears a fatal marker.

Ordinary return/throw runs the real Source finally and permits its ordinary
override. Trusted fatal skips guest catch/finally, matching the VM's uncatchable
policy. All native activation teardown runs. No native instantiation decrement,
counter reset, threshold relaxation, generic fatal latch or C helper is added.
An owned child completion is moved before Scope.own, which consumes even on
append failure. Pending exceptions are owned before cleanup; later cleanup
cannot replace the first trusted fatal or escape alongside a successful result.
Captured-slot behavior is preserved through Engine.checked under the existing
diagnostic suppression. The Cmalloc-null frontier remains unqualified.

## Prepared gates, all unrun

1. Direct single-file Node tooling gate for `emit-continuations.test.mjs`:
   27 prepared tests (7 positive,20 rejection controls), no TypeBox/Acorn import.
   Retain/rerun the existing18+9 pure tooling controls with their actual hashes.
   Use the reviewed bounded Node owner, explicit owned-start fence and complete
   Node1838/1774/source/control seals; Root grants each job separately.
2. `build-native-typebox-heap-continuation` / installed binary metadata/runtime:
   15 prepared named controls, plus any actual anonymous imports must be frozen
   from metadata (one storage import is anticipated, not newly observed).
   Controls cover1500 real private dispatches, exact closure identity/reuse,
   arrow/ordinary/constructor receiver rules, real reduce reentry, ordinary
   finally/captured identity, fresh/historical fatal policy, native teardown
   fatal priority, moved-result append OOM and actual VM cancellation.
3. A separately granted package-only static authoring pass over immutable
   TypeBox1385+Acorn10 authorities creates FOUR fresh staged outputs. Add these
   new authoring controls to the sealed closure. Review actual CFG/metadata/
   provenance/unchanged original identities before product intake.
4. A fresh matching native Source80/52/396+storage group retains all original
   assertions and case391 expected Error/recoveredLiteral/129/792. No failure
   becomes an expected success. Compile1320/-j1, metadata30, canonical runtime120,
   pipe10, full before/between/post seals and fresh16GiB/globalnative0 admission
   remain Root-controlled. Existing15 controls do not qualify this product gate.

Only actual matching PDB/trace evidence can establish stack reduction or parity.
With invokeBody routing to a descriptor, observer f_N is retained callback
identity/provenance, **not proof the legacy f_N body/frame executed**. New
Machine/Step/invokeBody and private scheduling frames require their own PDB and
trace interpretation. Do not subtract old static frames or sum them into a peak.
Real reduce bridges remain; their measured new live cost must still fit the
unchanged guard before the library reaches its genuine128 instantiation policy.
