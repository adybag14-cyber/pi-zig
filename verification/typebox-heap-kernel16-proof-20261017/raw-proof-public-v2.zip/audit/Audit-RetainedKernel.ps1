$ErrorActionPreference='Stop'
$container='<PI_ZIG>'
$build=Join-Path $container 'evidence/root-typebox-heap-kernel-v5-buildquery-20261017-174640'
$runtime=Join-Path $container 'evidence/root-typebox-heap-kernel-v5-runtime-20261017-174932'
$controls=Join-Path $container 'evidence/typebox-heap-execution-prepared-20261017'
$work=Join-Path $container 'worktrees/typebox-heap-continuation'
$head='fe18566011346d210267c2b49bc1eb0bcd5f7b4d'
$proof=$PSScriptRoot
$checks=[Collections.Generic.List[object]]::new()
function Check([string]$Name,[bool]$Condition,$Detail=$null){$checks.Add([ordered]@{name=$Name;passed=$Condition;detail=$Detail});if(!$Condition){throw "Independent audit failed: $Name"}}
function Load([string]$Path){Get-Content -LiteralPath $Path -Raw|ConvertFrom-Json}
function Fingerprint($Rows){$lines=@($Rows|ForEach-Object{$_.relative+' '+$_.sha256}|Sort-Object -CaseSensitive);[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes([string]::Join([char]10,$lines))))}
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash}
$baseline=Load (Join-Path $build 'before.json')
$groupPrint=@{};foreach($g in @('source','tree','vendor','compiler','controls')){$groupPrint[$g]=Fingerprint $baseline.$g}
Check 'baseline full counts' ($baseline.source.Count-eq10645-and$baseline.tree.Count-eq10645-and$baseline.vendor.Count-eq1336-and$baseline.compiler.Count-eq19546) @{source=$baseline.source.Count;tree=$baseline.tree.Count;vendor=$baseline.vendor.Count;compiler=$baseline.compiler.Count}
$sealRows=@()
foreach($run in @(@{name='build';path=$build;files=@('before.json','compile-before.json','compile-after.json','metadata-before.json','metadata-after.json','final.json')},@{name='runtime';path=$runtime;files=@('before.json','runtime-before.json','runtime-after.json','final.json')})){
 $controlPrint=$null
 foreach($f in $run.files){
  $path=Join-Path $run.path $f;$s=Load $path
  Check ($run.name+'/'+$f+' identity') ($s.candidate_head-ceq$head-and$s.clean-eq$true-and$s.errors.Count-eq0)
  $groups=[ordered]@{}
  foreach($g in @('source','tree','vendor','compiler')){
   $fp=Fingerprint $s.$g;$groups[$g]=@{count=$s.$g.Count;fingerprint=$fp}
   Check ($run.name+'/'+$f+'/'+$g) ($fp-ceq$groupPrint[$g])
  }
  $fp=Fingerprint $s.controls;if($null-eq$controlPrint){$controlPrint=$fp}
  Check ($run.name+'/'+$f+'/controls') ($fp-ceq$controlPrint)
  foreach($row in $s.controls){Check ($run.name+'/'+$f+'/current-control/'+[IO.Path]::GetFileName($row.path)) ((Hash $row.path)-ceq$row.sha256)}
  $sealRows+=,[ordered]@{run=$run.name;file=$f;sha256=(Hash $path);groups=$groups;control_count=$s.controls.Count;control_fingerprint=$fp}
 }
}
$originalPath=Join-Path $container 'evidence/durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
Check 'original compiler authority hash' ((Hash $originalPath)-ceq'DEE259F171F720AB2C08E8DD473975E22C876417CD62E4F016C71A7C662794EB')
$original=Load $originalPath
$expected=@(foreach($row in $original.inputs){[ordered]@{relative=[IO.Path]::GetRelativePath([string]$original.root,[string]$row.path).Replace([char]92,[char]47);sha256=$row.sha256}})
Check 'compiler all19546 original relative hashes' ($expected.Count-eq19546-and(Fingerprint $expected)-ceq$groupPrint.compiler)
$current=@{};foreach($g in @('source','compiler')){
 $bad=@(foreach($row in $baseline.$g){if(!(Test-Path -LiteralPath $row.path -PathType Leaf)-or(Hash $row.path)-cne$row.sha256){$row.relative}})
 Check ('current complete '+$g+' hashes') ($bad.Count-eq0) @{count=$baseline.$g.Count;drift=$bad}
 $current[$g]=@{count=$baseline.$g.Count;drift=0}
}
$currentFiles=@(git --no-optional-locks -C $work ls-files)
Check 'current git exact head/clean/inventory' ((([string](git --no-optional-locks -C $work rev-parse HEAD)).Trim()-ceq$head)-and@(git --no-optional-locks -C $work status --porcelain).Count-eq0-and$currentFiles.Count-eq10645)
$physical=@(Get-ChildItem -LiteralPath (Join-Path $container 'toolchain/zig-x86_64-windows-0.16.0') -Recurse -File -Force|ForEach-Object{[IO.Path]::GetRelativePath((Join-Path $container 'toolchain/zig-x86_64-windows-0.16.0'),$_.FullName).Replace([char]92,[char]47)})
Check 'current complete compiler inventory no extras' ($physical.Count-eq19546-and@(Compare-Object @($baseline.compiler.relative) $physical -CaseSensitive).Count-eq0)
$artifact=Load (Join-Path $build 'build-artifacts.json')
$exe=@($artifact.installed|Where-Object path -Like '*.exe')[0];$pdb=@($artifact.installed|Where-Object path -Like '*.pdb')[0]
Check 'actual executable full hash' ((Hash $exe.path)-ceq'BAB4229543529C50551D7CF906FDC0A21E35CCEC3FB5BB5148514F7AE2EB42F2')
Check 'actual PDB full hash' ((Hash $pdb.path)-ceq'92326DC85893754DF74CF56C181A740BEA23FB095474A0238077EE35C0310354')
foreach($run in @($build,$runtime)){foreach($path in Get-ChildItem -LiteralPath $run -File -Filter '*artifacts.json'){
 $a=Load $path.FullName
 Check ('artifact no errors '+$path.Name) ($a.errors.Count-eq0-and$a.installed.Count-eq2-and$a.pe.reserved_stack_bytes-eq16777216-and$a.pe.Engine_guard_bytes-eq1048576)
 foreach($row in $a.installed){$matches=@($artifact.installed|Where-Object path -CEQ $row.path);Check ('artifact unchanged '+$path.Name+'/'+[IO.Path]::GetFileName($row.path)) ($matches.Count-eq1-and$matches[0].sha256-ceq$row.sha256-and$matches[0].bytes-eq$row.bytes)}
 $cached=@($a.cached_executables|Where-Object sha256 -CEQ $exe.sha256)
 Check ('unique cached executable '+$path.Name) ($cached.Count-eq1-and(Hash $cached[0].path)-ceq$exe.sha256)
}}
$selected=Load (Join-Path $build 'selected-tests.json')
$readyPath=Join-Path $container 'evidence/typebox-heap-continuation-source-prototype-20261017/readiness-v6-fe185.json'
$ready=Load $readyPath
$planned=@($ready.prepared_native_names|ForEach-Object{'native_typebox_continuation_test.test.'+$_})+@('extensions.native_durable_storage.test_0')
Check 'actual metadata original15 plus storage' ($planned.Count-eq16-and[string]::Join([char]10,@($selected.tests))-ceq[string]::Join([char]10,$planned)-and$selected.binary-ceq$exe.path-and$selected.binary_sha256-ceq$exe.sha256)
foreach($row in @($ready.sources)+@($ready.protected)){Check ('readiness exact '+$row.path) ((Hash (Join-Path $work $row.path))-ceq$row.sha256)}
# Decode actual wire frames independently. No process or VM call is made.
function Frames([string]$Path){
 $b=[IO.File]::ReadAllBytes($Path);$offset=0;$rows=@()
 while($offset-lt$b.Length){
  if($b.Length-$offset-lt8){throw 'Truncated raw frame'};$tag=[BitConverter]::ToUInt32($b,$offset);$length=[BitConverter]::ToUInt32($b,$offset+4);$offset+=8
  if($length-gt1MB-or$length-gt$b.Length-$offset){throw 'Invalid raw frame length'}
  $body=[byte[]]::new($length);[Array]::Copy($b,$offset,$body,0,$length);$rows+=,[ordered]@{tag=$tag;length=$length;body=$body};$offset+=$length
 };return $rows
}
$m=@(Frames (Join-Path $build 'metadata.stdout.bin'))
Check 'metadata exactly version+array frames' ($m.Count-eq2-and$m[0].tag-eq0-and[Text.Encoding]::UTF8.GetString($m[0].body)-ceq'0.16.0'-and$m[1].tag-eq3)
$body=$m[1].body;$strings=[BitConverter]::ToUInt32($body,0);$count=[BitConverter]::ToUInt32($body,4);$names=@();$stringStart=8+8*$count
Check 'metadata actual16 layout' ($count-eq16-and$body.Length-eq8+8*$count+$strings)
for($i=0;$i-lt$count;$i++){
 $off=[BitConverter]::ToUInt32($body,8+4*$i);$panic=[BitConverter]::ToUInt32($body,8+4*$count+4*$i)
 Check ('metadata offset/panic '+$i) ($off-lt$strings-and$panic-eq0)
 $end=$off;while($end-lt$strings-and$body[$stringStart+$end]-ne0){$end++};Check ('metadata terminated '+$i) ($end-lt$strings)
 $names+=[Text.UTF8Encoding]::new($false,$true).GetString($body,$stringStart+$off,$end-$off)
}
Check 'raw metadata exact ordered names' ([string]::Join([char]10,$names)-ceq[string]::Join([char]10,@($selected.tests)))
$frames=@(Frames (Join-Path $runtime 'runtime.stdout.bin'))
Check 'runtime version+16 starts/results frame count' ($frames.Count-eq33-and$frames[0].tag-eq0-and[Text.Encoding]::UTF8.GetString($frames[0].body)-ceq'0.16.0')
$actual=@()
for($i=0;$i-lt16;$i++){
 $start=$frames[1+2*$i];$result=$frames[2+2*$i]
 Check ('raw runtime sequential start/result '+$i) ($start.tag-eq5-and$start.length-eq0-and$result.tag-eq4-and$result.length-eq12-and[BitConverter]::ToUInt32($result.body,0)-eq$i)
 $flags=[BitConverter]::ToUInt64($result.body,4);Check ('raw runtime flags zero '+$i) ($flags-eq0)
 $actual+=,[ordered]@{index=$i;name=$names[$i];flags=$flags}
}
foreach($run in @($build,$runtime)){foreach($step in $(if($run-ceq$build){@('metadata')}else{@('runtime')})){Check ('actual empty '+$step+' stderr') ((Get-Item -LiteralPath (Join-Path $run "$step.stderr.log")).Length-eq0)}}
$owners=@()
foreach($case in @(@{run=$build;step='compile';timeout=1320},@{run=$build;step='metadata';timeout=30},@{run=$runtime;step='runtime';timeout=120})){
 $owner=Load (Join-Path $case.run ($case.step+'.json'));$result=Load (Join-Path $case.run 'result.json')
 $grantName=$(if($case.run-ceq$build){'root-typebox-heap-kernel-v5-buildquery-20261017-174640'}else{'root-typebox-heap-kernel-v5-runtime-20261017-174932'})
 $grant=Load (Join-Path $controls ($grantName+'-grant.json'))
 $expectedExe=$(if($case.step-ceq'compile'){Join-Path $container 'toolchain/zig-x86_64-windows-0.16.0/zig.exe'}else{$exe.path})
 Check ($case.step+' actual owner/live identity') ($owner.status-ceq'passed'-and$owner.exit_code-eq0-and$owner.timeout_seconds-eq$case.timeout-and$owner.retained_handle-gt0-and$owner.pid-gt0-and$owner.executable-ceq$expectedExe-and(Hash $owner.executable)-ceq$owner.executable_sha256-and$owner.working_directory-ceq$work-and$owner.live_identity.pid-eq$owner.pid-and$owner.live_identity.executable-ceq$owner.executable-and([DateTimeOffset]$owner.live_identity.created_utc).UtcTicks-eq([DateTimeOffset]$owner.created_utc).UtcTicks-and$owner.live_identity.command_line)
 $args=$(if($case.step-ceq'compile'){@('build','build-native-typebox-heap-continuation','-Doptimize=Debug','-Duse-llvm=true','-Ddiagnostic-tests=false','-j1','--test-timeout','120s','--prefix',$grant.output_prefix,'--cache-dir',$grant.cache_directory,'--global-cache-dir',$grant.global_cache_directory,'--summary','all')}else{@('--listen=-')})
 Check ($case.step+' exact argv') ([string]::Join([char]10,@($owner.arguments))-ceq[string]::Join([char]10,$args))
 $expectedCommand='"'+$owner.executable+'" '+[string]::Join(' ',$args)
 Check ($case.step+' actual CIM command line') ($owner.live_identity.command_line-ceq$expectedCommand)
 $elapsed=([DateTimeOffset]$owner.completed_utc-[DateTimeOffset]$owner.created_utc).TotalSeconds
 Check ($case.step+' actual bounded elapsed') ($elapsed-ge0-and$elapsed-le$case.timeout+10)
 $part=$result.phases.($case.step)
 Check ($case.step+' original output hashes/postchecks') ($part.failure-eq$null-and$part.original_execution_failure-eq$null-and$part.owner_binding.status-ceq'passed'-and$part.evidence.valid-eq$true-and$part.evidence.current_owner_pid_present-eq0-and$part.evidence.current_owned_descendants.Count-eq0)
 foreach($field in @('evidence_valid','owner_bound','source_sealed','artifacts_bound','absence_closed')){Check ($case.step+'/post/'+$field) ($part.postchecks.$field-is[bool]-and$part.postchecks.$field-eq$true)}
 foreach($row in $part.evidence.raw_outputs){Check ($case.step+'/raw/'+[IO.Path]::GetFileName($row.path)) ((Hash $row.path)-ceq$row.sha256-and(Get-Item -LiteralPath $row.path).Length-eq$row.bytes)}
 $admission=Load (Join-Path $case.run ($case.step+'-admission.json'))
 Check ($case.step+' fresh native0/16GiB admission') ($admission.status-ceq'admitted'-and$admission.accepted_elapsed_seconds-lt54-and$admission.probe.native_roots-eq0-and$admission.probe.native.Count-eq0-and$admission.probe.free_kib-ge16777216-and$admission.probe.minimum_kib-eq16777216-and([DateTimeOffset]$owner.created_utc-[DateTimeOffset]$admission.probe.utc).TotalSeconds-ge0-and([DateTimeOffset]$owner.created_utc-[DateTimeOffset]$admission.probe.utc).TotalSeconds-lt2)
 Check ($case.step+' actual source/compiler/absence terminal') ($result.postseal-eq$true-and$result.errors.Count-eq0-and$result.absence.native_roots.Count-eq0-and$result.controller_environment_restored-eq$true-and$result.candidate_head-ceq$head-and$result.driver_sha256-ceq'CBEF6BF6657EEA2B4102350068ED1040DD5A63E63D4A8ACA0BD4523278239D8D')
 $absence=Load (Join-Path $case.run ($case.step+'-absence.json'))
 Check ($case.step+' retained fresh phase absence') ($absence.status-ceq'closed'-and$absence.global_native.Count-eq0-and$absence.evidence.current_owner_pid_present-eq0-and$absence.evidence.current_owned_descendants.Count-eq0)
 $owners+=,[ordered]@{phase=$case.step;pid=$owner.pid;exe_sha256=$owner.executable_sha256;elapsed_seconds=$elapsed;deadline=$case.timeout}
}
$outerRows=@()
foreach($name in @('root-typebox-heap-kernel-v5-buildquery-20261017-174640','root-typebox-heap-kernel-v5-runtime-20261017-174932')){
 $o=Load (Join-Path $controls ($name+'-outer.json'));$g=Load (Join-Path $controls ($name+'-grant.json'));$a=Load (Join-Path $controls ($name+'-outer-absence.json'))
 $mode=$g.mode;$dir=Join-Path $container ('evidence/'+$name)
 $expected=@('-NoLogo','-NoProfile','-NonInteractive','-File',(Join-Path $controls 'Run-HeapKernelV5WarmFe185.ps1'),'-RootGrant',(Join-Path $controls ($name+'-grant.json')),'-Mode',$mode)
 Check ($name+' exact outer retained/live identity') ($o.status-ceq'passed'-and$o.exit_code-eq0-and$o.retained_handle-gt0-and$o.executable-ceq'C:\Program Files\PowerShell\7\pwsh.exe'-and$o.executable_sha256-ceq'BFB46AF89433268872DDB43D1CA7A3F433452EE91ED356A9786940F90118E285'-and$o.working_directory-ceq$container-and$o.live_identity.pid-eq$o.pid-and$o.live_identity.executable-ceq$o.executable-and([DateTimeOffset]$o.live_identity.created_utc).UtcTicks-eq([DateTimeOffset]$o.created_utc).UtcTicks-and[string]::Join([char]10,@($o.arguments))-ceq[string]::Join([char]10,$expected)-and$o.timeout_seconds-eq$(if($mode-ceq'BuildQuery'){1800}else{600}))
 Check ($name+' outer exact CIM argv') ($o.live_identity.command_line-ceq('"'+$o.executable+'" '+[string]::Join(' ',$expected)))
 Check ($name+' fresh grant and initial native launch') ($g.execution_authorized-is[bool]-and$g.execution_authorized-eq$true-and$g.candidate_head-ceq$head-and$g.driver_sha256-ceq(Hash (Join-Path $controls 'Run-HeapKernelV5WarmFe185.ps1'))-and([DateTimeOffset]$o.created_utc-[DateTimeOffset]$g.issued_utc).TotalSeconds-ge0-and([DateTimeOffset]$o.created_utc-[DateTimeOffset]$g.issued_utc).TotalSeconds-le300)
 $first=Load (Join-Path $dir ($(if($mode-ceq'BuildQuery'){'compile.json'}else{'runtime.json'})))
 Check ($name+' first native grant freshness') (([DateTimeOffset]$first.created_utc-[DateTimeOffset]$g.issued_utc).TotalSeconds-ge0-and([DateTimeOffset]$first.created_utc-[DateTimeOffset]$g.issued_utc).TotalSeconds-le300)
 Check ($name+' outer stderr/stdout') ((Get-Item -LiteralPath (Join-Path $controls ($name+'-outer.stderr.log'))).Length-eq0-and(Hash (Join-Path $controls ($name+'-outer.stdout.bin')))-ceq(Hash (Join-Path $dir 'result.json')))
 Check ($name+' fresh outer absence') ($a.pid-eq$o.pid-and$a.status-ceq'passed'-and$a.exit_code-eq0-and$a.fresh_pid_present-eq0-and$a.owner_sha256-ceq(Hash (Join-Path $controls ($name+'-outer.json')))-and([DateTimeOffset]$a.checked_utc-[DateTimeOffset]$o.completed_utc).TotalSeconds-ge0-and([DateTimeOffset]$a.checked_utc-[DateTimeOffset]$o.completed_utc).TotalSeconds-lt10)
 $outerRows+=,[ordered]@{mode=$mode;pid=$o.pid;exit_code=$o.exit_code;absence=0}
}
$grant=Load (Join-Path $controls 'root-typebox-heap-kernel-v5-runtime-20261017-174932-grant.json')
foreach($pair in @(@{path='build_result_path';sha='build_result_sha256'},@{path='build_artifacts_path';sha='build_artifacts_sha256'},@{path='build_metadata_path';sha='build_metadata_sha256'})){Check ('runtime actual BuildQuery join '+$pair.path) ((Hash $grant.($pair.path))-ceq$grant.($pair.sha))}
$negative=Load (Join-Path $container 'evidence/root-typebox-heap-kernel-fe185-runtime-20261017-172520/result.json')
Check 'V4 negative remains prelaunch/refusal' ($negative.status-ceq'failed_final_artifact'-and$negative.runtime_owner_launch_attempted-eq$false-and$negative.actual_runtime_owner_started-eq$false-and@($negative.phases.PSObject.Properties).Count-eq0-and$negative.errors.Count-eq2)
$summary=Load (Join-Path $runtime 'runtime.results.json')
Check 'actual canonical summary agrees with raw16' ($summary.status-ceq'passed'-and$summary.started-eq16-and$summary.completed-eq16-and$summary.expected-eq16-and$summary.failed_or_skipped_or_logged_or_leaked-eq0-and$summary.results.Count-eq16)
$out=[ordered]@{schema=1;status='accepted_actual_kernel16_only';candidate_head=$head;driver_sha256='CBEF6BF6657EEA2B4102350068ED1040DD5A63E63D4A8ACA0BD4523278239D8D';actual_metadata_names=$names;actual_results=$actual;owners=$owners;outers=$outerRows;full_seals=$sealRows;current=$current;checks=$checks.ToArray();generated34_qualified=$false;product_qualified=$false;frame_improvement=$false;runtime_restored=$false;fresh_cache_reproduction=$false;cache_policy='Explicit terminal-owned parser-negative164212 unsealed cache reuse; no fresh-cache reproduction claim';review_method='Retained raw data decode and full source/compiler/control/artifact reads only; no native, compiler, Node, LLVM, parser or metadata process invoked'}
$out.current=$current
[IO.File]::WriteAllText((Join-Path $proof 'independent-audit.json'),($out|ConvertTo-Json -Depth 14)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
@{status=$out.status;checks=$checks.Count;names=$names.Count;source=$baseline.source.Count;compiler=$baseline.compiler.Count}|ConvertTo-Json