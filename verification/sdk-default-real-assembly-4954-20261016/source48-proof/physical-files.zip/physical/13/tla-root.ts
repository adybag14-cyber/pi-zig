export const before:number=1;await Promise.resolve();export const after:number=2;export const url=import.meta.url;export default ()=>({before,after,url});
