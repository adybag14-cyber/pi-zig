globalThis.freshStaleRuns.push(2);export default pi=>pi.registerCommand('stale',{handler:()=>2});
