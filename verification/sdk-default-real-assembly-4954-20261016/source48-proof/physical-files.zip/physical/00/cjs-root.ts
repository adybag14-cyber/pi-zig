import value from './dependency.cjs'; export default ()=>value;
