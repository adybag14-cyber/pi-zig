import {value,count} from './dependency.ts';export default ()=>({value,count});
