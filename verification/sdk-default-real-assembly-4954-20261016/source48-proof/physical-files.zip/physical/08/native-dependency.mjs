export const value=2;export const url=import.meta.url;
