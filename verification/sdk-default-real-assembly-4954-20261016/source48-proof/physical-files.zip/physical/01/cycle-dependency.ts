import {version} from './cycle-root.ts'; globalThis.freshRootCounts.cycleDependency++; export const peek=()=>version;
