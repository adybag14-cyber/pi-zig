import {value,url} from './native-dependency.mjs';export default ()=>({value,url});
