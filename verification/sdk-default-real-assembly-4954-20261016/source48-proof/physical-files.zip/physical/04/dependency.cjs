globalThis.freshRootCounts.cjs++;module.exports={value:2,count:globalThis.freshRootCounts.cjs};
