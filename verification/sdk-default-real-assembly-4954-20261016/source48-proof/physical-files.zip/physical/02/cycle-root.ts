import {peek} from './cycle-dependency.ts'; globalThis.freshRootCounts.cycleRoot++; export const version:number=2; export default ()=>({version,peek:peek()});
