globalThis.freshRootCounts.dependency++;export const value:number=3;export const count=globalThis.freshRootCounts.dependency;
