export const value=1;export const url=import.meta.url;
