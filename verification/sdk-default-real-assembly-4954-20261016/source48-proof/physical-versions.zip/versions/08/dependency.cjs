globalThis.freshRootCounts.cjs++;module.exports={value:1,count:globalThis.freshRootCounts.cjs};
