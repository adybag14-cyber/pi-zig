globalThis.freshStaleRuns.push(1);globalThis.freshRootStarted();await globalThis.freshRootGate;export default pi=>pi.registerCommand('stale',{handler:()=>1});
