globalThis.freshRootCounts.dependency++; export const value:number=1; export const count=globalThis.freshRootCounts.dependency;
