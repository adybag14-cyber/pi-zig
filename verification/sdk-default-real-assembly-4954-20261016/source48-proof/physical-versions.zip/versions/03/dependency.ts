globalThis.freshRootCounts.dependency++; export const value:number=2; export const count=globalThis.freshRootCounts.dependency;
