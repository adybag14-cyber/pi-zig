import {peek} from './cycle-dependency.ts'; globalThis.freshRootCounts.cycleRoot++; export const version:number=1; export default ()=>({version,peek:peek()});
