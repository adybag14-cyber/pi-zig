globalThis.modulePolicyCounts["transition"]=(globalThis.modulePolicyCounts["transition"]??0)+1;export default ()=>({version:2,url:import.meta.url});
