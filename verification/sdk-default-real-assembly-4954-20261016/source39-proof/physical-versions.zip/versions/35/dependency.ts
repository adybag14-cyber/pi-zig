export function physicalDependencyStack(){throw new Error('physical-dependency-stack')}
