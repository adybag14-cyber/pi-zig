export default function physicalRootStack(){throw new Error('physical-root-stack')}
