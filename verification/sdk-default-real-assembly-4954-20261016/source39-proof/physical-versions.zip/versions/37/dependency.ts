globalThis.modulePolicyCounts["parallel"]=(globalThis.modulePolicyCounts["parallel"]??0)+1;await Promise.resolve();export const value:number=globalThis.modulePolicyCounts.parallel;
