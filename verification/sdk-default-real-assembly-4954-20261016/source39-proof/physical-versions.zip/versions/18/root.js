globalThis.modulePolicyCounts["transition"]=(globalThis.modulePolicyCounts["transition"]??0)+1;module.exports=()=>({version:3});
