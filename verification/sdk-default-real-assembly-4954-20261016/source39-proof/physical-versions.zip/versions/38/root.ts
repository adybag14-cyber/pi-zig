export default async()=>{const dep=await import('./dependency.ts');return dep.value};
