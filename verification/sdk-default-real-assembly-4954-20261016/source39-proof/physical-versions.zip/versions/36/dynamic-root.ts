export default async function physicalDynamicRootStack(){const dep=await import('./dependency.ts');return dep.physicalDependencyStack()}
