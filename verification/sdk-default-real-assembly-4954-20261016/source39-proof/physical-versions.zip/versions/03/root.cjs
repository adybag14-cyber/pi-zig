globalThis.modulePolicyCounts["direct-cjs"]=(globalThis.modulePolicyCounts["direct-cjs"]??0)+1;const version=2,count=globalThis.modulePolicyCounts["direct-cjs"];module.exports=()=>({version,count});
