param([Parameter(Mandatory)][string]$RootGrantPath,[Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9][A-Za-z0-9._-]{0,100}$')][string]$RunId)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$true
$taskContainer='C:\Users\adyba\pi-zig'
$taskRoot=Join-Path $taskContainer 'worktrees/jiti-current-172-lexical-fix'
$taskExpectedHead='6097d0985e72343e0f6ce8699d14a8be5f5e475a'
$taskProof=Join-Path $PSScriptRoot $RunId
$taskCompiler=Join-Path $taskContainer 'toolchain/zig-x86_64-windows-0.16.0'
$taskZig=Join-Path $taskCompiler 'zig.exe'
$taskGit='C:\Program Files\Git\cmd\git.exe'
$taskCi=Join-Path $taskRoot 'tools/ci/native_qualification_ci.ps1'
$taskClassifier=Join-Path $PSScriptRoot 'Get-ModelsNativeCandidates.ps1'
$taskOuter=Join-Path $PSScriptRoot 'outer-owned-process.ps1'
$taskCompilerAuthority=Join-Path $taskContainer 'evidence/durable-latest89-full-inspect-53ae-tool-prehash-20261011.json'
$taskPreviousPacket=Join-Path $taskContainer 'evidence/jiti-current-172-lexical-retry-prepared-20261017'
$taskPreviousRun=Join-Path $taskPreviousPacket 'root-current-172-lexical-retry-20261017-154003'
$taskCache=Join-Path $taskPreviousRun 'cache';$taskGlobalCache=Join-Path $taskPreviousRun 'global-cache'
$taskTerminalSource=Join-Path $PSScriptRoot 'terminal-source-verification.json'
if((Get-FileHash -LiteralPath $taskTerminalSource).Hash -cne 'D2A8FBCA7256443F8C4F0C7FE0CAFFA88FA136855476659E7429F09140ACB70C'){throw 'Exact terminal predecessor proof binding differs'}
$taskTerminal=Get-Content -Raw -LiteralPath $taskTerminalSource|ConvertFrom-Json -DateKind String
$taskDriverHash=(Get-FileHash -LiteralPath $PSCommandPath).Hash
$taskGrant=Get-Content -Raw -LiteralPath $RootGrantPath|ConvertFrom-Json
$taskNow=[DateTimeOffset]::UtcNow
if($taskGrant.authorized -isnot [bool] -or !$taskGrant.authorized -or $taskGrant.scope -cne 'ROOT-EXPANDED-MAIN-213-TERMINAL-CACHE-REUSE-SERIAL' -or $taskGrant.run_id -cne $RunId -or $taskGrant.candidate_head -cne $taskExpectedHead -or $taskGrant.driver_sha256 -cne $taskDriverHash){throw 'Exact terminal-cache-reuse compile-only Root grant required'}
foreach($taskForbidden in @('runtime_allowed','metadata_allowed','node_allowed','sentinel_allowed')){if($taskGrant.$taskForbidden -isnot [bool] -or $taskGrant.$taskForbidden){throw 'Runtime, metadata, Node and sentinel execution must remain explicitly forbidden'}}
$taskIssued=[DateTimeOffset]$taskGrant.issued_utc;$taskExpires=[DateTimeOffset]$taskGrant.expires_utc
if($taskIssued -gt $taskNow -or $taskExpires -lt $taskNow -or $taskExpires -le $taskIssued -or ($taskExpires-$taskIssued).TotalSeconds -gt 300){throw 'Fresh initial Root grant bounded to300s required'}
if($taskGrant.cache_mode -cne 'terminal-owned-154003-unsealed-reuse' -or $taskGrant.reuse_unsealed_compile_caches -isnot [bool] -or !$taskGrant.reuse_unsealed_compile_caches -or $taskGrant.cache_directory -cne $taskCache -or $taskGrant.global_cache_directory -cne $taskGlobalCache -or $taskGrant.unsealed_cache_exception -isnot [bool] -or !$taskGrant.unsealed_cache_exception -or $taskGrant.fresh_reproducibility_claim -isnot [bool] -or $taskGrant.fresh_reproducibility_claim){throw 'Only exact terminal-owned154003 UNSEALED cache exception permitted; no fresh reproducibility claim'}
if($taskGrant.predecessor_head -cne 'a7c7ef6b84e99cc018e75b2725c1b1375c41e56a' -or $taskGrant.predecessor_result_sha256 -cne '52E5B70F9F471A3530A9814F84EF565F4070F72B127121268F813A4425BCD9C4' -or $taskGrant.predecessor_compile_sha256 -cne 'BC5E7D5125548DDEA32059D5B0702FA614247D85370B6D0F365BA224CEB69C55' -or $taskGrant.predecessor_outer_sha256 -cne 'F4EFA7880B4771BA69ED178CE47E5718BF2BA93D79A166762B86AD2CBDF7A8C8'){throw 'Exact predecessor result/compiler/outer permission pins required'}
if((Get-FileHash -LiteralPath $taskCi).Hash -cne '607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285' -or (Get-FileHash -LiteralPath $taskClassifier).Hash -cne '3413A2A50B4D4C3BFF8709E4EE08C76BE449AAB1EDCB1E0C5C167DC7A804E301' -or (Get-FileHash -LiteralPath $taskOuter).Hash -cne '53E522C8397B5F7EE9AF721D8160B227E97FADA4E1DA36A938656E2403D56B6B'){throw 'Canonical owner/census/outer identity differs'}
. $taskCi
. $taskClassifier
New-Item -ItemType Directory -Path $taskProof -ErrorAction Stop|Out-Null
Copy-Item -LiteralPath $RootGrantPath -Destination (Join-Path $taskProof 'root-grant.json') -ErrorAction Stop
$taskAdmissionHistory=[Collections.Generic.List[object]]::new()
function Write-TaskJson {param($Value,[string]$Name) ConvertTo-Json -InputObject $Value -Depth 16|Set-Content -LiteralPath (Join-Path $taskProof $Name) -Encoding utf8NoBOM}
function Assert-TaskCachePath {
 param([string]$Path,[string]$Leaf)
 $taskFull=[IO.Path]::GetFullPath($Path);$taskAllowed=[IO.Path]::GetFullPath((Join-Path $taskPreviousRun $Leaf))
 if(![StringComparer]::OrdinalIgnoreCase.Equals($taskFull,$taskAllowed) -or !$taskFull.StartsWith($taskPreviousRun+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Cache escapes exact previous owned run allowlist'}
 $taskAncestor=[IO.DirectoryInfo]::new($taskFull)
 while($taskAncestor -and $taskAncestor.FullName.StartsWith($taskContainer,[StringComparison]::OrdinalIgnoreCase)){
  $taskItem=Get-Item -LiteralPath $taskAncestor.FullName -Force
  if(!$taskItem.PSIsContainer -or ($taskItem.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Cache ancestor missing or reparse point'}
  if([StringComparer]::OrdinalIgnoreCase.Equals($taskAncestor.FullName,$taskContainer)){break};$taskAncestor=$taskAncestor.Parent
 }
 if($null-eq$taskAncestor){throw 'Cache containment ancestry unavailable'}
 $taskPending=[Collections.Generic.Stack[string]]::new();$taskPending.Push($taskFull);$taskEntries=0
 while($taskPending.Count){foreach($taskItem in Get-ChildItem -LiteralPath $taskPending.Pop() -Force){
  if($taskItem.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Cache contents include a reparse point'}
  $taskEntries++;if($taskItem.PSIsContainer){$taskPending.Push($taskItem.FullName)}
 }}
 return @{path=$taskFull;entries_observed=$taskEntries;contents_sealed=$false;owned_path_reparse_check=$true}
}
function Assert-TaskLatestTerminalSource {
 $taskLatestPath=Join-Path $PSScriptRoot 'latest-terminal-source.json'
 if((Get-FileHash -LiteralPath $taskLatestPath).Hash -cne 'E53FE83F1DD90EEEF779E3B55913DDA15C405028AC324E2D78DB4CACCCF123A2'){throw 'Latest6f terminal binding differs'}
 $taskLatest=Get-Content -Raw -LiteralPath $taskLatestPath|ConvertFrom-Json -DateKind String
 foreach($taskFile in $taskLatest.files){if((Get-FileHash -LiteralPath $taskFile.path).Hash -cne $taskFile.sha256 -or (Get-Item -LiteralPath $taskFile.path).Length -ne $taskFile.bytes){throw 'Immutable latest6f terminal proof drift'}}
 $taskLatestRun=Join-Path $taskContainer 'evidence/jiti-current-172-terminal-cache-reuse-prepared-20261017/root-current-172-package-retry-20261017-163830'
 $taskLastResult=Get-Content -Raw -LiteralPath (Join-Path $taskLatestRun 'result.json')|ConvertFrom-Json -DateKind String
 $taskLastCompile=Get-Content -Raw -LiteralPath (Join-Path $taskLatestRun 'compile.json')|ConvertFrom-Json -DateKind String
 $taskLastOuter=Get-Content -Raw -LiteralPath ($taskLatestRun+'-outer.json')|ConvertFrom-Json -DateKind String
 $taskLastAbsent=@(Get-Content -Raw -LiteralPath (Join-Path $taskLatestRun 'owner-absence.json')|ConvertFrom-Json -DateKind String)
 $taskLastOuterAbsent=Get-Content -Raw -LiteralPath ($taskLatestRun+'-outer-absence.json')|ConvertFrom-Json -DateKind String
 $taskLastPlan=Get-Content -Raw -LiteralPath (Join-Path $taskLatestRun 'compile-plan.json')|ConvertFrom-Json -DateKind String
 if($taskLastResult.source_head -cne '6f0214152c1813974af99c9f3d6f7658825ce400' -or $taskLastResult.status -cne 'compile_only_passed' -or !$taskLastResult.postseal -or $taskLastResult.native_roots_after -ne 0 -or !$taskLastResult.owner_absence_verified -or $taskLastCompile.pid -ne 29848 -or $taskLastCompile.status -cne 'passed' -or $taskLastCompile.exit_code -ne 0 -or !$taskLastCompile.completed_utc -or ![StringComparer]::OrdinalIgnoreCase.Equals($taskLastCompile.working_directory,$taskRoot) -or $taskLastOuter.pid -ne 29868 -or $taskLastOuter.status -cne 'passed' -or $taskLastOuter.exit_code -ne 0 -or !$taskLastOuter.completed_utc){throw 'Latest6f cache owners are not saved terminal at the same physical path'}
 if($taskLastAbsent.Count -ne 1 -or $taskLastAbsent[0].pid -ne $taskLastCompile.pid -or $taskLastAbsent[0].recorded_created_utc -cne $taskLastCompile.created_utc -or !$taskLastAbsent[0].absent -or @($taskLastAbsent[0].current).Count -ne 0 -or $taskLastOuterAbsent.pid -ne $taskLastOuter.pid -or $taskLastOuterAbsent.fresh_pid_present -ne 0 -or $taskLastOuterAbsent.owner_sha256 -cne (Get-FileHash -LiteralPath ($taskLatestRun+'-outer.json')).Hash){throw 'Latest6f exact saved owner absences differ'}
 if($taskLastPlan.cache_directory -cne $taskCache -or $taskLastPlan.global_cache_directory -cne $taskGlobalCache -or $taskLastPlan.cache_content_sealed -or $taskGrant.latest_terminal_binding_sha256 -cne 'E53FE83F1DD90EEEF779E3B55913DDA15C405028AC324E2D78DB4CACCCF123A2'){throw 'Latest6f same UNSEALED cache pair and grant binding required'}
 return @{source_head=$taskLastResult.source_head;compiler_pid=29848;outer_pid=29868;terminal_saved_absences=$true;cache_contents_sealed=$false}
}

function Assert-TaskTerminalCacheSource {
 if((Get-FileHash -LiteralPath $taskTerminalSource).Hash -cne 'D2A8FBCA7256443F8C4F0C7FE0CAFFA88FA136855476659E7429F09140ACB70C'){throw 'Terminal source binding drift'}
 foreach($taskFile in $taskTerminal.files){if((Get-FileHash -LiteralPath $taskFile.path).Hash -cne $taskFile.sha256 -or (Get-Item -LiteralPath $taskFile.path).Length -ne $taskFile.bytes){throw 'Immutable original terminal proof drift'}}
 $taskOldResult=Get-Content -Raw -LiteralPath (Join-Path $taskPreviousRun 'result.json')|ConvertFrom-Json -DateKind String
 $taskOldCompile=Get-Content -Raw -LiteralPath (Join-Path $taskPreviousRun 'compile.json')|ConvertFrom-Json -DateKind String
 $taskOldAbsent=@(Get-Content -Raw -LiteralPath (Join-Path $taskPreviousRun 'owner-absence.json')|ConvertFrom-Json -DateKind String)
 $taskOldOuterPath=Join-Path $taskPreviousPacket 'root-current-172-lexical-retry-20261017-154003-outer.json'
 $taskOldOuter=Get-Content -Raw -LiteralPath $taskOldOuterPath|ConvertFrom-Json -DateKind String
 $taskOldOuterAbsent=Get-Content -Raw -LiteralPath (Join-Path $taskPreviousPacket 'root-current-172-lexical-retry-20261017-154003-outer-absence.json')|ConvertFrom-Json -DateKind String
 $taskOldPlan=Get-Content -Raw -LiteralPath (Join-Path $taskPreviousRun 'compile-plan.json')|ConvertFrom-Json -DateKind String
 if($taskOldResult.source_head -cne 'a7c7ef6b84e99cc018e75b2725c1b1375c41e56a' -or $taskOldResult.status -cne 'failed' -or !$taskOldResult.postseal -or $taskOldResult.native_roots_after -ne 0 -or !$taskOldResult.owner_absence_verified){throw 'Predecessor is not the exact terminal sealed negative'}
 if($taskOldCompile.pid -ne 27688 -or $taskOldCompile.status -cne 'failed' -or $taskOldCompile.exit_code -ne 1 -or !$taskOldCompile.completed_utc -or ![StringComparer]::OrdinalIgnoreCase.Equals($taskOldCompile.working_directory,$taskRoot) -or $taskOldOuter.pid -ne 53836 -or $taskOldOuter.status -cne 'failed' -or $taskOldOuter.exit_code -ne 1 -or !$taskOldOuter.completed_utc){throw 'Predecessor compiler/outer not terminal at the same physical candidate path'}
 if($taskOldAbsent.Count -ne 1 -or $taskOldAbsent[0].pid -ne $taskOldCompile.pid -or $taskOldAbsent[0].recorded_created_utc -cne $taskOldCompile.created_utc -or !$taskOldAbsent[0].absent -or @($taskOldAbsent[0].current).Count -ne 0 -or $taskOldOuterAbsent.pid -ne $taskOldOuter.pid -or $taskOldOuterAbsent.fresh_pid_present -ne 0 -or $taskOldOuterAbsent.owner_sha256 -cne (Get-FileHash -LiteralPath $taskOldOuterPath).Hash){throw 'Exact original compiler/outer terminal absence proof differs'}
 if($taskOldPlan.cache_directory -cne $taskCache -or $taskOldPlan.global_cache_directory -cne $taskGlobalCache -or $taskOldPlan.cache_content_sealed){throw 'Caches are not the exact originally recorded unsealed pair'}
 return @{latest_terminal=Assert-TaskLatestTerminalSource;predecessor_head=$taskOldResult.source_head;compile_pid=27688;outer_pid=53836;terminal_saved_absences=$true;cache=Assert-TaskCachePath $taskCache 'cache';global_cache=Assert-TaskCachePath $taskGlobalCache 'global-cache';cache_contents_sealed=$false;fresh_reproducibility_claim=$false}
}
function Get-TaskCensus {
 $taskRows=@(Get-CimInstance Win32_Process -OperationTimeoutSec 3 -ErrorAction Stop)
 if(!$taskRows.Count){throw 'Successful nonempty process census required'}
 return @{rows=$taskRows;candidates=@(Get-ModelsNativeCandidates -Rows $taskRows -Container $taskContainer)}
}
function Assert-TaskAdmission {
 $taskWait=[Diagnostics.Stopwatch]::StartNew()
 do {
  $taskOs=@(Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 3 -ErrorAction Stop)
  if($taskOs.Count -ne 1 -or $null -eq $taskOs[0].FreePhysicalMemory){throw 'One OS row with available RAM required'}
  $taskCensus=Get-TaskCensus
  if(@($taskCensus.rows|Where-Object {$_.ProcessId -in @(27688,53836,29848,29868)}).Count){throw 'Original compiler/outer PID is live or reused; independent Root reconciliation required'}
  $taskProbe=[ordered]@{free_kib=[long]$taskOs[0].FreePhysicalMemory;minimum_kib=16777216;native_roots=$taskCensus.candidates.Count;native_candidates=$taskCensus.candidates;census_count=$taskCensus.rows.Count;utc=[DateTimeOffset]::UtcNow.ToString('o')}
  $taskAdmissionHistory.Add($taskProbe)
  if($taskCensus.candidates.Count){throw 'Another native candidate prevents serial admission'}
  if($taskWait.Elapsed.TotalSeconds -ge 54){throw 'Fresh16GiB admission expired after bounded54s'}
  if($taskProbe.free_kib -ge 16777216){return $taskProbe}
  $taskRemainingMs=54000-$taskWait.ElapsedMilliseconds
  if($taskRemainingMs -gt 0){Start-Sleep -Milliseconds ([int][Math]::Min(1000,$taskRemainingMs))}
 }while($true)
}
function Get-TaskSeal {
 param([string]$Name)
 $null=Assert-TaskTerminalCacheSource
 $taskPaths=@(& $taskGit -c core.fsmonitor=false -c core.hooksPath=NUL -C $taskRoot ls-files)
 if($LASTEXITCODE -ne 0 -or $taskPaths.Count -ne 11631 -or @($taskPaths|Sort-Object -Unique -CaseSensitive).Count -ne 11631){throw 'Exact full11631 tracked candidate paths required'}
 $taskHead=([string](& $taskGit -c core.fsmonitor=false -c core.hooksPath=NUL -C $taskRoot rev-parse HEAD)).Trim()
 if($LASTEXITCODE -ne 0 -or $taskHead -cne $taskExpectedHead){throw 'Exact immutable C3/213-AgentAF-SDK-CommonJS-Babel32EA compile-only head differs'}
 $taskStatus=@(& $taskGit -c core.fsmonitor=false -c core.hooksPath=NUL -C $taskRoot status --porcelain)
 if($LASTEXITCODE -ne 0 -or $taskStatus.Count){throw 'Clean exact candidate required'}
 $taskCompilerInventory=Get-CiInventory $taskCompiler
 if($taskCompilerInventory.rows.Count -ne 19546){throw 'Complete compiler19546 required'}
 if((Get-FileHash -LiteralPath $taskCompilerAuthority).Hash -cne 'DEE259F171F720AB2C08E8DD473975E22C876417CD62E4F016C71A7C662794EB'){throw 'Immutable compiler authority differs'}
 $taskOriginal=Get-Content -Raw -LiteralPath $taskCompilerAuthority|ConvertFrom-Json
 $taskAuthorityRows=@($taskOriginal.inputs|ForEach-Object {if(!$_.path.StartsWith($taskOriginal.root+'\',[StringComparison]::Ordinal)){throw 'Compiler authority path escapes original root'};$_.path.Substring($taskOriginal.root.Length+1).Replace([char]92,[char]47)+' '+$_.sha256})
 $taskCompilerRows=@($taskCompilerInventory.rows|ForEach-Object {$_.relative.Replace([char]92,[char]47)+' '+$_.sha256})
 if($taskAuthorityRows.Count -ne 19546 -or @($taskAuthorityRows|Sort-Object -Unique -CaseSensitive).Count -ne 19546 -or @($taskCompilerRows|Sort-Object -Unique -CaseSensitive).Count -ne 19546 -or @(Compare-Object $taskAuthorityRows $taskCompilerRows -CaseSensitive).Count){throw 'Full compiler differs from original19546 authority'}
 $taskCPins=@{'vendor/quickjs/quickjs.c'='DA14DFBB7E73DED032E9FCD742FD2E49FDAF45273F48D24D6089018539601614';'vendor/quickjs/quickjs.h'='A79E75A40D34C9E7CAFB9AB31359B7EE925FE205636603F2022CF764CFC18346';'build.zig'='5837DE41F1D08C520A38D049895A817F6BE71F11475AC7AB7CBD07928D815B05';'src/native_jiti_expanded_compile_only_root.zig'='026E723E6DFC1025D07C53485500F609C78DCCC41F8ACB067AF487ACCDDA031A';'tools/ci/native_qualification_ci.ps1'='607BEDBB91FE318D214CD2C3B9C83D80437335C0062C320C0EACB3A745B38285'}
 foreach($taskPin in $taskCPins.GetEnumerator()){if((Get-FileHash -LiteralPath (Join-Path $taskRoot $taskPin.Key)).Hash -cne $taskPin.Value){throw "Exact C3/213-AgentAF-SDK-CommonJS-Babel32EA/owner pin differs: $($taskPin.Key)"}}
 $taskExpectedAbsent=@('src/extensions/fixtures/jiti-utils-2_7.expected.json','src/extensions/fixtures/jiti-options-2_7.expected.json','src/extensions/fixtures/jiti-mlly-1.8.2.json','src/extensions/fixtures/jiti-mlly-boundaries-4.2.json','src/extensions/fixtures/jiti-mlly-normal-close-numeric-4.2.json','src/extensions/fixtures/jiti-pathe-2.0.3.json','src/extensions/fixtures/jiti-pathe-2.0.3-supplement.json','src/extensions/fixtures/jiti-pathe-cache-2.0.3.json','src/extensions/fixtures/jiti-pathe-policy-2.0.3.json')
 foreach($taskPath in $taskExpectedAbsent){if(Test-Path -LiteralPath (Join-Path $taskRoot $taskPath)){throw 'Uncaptured expected file unexpectedly present'}}
 $taskControlPaths=@($PSCommandPath,$taskCi,$taskClassifier,$taskOuter,$taskCompilerAuthority,$taskTerminalSource,(Join-Path $PSScriptRoot 'README.md'),(Join-Path $PSScriptRoot 'retry4.prepared-manifest.json'),(Join-Path $PSScriptRoot 'predecessor-prepared-manifest.json'),(Join-Path $PSScriptRoot 'derivation.json'),(Join-Path $PSScriptRoot 'target-independent-body-review.json'),(Join-Path $PSScriptRoot 'driver-independent-body-review.json'),(Join-Path $PSScriptRoot 'root-grant.template.json'),(Join-Path $PSScriptRoot 'prepared-manifest.json'),(Join-Path $taskProof 'root-grant.json'),(Join-Path $taskContainer '.pi-zig-workspace.json'),(Join-Path $taskContainer 'path-relocations.json'),$taskGit,'C:\Program Files\PowerShell\7\pwsh.exe')+@($taskTerminal.files|ForEach-Object path)+@((Join-Path $PSScriptRoot 'latest-terminal-source.json'))+@((Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'latest-terminal-source.json')|ConvertFrom-Json -DateKind String).files|ForEach-Object path)
 $taskSeal=[ordered]@{candidate_head=$taskHead;source=@(Get-CiRows $taskRoot $taskPaths);compiler=@($taskCompilerInventory.rows);controls=@($taskControlPaths|ForEach-Object {[ordered]@{path=$_;sha256=(Get-FileHash -LiteralPath $_).Hash}});expected_absences=$taskExpectedAbsent;utc=[DateTimeOffset]::UtcNow.ToString('o')}
 Write-TaskJson $taskSeal "$Name.json";return $taskSeal
}
function Assert-TaskSeal {
 param($Actual,$Expected)
 if($Actual.candidate_head -cne $Expected.candidate_head){throw 'Source head drift'}
 foreach($taskGroup in @('source','compiler','controls')){
  $taskLeft=@($Expected[$taskGroup]|ForEach-Object {$(if($taskGroup -ceq 'controls'){$_.path}else{$_.relative})+' '+$_.sha256})
  $taskRight=@($Actual[$taskGroup]|ForEach-Object {$(if($taskGroup -ceq 'controls'){$_.path}else{$_.relative})+' '+$_.sha256})
  if(@(Compare-Object $taskLeft $taskRight -CaseSensitive).Count){throw "$taskGroup inventory/hash drift"}
 }
}
$taskResult=[ordered]@{status='running';source_head=$taskExpectedHead;scope='C3/213-AgentAF-SDK-CommonJS-Babel32EA compile-only with exact terminal-owned154003 cache exception';cache_mode='terminal-owned-154003-unsealed-reuse';unsealed_cache_exception=$true;fresh_reproducibility_claim=$false;runtime_executed=$false;metadata_executed=$false;node_executed=$false;sentinel_executed=$false;compile=$null;postseal=$false;artifacts_verified=$false;native_roots_after=$null;owner_absence_verified=$false}
$taskBefore=$null;$taskArtifacts=$null;$taskCompileAttempted=$false
try {
 if((Get-FileHash -LiteralPath $taskZig).Hash -cne '086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864'){throw 'Pinned Zig0.16 differs'}
 Write-TaskJson (Assert-TaskTerminalCacheSource) 'cache-reuse-source.json'
 Write-TaskJson (Assert-TaskAdmission) 'initial-admission.json'
 $taskBefore=Get-TaskSeal 'before'
 Write-TaskJson (Assert-TaskAdmission) 'compile-admission.json'
 $taskPrefix=Join-Path $taskProof 'out'
 if(Test-Path -LiteralPath $taskPrefix){throw 'New RunId output must be fresh; old artifacts are never reused'}
 $taskArgs=@('build','build-expanded-main-jiti-sdk-agent-compile-only-artifact','-Doptimize=Debug','-Duse-llvm=true','-Ddiagnostic-tests=false','-j1','--prefix',$taskPrefix,'--cache-dir',$taskCache,'--global-cache-dir',$taskGlobalCache,'--summary','all')
 Write-TaskJson @{executable=$taskZig;arguments=$taskArgs;timeout_seconds=1320;pipe_settle_seconds=10;cache_mode=$taskGrant.cache_mode;cache_directory=$taskCache;global_cache_directory=$taskGlobalCache;cache_content_sealed=$false;output_prefix_fresh=$true;predecessor_result_sha256=$taskGrant.predecessor_result_sha256;predecessor_compile_sha256=$taskGrant.predecessor_compile_sha256;predecessor_outer_sha256=$taskGrant.predecessor_outer_sha256;fresh_reproducibility_claim=$false} 'compile-plan.json'
 $taskCompileAttempted=$true
 $taskResult.compile=Invoke-CiOwnedProcess $taskZig $taskArgs $taskRoot (Join-Path $taskProof 'compile') 1320
 $taskArtifacts=Get-CiInventory $taskPrefix;Write-TaskJson $taskArtifacts 'artifacts-before.json'
 $taskRoles=@($taskArtifacts.rows|ForEach-Object {$_.relative.Replace([char]92,[char]47)}|Sort-Object -CaseSensitive)
 if($taskRoles.Count -ne 2 -or ($taskRoles -join '|') -cne 'bin/pi-expanded-jiti-sdk-agent-compile-only.exe|bin/pi-expanded-jiti-sdk-agent-compile-only.pdb'){throw 'Exactly fresh named213 compile-only EXE/PDB roles required'}
 foreach($taskRole in $taskRoles){if((Get-Item -LiteralPath (Join-Path $taskPrefix $taskRole)).Length -le 0){throw 'Nonempty EXE/PDB required'}}
 $taskResult.artifacts_verified=$true;$taskResult.status='compile_only_passed'
}catch{$taskResult.status='failed';$taskResult.error=$_.Exception.Message}
finally {
 try{$taskFinal=Get-TaskSeal 'final';if($null -eq $taskBefore){throw 'Before baseline unavailable; final retained only'};Assert-TaskSeal $taskFinal $taskBefore;$taskResult.postseal=$true}catch{$taskResult.status='failed_postseal';$taskResult.postseal_error=$_.Exception.Message}
 try{if($null -ne $taskArtifacts){Assert-CiInventory $taskArtifacts (Join-Path $taskProof 'artifacts-final.json')}elseif(Test-Path -LiteralPath (Join-Path $taskProof 'out')){Write-TaskJson (Get-CiInventory (Join-Path $taskProof 'out')) 'artifacts-negative.json'}}catch{$taskResult.status='failed_artifacts';$taskResult.artifacts_error=$_.Exception.Message}
 try{$taskCensus=Get-TaskCensus;Write-TaskJson $taskCensus 'process-census-final.json';$taskResult.native_roots_after=$taskCensus.candidates.Count;if($taskCensus.candidates.Count){throw 'Native candidates remain'}}catch{$taskResult.status='failed_native_census';$taskResult.census_error=$_.Exception.Message}
 try{
  $taskReceipt=Join-Path $taskProof 'compile.json'
  if($taskCompileAttempted -and !(Test-Path -LiteralPath $taskReceipt)){throw 'Attempted compile has no durable owner receipt; independent reconciliation required'}
  $taskAbsent=@(if(Test-Path -LiteralPath $taskReceipt){$taskOwner=Get-Content -Raw -LiteralPath $taskReceipt|ConvertFrom-Json;if(!$taskOwner.pid -or !$taskOwner.created_utc){throw 'Incomplete original compile owner identity'};$taskLive=@(Get-CimInstance Win32_Process -Filter "ProcessId = $($taskOwner.pid)" -OperationTimeoutSec 3 -ErrorAction Stop);[ordered]@{phase='compile';owner_receipt=$taskReceipt;pid=$taskOwner.pid;recorded_created_utc=$taskOwner.created_utc;current=$taskLive;absent=($taskLive.Count -eq 0)}})
  Write-TaskJson $taskAbsent 'owner-absence.json'
  if(@($taskAbsent|Where-Object {!$_.absent}).Count){throw 'Original owner PID still present or reused; Root reconciliation required'}
  $taskResult.owner_absence_verified=(!$taskCompileAttempted -or $taskAbsent.Count -eq 1)
 }catch{$taskResult.status='failed_absence';$taskResult.absence_error=$_.Exception.Message}
 $taskResult.admission_probes=$taskAdmissionHistory.ToArray();$taskResult.completed_utc=[DateTimeOffset]::UtcNow.ToString('o');Write-TaskJson $taskResult 'result.json'
}
$taskResult|ConvertTo-Json -Depth 16
if($taskResult.status -cne 'compile_only_passed'){throw 'Jiti compile-only gate failed'}

