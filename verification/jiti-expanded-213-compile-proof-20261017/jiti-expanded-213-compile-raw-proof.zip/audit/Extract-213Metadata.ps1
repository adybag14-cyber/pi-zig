$ErrorActionPreference='Stop'
$out=Join-Path $PSScriptRoot 'metadata-fragments';[IO.Directory]::CreateDirectory($out)|Out-Null
$report=Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'independent-acceptance.json')|ConvertFrom-Json -DateKind String
function Sha([string]$path){(Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash}
function Need([bool]$condition,[string]$message){if(!$condition){throw $message}}
$exePath=$report.artifact_roles[0].path;$pdbPath=$report.artifact_roles[1].path
Need ((Sha $exePath)-ceq$report.artifact_roles[0].sha256-and(Sha $pdbPath)-ceq$report.artifact_roles[1].sha256) 'audited artifact bytes'
$pe=[IO.File]::ReadAllBytes($exePath);$pdb=[IO.File]::ReadAllBytes($pdbPath)
function PE16([int]$offset){[BitConverter]::ToUInt16($pe,$offset)}
function PE32([int]$offset){[BitConverter]::ToUInt32($pe,$offset)}
$header=PE32 60;$optional=$header+24;$sectionCount=PE16 ($header+6);$sectionStart=$optional+(PE16 ($header+20))
function MapRva([uint32]$rva){for($i=0;$i-lt$sectionCount;$i++){$row=$sectionStart+40*$i;$va=PE32 ($row+12);$size=[Math]::Max((PE32 ($row+8)),(PE32 ($row+16)));if($rva-ge$va-and$rva-lt$va+$size){return [int]((PE32 ($row+20))+$rva-$va)}};throw 'RVA not mapped'}
$debug=MapRva (PE32 ($optional+112+6*8));$debugBytes=PE32 ($optional+116+6*8);$rsdsOffset=$null
for($i=0;$i-lt$debugBytes/28;$i++){if((PE32 ($debug+28*$i+12))-eq2){$raw=PE32 ($debug+28*$i+24);if([Text.Encoding]::ASCII.GetString($pe,$raw,4)-ceq'RSDS'){$rsdsOffset=$raw}}};Need ($null-ne$rsdsOffset) 'RSDS identity'
[IO.File]::WriteAllBytes((Join-Path $out 'PE-RSDS-identity-header.bin'),$pe[$rsdsOffset..($rsdsOffset+23)])
[IO.File]::WriteAllBytes((Join-Path $out 'PE-section-headers.bin'),$pe[$sectionStart..($sectionStart+40*$sectionCount-1)])
$blockSize=[BitConverter]::ToUInt32($pdb,32);$directorySize=[BitConverter]::ToUInt32($pdb,44);$map=[BitConverter]::ToUInt32($pdb,52);$directory=[byte[]]::new($directorySize)
for($i=0;$i-lt[Math]::Ceiling($directorySize/$blockSize);$i++){$block=[BitConverter]::ToUInt32($pdb,$map*$blockSize+4*$i);[Array]::Copy($pdb,$block*$blockSize,$directory,$i*$blockSize,[Math]::Min($blockSize,$directorySize-$i*$blockSize))}
$count=[BitConverter]::ToUInt32($directory,0);$cursor=4+4*$count;$streams=@{}
for($index=0;$index-lt$count;$index++){$size=[BitConverter]::ToUInt32($directory,4+4*$index);$n=if($size-eq[uint32]::MaxValue){0}else{[int][Math]::Ceiling($size/$blockSize)};$blocks=[uint32[]]::new($n);for($i=0;$i-lt$n;$i++){$blocks[$i]=[BitConverter]::ToUInt32($directory,$cursor+4*$i)};$streams[$index]=@{size=$size;blocks=$blocks};$cursor+=4*$n}
function Stream([int]$index){$entry=$streams[$index];$bytes=[byte[]]::new($entry.size);for($i=0;$i-lt$entry.blocks.Count;$i++){[Array]::Copy($pdb,$entry.blocks[$i]*$blockSize,$bytes,$i*$blockSize,[Math]::Min($blockSize,$entry.size-$i*$blockSize))};return ,$bytes}
$info=Stream 1;$dbi=Stream 3;$symbolStream=[BitConverter]::ToUInt16($dbi,20);$symbols=Stream $symbolStream
[IO.File]::WriteAllBytes((Join-Path $out 'PDB-info-identity-header.bin'),$info[0..27])
$anchors=Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'actual213-anchor-symbols.json')|ConvertFrom-Json -DateKind String
$buffer=[IO.MemoryStream]::new();$records=@()
foreach($anchor in $anchors){$start=[int]$anchor.stream_record_offset;$size=2+[int]$anchor.record_length;$raw=[byte[]]::new($size);[Array]::Copy($symbols,$start,$raw,0,$size)
 Need ([BitConverter]::ToUInt16($raw,2)-eq0x110e-and([BitConverter]::ToUInt32($raw,4)-band2)-ne0) 'actual raw S_PUB32 function record'
 $records+=[ordered]@{name=$anchor.name;source_symbol_stream=$symbolStream;source_stream_offset=$start;capsule_record_offset=$buffer.Position;bytes=$size;sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($raw));segment=$anchor.segment;section_offset=$anchor.section_offset;rva=$anchor.rva}
 $buffer.Write($raw,0,$raw.Length)
}
Need ($records.Count-eq213) '213 raw records';[IO.File]::WriteAllBytes((Join-Path $out 'PDB-S_PUB32-anchor-records.bin'),$buffer.ToArray());$buffer.Dispose()
[IO.File]::WriteAllText((Join-Path $out 'raw-anchor-record-index.json'),($records|ConvertTo-Json -Depth 6).Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$ledger=[ordered]@{scope='Inert metadata fragments only; no complete EXE/PDB/cache, machine instructions, unrelated symbol inventory or CodeView absolute filename';source_artifacts=$report.artifact_roles;source_PE_RSDS_file_offset=$rsdsOffset;PE_RSDS_header_bytes=24;PE_section_headers_file_offset=$sectionStart;PE_section_count=$sectionCount;PDB_info_stream=1;PDB_info_header_bytes=28;PDB_symbol_record_stream=$symbolStream;raw_function_anchor_records=213;identity=$report.EXE_RSDS;files=@(Get-ChildItem -LiteralPath $out -File|Sort-Object Name|ForEach-Object{[ordered]@{name=$_.Name;bytes=$_.Length;sha256=(Sha $_.FullName)}});no_execution=$true}
[IO.File]::WriteAllText((Join-Path $out 'fragment-provenance.json'),($ledger|ConvertTo-Json -Depth 7).Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{records=213;files=$ledger.files.Count;fragment_provenance_sha256=(Sha (Join-Path $out 'fragment-provenance.json'))}|ConvertTo-Json
