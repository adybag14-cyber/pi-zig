$ErrorActionPreference='Stop'
$taskRoot='C:\Users\adyba\pi-zig\worktrees\root-tla-qualification'
$taskProof=$PSScriptRoot
$taskCompiler='C:\Users\adyba\pi-zig\toolchain\zig-x86_64-windows-0.16.0'
$taskZig=Join-Path $taskCompiler 'zig.exe'
$taskCi=Join-Path $taskRoot 'tools\ci\native_qualification_ci.ps1'
$taskProtocol=Join-Path $taskRoot 'tools\ci\Invoke-NativeTestProtocol.ps1'
. $taskCi
. $taskProtocol
if(Test-Path -LiteralPath (Join-Path $taskProof 'grant.json')){throw 'Refuse focused proof overwrite'}
function Get-TaskNativeRoots {
 @(Get-CimInstance Win32_Process | Where-Object {
  $_.Name -in @('zig.exe','build.exe','test.exe') -or
  ($_.ExecutablePath -and ($_.ExecutablePath -match '\\(?:\.zig-cache|zig-out)\\' -or $_.ExecutablePath.StartsWith($taskProof+'\',[StringComparison]::OrdinalIgnoreCase)))
 })
}
$taskAdmissionHistory=[Collections.Generic.List[object]]::new()
function Assert-TaskAdmission {
 $taskWait=[Diagnostics.Stopwatch]::StartNew()
 $taskProbes=[Collections.Generic.List[object]]::new()
 do {
  $taskOs=Get-CimInstance Win32_OperatingSystem
  $taskRoots=Get-TaskNativeRoots
  $taskProbe=[ordered]@{free_kib=$taskOs.FreePhysicalMemory;minimum_kib=16777216;native_roots=$taskRoots.Count;utc=[DateTimeOffset]::UtcNow.ToString('o')}
  $taskProbes.Add($taskProbe)
  $taskAdmissionHistory.Add($taskProbe)
  if($taskRoots.Count){throw 'Another native root prevents serial admission'}
  if($taskWait.Elapsed.TotalSeconds -ge 54){throw ("Fresh16GiB admission window expired: free_kib={0}, native_roots=0" -f $taskOs.FreePhysicalMemory)}
  if($taskOs.FreePhysicalMemory -ge 16777216){return [ordered]@{free_kib=$taskOs.FreePhysicalMemory;minimum_kib=16777216;native_roots=0;utc=$taskProbe.utc;wait_seconds=$taskWait.Elapsed.TotalSeconds;probes=$taskProbes.ToArray()}}
  if($taskWait.Elapsed.TotalSeconds -ge 54){throw ("Fresh16GiB admission denied after bounded wait: free_kib={0}, native_roots=0" -f $taskOs.FreePhysicalMemory)}
  $taskRemainingMs=54000-$taskWait.ElapsedMilliseconds
  if($taskRemainingMs -gt 0){Start-Sleep -Milliseconds ([int][Math]::Min(1000,$taskRemainingMs))}
 }while($true)
}
function Get-TaskSeal {
 param([string]$Name)
 $taskSourcePaths=@(git -C $taskRoot ls-files)
 if($LASTEXITCODE -ne 0){throw 'Candidate tracked inventory unavailable'}
 $taskCompilerInventory=Get-CiInventory $taskCompiler
 if($taskCompilerInventory.rows.Count -ne 19546){throw 'Complete compiler19546 inventory required'}
 $taskSeal=[ordered]@{
  candidate_head=([string](git -C $taskRoot rev-parse HEAD)).Trim()
  source=@(Get-CiRows $taskRoot $taskSourcePaths)
  compiler=@($taskCompilerInventory.rows)
  driver_sha256=(Get-FileHash -LiteralPath $PSCommandPath).Hash
 }
 $taskSeal|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $taskProof "$Name.json") -Encoding utf8NoBOM
 return $taskSeal
}
function Assert-TaskSeal {
 param($Actual,$Expected)
 if($Actual.candidate_head -cne $Expected.candidate_head -or $Actual.driver_sha256 -cne $Expected.driver_sha256){throw 'Candidate/driver changed'}
 foreach($taskGroup in @('source','compiler')){
  $taskExpectedRows=@($Expected[$taskGroup]|ForEach-Object{$_.relative+' '+$_.sha256})
  $taskActualRows=@($Actual[$taskGroup]|ForEach-Object{$_.relative+' '+$_.sha256})
  if(@(Compare-Object $taskExpectedRows $taskActualRows).Count){throw "$taskGroup hash or inventory drift"}
 }
}
if(@(git -C $taskRoot status --porcelain).Count){throw 'Clean exact Root qualification composition required'}
if((Get-FileHash -LiteralPath (Join-Path $taskRoot 'vendor\quickjs\quickjs.c')).Hash -cne '2FA2E26E35B7D5C45D1FFD3F6F10EE3A5DE9A984738486128399A20BD8E4D88D'){throw 'Reviewed C identity differs'}
if((Get-FileHash -LiteralPath (Join-Path $taskRoot 'vendor\quickjs\quickjs.h')).Hash -cne '341CF06F8041B8311D49767026C85C7B859BCFEE3088380F3FFE6D77527052AB'){throw 'Reviewed header differs'}
if((Get-FileHash -LiteralPath $taskZig).Hash -cne '086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864'){throw 'Pinned Zig0.16 identity differs'}
$taskBefore=Get-TaskSeal 'before'
$taskGroups=@(
 @{name='foundation';step='build-highlight-root10db-foundation';count=6;artifact='highlight-root10db-foundation.exe'},
 @{name='async26';step='build-highlight-root10db-async26';count=26;artifact='highlight-root10db-async26.exe'},
 @{name='generator';step='build-highlight-root10db-generator';count=19;artifact='highlight-root10db-generator.exe'},
 @{name='generator-gpa';step='build-highlight-root10db-generator-gpa';count=2;artifact='highlight-root10db-generator-gpa.exe'},
 @{name='json';step='build-highlight-root10db-json';count=11;artifact='highlight-root10db-json.exe'},
 @{name='source51';step='build-highlight-root10db-source51';count=2;artifact='highlight-root10db-source51.exe'},
 @{name='operators';step='build-highlight-root10db-operators';count=2;artifact='highlight-root10db-operators.exe'},
 @{name='engine';step='build-highlight-root10db-engine';count=20;artifact='highlight-root10db-engine.exe'},
 @{name='recovery';step='build-highlight-root10db-recovery';count=23;artifact='highlight-root10db-recovery.exe'},
 @{name='sdk-boundary';step='build-native-sdk-exception-boundary';count=5;artifact='test.exe'}
)
$taskGrant=[ordered]@{scope='Root post-shared-Promise C regression groups plus actual SDK boundary controls; no deleted runtime/Node/Source capture or default application qualification';source_head=$taskBefore.candidate_head;source_files=$taskBefore.source.Count;compiler_files=$taskBefore.compiler.Count;ci_owner_sha256=(Get-FileHash -LiteralPath $taskCi).Hash;protocol_sha256=(Get-FileHash -LiteralPath $taskProtocol).Hash;groups=$taskGroups;runtime_scope='Actual --listen=- run_test protocol, every selected index, flags allzero, 120s total per group, owner pipe settle10s';admission=$null;status='pending'}
try{$taskGrant.admission=Assert-TaskAdmission;$taskGrant.status='admitted'}catch{$taskGrant.status='admission_denied';$taskGrant.error=$_.Exception.Message}
$taskGrant|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $taskProof 'grant.json') -Encoding utf8NoBOM
if($taskGrant.status -cne 'admitted'){throw 'Focused native grant admission denied'}
$taskResult=[ordered]@{status='running';groups=@();postseal=$false;native_roots_after=$null}
try {
 foreach($taskGroup in $taskGroups){
  $null=Assert-TaskAdmission
  $taskPrefix=Join-Path $taskProof ($taskGroup.name+'-out')
  $taskArgs=@('build',$taskGroup.step,'-Doptimize=Debug','-Duse-llvm=true','-j1','--prefix',$taskPrefix,'--cache-dir','C:\Users\adyba\pi-zig\evidence\root-tla-focused-20261016\cache','--global-cache-dir','C:\Users\adyba\pi-zig\evidence\root-tla-focused-20261016\global-cache','--summary','all')
  $taskCompileReceipt=Join-Path $taskProof ($taskGroup.name+'-compile')
  $null=Invoke-CiOwnedProcess $taskZig $taskArgs $taskRoot $taskCompileReceipt 1320
  $taskCompile=Get-Content -LiteralPath "$taskCompileReceipt.json" -Raw|ConvertFrom-Json
  if((Get-TaskNativeRoots).Count){throw 'Native roots remain after compile'}
  $taskCompiledBinary=Join-Path (Join-Path $taskPrefix 'bin') $taskGroup.artifact
  $taskBinary=Join-Path (Join-Path $taskPrefix 'bin') 'test.exe'
  if($taskCompiledBinary -cne $taskBinary){Copy-Item -LiteralPath $taskCompiledBinary -Destination $taskBinary}
  $taskCompiledHash=(Get-FileHash -LiteralPath $taskCompiledBinary).Hash
  if((Get-FileHash -LiteralPath $taskBinary).Hash -cne $taskCompiledHash){throw 'Owned test-name copy differs from exact compiled artifact'}
  @{compiled=$taskCompiledBinary;owned=$taskBinary;sha256=$taskCompiledHash;scope='Byte-identical canonical test.exe copy for unchanged strict CI owner whitelist'}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $taskProof ($taskGroup.name+'-artifact-copy.json')) -Encoding utf8NoBOM
  $taskMetadata=Read-CiTestMetadata $taskBinary $taskRoot (Join-Path $taskProof ($taskGroup.name+'-metadata')) $taskGroup.count
  $taskMetadata|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $taskProof ($taskGroup.name+'-selected-tests.json')) -Encoding utf8NoBOM
  $null=Assert-TaskAdmission
  $taskRuntime=Invoke-NativeTestProtocol $taskBinary $taskRoot (Join-Path $taskProof ($taskGroup.name+'-runtime')) $taskMetadata.tests.Count
  $taskResult.groups+=,[ordered]@{name=$taskGroup.name;compile=$taskCompile;metadata=$taskMetadata;runtime=$taskRuntime}
  Assert-TaskSeal (Get-TaskSeal ($taskGroup.name+'-after')) $taskBefore
 }
 $taskResult.status='passed'
}catch{$taskResult.status='failed';$taskResult.error=$_.Exception.Message}
finally {
 try{Assert-TaskSeal (Get-TaskSeal 'final') $taskBefore;$taskResult.postseal=$true}catch{$taskResult.status='failed_postseal';$taskResult.postseal_error=$_.Exception.Message}
 $taskResult.native_roots_after=(Get-TaskNativeRoots).Count
 if($taskResult.native_roots_after){$taskResult.status='failed_absence'}
 $taskResult.admission_probes=$taskAdmissionHistory.ToArray()
 $taskResult.completed_utc=[DateTimeOffset]::UtcNow.ToString('o')
 $taskResult|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $taskProof 'result.json') -Encoding utf8NoBOM
}
$taskResult|ConvertTo-Json -Depth 12
if($taskResult.status -cne 'passed'){throw 'Focused TLA gate failed'}
