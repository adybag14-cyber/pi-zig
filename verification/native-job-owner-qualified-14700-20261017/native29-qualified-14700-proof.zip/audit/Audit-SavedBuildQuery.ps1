$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$true
$container='C:\Users\adyba\pi-zig'
$candidate=Join-Path $container 'worktrees/ignore'
$run=Join-Path $container 'evidence/runtime-job-owner-native29-gates-20261017/root-native29-identity-buildquery-20261017-184305'
$outerPath=Join-Path $container 'evidence/root-native29-identity-buildquery-20261017-184305-outer.json'
$outerAbsencePath=Join-Path $container 'evidence/root-native29-identity-buildquery-20261017-184305-outer-absence.json'
$head='14700e0b79d94996d2634f9486e7ebcfe1dbedfd'
$checks=[Collections.Generic.List[object]]::new()
function J([string]$p){Get-Content -Raw -LiteralPath $p|ConvertFrom-Json -Depth 80 -DateKind String}
function Pin([string]$p){[ordered]@{path=$p;bytes=(Get-Item -LiteralPath $p).Length;sha256=(Get-FileHash -LiteralPath $p).Hash}}
function Check([string]$n,[bool]$ok,$detail){if(!$ok){throw "Saved Native29 audit failed: $n"};$checks.Add([ordered]@{name=$n;passed=$true;detail=$detail})}
function Rows($rows,[string]$key){@($rows|ForEach-Object{([string]$_.$key).Replace('\','/')+' '+$_.sha256}|Sort-Object -CaseSensitive)}
function Same($a,$b){($a.Count -eq $b.Count -and @(Compare-Object $a $b -CaseSensitive).Count -eq 0)}
$result=J "$run\result.json";$compile=J "$run\compile.json";$metadataOwner=J "$run\metadata.json";$actual=J "$run\actual-metadata.json";$grant=J "$run\root-grant.json";$outer=J $outerPath;$outerAbsent=J $outerAbsencePath
Check 'exact BuildQuery terminal scope' ($result.status -ceq 'built_metadata_verified_pending_independent_review' -and $result.mode -ceq 'BuildQuery' -and $result.source_head -ceq $head -and $result.actual_metadata_count -eq 29 -and $result.postseal -and $result.artifact_seal -and $result.native_roots_after -eq 0 -and $null -eq $result.runtime) 'Build/query accepted only; runtime not qualified'
Check 'exact candidate clean source count' ((git -C $candidate rev-parse HEAD).Trim() -ceq $head -and @(git -C $candidate status --porcelain).Count -eq 0 -and @(git -C $candidate ls-files).Count -eq 10233) @{head=$head;source_count=10233}
Check 'saved exact grant and bounded lifetime' ($grant.authorized -is [bool] -and $grant.authorized -and $grant.scope -ceq 'ROOT-NATIVE29-BUILD-QUERY-SERIAL' -and $grant.candidate_head -ceq $head -and $grant.tracked_source_count -eq 10233 -and $grant.driver_sha256 -ceq '983C62A02BFF5ABE1E85E30871C77495990FFB33ADD709DF94B38CF3340B1374' -and ([DateTimeOffset]$grant.expires_utc-[DateTimeOffset]$grant.issued_utc).TotalSeconds -le 300) (Pin "$run\root-grant.json")
Check 'compiler terminal0' ($compile.pid -eq 40248 -and $compile.status -ceq 'passed' -and $compile.exit_code -eq 0 -and $compile.completed_utc -and $compile.timeout_seconds -eq 1320 -and $compile.working_directory -ceq $candidate) (Pin "$run\compile.json")
Check 'metadata terminal0' ($metadataOwner.pid -eq 13788 -and $metadataOwner.status -ceq 'passed' -and $metadataOwner.exit_code -eq 0 -and $metadataOwner.timeout_seconds -eq 30 -and ($metadataOwner.arguments -join '|') -ceq '--listen=-' -and $metadataOwner.completed_utc) (Pin "$run\metadata.json")
Check 'outer terminal0 exact absence' ($outer.pid -eq 8964 -and $outer.status -ceq 'passed' -and $outer.exit_code -eq 0 -and $outer.completed_utc -and $outerAbsent.pid -eq $outer.pid -and $outerAbsent.fresh_pid_present -is [bool] -and !$outerAbsent.fresh_pid_present -and $outerAbsent.terminal.pid -eq $outer.pid -and [DateTimeOffset]$outerAbsent.terminal.created_utc -eq [DateTimeOffset]$outer.created_utc -and [DateTimeOffset]$outerAbsent.terminal.completed_utc -eq [DateTimeOffset]$outer.completed_utc -and $outerAbsent.terminal.executable -ceq $outer.executable -and ($outerAbsent.terminal.arguments -join "`0") -ceq ($outer.arguments -join "`0")) @{receipt=Pin $outerPath;absence=Pin $outerAbsencePath}
$absences=@(J "$run\owner-absence.json")
Check 'two exact saved owner absences' ($absences.Count -eq 2 -and @($absences|Where-Object{!$_.absent -or @($_.current).Count}).Count -eq 0) $absences
foreach($owner in @($compile,$metadataOwner)){$matched=@($absences|Where-Object pid -EQ $owner.pid);Check "exact saved birth absence $($owner.pid)" ($matched.Count -eq 1 -and [DateTimeOffset]$matched[0].recorded_created_utc -eq [DateTimeOffset]$owner.created_utc) 'Exact UTC tick normalization; no time tolerance'}
$expectedArgs=@('build','--build-file','verification/runtime_job_owner/controls_build.zig','-Doptimize=Debug','-j1','--prefix',"$run\out",'--cache-dir',"$run\cache",'--global-cache-dir',"$run\global-cache",'--summary','all')
Check 'exact fresh build command' (($compile.arguments -join "`0") -ceq ($expectedArgs -join "`0") -and $compile.executable_sha256 -ceq '086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864') $expectedArgs
foreach($owner in @($compile,$metadataOwner)){Check "owner started within saved grant $($owner.pid)" ([DateTimeOffset]$owner.created_utc -ge [DateTimeOffset]$grant.issued_utc -and [DateTimeOffset]$owner.created_utc -le [DateTimeOffset]$grant.expires_utc) $null}
foreach($phase in 'initial-admission','compile-admission','metadata-admission'){$a=J "$run\$phase.json";Check "saved $phase" ($a.free_kib -ge 16777216 -and $a.native_roots -eq 0 -and @($a.native_candidates).Count -eq 0) $a}
Check 'saved final native zero' (@(J "$run\native-roots-final.json").Count -eq 0) (Pin "$run\native-roots-final.json")
$before=J "$run\before.json";$between=J "$run\between.json";$final=J "$run\final.json"
Check 'exact saved seal counts' (@($before.source).Count -eq 10233 -and @($before.compiler).Count -eq 19546 -and @($before.controls).Count -eq 16 -and @($before.source36).Count -eq 36 -and @($before.source45).Count -eq 45) @{source=10233;compiler=19546;controls=16;source36=36;source45=45}
foreach($group in 'source','compiler','controls','source36','source45'){
 $key=if($group -ceq 'controls'){'path'}else{'relative'}
 $left=Rows $before.$group $key;$middle=Rows $between.$group $key;$right=Rows $final.$group $key
 Check "$group full before/between/final" ((Same $left $middle) -and (Same $left $right) -and @($left|Sort-Object -Unique -CaseSensitive).Count -eq $left.Count) @{count=$left.Count;drift=0}
}
foreach($group in 'source','compiler','controls'){
 $drift=[Collections.Generic.List[string]]::new()
 foreach($row in $final.$group){if((Get-FileHash -LiteralPath $row.path).Hash -cne $row.sha256){$drift.Add($row.path)}}
 Check "$group full current file readback" ($drift.Count -eq 0) @{count=@($final.$group).Count;drift=0}
}
$authorityPath=Join-Path $container 'evidence/durable-latest89-full-inspect-53ae-tool-prehash-20261011.json';$authority=J $authorityPath
Check 'original compiler authority SHA' ((Get-FileHash -LiteralPath $authorityPath).Hash -ceq 'DEE259F171F720AB2C08E8DD473975E22C876417CD62E4F016C71A7C662794EB') (Pin $authorityPath)
$authorityRows=@($authority.inputs|ForEach-Object{$_.path.Substring($authority.root.Length+1).Replace('\','/')+' '+$_.sha256}|Sort-Object -CaseSensitive)
Check 'all19546 original compiler hashes' (@($authorityRows).Count -eq 19546 -and (Same $authorityRows (Rows $before.compiler 'relative'))) @{count=19546;drift=0}
$core=J "$candidate\verification\runtime_job_owner\packet-v15\controller36-source-map.json";$fixture=J "$candidate\verification\runtime_job_owner\packet-v15\fixture45-source-map.json";$sourceManifest=@(J "$candidate\verification\runtime_job_owner\controls\source-v14.manifest.json")
Check '36 and45 exact map rows' ((Same (Rows $core.files 'relative') (Rows $before.source36 'relative')) -and (Same (Rows $fixture.files 'relative') (Rows $before.source45 'relative')) -and $sourceManifest.Count -eq 45) @{core=36;fixture=45;source_manifest=45}
foreach($row in $sourceManifest){if((Get-FileHash -LiteralPath $row.path).Hash -cne $row.sha256){throw 'Source45 manifest readback differs'}}
Check 'all45 source-manifest hashes' $true @{count=45;drift=0}
# Parse saved inert query bytes independently; do not load or execute artifact.
$bytes=[IO.File]::ReadAllBytes("$run\metadata.stdout.bin");$position=0;$version=$null;$names=$null;$tags=[Collections.Generic.List[uint32]]::new();$utf8=[Text.UTF8Encoding]::new($false,$true)
while($position -lt $bytes.Length){
 if($bytes.Length-$position -lt 8){throw 'Truncated raw query header'}
 $tag=[BitConverter]::ToUInt32($bytes,$position);$length=[BitConverter]::ToUInt32($bytes,$position+4);$position+=8;$tags.Add($tag)
 if($length -gt 1MB -or $length -gt $bytes.Length-$position){throw 'Invalid raw query frame length'}
 if($tag -eq 0){if($null-ne$version -or $null-ne$names){throw 'Duplicate or late raw version'};$version=$utf8.GetString($bytes,$position,$length)}
 elseif($tag -eq 3){
  if($version-cne'0.16.0' -or $null-ne$names -or $length-lt8){throw 'Invalid raw metadata order'}
  $stringBytes=[BitConverter]::ToUInt32($bytes,$position);$count=[BitConverter]::ToUInt32($bytes,$position+4)
  if($count-eq0 -or $count-gt64 -or $length-ne8+8*$count+$stringBytes){throw 'Invalid raw metadata shape'}
  $start=$position+8+8*$count;$names=[Collections.Generic.List[string]]::new()
  for($i=0;$i-lt$count;$i++){$offset=[BitConverter]::ToUInt32($bytes,$position+8+4*$i);$panic=[BitConverter]::ToUInt32($bytes,$position+8+4*$count+4*$i);if($panic-ne0 -or $offset-ge$stringBytes){throw 'Invalid raw name or panic offset'};$end=$offset;while($end-lt$stringBytes -and $bytes[$start+$end]-ne0){$end++};if($end-eq$stringBytes){throw 'Raw name missing NUL'};$names.Add($utf8.GetString($bytes,$start+$offset,$end-$offset))}
 }else{throw 'Unexpected metadata-only tag'}
 $position+=$length
}
Check 'raw exact version and metadata frames only' ($position-eq$bytes.Length -and ($tags -join ',') -ceq '0,3' -and $version-ceq'0.16.0' -and $names.Count-eq29 -and @($names|Sort-Object -Unique -CaseSensitive).Count-eq29) @{bytes=$bytes.Length;tags=@($tags);version=$version;actual_count=$names.Count;run_test_sent_by_bound_driver=$false}
$declared=J "$candidate\verification\runtime_job_owner\native29_adapter\declared-tests.authority.json";$comparison=J "$run\metadata-name-comparison.json"
Check 'all29 raw ordered names match saved and declared' (($names -join "`0") -ceq ($actual.tests -join "`0") -and ($names -join "`0") -ceq ($declared.tests -join "`0") -and $actual.actual_count-eq29 -and $actual.version-ceq$version -and ($names -join "`0") -ceq ($result.metadata.tests -join "`0") -and ($names -join "`0") -ceq ($comparison.actual -join "`0") -and @($comparison.unknown).Count-eq0 -and @($comparison.missing).Count-eq0 -and !$comparison.filters_used) @{actual_count=29;missing=0;extra=0;filtered=$false}
$artBefore=J "$run\artifacts-before.json";$artBetween=J "$run\artifacts-between.json";$artFinal=J "$run\artifacts-final.json"
$roles=@('bin/runtime-job-owner-actor.exe','bin/runtime-job-owner-actor.pdb','bin/test.exe','bin/test.pdb')
Check 'four exact new artifact roles sealed before/between/final' (@($artBefore.rows).Count-eq4 -and ($artBefore.rows.relative -join "`0")-ceq($roles -join "`0") -and (Same (Rows $artBefore.rows 'relative') (Rows $artBetween.rows 'relative')) -and (Same (Rows $artBefore.rows 'relative') (Rows $artFinal.rows 'relative')) -and @($artFinal.path_drift).Count-eq0 -and @($artFinal.hash_drift).Count-eq0) $artBefore.rows
foreach($row in $artFinal.rows){Check "artifact full hash $($row.relative)" ((Get-FileHash -LiteralPath $row.path).Hash-ceq$row.sha256 -and (Get-Item -LiteralPath $row.path).Length-gt0) (Pin $row.path)}
$test=@($artBefore.rows|Where-Object relative -CEQ 'bin/test.exe')[0]
Check 'queried binary exact matched test role' ($metadataOwner.executable-ceq$test.path -and $metadataOwner.executable_sha256-ceq$test.sha256 -and $actual.binary-ceq$test.path -and $actual.binary_sha256-ceq$test.sha256 -and $result.metadata.binary_sha256-ceq$test.sha256) $test
Check 'query stderr and build stdout empty' ((Get-Item -LiteralPath "$run\metadata.stderr.log").Length-eq0 -and (Get-Item -LiteralPath "$run\compile.stdout.bin").Length-eq0) $null
Check 'actual five build steps succeeded' ([IO.File]::ReadAllText("$run\compile.stderr.log").StartsWith('Build Summary: 5/5 steps succeeded')) (Pin "$run\compile.stderr.log")
$pins=@(Get-ChildItem -LiteralPath $run -File|ForEach-Object{Pin $_.FullName})+@(Pin $outerPath;Pin $outerAbsencePath)
[ordered]@{status='independent_build_query_raw_audit_accepted';candidate_head=$head;scope='Native29 14700 exact build/query metadata only; no runtime qualification';checks=$checks;actual_metadata_names=@($names);artifact_roles=$artBefore.rows;proof_files=$pins;auditor_script=Pin $PSCommandPath;new_compiler_query_runtime_Node_CIM_RAM_process_jobs=$false;Main_or_candidate_written=$false;fresh_runtime_authorization_not_granted=$true;completed_utc=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 40|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'buildquery-raw-audit.json') -Encoding utf8NoBOM
[ordered]@{status='accepted_build_query_only';checks=$checks.Count;actual_metadata_count=29;source=10233;compiler=19546;controls=16;roles=4;receipt_sha256=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'buildquery-raw-audit.json')).Hash}|ConvertTo-Json
