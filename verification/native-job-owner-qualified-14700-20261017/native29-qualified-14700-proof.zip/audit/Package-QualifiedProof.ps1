$ErrorActionPreference='Stop'
$container='C:\Users\adyba\pi-zig'
$stage=Join-Path $PSScriptRoot 'public-staging-v2'
$output=Join-Path $PSScriptRoot 'capsule-v2'
New-Item -ItemType Directory -Path $stage -ErrorAction Stop|Out-Null
New-Item -ItemType Directory -Path $output -ErrorAction Stop|Out-Null
$members=[Collections.Generic.List[object]]::new();$privacy=[Collections.Generic.List[object]]::new()
function Pin([string]$p){[ordered]@{path=$p;bytes=(Get-Item -LiteralPath $p).Length;sha256=(Get-FileHash -LiteralPath $p).Hash}}
function J([string]$p){Get-Content -Raw -LiteralPath $p|ConvertFrom-Json -Depth 80 -DateKind String}
function Add([string]$p,[string]$name,[string]$kind='byte_exact_original'){
 if($name-match'(^|/)(cache|global-cache|out)/' -or $name-match'\.(exe|pdb|dll|obj|lib)$'){throw 'Binary/cache payload excluded'}
 if($members.name-ccontains$name){return}
 $pin=Pin $p;$members.Add([ordered]@{name=$name;source=$p;bytes=$pin.bytes;sha256=$pin.sha256;kind=$kind})
}
function Derived($data,[string]$name){$p=Join-Path $stage $name;New-Item -ItemType Directory -Path (Split-Path $p) -Force|Out-Null;$data|ConvertTo-Json -Depth 40|Set-Content -LiteralPath $p -Encoding utf8NoBOM;Add $p $name 'derived_explicitly_labeled'}
$specs=@(
 @{run='root-native29-lineage-runtime-retry-20261017-171419';siblings='runtime-job-owner-native29-runtime-preparation-452b-20261017'},
 @{run='root-native29-detached-runtime-20261017-174139';siblings='native29-detached-pipe-prospective-20261017'},
 @{run='root-native29-clockgate-runtime-20261017-181821';siblings=''},
 @{run='root-native29-identity-buildquery-20261017-184305';siblings=''},
 @{run='root-native29-identity-runtime-20261017-184718';siblings=''}
)
foreach($spec in $specs){
 $run=Join-Path $container ('evidence/runtime-job-owner-native29-gates-20261017/'+$spec.run)
 foreach($f in Get-ChildItem -LiteralPath $run -File){if($f.Name-match'process-census'){throw 'Full census requires separate privacy projection'};Add $f.FullName ('runs/'+$spec.run+'/'+$f.Name)}
 $parent=if($spec.siblings){Join-Path $container ('evidence/'+$spec.siblings)}else{Join-Path $container 'evidence'}
 foreach($suffix in '-outer.json','-outer-absence.json','-outer.stdout.bin','-outer.stderr.log','-grant.json','-fixture-grant.json','-lease.json','-previous-lease-terminal.json'){$p=Join-Path $parent ($spec.run+$suffix);if(Test-Path -LiteralPath $p){Add $p ('runs/'+$spec.run+'/'+$spec.run+$suffix)}}
}
foreach($name in 'Audit-SavedBuildQuery.ps1','buildquery-raw-audit.json','Audit-SavedRuntime.ps1','paired-raw-audit.json'){Add (Join-Path $PSScriptRoot $name) ('audit/'+$name)}
Add $PSCommandPath 'audit/Package-QualifiedProof.ps1'
foreach($packet in 'native29-detached-pipe-prospective-20261017','native29-clock-gate-prospective-20261017','native29-identity-lease-prospective-20261017'){
 foreach($f in Get-ChildItem -LiteralPath (Join-Path $container ('evidence/'+$packet)) -File){if($f.Name-like'root-native29-*'){continue};Add $f.FullName ('preparation/'+$packet+'/'+$f.Name)}
}
Add (Join-Path $container 'evidence/native29-lease-kernel-identity-diagnostic-20261017/kernel-observations.json') 'diagnostic/authorized-six-PID-later-kernel-observation.json'
Add (Join-Path $container 'evidence/native29-identity-lease-14700-independent-body-source-review-20261017.json') 'source-review/identity-lease-independent-review.json'
Add (Join-Path $container 'evidence/durable-latest89-full-inspect-53ae-tool-prehash-20261011.json') 'authority/compiler19546-original.json'
$candidate=Join-Path $container 'worktrees/ignore'
Add (Join-Path $container 'main/tools/ci/native_qualification_ci.ps1') 'owners/CI607.ps1'
Add (Join-Path $container 'main/tools/ci/Invoke-NativeTestProtocol.ps1') 'owners/Protocol39F.ps1'
Add (Join-Path $container 'evidence/jiti-current-172-terminal-cache-reuse-prepared-20261017/outer-owned-process.ps1') 'owners/outer53E5.ps1'
foreach($commit in '2956e44901802e8727cd41bef217751f883feb1d','bff2ff95d4bac7f1c2413696c3d9a9bab310b42e','cc42fc0e8ace9c0a0a7b5f0a56df9017c4871def'){$p=Join-Path $stage ($commit+'.patch.txt');git -C $candidate show --format=fuller --no-ext-diff --no-renames $commit|Set-Content -LiteralPath $p -Encoding utf8NoBOM;Add $p ('source-history/'+$commit+'.patch.txt')}
$fixture=J (Join-Path $container 'evidence/root-native29-identity-runtime-20261017-184718-fixture-grant.json')
$observationRoot=$fixture.evidence_root
$ledgers=@(Get-ChildItem -LiteralPath $observationRoot -Recurse -File|Where-Object Name -EQ 'identity-ledger.jsonl')
$owned=[Collections.Generic.HashSet[uint32]]::new()
# Explicitly owned fixture hosts/actors from their real identity events. No
# workstation process inventories are serialized into the public capsule.
foreach($file in $ledgers){foreach($line in Get-Content -LiteralPath $file.FullName){$r=$line|ConvertFrom-Json -Depth 80 -DateKind String;if($r.state-in@('actor_bound','actor_metadata_completed')){$id=if($r.kernel_pid){$r.kernel_pid}else{$r.pid};if($id){[void]$owned.Add([uint32]$id)}};if($r.state-in@('actor_exit','actor_retired','actual_live_owned_rejected_and_retired_held_handle_accepted') -and $r.identity.pid){[void]$owned.Add([uint32]$r.identity.pid)}}}
foreach($file in Get-ChildItem -LiteralPath $observationRoot -Recurse -File){
 if($file.Attributes-band[IO.FileAttributes]::ReparsePoint){throw 'Unexpected linked observation payload'}
 $relative=$file.FullName.Substring($observationRoot.Length+1).Replace('\','/')
 if($file.Name-cne'identity-ledger.jsonl'){Add $file.FullName ('observations/'+$relative);continue}
 $kept=[Collections.Generic.List[string]]::new();$total=0;$removed=0
 foreach($line in Get-Content -LiteralPath $file.FullName){$total++;$r=$line|ConvertFrom-Json -Depth 80 -DateKind String;$keep=$true
  if($r.state-ceq'native_metadata_unavailable'){$keep=($r.required_by_name -or $r.required_by_path -or $owned.Contains([uint32]$r.pid))}
  elseif($r.state-ceq'native_gone_before_probe'){$keep=$owned.Contains([uint32]$r.pid)}
  elseif($r.state-ceq'native_candidate'){$keep=($r.own_attempt -or $r.blocks -or $owned.Contains([uint32]$r.pid))}
  if($keep){$kept.Add($line)}else{$removed++}
 }
 $name='observations/'+$relative.Replace('.jsonl','.project-filtered.jsonl');$dest=Join-Path $stage $name;New-Item -ItemType Directory -Path (Split-Path $dest) -Force|Out-Null
 [IO.File]::WriteAllText($dest,([string]::Join("`n",$kept)+"`n"),[Text.UTF8Encoding]::new($false));Add $dest $name 'derived_project_only_ledger_preserving_kept_raw_lines'
 $record=[ordered]@{public_member=$name;original=Pin $file.FullName;original_rows=$total;kept_rows=$kept.Count;withheld_unrelated_rows=$removed;kept_line_bytes_unchanged=$true;filter='Only discovery rows are filtered: metadata_unavailable requires named/path relevance or actual fixture actor identity; gone_before_probe requires actual actor identity; candidate requires own-attempt/blocking/actor identity. All other owned job/control events retained.';private_original_retained_local_unchanged=$true;not_a_full_public_workstation_census=$true}
 $privacy.Add($record);Derived $record ('privacy/'+$relative.Replace('/','_')+'.derivation.json')
}
# Preserve actual causal JSON bytes (created by the real executed kernel actor).
$causal=Join-Path $fixture.working_root 'control22-stale-grant'
foreach($name in 'actual-retired-held-owner.json','actual-retired-held-lease.json','live-previous-pid-grant.json','unauthorized-grant.json'){Add (Join-Path $causal $name) ('causal-control22/'+$name)}
Derived ([ordered]@{scope='Actual Native29 14700 29/29 controls and shared primitives; source45/intake elsewhere';privacy=$privacy;no_workstation_full_process_census_payload=$true;no_EXE_PDB_cache_payload=$true;raw_protocol_seals_grants_owners_and_retained_output_payloads_byte_exact=$true;production_owner_CLI_build_and_phase_execution_NOT_qualified=$true;runtime_recovery_NOT_qualified=$true;original_negatives_retained=$true}) 'capsule-scope-and-privacy.json'
$manifest=[ordered]@{status='prepared_for_Root_intake_publication_pending';source_head='14700e0b79d94996d2634f9486e7ebcfe1dbedfd';member_count=$members.Count;members=@($members|Sort-Object name|ForEach-Object{[ordered]@{name=$_.name;bytes=$_.bytes;sha256=$_.sha256;kind=$_.kind}});privacy=$privacy;qualified_scope='Native29 actual29/29 only';production_CLI_or_phase_runtime_or_recovery_claim=$false}
$manifest|ConvertTo-Json -Depth 35|Set-Content -LiteralPath (Join-Path $output 'capsule-manifest.json') -Encoding utf8NoBOM
function WriteZip([string]$path){$stream=[IO.File]::Open($path,[IO.FileMode]::CreateNew);try{$zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true);try{foreach($r in @($members|Sort-Object name)){$entry=$zip.CreateEntry($r.name,[IO.Compression.CompressionLevel]::Optimal);$entry.LastWriteTime=[DateTimeOffset]::new(2000,1,1,0,0,0,[TimeSpan]::Zero);$entry.ExternalAttributes=0;$input=[IO.File]::OpenRead($r.source);try{$dest=$entry.Open();try{$input.CopyTo($dest)}finally{$dest.Dispose()}}finally{$input.Dispose()}}}finally{$zip.Dispose()}}finally{$stream.Dispose()}}
$path=Join-Path $output 'native29-qualified-14700-proof.zip';$second=Join-Path $PSScriptRoot 'deterministic-second.zip';WriteZip $path;WriteZip $second
if((Get-FileHash -LiteralPath $path).Hash-cne(Get-FileHash -LiteralPath $second).Hash){throw 'Deterministic ZIP differs'}
$archive=[IO.Compression.ZipFile]::OpenRead($path);try{if($archive.Entries.Count-ne$members.Count){throw 'ZIP member count mismatch'};foreach($entry in $archive.Entries){$expected=@($members|Where-Object name -CEQ $entry.FullName);if($expected.Count-ne1){throw 'ZIP unique path differs'};$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()};if($entry.Length-ne$expected[0].bytes -or $hash-cne$expected[0].sha256){throw 'Decompressed member mismatch'}}}finally{$archive.Dispose()}
foreach($r in $members){if((Get-FileHash -LiteralPath $r.source).Hash-cne$r.sha256){throw 'Original payload changed during packaging'}}
foreach($r in $privacy){if((Get-FileHash -LiteralPath $r.original.path).Hash-cne$r.original.sha256 -or (Get-Item -LiteralPath $r.original.path).Length-ne$r.original.bytes){throw 'Private original ledger drift'}}
[ordered]@{status='deterministic_two_archives_all_decompressed_members_verified';archive=Pin $path;second_archive=Pin $second;member_count=$members.Count;all_members_readback_zero_drift=$true;all_source_payloads_and_private_original_ledgers_unchanged=$true;derived_ledger_count=$privacy.Count;removed_discovery_rows=($privacy|ForEach-Object withheld_unrelated_rows|Measure-Object -Sum).Sum;no_binary_PDB_cache_or_unrelated_full_census_payload=$true;no_jobs_or_Main_writes=$true}|ConvertTo-Json -Depth 15|Set-Content -LiteralPath (Join-Path $output 'archive-verification.json') -Encoding utf8NoBOM
Get-Content -Raw -LiteralPath (Join-Path $output 'archive-verification.json')
