const std = @import("std");
pub fn build(b: *std.Build) void {
    const tests = b.addTest(.{
        .name = "test",
        .root_module = b.createModule(.{
            .root_source_file = b.path("retry.zig"),
            .target = b.standardTargetOptions(.{}),
            .optimize = b.standardOptimizeOption(.{}),
        }),
    });
    b.getInstallStep().dependOn(&b.addInstallArtifact(tests, .{}).step);
}
