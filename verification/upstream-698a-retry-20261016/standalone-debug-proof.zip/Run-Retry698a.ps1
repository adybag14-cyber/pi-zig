$ErrorActionPreference='Stop'
$taskContainer='C:\Users\adyba\pi-zig'
$taskProof=$PSScriptRoot
$taskZig=Join-Path $taskContainer 'toolchain\zig-x86_64-windows-0.16.0\zig.exe'
$taskCompiler=Split-Path $taskZig
$taskOwner=Join-Path $taskContainer 'evidence\owners\run-owned-process.ps1'
$taskInput=Join-Path $taskContainer 'main\src\ai\retry.zig'
if(Test-Path -LiteralPath (Join-Path $taskProof 'grant.json')){throw 'Refuse proof overwrite'}
function Get-TaskNativeRoots {
    @(Get-CimInstance Win32_Process -Filter "Name='zig.exe' OR Name='build.exe' OR Name='test.exe'")
}
function Get-TaskCompilerRows {
    @(Get-ChildItem -LiteralPath $taskCompiler -File -Recurse -Force | Sort-Object FullName | ForEach-Object {
        [ordered]@{relative=[IO.Path]::GetRelativePath($taskCompiler,$_.FullName);sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}
    })
}
$taskSources=@($taskInput,(Join-Path $taskProof 'build.zig'),$taskOwner,$PSCommandPath)
$taskSourceRows=@($taskSources|ForEach-Object{[ordered]@{path=$_;sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash}})
if((Get-FileHash -LiteralPath $taskOwner).Hash -cne 'B91945EF77F91388BB8792959AB29C3A49505B5381BA0994723AC0FC6E0502AB'){throw 'Owner identity mismatch'}
if((Get-FileHash -LiteralPath $taskZig).Hash -cne '086CE9D47BA42F33A514E1A6E04EB1D4A8FA1D75E0868E0213CAAD447C91E864'){throw 'Compiler identity mismatch'}
$taskBefore=Get-TaskCompilerRows
if($taskBefore.Count -ne 19546){throw 'Compiler inventory mismatch'}
$taskBefore|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $taskProof 'compiler-before.json') -Encoding utf8NoBOM
Copy-Item -LiteralPath $taskInput -Destination (Join-Path $taskProof 'retry.zig')
if((Get-FileHash -LiteralPath $taskInput).Hash -cne (Get-FileHash -LiteralPath (Join-Path $taskProof 'retry.zig')).Hash){throw 'Source copy mismatch'}
$taskOs=Get-CimInstance Win32_OperatingSystem
$taskRoots=Get-TaskNativeRoots
$taskGrant=[ordered]@{scope='Root standalone retry.zig unit tests only; no QuickJS, reference runtime, Source capture or default application qualification';upstream='698a2d23b86a5045dd54554354a5e0cb7e466795';free_kib=$taskOs.FreePhysicalMemory;minimum_kib=16777216;other_native_roots=$taskRoots.Count;compiler_files=$taskBefore.Count;source_rows=$taskSourceRows;created_utc=[DateTimeOffset]::UtcNow.ToString('o');status='admitted'}
if($taskOs.FreePhysicalMemory -lt 16777216 -or $taskRoots.Count){$taskGrant.status='admission_denied'}
$taskGrant|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $taskProof 'grant.json') -Encoding utf8NoBOM
if($taskGrant.status -cne 'admitted'){throw 'Standalone native admission denied'}
$taskResult=[ordered]@{status='running';compile=$null;runtime=$null;source_drift=@();compiler_drift=@();native_roots_after=$null}
try {
    $taskArgs=@('build','--build-file',(Join-Path $taskProof 'build.zig'),'-j1','-Doptimize=Debug','--prefix',(Join-Path $taskProof 'out'),'--cache-dir',(Join-Path $taskProof 'cache'),'--global-cache-dir',(Join-Path $taskProof 'global-cache'),'--summary','all')
    & $taskOwner -Executable $taskZig -WorkingDirectory $taskProof -Arguments $taskArgs -ReceiptBase (Join-Path $taskProof 'compile') -TimeoutSeconds 1320
    $taskResult.compile=Get-Content -LiteralPath (Join-Path $taskProof 'compile.process.json') -Raw|ConvertFrom-Json
    $taskArtifact=Join-Path $taskProof 'out\bin\test.exe'
    $taskResult.artifact_sha256=(Get-FileHash -LiteralPath $taskArtifact).Hash
    if((Get-TaskNativeRoots).Count){throw 'Native roots remain after compile'}
    & $taskOwner -Executable $taskArtifact -WorkingDirectory $taskProof -Arguments @('--seed=0') -ReceiptBase (Join-Path $taskProof 'runtime') -TimeoutSeconds 300
    $taskResult.runtime=Get-Content -LiteralPath (Join-Path $taskProof 'runtime.process.json') -Raw|ConvertFrom-Json
    $taskResult.status='passed'
} catch {
    $taskResult.status='failed';$taskResult.error=$_.Exception.Message
} finally {
    $taskAfter=Get-TaskCompilerRows
    $taskAfter|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $taskProof 'compiler-after.json') -Encoding utf8NoBOM
    $taskResult.compiler_drift=@(Compare-Object @($taskBefore|ForEach-Object{ $_.relative+' '+$_.sha256 }) @($taskAfter|ForEach-Object{ $_.relative+' '+$_.sha256 }))
    $taskResult.source_drift=@($taskSourceRows|Where-Object{(Get-FileHash -LiteralPath $_.path).Hash -cne $_.sha256})
    $taskResult.native_roots_after=(Get-TaskNativeRoots).Count
    if($taskResult.compiler_drift.Count -or $taskResult.source_drift.Count -or $taskResult.native_roots_after){$taskResult.status='failed_postcheck'}
    $taskResult.completed_utc=[DateTimeOffset]::UtcNow.ToString('o')
    $taskResult|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $taskProof 'result.json') -Encoding utf8NoBOM
}
$taskResult|ConvertTo-Json -Depth 8
if($taskResult.status -cne 'passed'){throw 'Standalone retry gate failed'}
