$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath('C:\Users\adyba\pi-zig-composition225-20261009')
$target=[IO.Path]::GetFullPath((Join-Path $root '.zig-cache\o'))
$evidence='C:\Users\adyba\pi-zig-update-evidence-20261003'
if($target -cne 'C:\Users\adyba\pi-zig-composition225-20261009\.zig-cache\o' -or !$target.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Unexpected normalized recycle target'}
foreach($path in @($root,(Join-Path $root '.zig-cache'),$target)){if((Get-Item -LiteralPath $path).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Reparse ancestor'}}
$sourceHead=(& git -C $root rev-parse HEAD).Trim()
if($sourceHead -cne '1a90ca5333f934d810f98b57382a4f3888daf97e'){throw 'Source head changed'}
if(& git -C $root status --porcelain){throw 'Source worktree dirty'}
& git -C C:/Users/adyba/pi-zig merge-base --is-ancestor $sourceHead origin/checkpoint/native-sdk-check-compaction-b06-corrected-20261014
if($LASTEXITCODE){throw 'Not published ancestor'}
$live=@(Get-CimInstance Win32_Process|Where-Object{$_.ProcessId -ne $PID -and (($_.ExecutablePath -and $_.ExecutablePath.StartsWith($root,[StringComparison]::OrdinalIgnoreCase)) -or ($_.CommandLine -and ($_.CommandLine.IndexOf($root,[StringComparison]::OrdinalIgnoreCase) -ge 0 -or $_.CommandLine.IndexOf($root.Replace('\','/'),[StringComparison]::OrdinalIgnoreCase) -ge 0)))})
if($live.Count){throw 'Active process dependency'}
$queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue($target);$files=[Collections.Generic.List[object]]::new();$bytes=[long]0
while($queue.Count){foreach($path in [IO.Directory]::EnumerateFileSystemEntries($queue.Dequeue())){$attr=[IO.File]::GetAttributes($path);if($attr -band [IO.FileAttributes]::ReparsePoint){throw 'Reparse descendant'};if($attr -band [IO.FileAttributes]::Directory){$queue.Enqueue($path)}else{$item=[IO.FileInfo]::new($path);$bytes+=$item.Length;$files.Add([ordered]@{path=$item.FullName.Substring($target.Length+1);bytes=$item.Length;written_utc=$item.LastWriteTimeUtc.ToString('o')})}}}
$proofPaths=@('checkpoint231-event-durable-integration-final-inputs.json','checkpoint225-catalog-ui-integration-final-windows-debug-20261008.json','checkpoint225-catalog-ui-integration-final-windows-debug-20261008.stderr.log','checkpoint225-catalog-ui-counter-final-windows-debug-20261008.json','checkpoint225-catalog-ui-counter-final-windows-debug-20261008.stderr.log')
$proofs=@($proofPaths|ForEach-Object{$p=Join-Path $evidence $_;if(!(Test-Path -LiteralPath $p -PathType Leaf)){throw 'Missing retained proof'};[ordered]@{path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash}})
$files|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $evidence 'platform-cache-recycled225-files-20261015.json')
$receipt=[ordered]@{status='checked_ready_for_recycle';target=$target;root=$root;source_head=$sourceHead;published_ancestor='origin/checkpoint/native-sdk-check-compaction-b06-corrected-20261014';authority='Root explicit Recycle Bin grant 20261015';bytes=$bytes;files=$files.Count;active_dependencies=0;reparse_entries=0;runtime_wrapper_cache_references=0;current_pi_junction_references=0;proofs=$proofs;checked_utc=[datetime]::UtcNow.ToString('o');checker_pid=$PID;maintenance_preserved='C:\Users\adyba\pi-zig-composition241-20261010\.zig-cache\o\f737a672497db8e244806e7a1d08781f\pi-maintenance.exe'}
$receiptPath=Join-Path $evidence 'platform-cache-recycled225-20261015.json'
$receipt|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $receiptPath
Add-Type -AssemblyName Microsoft.VisualBasic.Core
[Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($target,[Microsoft.VisualBasic.FileIO.UIOption]::OnlyErrorDialogs,[Microsoft.VisualBasic.FileIO.RecycleOption]::SendToRecycleBin,[Microsoft.VisualBasic.FileIO.UICancelOption]::ThrowException)
$receipt.status='recycle_api_completed_pending_independent_absence';$receipt.completed_utc=[datetime]::UtcNow.ToString('o')
$receipt|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $receiptPath
[pscustomobject]@{status=$receipt.status;target=$target;GiB=[math]::Round($bytes/1GB,3);files=$files.Count;receipt=$receiptPath}|ConvertTo-Json
