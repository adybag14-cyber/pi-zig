$ErrorActionPreference='Stop'
$base='C:\Users\adyba';$evidence=Join-Path $base 'pi-zig-update-evidence-20261003'
$targets=@(@{name='pi-zig-composition210-20261008';number='210';head='0fdb6e667c7920de2eaf4487303e627c01059900'},@{name='pi-zig-composition222-20261009';number='222';head='0fd59bd5e1b750b277313b4393f88848a8fb7759'},@{name='pi-zig-composition203-20261007';number='203';head='ec1dd6492b3a2ce70c422f87474cfe5a9d5ef318'})
$maintenance='C:\Users\adyba\pi-zig-composition241-20261010\.zig-cache\o\f737a672497db8e244806e7a1d08781f\pi-maintenance.exe'
Add-Type -AssemblyName Microsoft.VisualBasic.Core
foreach($selection in $targets){
 $root=[IO.Path]::GetFullPath((Join-Path $base $selection.name));$target=[IO.Path]::GetFullPath((Join-Path $root '.zig-cache\o'))
 if($target -cne ($base+'\'+$selection.name+'\.zig-cache\o') -or !$target.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Unexpected normalized exact target'}
 foreach($path in @($root,(Join-Path $root '.zig-cache'),$target)){if((Get-Item -LiteralPath $path).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Reparse ancestor'}}
 $head=(& git -C $root rev-parse HEAD).Trim();if($head -cne $selection.head){throw 'Source head drift'}
 if(& git -C $root status --porcelain){throw 'Dirty source worktree'}
 & git -C (Join-Path $base 'pi-zig') merge-base --is-ancestor $head origin/checkpoint/native-sdk-check-compaction-b06-corrected-20261014
 if($LASTEXITCODE){throw 'Not a published source ancestor'}
 $live=@(Get-CimInstance Win32_Process|Where-Object{$_.ProcessId -ne $PID -and (($_.ExecutablePath -and $_.ExecutablePath.StartsWith($root,[StringComparison]::OrdinalIgnoreCase)) -or ($_.CommandLine -and ($_.CommandLine.IndexOf($root,[StringComparison]::OrdinalIgnoreCase) -ge 0 -or $_.CommandLine.IndexOf($root.Replace('\','/'),[StringComparison]::OrdinalIgnoreCase) -ge 0)))})
 if($live.Count){throw 'Active process dependency'}
 $queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue($target);$files=[Collections.Generic.List[object]]::new();$bytes=[long]0
 while($queue.Count){foreach($path in [IO.Directory]::EnumerateFileSystemEntries($queue.Dequeue())){$attr=[IO.File]::GetAttributes($path);if($attr -band [IO.FileAttributes]::ReparsePoint){throw 'Reparse descendant'};if($attr -band [IO.FileAttributes]::Directory){$queue.Enqueue($path)}else{$item=[IO.FileInfo]::new($path);$bytes+=$item.Length;$files.Add([ordered]@{path=$item.FullName.Substring($target.Length+1);bytes=$item.Length;written_utc=$item.LastWriteTimeUtc.ToString('o')})}}}
 $proofs=@(Get-ChildItem -LiteralPath $evidence -File -Filter ("checkpoint"+$selection.number+'*.stderr.log')|Select-Object -First 3|ForEach-Object{[ordered]@{path=$_.FullName;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash}})
 if($proofs.Count -ne 3){throw 'Insufficient retained raw proofs'}
 if(!(Test-Path -LiteralPath $maintenance -PathType Leaf)){throw 'Protected maintenance tool missing'}
 $prefix='platform-cache-recycled'+$selection.number+'-20261015'
 $files|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $evidence "$prefix-files.json")
 $receipt=[ordered]@{status='checked_ready_for_recycle';target=$target;root=$root;source_head=$head;published_ancestor='origin/checkpoint/native-sdk-check-compaction-b06-corrected-20261014';authority='Root explicit next3 Recycle Bin grant 20261015';bytes=$bytes;files=$files.Count;active_dependencies=0;reparse_entries=0;runtime_wrapper_cache_references=0;current_pi_junction_references=0;proofs=$proofs;checked_utc=[datetime]::UtcNow.ToString('o');checker_pid=$PID;maintenance_preserved=$maintenance}
 $receiptPath=Join-Path $evidence "$prefix.json";$receipt|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $receiptPath
 [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($target,[Microsoft.VisualBasic.FileIO.UIOption]::OnlyErrorDialogs,[Microsoft.VisualBasic.FileIO.RecycleOption]::SendToRecycleBin,[Microsoft.VisualBasic.FileIO.UICancelOption]::ThrowException)
 $receipt.status='recycle_api_completed_pending_independent_absence';$receipt.completed_utc=[datetime]::UtcNow.ToString('o')
 $receipt|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $receiptPath
 [pscustomobject]@{status=$receipt.status;target=$target;GiB=[math]::Round($bytes/1GB,3);files=$files.Count;receipt=$receiptPath}|ConvertTo-Json
}
