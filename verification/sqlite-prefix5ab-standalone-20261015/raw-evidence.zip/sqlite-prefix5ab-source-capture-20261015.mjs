import { mkdtempSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { openNodeSqliteStorage } from '@earendil-works/pi-durable/storage/sqlite/node';
const evidence='C:/Users/adyba/pi-zig-update-evidence-20261003';
const directory=mkdtempSync(join(evidence,'sqlite-prefix5ab-source-state-20261015-'));
const path=join(directory,'prefix.sqlite');
const plain=await openNodeSqliteStorage(path),alpha=await openNodeSqliteStorage(path,{prefix:'alpha_'}),beta=await openNodeSqliteStorage(path,{prefix:'beta_'});
await alpha.commit([{type:'conversation',value:{id:1}}],{});
await beta.commit([{type:'conversation',value:{id:3}}],{});
const isolated=(await plain.conversation(1,{}))===undefined&&(await alpha.conversation(3,{}))===undefined&&(await beta.conversation(1,{}))===undefined;
await plain.close({});await alpha.close({});await beta.close({});
const again=await openNodeSqliteStorage(path,{prefix:'alpha_'}),reopened=(await again.conversation(1,{})).id;
await again.close({});
const rejected=[];
for(const prefix of ['', '1bad', 'a-b', 'sqlite_', 'SqLiTe_private', 'x;DROP']){
 try{const unexpected=await openNodeSqliteStorage(path,{prefix});await unexpected.close({});rejected.push({prefix,rejected:false})}
 catch(error){rejected.push({prefix,rejected:true,name:error.name,message:error.message})}
}
const db=new DatabaseSync(path);
const tables=db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all().map(row=>row.name);
const indexes=db.prepare("SELECT name FROM sqlite_master WHERE type='index' AND name NOT LIKE 'sqlite_%' ORDER BY name").all().map(row=>row.name);
const counts=db.prepare('SELECT (SELECT count(*) FROM conversations) AS plain,(SELECT count(*) FROM alpha_conversations) AS alpha,(SELECT count(*) FROM beta_conversations) AS beta,(SELECT version FROM alpha_durable_schema) AS alpha_version,(SELECT version FROM beta_durable_schema) AS beta_version').get();
db.close();
const result={source:'5ab7fe74c400097b386662205cd93900695b8a71',bridge:{isolated,reopened,rejected:rejected.filter(row=>row.rejected).length},counts,tables,indexes,rejected,directory};
writeFileSync(join(directory,'capture.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));
