import { openNodeSqliteStorage } from '@earendil-works/pi-durable/storage/sqlite/node';
const outcomes=[];
for(const [name,create] of [
 ['zero',()=>0],['null',()=>null],['boolean',()=>true],['array',()=>['alpha_']],['boxed',()=>new String('alpha_')],['object',()=>({})],
 ['coerced',events=>({toString(){events.push('toString');return 'alpha_'},toLowerCase(){events.push('toLowerCase');return 'alpha_'}})],
 ['throwsToString',events=>({toString(){events.push('toString');throw {raw:'toString'}}})]
]){
 const events=[],reason={raw:name},value=create(events);let result;
 try{const store=await openNodeSqliteStorage(':memory:',{prefix:value});await store.close({});result={accepted:true}}
 catch(error){result={accepted:false,name:error.name??null,message:error.message??null,raw:error===reason}}
 outcomes.push({name,events,...result});
}
for(const invalid of [false,true]){
 const events=[],reason={raw:'prefixGetter'},options={get prefix(){events.push('prefix');if(!invalid)throw reason;return ''},get busyTimeoutMs(){events.push('busyTimeoutMs');if(invalid)throw reason;return 50},get walAutoCheckpointPages(){events.push('walAutoCheckpointPages');return 0}};
 let result;try{const store=await openNodeSqliteStorage(':memory:',options);await store.close({});result={accepted:true}}catch(error){result={accepted:false,name:error.name??null,message:error.message??null,raw:error===reason}}
 outcomes.push({name:invalid?'invalidPrefixAndBusyGetter':'prefixGetter',events,...result});
}
console.log(JSON.stringify({source:'5ab7fe74c400097b386662205cd93900695b8a71',outcomes}));
