param([Parameter(Mandatory)][ValidateSet('sqlite','vmcompile','vmruntime','source')][string]$Phase,[Parameter(Mandatory)][ValidateRange(1,4)][int]$RootSlot,[string]$Attempt='first',[string]$SourceCapture='sqlite-prefix5ab-source-capture-20261015.mjs')
$ErrorActionPreference='Stop'
$taskEvidence=$PSScriptRoot
$taskRoot='C:\Users\adyba\pi-zig-platform-20261015'
$taskSource='C:\Users\adyba\pi-upstream-source-5ab7fe7-20261015'
$taskZig='C:\Users\adyba\pi-zig-toolchain-20261003\zig-x86_64-windows-0.16.0\zig.exe'
$taskNode='C:\Program Files\nodejs\node.exe'
$taskOwner=Join-Path $taskEvidence 'Invoke-OwnedEeSourceJob-20261012.ps1'
$taskName="platform-$Phase-$Attempt-20261015"
if(Test-Path -LiteralPath (Join-Path $taskEvidence "$taskName.json")){throw 'Refuse receipt replay'}
function Check-Rows($rows){
 $changes=[Collections.Generic.List[string]]::new()
 foreach($row in $rows){$path=$row.path;if(!(Test-Path -LiteralPath $path -PathType Leaf)){$changes.Add($path);continue};$stream=[IO.File]::OpenRead($path);try{$sha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()};if($sha -cne $row.sha256.ToUpperInvariant()){$changes.Add($path)}}
 @($changes)
}
function Source-Rows {
 @(git -C $taskRoot ls-files --cached --others --exclude-standard|Sort-Object -Unique|Where-Object{Test-Path -LiteralPath (Join-Path $taskRoot $_) -PathType Leaf}|ForEach-Object{[ordered]@{relative=$_;path=(Join-Path $taskRoot $_);sha256=(Get-FileHash -LiteralPath (Join-Path $taskRoot $_)).Hash}})
}
function Admit {
 $free=[long](Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory*1024
 $builds=@(Get-CimInstance Win32_Process -Filter "Name='zig.exe'"|Where-Object{$_.CommandLine -match '\sbuild\s'})
 $required=if($Phase -eq 'source'){2GB}else{16GB}
 if($free -lt $required -or $builds.Count -ge 4){throw 'Fresh resource floor/max4 admission failed'}
 [ordered]@{root_slot=$RootSlot;free_bytes=$free;required_bytes=$required;other_build_roots=$builds.Count;max_coordinated_jobs=4;native_jobs=1;test_seconds=120;host_await_ms=10000;public_activation=$false;observed_utc=[datetime]::UtcNow.ToString('o')}
}
$admission=Admit
$before=Source-Rows
if($Phase -eq 'vmruntime'){
 $compileName='platform-vmcompile-first-20261015'
 $compile=Get-Content -LiteralPath (Join-Path $taskEvidence "$compileName-posthash.json") -Raw|ConvertFrom-Json
 $compileRows=@(Get-Content -LiteralPath (Join-Path $taskEvidence "$compileName-source-before.json") -Raw|ConvertFrom-Json)
 if($compile.status -cne 'passed' -or $compile.source_drift -or $compile.tool_drift -or $compile.control_drift){throw 'VM exact compile prerequisite failed'}
 if(Compare-Object @($compileRows|ForEach-Object{"$($_.relative):$($_.sha256)"}) @($before|ForEach-Object{"$($_.relative):$($_.sha256)"})){throw 'Source changed since VM compile'}
}
$sourceRows=@();$dependencies=@();$tools=@()
$controls=@($PSCommandPath,$taskOwner)
if($Phase -eq 'source'){
 if((git -C $taskSource rev-parse HEAD).Trim() -cne '5ab7fe74c400097b386662205cd93900695b8a71'){throw 'Latest Source head changed'}
 $sourceRows=@(Get-Content -LiteralPath (Join-Path $taskEvidence 'source5ab-full-manifest-20261015.json') -Raw|ConvertFrom-Json)
 $dependencies=@(Get-Content -LiteralPath (Join-Path $taskEvidence 'durable-19cb534-reference-20261012-all-built-runtime.json') -Raw|ConvertFrom-Json)
 $tools=@(Get-Content -LiteralPath (Join-Path $taskEvidence 'root-current8a-npm-tools-before.json') -Raw|ConvertFrom-Json)
 if($sourceRows.Count -ne 1967 -or $dependencies.Count -ne 31064 -or $tools.Count -ne 1774){throw 'Full Source/tools/dependencies inventory count changed'}
 $controls+=@((Join-Path $taskEvidence 'source5ab-full-manifest-20261015.json'),(Join-Path $taskEvidence 'durable-19cb534-reference-20261012-all-built-runtime.json'),(Join-Path $taskEvidence 'root-current8a-npm-tools-before.json'),(Join-Path $taskEvidence 'source5ab-observe-20261015.mjs'),(Join-Path $taskEvidence 'source5ab-dependency-contract-audit-20261015.json'),(Join-Path $taskEvidence $SourceCapture))
}else{
 $tools=@((Get-Content -LiteralPath (Join-Path $taskEvidence 'durable-latest89-full-inspect-53ae-tool-prehash-20261011.json') -Raw|ConvertFrom-Json).inputs)
 if($tools.Count -ne 19546){throw 'Full Zig inventory count changed'}
 $controls+=(Join-Path $taskEvidence 'durable-latest89-full-inspect-53ae-tool-prehash-20261011.json')
}
if(@(Check-Rows $tools).Count -or @(Check-Rows $sourceRows).Count -or @(Check-Rows $dependencies).Count){throw 'Frozen input drift before launch'}
$controlRows=@($controls|ForEach-Object{[ordered]@{path=$_;sha256=(Get-FileHash -LiteralPath $_).Hash}})
$before|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $taskEvidence "$taskName-source-before.json") -Encoding utf8NoBOM
$controlManifest=Join-Path $taskEvidence "$taskName-controls-before.json"
$controlRows|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $controlManifest -Encoding utf8NoBOM
$admission=Admit
$admission|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $taskEvidence "$taskName-admission.json") -Encoding utf8NoBOM
if($Phase -eq 'source'){
 $executable=$taskNode;$working=$taskSource;$timeout=300
 $arguments=@('--max-old-space-size=256','--import',([Uri](Join-Path $taskEvidence 'source5ab-observe-20261015.mjs')).AbsoluteUri,(Join-Path $taskEvidence $SourceCapture))
 $environment=@{NODE_OPTIONS='';NODE_PATH='';PI_SOURCE_ORACLE_CONTROL_MANIFEST=$controlManifest}
}else{
 $executable=$taskZig;$working=$taskRoot;$timeout=if($Phase -eq 'vmruntime'){300}else{1320}
 $arguments=switch($Phase){'sqlite'{@('build','sqlite-admin','test-durable-sqlite-prefix','-Doptimize=ReleaseSafe','-j1','--test-timeout','120s','--summary','all')};'vmcompile'{@('build','build-native-durable-sqlite-prefix','sqlite-admin','test-durable-sqlite-prefix','-Doptimize=Debug','-j1','--test-timeout','120s','--summary','all')};'vmruntime'{@('build','test-native-durable-sqlite-prefix','-Doptimize=Debug','-j1','--test-timeout','120s','--summary','all')}}
 $environment=@{}
}
try{& $taskOwner -Name $taskName -Executable $executable -WorkingDirectory $working -Arguments $arguments -TimeoutSeconds $timeout -EnvironmentOverrides $environment}finally{
 $sourceDrift=@(Check-Rows $before);$toolsDrift=@(Check-Rows $tools);$originalDrift=@(Check-Rows $sourceRows);$dependencyDrift=@(Check-Rows $dependencies);$controlDrift=@(Check-Rows $controlRows)
 $after=Source-Rows;$inventoryDrift=@(Compare-Object @($before.relative) @($after.relative))
 $owner=if(Test-Path -LiteralPath (Join-Path $taskEvidence "$taskName.json")){Get-Content -LiteralPath (Join-Path $taskEvidence "$taskName.json") -Raw|ConvertFrom-Json}else{$null}
 [ordered]@{status=if($owner){$owner.status}else{'not_launched'};exit_code=if($owner){$owner.exit_code}else{$null};phase=$Phase;root_slot=$RootSlot;source=$before.Count;source_drift=$sourceDrift.Count;source_inventory_drift=$inventoryDrift.Count;tools=$tools.Count;tool_drift=$toolsDrift.Count;original=$sourceRows.Count;original_drift=$originalDrift.Count;dependencies=$dependencies.Count;dependency_drift=$dependencyDrift.Count;controls=$controlRows.Count;control_drift=$controlDrift.Count;public_activation=$false;completed_utc=[datetime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $taskEvidence "$taskName-posthash.json") -Encoding utf8NoBOM
 if($sourceDrift.Count -or $toolsDrift.Count -or $originalDrift.Count -or $dependencyDrift.Count -or $controlDrift.Count -or $inventoryDrift.Count){throw 'Exact-input posthash drift'}
}
$terminal=Get-Content -LiteralPath (Join-Path $taskEvidence "$taskName-posthash.json") -Raw|ConvertFrom-Json
$terminal|ConvertTo-Json -Depth 5
if($terminal.status -cne 'passed'){throw 'Owned job terminal failure'}




