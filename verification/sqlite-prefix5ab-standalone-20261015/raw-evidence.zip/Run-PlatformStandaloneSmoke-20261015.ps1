param([string]$Attempt='first',[string]$CompileReceipt='platform-sqlite-first-20261015-posthash.json')
$ErrorActionPreference='Stop'
$evidence=$PSScriptRoot
$root='C:\Users\adyba\pi-zig-platform-20261015'
$owner=Join-Path $evidence 'Invoke-OwnedEeSourceJob-20261012.ps1'
$compile=Get-Content -LiteralPath (Join-Path $evidence $CompileReceipt) -Raw|ConvertFrom-Json
if($compile.status -cne 'passed' -or $compile.source_drift -or $compile.tool_drift -or $compile.control_drift){throw 'Exact SQLite build prerequisite failed'}
$source=Join-Path $root 'zig-out\bin\pi-sqlite.exe'
$stage=Join-Path $evidence "platform-standalone-sqlite-$Attempt-20261015"
if(Test-Path -LiteralPath $stage){throw 'Fresh standalone stage required'}
New-Item -ItemType Directory -Path $stage|Out-Null
$exe=Join-Path $stage 'pi-sqlite.exe'
$originalHash=(Get-FileHash -LiteralPath $source).Hash
Copy-Item -LiteralPath $source -Destination $exe
if((Get-FileHash -LiteralPath $exe).Hash -cne $originalHash){throw 'Standalone copy identity mismatch'}
$bytes=[IO.File]::ReadAllBytes($exe)
$pe=[BitConverter]::ToInt32($bytes,0x3c)
if([BitConverter]::ToUInt32($bytes,$pe) -ne 0x00004550){throw 'Not a PE executable'}
$optional=$pe+24;$magic=[BitConverter]::ToUInt16($bytes,$optional)
$directory=if($magic -eq 0x20b){$optional+112}elseif($magic -eq 0x10b){$optional+96}else{throw 'Unknown PE optional header'}
$sectionCount=[BitConverter]::ToUInt16($bytes,$pe+6)
$sectionStart=$optional+[BitConverter]::ToUInt16($bytes,$pe+20)
function RvaOffset([uint32]$rva){for($i=0;$i -lt $sectionCount;$i++){$s=$sectionStart+40*$i;$virtual=[BitConverter]::ToUInt32($bytes,$s+12);$span=[Math]::Max([BitConverter]::ToUInt32($bytes,$s+8),[BitConverter]::ToUInt32($bytes,$s+16));if($rva -ge $virtual -and $rva -lt $virtual+$span){return [int]([BitConverter]::ToUInt32($bytes,$s+20)+$rva-$virtual)}};throw 'Unmapped PE RVA'}
$imports=[Collections.Generic.List[string]]::new()
$importRva=[BitConverter]::ToUInt32($bytes,$directory+8)
if($importRva){$descriptor=RvaOffset $importRva;for($i=0;$i -lt 256;$i++){$nameRva=[BitConverter]::ToUInt32($bytes,$descriptor+20*$i+12);if(!$nameRva){break};$nameStart=RvaOffset $nameRva;$end=$nameStart;while($bytes[$end]){$end++};$imports.Add([Text.Encoding]::ASCII.GetString($bytes,$nameStart,$end-$nameStart))}}
if(@($imports|Where-Object{$_ -match '(?i)sqlite'}).Count){throw 'Standalone artifact imports an external SQLite runtime; refusing launch'}
$record=[ordered]@{status='pe_imports_checked';source=$source;source_sha256=$originalHash;staged_executable=$exe;staged_sha256=(Get-FileHash -LiteralPath $exe).Hash;pe_imports=@($imports);path="$env:SystemRoot\System32;$env:SystemRoot";working_directory=$stage;sqlite_runtime_required=$false;public_activation=$false;started_utc=[datetime]::UtcNow.ToString('o')}
$receipt=Join-Path $evidence "platform-standalone-sqlite-$Attempt-20261015.json"
$record|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $receipt
try{
 foreach($action in @('init','doctor')){
  $name="platform-standalone-$action-$Attempt-20261015"
  & $owner -Name $name -Executable $exe -WorkingDirectory $stage -Arguments @('--db','standalone.sqlite',$action,'--json') -TimeoutSeconds 120 -EnvironmentOverrides @{PATH=$record.path;NODE_PATH='';NODE_OPTIONS=''}
  $terminal=Get-Content -LiteralPath (Join-Path $evidence "$name.json") -Raw|ConvertFrom-Json
  if($terminal.status -cne 'passed'){throw 'Standalone action terminal failure'}
  $value=Get-Content -LiteralPath (Join-Path $evidence "$name.stdout.log") -Raw|ConvertFrom-Json
  if($value.ok -ne $true){throw 'Standalone action unhealthy JSON'}
  $record[$action]=$value
 }
 $record.status='passed'
}finally{
 $record.completed_utc=[datetime]::UtcNow.ToString('o');$record.source_post_sha256=(Get-FileHash -LiteralPath $source).Hash;$record.staged_post_sha256=(Get-FileHash -LiteralPath $exe).Hash
 if($record.source_post_sha256 -cne $originalHash -or $record.staged_post_sha256 -cne $originalHash){$record.status='identity_drift'}
 $record|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $receipt
}
$record|ConvertTo-Json -Depth 6
if($record.status -cne 'passed'){throw 'Standalone smoke failed'}

